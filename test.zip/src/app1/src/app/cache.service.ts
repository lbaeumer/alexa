import { Injectable } from '@angular/core';
import { Selection } from './selection/selection';

@Injectable()
export class CacheService {

    cache = new Map();

    getSelection(site: string): Selection {
        const cached = this.cache.get(site);

        if (!cached) {
            return undefined;
        }

        return cached;
    }

    putSelection(site: string, value: Selection): void {

        this.cache.set(site, value);
    }
}
