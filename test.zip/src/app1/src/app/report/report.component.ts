import { Component, OnInit, isDevMode } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';

import { Report } from './report';
import { ReportService } from './report.service';
import { ConfigService } from '../config.service';
import { Config } from '../config';
import { ErrorService } from '../error.service';

@Component({
    selector: 'app-report',
    templateUrl: './report.component.html',
    styleUrls: ['./report.component.css']
})
export class ReportComponent implements OnInit {

    site: string;
    basesite: string;
    subsite: string;
    subsiteCount: number;

    baseconfig: Config;
    config: Config;

    report: Report;
    loading: boolean;
    dropDownTyp: string;

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private toastr: ToastrService,
        private errorService: ErrorService,
        private reportService: ReportService,
        private configService: ConfigService
    ) {
        this.config = new Config();
        this.baseconfig = new Config();
        this.subsiteCount = 0;
        this.report = new Report;
        this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    }

    ngOnInit() {
        // set site drop down
        this.site = this.route.snapshot.paramMap.get('site');
        this.dropDownTyp = this.site;
        if (this.site.indexOf('_') > 0) {
            this.basesite = this.site.substring(0, this.site.indexOf('_'));
            this.subsite = this.site.substring(this.site.indexOf('_') + 1);
        } else {
            this.basesite = this.site;
        }
        if (isDevMode()) { console.log('site=' + this.site + '; subsite=' + this.subsite + '; base=' + this.basesite); }

        this.loadData(this.basesite);
    }

    loadData(site: string) {
        this.loading = true;
        this.configService.getConfig(site).subscribe(
            config => {
                this.loading = false;
                this.baseconfig = config;
                if (this.baseconfig.subConfig) {
                    this.subsiteCount = Object.keys(this.baseconfig.subConfig).length;
                }
                if (this.site === this.basesite) {
                    this.config = config;
                } else {
                    if (config.subConfig[this.subsite]) {
                        this.config = config.subConfig[this.subsite];
                    } else {
                        // there is no base site, as a workaround set config
                        if (isDevMode()) { console.log('no base site'); }
                    }
                }

                // now load reports
                this.loadReports();
            },
            error => {
                this.loading = false;
                this.errorService.handleError(site, error);
            }
        );
    }

    loadReports() {
        this.loading = true;
        this.reportService.getReport(this.site).subscribe(
            report => {
                this.loading = false;
                this.report = report;
            },
            error => {
                this.loading = false;
                if (error instanceof HttpErrorResponse) {
                    this.toastr.error(error.error.text + ' (' + error.status + ')',
                        'Die Reports konnten nicht geladen werden.');
                } else {
                    this.toastr.error(error.error.text, 'Fehler aufgetreten');
                }
            }
        );
    }

    onChange() {
        if (isDevMode()) {
            console.log('redirect to ' + this.dropDownTyp
                + '/report');
        }
        this.router.navigate(['/' + this.dropDownTyp
            + '/report']);
    }
}
