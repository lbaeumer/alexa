import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Report } from './report';

import { environment } from '../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class ReportService {

    constructor(private http: HttpClient) { }

    getReport(site: string): Observable<Report> {
        return this.http.get<Report>(environment.serviceUrl + '/ws/report/' + site + '/stats.json');
    }
}
