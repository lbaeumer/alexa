export class Report {
    report1: ReportContent;
    report2: ReportContent;
    report3: ReportContent;
}

export class ReportContent {
    data: Object;
    options: Object;
    columnNames: Object;
}
