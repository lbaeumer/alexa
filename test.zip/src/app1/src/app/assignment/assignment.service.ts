import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Assignment } from './assignment';

import { environment } from '../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class AssignmentService {

    constructor(private http: HttpClient) { }

    getAssignment(site: string): Observable<Assignment> {
        return this.http.get<Assignment>(environment.serviceUrl + '/ws/report/' + site + '/assigned.json');
    }
}
