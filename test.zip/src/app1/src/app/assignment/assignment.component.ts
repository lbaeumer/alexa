import { Component, OnInit, isDevMode } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';

import { AssignmentService } from './assignment.service';
import { Assignment } from './assignment';
import { ConfigService } from '../config.service';
import { Config } from '../config';
import { ErrorService } from '../error.service';
import { LoginService } from '../login/login.service';
import { User } from '../login/user';

import { environment } from '../../environments/environment';

@Component({
    selector: 'app-assignment',
    templateUrl: './assignment.component.html',
    styleUrls: ['./assignment.component.css']
})
export class AssignmentComponent implements OnInit {

    user: User;

    site: string;
    basesite: string;
    subsite: string;
    subsiteCount: number;

    baseconfig: Config;
    config: Config;

    assignment: Assignment;

    loading: boolean;
    dropDownTyp: string;

    environment: any;

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private toastr: ToastrService,
        private errorService: ErrorService,
        private assignmentService: AssignmentService,
        private loginService: LoginService,
        private configService: ConfigService
    ) {
        this.environment = environment;
        this.config = new Config();
        this.baseconfig = new Config();
        this.subsiteCount = 0;
        this.assignment = new Assignment;
        this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    }

    ngOnInit() {
        // get login user
        this.user = this.loginService.user;
        this.loginService.loginEvent$.subscribe(
            user => {
                if (isDevMode()) { console.log('user=' + user); }
                this.user = user;
            }
        );

        // set site drop down
        this.site = this.route.snapshot.paramMap.get('site');
        this.dropDownTyp = this.site;
        if (this.site.indexOf('_') > 0) {
            this.basesite = this.site.substring(0, this.site.indexOf('_'));
            this.subsite = this.site.substring(this.site.indexOf('_') + 1);
        } else {
            this.basesite = this.site;
        }
        if (isDevMode()) { console.log('site=' + this.site + '; subsite=' + this.subsite + '; base=' + this.basesite); }

        this.loadData(this.basesite);
    }

    loadData(site: string) {
        this.loading = true;
        this.configService.getConfig(site).subscribe(
            config => {
                this.loading = false;
                this.baseconfig = config;
                if (this.baseconfig.subConfig) {
                    this.subsiteCount = Object.keys(this.baseconfig.subConfig).length;
                }
                if (this.site === this.basesite) {
                    this.config = config;
                } else {
                    if (config.subConfig[this.subsite]) {
                        this.config = config.subConfig[this.subsite];
                    } else {
                        // there is no base site, as a workaround set config
                        if (isDevMode()) { console.log('no base site'); }
                    }
                }

                // now load assignment
                this.loadAssignment();
            },
            error => {
                this.loading = false;
                this.errorService.handleError(site, error);
            }
        );
    }

    loadAssignment() {
        this.loading = true;
        this.assignmentService.getAssignment(this.site).subscribe(
            assignment => {
                this.loading = false;
                this.assignment = assignment;
            },
            error => {
                this.loading = false;
                if (error instanceof HttpErrorResponse) {
                    this.toastr.error(error.error.text + ' (' + error.status + ')',
                        'Die Zuordnung konnte nicht geladen werden.');
                } else {
                    this.toastr.error(error.error.text, 'Fehler aufgetreten');
                }
            }
        );
    }

    onChange() {
        if (isDevMode()) {
            console.log('redirect to ' + this.dropDownTyp
                + '/assignment');
        }
        this.router.navigate(['/' + this.dropDownTyp
            + '/assignment']);
    }
}
