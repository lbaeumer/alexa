import { Person } from '../person';

export class Assignment {
    assignedPersons: AssignedPerson[];
    unassignedPersons: UnassignedPerson[];
}

export class AssignedPerson {
    id: number;
    maxSize: number;
    minSize: number;
    title: string;
    additional: AdditionalProject;
    persons: Person;
}

export class AdditionalProject {
    clazz: string;
    teacher: string;
}

export class UnassignedPerson {
    selections: number[];
    name: string;
    surname: string;
    email: string;
    clazz: string;
    gender: string;
    att1: string;
    code: string;
}
