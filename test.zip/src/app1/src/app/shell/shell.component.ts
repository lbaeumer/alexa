import { Component, OnInit, isDevMode } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';

import { Config } from '../config';
import { ConfigService } from '../config.service';
import { IssueService } from '../admin/issues/issue.service';
import { Issues } from '../admin/issues/issue';
import { LoginService } from '../login/login.service';
import { User } from '../login/user';

import { environment } from '../../environments/environment';

@Component({
    selector: 'app-shell',
    templateUrl: './shell.component.html',
    styleUrls: ['./shell.component.css']
})
export class ShellComponent implements OnInit {

    page: string;
    environment: any;
    site: string;
    basesite: string;
    baseconfig: Config;
    imageUrl: string;
    user: User;
    loading: boolean;
    issues: Issues;

    constructor(
        private location: Location,
        private router: Router,
        private toastr: ToastrService,
        private configService: ConfigService,
        private issueService: IssueService,
        private loginService: LoginService
    ) {
        this.baseconfig = new Config();
        this.environment = environment;
    }

    ngOnInit() {
        this.loading = true;
        this.user = this.loginService.user;
        this.loginService.loginEvent$.subscribe(
            user => {
                if (isDevMode()) { console.log('user=' + user); }
                this.user = user;
            }
        );

        // site
        let t = this.location.path(false).substring(1);
        let remainingPath: string;
        let pos = t.indexOf('/');
        if (pos > 1) {
            if (pos < t.length - 1) {
                remainingPath = t.substring(pos + 1);
            } else {
                remainingPath = '';
            }
            t = t.substring(0, pos);
        } else {
            remainingPath = '';
        }
        pos = t.indexOf('_');

        if (isDevMode()) { console.log('remainingPath=' + remainingPath); }
        if (remainingPath.indexOf('/') > 1) {
            this.page = remainingPath.substring(0, remainingPath.indexOf('/'));
        } else {
            this.page = remainingPath;
        }
        if (pos > 1) {
            t = t.substring(0, pos);
            this.basesite = t.substring(0, pos);
        } else {
            this.basesite = t;
        }
        this.site = t;
        this.imageUrl = environment.imageUrl + '/' + this.basesite + '/logo.jpg';

        if (!this.loginService.user) {
            this.loadUser();
        } else {
            this.loadConfig(this.basesite);
        }
    }

    loadUser() {
        if (isDevMode()) { console.log('getting user'); }
        this.loginService.getUser(this.basesite).subscribe(
            user => {
                this.loading = false;
                this.user = user;
                this.loginService.loginEvent(user);
                this.loadConfig(this.basesite);
            },
            error => {
                this.loading = false;
                if (error instanceof HttpErrorResponse) {
                    if (error.status === 404) {
                        this.toastr.error(
                            'Bitte prüfen Sie die Korrektheit oder '
                            + '<a href="https://quaestio24.de/p/demo2/feedback">melden Sie das Problem</a>.',
                            'Die URL ist falsch bzw. das Projekt ' + this.site + ' existiert nicht.',
                            {
                                enableHtml: true,
                                closeButton: true,
                                disableTimeOut: true
                            });
                    } else if (error.status === 401) {
                        if (isDevMode()) {
                            console.log('you are not authenticated redirect to '
                                + this.basesite + '/login');
                        }
                        this.router.navigate(['/' + this.basesite + '/login'], { queryParams: { action: this.page } });
                    } else if (error.status === 403) {
                        if (isDevMode()) { console.log('config admin with 403'); }
                    } else {
                        this.toastr.error(error.error.text + ' (' + error.status + ')', 'Fehler aufgetreten');
                    }
                } else {
                    this.toastr.error(error.error.text, 'Fehler aufgetreten');
                }
            }
        );
    }

    loadConfig(site: string) {
        if (isDevMode()) { console.log('shell loading config ' + site); }
        this.configService.getConfig(site).subscribe(
            config => {
                this.baseconfig = config;
                this.loadIssues(site);
            },
            error => {
                if (error instanceof HttpErrorResponse) {
                    if (error.status === 404) {
                        this.toastr.error(
                            'Bitte prüfen Sie die Korrektheit oder '
                            + '<a href="https://quaestio24.de/p/demo2/feedback">melden Sie das Problem</a>.',
                            'Die URL ist falsch bzw. das Projekt ' + site + ' existiert nicht.',
                            {
                                enableHtml: true,
                                closeButton: true,
                                disableTimeOut: true
                            });
                    } else {
                        this.toastr.error(error.error.text + ' (' + error.status + ')', 'Fehler aufgetreten');
                    }
                } else {
                    this.toastr.error(error.error.text, 'Fehler aufgetreten');
                }
            }
        );
    }

    loadIssues(site: string) {
        if (isDevMode()) { console.log('shell loading issues ' + site); }
        this.issueService.getIssues(site).subscribe(
            issues => {
                this.issues = issues;
            }
        );
    }

    logout() {
        if (isDevMode()) { console.log('logout redirect to ' + this.basesite + '/login'); }
        this.loginService.logout().subscribe(
            config => {
                this.user = null;

                this.toastr.success('Abmeldung erfolgreich');
                window.location.href = environment.adminUrl + '/' + this.basesite + '/login';
            },
            error => {
                this.toastr.error('Abmeldung fehlgeschlagen');
            }
        );
    }
}
