import { Injectable, isDevMode } from '@angular/core';
import { HttpEvent, HttpRequest, HttpInterceptor, HttpHandler } from '@angular/common/http';

import { Observable, of } from 'rxjs';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        let path: string;
        path = req.url;
        if (path.match(/\/demo/g)) {
            req = req.clone({
                setHeaders: {
                    'Authorization': 'Basic bm9hdXRoL25vbmU6c2VjcmV0Cg=='
                }
            });
        }

        req = req.clone({
            withCredentials: true
        });

        return next.handle(req);
    }
}
