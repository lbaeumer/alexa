export class ConfigDesign {
    event: string;
    school: string;
    city: string;
    minSelections: number;
    maxCodeLen: number;
    minCodeLen: number;
    paginateCount: number;
    clazzes: string;

    displayTeacher: boolean;
    displayGenderRatio: boolean;
    displayRoom: boolean;
    displayCost: boolean;
    displayShift: boolean;

    txtInfoJumbotron: string;
    txtInfoInstructions: string;
    txtInfoFooter: string;

    txtSelectionHeader: string;
    txtSelectionNote: string;

    txtSelectionFormNameHeadline: string;
    txtSelectionFormCodeHeadline: string;
    txtSelectionFormNameText: string;
    txtSelectionFormCodeText: string;

    txtSelectionProjectsHeadline: string;
    txtSelectionProjectsText: string;

    txtSelectionPrioritizeHeadline: string;
    txtSelectionPrioritizeText: string;

    hidePriortize: boolean;
    lblProject: string;
    lblClass: string;
}

export class ConfigParameter {
    randomize: boolean;
    strategy: string;
    only2nd: boolean;
    skipMinimum: boolean;
    ignoreEmptyProjects: boolean;
    showSkipMinimum: boolean;
    showRandomize: boolean;
    showGreedy: boolean;
    addNonVoters: boolean;
}

export class Preferences {
    constructor() {
        this.design = new ConfigDesign();
        this.parameter = new ConfigParameter();
        this.subSites = [];
    }

    auth: boolean;
    anonymous: boolean;
    emailcc: string;
    startDate: Date;
    startDate2: Date;
    endDate: Date;
    endDate2: Date;
    eventDate: Date;
    includeStatus: boolean;
    design: ConfigDesign;
    parameter: ConfigParameter;

    subSites: string[];
}

export class Config {
    constructor() {
        this.pref = new Preferences();
    }

    state: string;
    site: string;

    pref: Preferences;
    subConfig: Map<string, Config>;
}
