import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HttpClientXsrfModule } from '@angular/common/http';
import { NgModule, ErrorHandler } from '@angular/core';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { GoogleChartsModule } from 'angular-google-charts';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { NgxEditorModule } from 'ngx-editor';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { AuthInterceptor } from './http-interceptors/auth-interceptor';
import { CacheService } from './cache.service';
import { CachingInterceptor } from './http-interceptors/caching-interceptor';
import { MyErrorHandler } from './error-handler';
import { RequestCache } from './http-interceptors/request-cache.service';

import { AdminComponent } from './admin/admin.component';
import { AdvancedComponent } from './admin/advanced/advanced.component';
import { AssignmentComponent } from './assignment/assignment.component';
import { CodeComponent } from './code/code.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { IndexComponent } from './index/index.component';
import { InitComponent } from './init/init.component';
import { IssuesComponent } from './admin/issues/issues.component';
import { LoginComponent } from './login/login.component';
import { PersonComponent } from './person/person.component';
import { PrivilegesComponent } from './admin/privileges/privileges.component';
import { ProjectDetailComponent } from './projects/project-detail/project-detail.component';
import { ProjectsComponent } from './projects/projects.component';
import { SelectionComponent } from './selection/selection.component';
import { ShellComponent } from './shell/shell.component';
import { SignupComponent } from './login/signup.component';
import { SelectionDetailComponent } from './selection/selection-detail/selection-detail.component';
import { RegisterComponent } from './login/register.component';
import { ReportComponent } from './report/report.component';

@NgModule({
    declarations: [
        AppComponent,
        AdminComponent,
        AdvancedComponent,
        AssignmentComponent,
        CodeComponent,
        FeedbackComponent,
        IndexComponent,
        InitComponent,
        IssuesComponent,
        LoginComponent,
        PersonComponent,
        PrivilegesComponent,
        ProjectsComponent,
        ProjectDetailComponent,
        RegisterComponent,
        ReportComponent,
        SelectionComponent,
        SelectionDetailComponent,
        ShellComponent,
        SignupComponent
    ],
    imports: [
        AppRoutingModule,
        BrowserAnimationsModule,
        BrowserModule,
        CommonModule,
        FormsModule,
        HttpClientModule,
        ToastrModule.forRoot({ maxOpened: 1, autoDismiss: true, preventDuplicates: true }),
        OwlDateTimeModule,
        OwlNativeDateTimeModule,
        NgxEditorModule,
        GoogleChartsModule.forRoot(),
        HttpClientXsrfModule.withOptions({
            cookieName: 'My-Xsrf-Cookie',
            headerName: 'My-Xsrf-Header',
        })
    ],
    providers: [
        { provide: ErrorHandler, useClass: MyErrorHandler },
        CacheService,
        RequestCache,
        { provide: HTTP_INTERCEPTORS, useClass: CachingInterceptor, multi: true },
        { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true }
    ],
    bootstrap: [AppComponent]
})
export class AppModule { }
