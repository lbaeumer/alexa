import { Component, OnInit, isDevMode } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';

import { SelectionService } from '../selection.service';
import { Selection } from '../selection';
import { ConfigService } from '../../config.service';
import { Config } from '../../config';
import { LoginService } from '../../login/login.service';
import { User } from '../../login/user';

@Component({
    selector: 'app-selection-detail',
    templateUrl: './selection-detail.component.html',
    styleUrls: ['./selection-detail.component.css']
})
export class SelectionDetailComponent implements OnInit {
    user: User;

    site: string;
    config: Config;
    loading: boolean;
    selection: Selection;
    select: string;

    constructor(
        private route: ActivatedRoute,
        private selectionService: SelectionService,
        private location: Location,
        private toastr: ToastrService,
        private loginService: LoginService,
        private configService: ConfigService) {
        this.config = new Config();
        this.selection = new Selection();
    }

    ngOnInit() {
        this.user = this.loginService.user;
        this.loginService.loginEvent$.subscribe(
            user => {
                if (isDevMode()) { console.log('user=' + user); }
                this.user = user;
            }
        );
        this.site = this.route.snapshot.paramMap.get('site');

        this.loadConfig(this.site);

        const id = this.route.snapshot.paramMap.get('id');
        if (isDevMode()) { console.log('id=' + id); }
        this.loading = true;
        this.selectionService.getSelection(this.site, id).subscribe(
            selection => {
                if (isDevMode()) { console.log('ok'); }
                this.loading = false;
                this.selection = selection;
                this.select = '' + selection.selections;
            },
            error => {
                if (isDevMode()) { console.log('nok'); }
                this.loading = false;
                if (error instanceof HttpErrorResponse) {
                    this.toastr.error(error.error.text + ' (' + error.status + ')', 'Fehler aufgetreten');
                } else {
                    this.toastr.error(error.error.text, 'Fehler aufgetreten');
                }
            }
        );
    }

    loadConfig(site: string) {
        this.configService.getConfig(this.site).subscribe(
            config => {
                this.config = config;
            },
            error => {
            }
        );
    }

    submit() {

        if (isDevMode()) { console.log('submit'); }
        try {
            this.selection.selections = JSON.parse('[' + this.select + ']');

            this.loading = true;
            this.selectionService.updateSelection(this.site, this.selection).subscribe(
                selection => {
                    this.loading = false;
                    this.location.back();
                },
                error => {
                    this.loading = false;
                    this.select = '' + this.selection.selections;
                    if (error instanceof HttpErrorResponse) {
                        this.toastr.error(error.error.text + ' (' + error.status + ')', 'Fehler aufgetreten');
                    } else {
                        this.toastr.error(error.error.text, 'Fehler aufgetreten');
                    }
                }
            );
        } catch (e) {
            this.toastr.error('Ungültiger Wert');
        }
    }
}
