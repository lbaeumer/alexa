import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Selection } from './selection';

import { environment } from '../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class SelectionService {

    constructor(private http: HttpClient) { }

    getSelections(site: string): Observable<Selection[]> {
        return this.http.get<Selection[]>(environment.serviceUrl + '/ws/selection/' + site + '/list');
    }

    getSelection(site: string, id: string): Observable<Selection> {
        return this.http.get<Selection>(environment.serviceUrl + '/ws/selection/' + site + '/' + id);
    }

    updateSelection(site: string, selection: Selection): Observable<Selection> {
        return this.http.post<Selection>(environment.serviceUrl + '/ws/selection/' + site + '/update',
            selection);
    }

    addSelection(site: string, selection: Selection, force: boolean): Observable<Selection> {
        return this.http.post<Selection>(environment.serviceUrl + '/ws/selection/' + site + '/insert'
            + (force ? '/force' : ''),
            selection);
    }

    deleteSelection(site: string, id: string): Observable<Selection> {
        return this.http.post<Selection>(environment.serviceUrl + '/ws/selection/' + site + '/delete',
            id);
    }
}
