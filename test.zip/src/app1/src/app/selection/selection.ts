import { Person } from '../person';

export class Selection {
    constructor() {
        this.person = new Person();
    }

    id: string;
    selections: number[];
    person: Person;
    addAfterAssignment: boolean;

    created: string;
}

export class NewSelection {
    code: string;
    selection: string;
}
