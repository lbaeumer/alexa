import { Component, OnInit, isDevMode } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';

import { SelectionService } from './selection.service';
import { Selection, NewSelection } from './selection';
import { ConfigService } from '../config.service';
import { Config } from '../config';
import { ErrorService } from '../error.service';
import { LoginService } from '../login/login.service';
import { User } from '../login/user';

import { environment } from '../../environments/environment';

@Component({
    selector: 'app-selection',
    templateUrl: './selection.component.html',
    styleUrls: ['./selection.component.css']
})
export class SelectionComponent implements OnInit {

    user: User;

    site: string;
    basesite: string;
    subsite: string;
    subsiteCount: number;

    baseconfig: Config;
    config: Config;

    selections: Selection[];
    newSelections: NewSelection[];
    loading: boolean;
    dropDownTyp: string;

    environment: any;

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private toastr: ToastrService,
        private errorService: ErrorService,
        private selectionService: SelectionService,
        private loginService: LoginService,
        private configService: ConfigService
    ) {
        this.environment = environment;
        this.config = new Config();
        this.baseconfig = new Config();
        this.subsiteCount = 0;
        this.router.routeReuseStrategy.shouldReuseRoute = () => false;
        this.newSelections = [];
    }

    ngOnInit() {
        // get login user
        this.user = this.loginService.user;
        this.loginService.loginEvent$.subscribe(
            user => {
                if (isDevMode()) { console.log('user=' + user); }
                this.user = user;
            }
        );

        // set site drop down
        this.site = this.route.snapshot.paramMap.get('site');
        this.dropDownTyp = this.site;
        if (this.site.indexOf('_') > 0) {
            this.basesite = this.site.substring(0, this.site.indexOf('_'));
            this.subsite = this.site.substring(this.site.indexOf('_') + 1);
        } else {
            this.basesite = this.site;
        }
        if (isDevMode()) { console.log('site=' + this.site + '; subsite=' + this.subsite + '; base=' + this.basesite); }

        this.loadData(this.basesite);
    }

    loadData(site: string) {
        this.loading = true;
        this.configService.getConfig(site).subscribe(
            config => {
                this.loading = false;
                this.baseconfig = config;
                if (this.baseconfig.subConfig) {
                    this.subsiteCount = Object.keys(this.baseconfig.subConfig).length;
                }
                if (this.site === this.basesite) {
                    this.config = config;
                } else {
                    if (config.subConfig[this.subsite]) {
                        this.config = config.subConfig[this.subsite];
                    } else {
                        // there is no base site, as a workaround set config
                        if (isDevMode()) { console.log('no base site'); }
                    }
                }

                // now load selections
                this.loadSelections();
            },
            error => {
                this.loading = false;
                this.errorService.handleError(site, error);
            }
        );
    }

    loadSelections() {
        this.loading = true;
        this.selectionService.getSelections(this.site).subscribe(
            selections => {
                this.loading = false;
                this.selections = selections;
            },
            error => {
                this.loading = false;
                if (error instanceof HttpErrorResponse) {
                    this.toastr.error(error.error.text + ' (' + error.status + ')',
                        'Die Wahlen konnten nicht geladen werden.');
                } else {
                    this.toastr.error(error.error.text, 'Fehler aufgetreten');
                }
            }
        );
    }

    onChange() {
        if (isDevMode()) {
            console.log('redirect to ' + this.dropDownTyp
                + '/selection');
        }
        this.router.navigate(['/' + this.dropDownTyp
            + '/selection']);
    }

    addSelection() {
        if (isDevMode()) { console.log('add selection'); }
        this.newSelections.push(new NewSelection);
    }

    saveSelection(i: number) {
        if (isDevMode()) { console.log('saving entry ' + i + ';' + JSON.stringify(this.newSelections[i])); }
        const select: Selection = new Selection;
        select.person.code = this.newSelections[i].code;

        try {
            select.selections = JSON.parse('[' + this.newSelections[i].selection + ']');
            if (isDevMode()) { console.log('saving entry ' + JSON.stringify(select)); }
            this.selectionService.addSelection(this.site, select, true).subscribe(
                selection => {
                    if (isDevMode()) { console.log('add ok'); }
                    this.selections.push(selection);
                    this.newSelections.splice(i, 1);
                },
                error => {
                    if (isDevMode()) { console.log('upload ok'); }
                    this.toastr.error(error.error.text + ' (' + error.status + ')', 'Fehler aufgetreten');
                }
            );
        } catch (e) {
            if (isDevMode()) { console.log('saving failed ' + e); }
            this.toastr.error('Die Wahl ' + this.newSelections[i].selection + ' ist ungültig');
        }
    }

    deleteSelection(i: number) {
        if (isDevMode()) { console.log('delete codes' + JSON.stringify(this.selections[i])); }
        if (confirm('Möchten Sie die Wahl ' + this.selections[i].id + ' wirklich löschen?') === true) {
            this.selectionService.deleteSelection(this.site, this.selections[i].id).subscribe(
                selection => {
                    if (isDevMode()) { console.log('delete ok'); }
                    this.selections.splice(i, 1);
                    this.toastr.success('Code gelöscht.');
                },
                error => {
                    if (isDevMode()) { console.log('delete failed'); }
                    this.toastr.error(error.error.text + ' (' + error.status + ')', 'Fehler aufgetreten');
                }
            );
        }
    }
}
