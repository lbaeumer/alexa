import { Component, OnInit, isDevMode } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';

import { RequestCache } from '../../http-interceptors/request-cache.service';

import { ProjectService } from '../project.service';
import { Project } from '../project';
import { ConfigService } from '../../config.service';
import { Config } from '../../config';
import { ErrorService } from '../../error.service';
import { LoginService } from '../../login/login.service';
import { User } from '../../login/user';

@Component({
    selector: 'app-project-detail',
    templateUrl: './project-detail.component.html',
    styleUrls: ['./project-detail.component.css']
})
export class ProjectDetailComponent implements OnInit {

    user: User;

    site: string;
    config: Config;

    id: string;
    modus: string;
    loading: boolean;
    project: Project;

    constructor(
        private location: Location,
        private requestCache: RequestCache,
        private route: ActivatedRoute,
        private toastr: ToastrService,
        private errorService: ErrorService,
        private projectService: ProjectService,
        private loginService: LoginService,
        private configService: ConfigService
    ) {
        this.config = new Config();
        this.project = new Project();
    }

    ngOnInit() {
        this.site = this.route.snapshot.paramMap.get('site');

        // get login user
        this.user = this.loginService.user;
        this.loginService.loginEvent$.subscribe(
            user => {
                if (isDevMode()) { console.log('user=' + user); }
                this.user = user;
            }
        );

        this.id = this.route.snapshot.paramMap.get('id');
        if (this.id !== 'create') {
            this.modus = 'edit';
        } else {
            this.modus = 'create';
        }

        this.loadData(this.site);
    }

    loadData(site: string) {
        this.loading = true;
        this.configService.getConfig(site).subscribe(
            config => {
                this.loading = false;
                this.config = config;

                // now load project details
                this.loadProjectDetails();
            },
            error => {
                this.loading = false;
                this.errorService.handleError(this.site, error);
            }
        );
    }

    loadProjectDetails() {
        if (isDevMode()) { console.log('id=' + this.id); }
        if (this.modus === 'create') {
            this.project.maxSize = 20;
            this.project.minSize = 0;
            this.project.details.description = ' ';
        } else {

            this.loading = true;
            this.projectService.getProject(this.site, this.id).subscribe(
                project => {
                    this.loading = false;
                    this.project = project;
                },
                error => {
                    this.loading = false;
                    if (error instanceof HttpErrorResponse) {
                        this.toastr.error(error.statusText + ' (' + error.status + ')', 'Fehler aufgetreten');
                    } else {
                        this.toastr.error(error.error.text, 'Fehler aufgetreten');
                    }
                }
            );
        }
    }

    deleteItem(project: Project) {
        if (isDevMode()) { console.log('delete id'); }

        if (confirm('Möchten Sie das Projekt \'' + project.title + '\' wirklich löschen?') === true) {
            this.loading = true;

            this.projectService.deleteProject(this.site, project.id).subscribe(
                result => {
                    this.loading = false;
                    this.requestCache.clearCacheByPattern('project/' + this.site + '/' + project.id);
                    this.requestCache.clearCacheByPattern('project/' + this.site + '/nocache/list');
                    this.location.back();
                },
                error => {
                    this.loading = false;
                    if (error instanceof HttpErrorResponse) {
                        this.toastr.error(error.statusText + ' (' + error.status + ')',
                            'Fehler aufgetreten');
                    } else {
                        this.toastr.error(error.error.text, 'Fehler aufgetreten');
                    }
                }
            );
        }
    }

    update() {
        this.loading = true;

        this.project.maxGenderRate = 100;
        if (isDevMode()) { console.log('submit'); }
        this.projectService.updateProject(this.site, this.project).subscribe(
            project => {
                this.requestCache.clearCacheByPattern('project/' + this.site + '/' + this.project.id);
                this.requestCache.clearCacheByPattern('project/' + this.site + '/nocache/list');
                this.location.back();
            },
            error => {
                this.loading = false;
                if (error instanceof HttpErrorResponse) {
                    this.toastr.error(error.statusText + ' (' + error.status + ')', 'Fehler aufgetreten');
                } else {
                    this.toastr.error(error.error.text, 'Fehler aufgetreten');
                }
            }
        );
    }

    add() {
        this.loading = true;

        this.project.maxGenderRate = 100;
        if (isDevMode()) { console.log('submit'); }
        this.projectService.addProject(this.site, this.project).subscribe(
            project => {
                this.requestCache.clearCacheByPattern('project/' + this.site + '/' + this.project.id);
                this.requestCache.clearCacheByPattern('project/' + this.site + '/nocache/list');
                this.location.back();
            },
            error => {
                this.loading = false;
                if (error instanceof HttpErrorResponse) {
                    this.toastr.error(error.statusText + ' (' + error.status + ')', 'Fehler aufgetreten');
                } else {
                    this.toastr.error(error.error.text, 'Fehler aufgetreten');
                }
            }
        );
    }
}
