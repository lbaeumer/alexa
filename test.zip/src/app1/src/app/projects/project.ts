export class ProjectAdditional {
    clazz: string;
    teacher: string;
    shift: string;
    room: string;
    costs: string;
}

export class ProjectDetails {
    description: string;
}
export class Project {
    constructor() {
        this.details = new ProjectDetails;
        this.additional = new ProjectAdditional;
    }

    id: string;
    title: string;
    additional: ProjectAdditional;
    details: ProjectDetails;
    maxSize: number;
    minSize: number;
    maxGenderRate: number;
}

export class Projects {
    projects: Project[];
}
