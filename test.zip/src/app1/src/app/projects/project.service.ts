import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Projects, Project } from './project';

import { environment } from '../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class ProjectService {

    constructor(private http: HttpClient) { }

    getProjects(site: string): Observable<Projects> {
        return this.http.get<Projects>(environment.serviceUrl + '/ws/project/' + site + '/nocache/list');
    }

    getProject(site: string, id): Observable<Project> {
        return this.http.get<Project>(environment.serviceUrl + '/ws/project/' + site + '/' + id);
    }

    updateProject(site: string, project: Project): Observable<Project> {
        return this.http.post<Project>(environment.serviceUrl + '/ws/project/' + site + '/update',
            project);
    }

    addProject(site: string, project: Project): Observable<Project> {
        return this.http.post<Project>(environment.serviceUrl + '/ws/project/' + site + '/insert',
            project);
    }

    deleteProject(site: string, id: string): Observable<Project> {
        return this.http.post<Project>(environment.serviceUrl + '/ws/project/' + site + '/delete',
            id);
    }

    deleteProjects(site: string): Observable<Projects> {
        return this.http.post<Projects>(environment.serviceUrl + '/ws/project/' + site + '/deleteall',
            null);
    }

    fixProjects(site: string): Observable<string> {
        return this.http.post<string>(environment.serviceUrl + '/ws/project/' + site + '/fixnumbers',
            null);
    }

    uploadProjects(site: string, file): Observable<Projects> {
        return this.http.post<Projects>(environment.serviceUrl + '/ws/upload-project/' + site, file);
    }
}
