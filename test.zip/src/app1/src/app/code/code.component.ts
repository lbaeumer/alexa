import { Component, OnInit, isDevMode } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';

import { CodeService } from './code.service';
import { Code } from './code';
import { ConfigService } from '../config.service';
import { Config } from '../config';
import { ErrorService } from '../error.service';
import { LoginService } from '../login/login.service';
import { User } from '../login/user';

@Component({
    selector: 'app-code',
    templateUrl: './code.component.html',
    styleUrls: ['./code.component.css']
})
export class CodeComponent implements OnInit {

    user: User;

    site: string;
    basesite: string;
    subsite: string;
    subsiteCount: number;

    baseconfig: Config;
    config: Config;

    codes: Code[];
    newCodes: Code[];
    loading: boolean;
    progressing: boolean;
    dropDownTyp: string;

    fileToUpload: File = null;

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private toastr: ToastrService,
        private errorService: ErrorService,
        private codeService: CodeService,
        private loginService: LoginService,
        private configService: ConfigService
    ) {
        this.config = new Config();
        this.baseconfig = new Config();
        this.subsiteCount = 0;
        this.router.routeReuseStrategy.shouldReuseRoute = () => false;
        this.newCodes = [];
    }

    ngOnInit() {
        // get login user
        this.user = this.loginService.user;
        this.loginService.loginEvent$.subscribe(
            user => {
                if (isDevMode()) { console.log('user=' + user); }
                this.user = user;
            }
        );

        // set site drop down
        this.site = this.route.snapshot.paramMap.get('site');
        this.dropDownTyp = this.site;
        if (this.site.indexOf('_') > 0) {
            this.basesite = this.site.substring(0, this.site.indexOf('_'));
            this.subsite = this.site.substring(this.site.indexOf('_') + 1);
        } else {
            this.basesite = this.site;
        }
        if (isDevMode()) { console.log('site=' + this.site + '; subsite=' + this.subsite + '; base=' + this.basesite); }

        this.loadData(this.basesite);
    }

    loadData(site: string) {
        this.loading = true;
        this.configService.getConfig(site).subscribe(
            config => {
                this.loading = false;
                this.baseconfig = config;
                if (this.baseconfig.subConfig) {
                    this.subsiteCount = Object.keys(this.baseconfig.subConfig).length;
                }
                if (this.site === this.basesite) {
                    this.config = config;
                } else {
                    if (config.subConfig[this.subsite]) {
                        this.config = config.subConfig[this.subsite];
                    } else {
                        // there is no base site, as a workaround set config
                        if (isDevMode()) { console.log('no base site'); }
                    }
                }

                // now load codes
                this.loadCodes();
            },
            error => {
                this.loading = false;
                this.errorService.handleError(site, error);
            }
        );
    }

    loadCodes() {
        this.loading = true;
        this.codeService.getCodes(this.site).subscribe(
            codes => {
                this.loading = false;
                this.codes = codes;
            },
            error => {
                this.loading = false;
                if (error instanceof HttpErrorResponse) {
                    this.toastr.error(error.error.text + ' (' + error.status + ')',
                        'Die Codes konnten nicht geladen werden.');
                } else {
                    this.toastr.error(error.error.text, 'Fehler aufgetreten');
                }
            }
        );
    }

    onChange() {
        if (isDevMode()) {
            console.log('redirect to ' + this.dropDownTyp
                + '/code');
        }
        this.router.navigate(['/' + this.dropDownTyp
            + '/code']);
    }

    addCode() {
        if (isDevMode()) { console.log('add code'); }
        this.newCodes.push(new Code);
    }

    saveCode(i: number) {
        if (isDevMode()) { console.log('save codes' + i); }
        this.codeService.addCode(this.site, this.newCodes[i]).subscribe(
            codes => {
                if (isDevMode()) { console.log('add ok'); }
                this.codes = codes;
                this.newCodes.splice(i, 1);
            },
            error => {
                if (isDevMode()) { console.log('upload ok'); }
                this.toastr.error(error.error.text + ' (' + error.status + ')', 'Fehler aufgetreten');
            }
        );
    }

    deleteCode(i: number) {
        if (isDevMode()) { console.log('delete codes' + JSON.stringify(this.codes[i])); }
        if (confirm('Möchten Sie den Code ' + this.codes[i].code + ' wirklich löschen?') === true) {
            this.codeService.deleteCode(this.site, this.codes[i]).subscribe(
                codes => {
                    if (isDevMode()) { console.log('delete ok'); }
                    this.codes = codes;
                    this.toastr.success('Code gelöscht.');
                },
                error => {
                    if (isDevMode()) { console.log('delete failed'); }
                    this.toastr.error(error.error.text + ' (' + error.status + ')', 'Fehler aufgetreten');
                }
            );
        }
    }

    handleFileInput(files: FileList) {
        if (isDevMode()) { console.log('onSuccessUpload(' + files); }
        this.progressing = true;
        this.codeService.uploadCodes(this.site, files.item(0)).subscribe(
            codeStats => {
                this.progressing = false;
                if (isDevMode()) { console.log('upload ok ' + codeStats); }
                if (codeStats.codes.length > 0) {
                    this.codes = codeStats.codes;
                }
                this.toastr.success('Es wurden ' + codeStats.addedCodes + ' Codes hinzugefügt'
                    + (codeStats.removedCodes > 0 ? ' und ' + codeStats.removedCodes + ' Codes entfernt.' : '.')
                );
            },
            error => {
                this.progressing = false;
                if (isDevMode()) { console.log('upload ok'); }
                this.toastr.error(error.error.text + ' (' + error.status + ')', 'Fehler aufgetreten');
            }
        );
    }
}
