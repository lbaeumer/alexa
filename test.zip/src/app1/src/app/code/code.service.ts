import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Code, CodeStats } from './code';

import { environment } from '../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class CodeService {

    constructor(private http: HttpClient) { }

    getCodes(site: string): Observable<Code[]> {
        return this.http.get<Code[]>(environment.serviceUrl + '/ws/code/' + site + '/list');
    }

    uploadCodes(site: string, file): Observable<CodeStats> {
        return this.http.post<CodeStats>(environment.serviceUrl + '/ws/upload-code/' + site, file);
    }

    addCode(site: string, code: Code): Observable<Code[]> {
        return this.http.post<Code[]>(environment.serviceUrl + '/ws/code/' + site + '/add', code);
    }

    deleteCode(site: string, code: Code): Observable<Code[]> {
        return this.http.post<Code[]>(environment.serviceUrl + '/ws/code/' + site + '/delete', code);
    }
}
