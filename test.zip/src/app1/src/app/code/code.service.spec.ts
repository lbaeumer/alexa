import { TestBed } from '@angular/core/testing';

import { CodeService } from './code.service';

describe('CodeService', () => {
    beforeEach(() => TestBed.configureTestingModule({}));

    it('should be created', () => {
        const service: CodeService = TestBed.inject(CodeService);
        expect(service).toBeTruthy();
    });
});
