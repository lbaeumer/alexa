export class Code {
    code: string;
    clazz: string;
}

export class CodeStats {
    addedCodes: number;
    removedCodes: number;
    codes: Code[];
}
