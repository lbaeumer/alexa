import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Preferences } from '../config';

import { environment } from '../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class AdminService {

    constructor(private http: HttpClient) { }

    getPreferences(site: string): Observable<Preferences> {
        return this.http.get<Preferences>(environment.serviceUrl + '/ws/preference/' + site + '/get');
    }

    updatePreferences(site: string, prefs: Preferences): Observable<Preferences> {
        return this.http.post<Preferences>(environment.serviceUrl + '/ws/preference/' + site + '/update', prefs);
    }

    updatePreferencesAdvanced(site: string, prefs: Preferences): Observable<Preferences> {
        return this.http.post<Preferences>(environment.serviceUrl + '/ws/preference/' + site + '/update/advanced', prefs);
    }

    uploadProgramPackage(site: string, file): Observable<String> {
        return this.http.post<String>(environment.serviceUrl + '/ws/upload-projectpackage/' + site, file);
    }
}
