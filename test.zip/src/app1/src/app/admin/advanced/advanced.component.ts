import { Component, OnInit, isDevMode } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';

import { AdminService } from '../admin.service';
import { ConfigService } from '../../config.service';
import { Config, Preferences } from '../../config';
import { ErrorService } from '../../error.service';
import { LoginService } from '../../login/login.service';
import { ProjectService } from '../../projects/project.service';
import { User } from '../../login/user';

import { environment } from '../../../environments/environment';

@Component({
    selector: 'app-advanced',
    templateUrl: './advanced.component.html',
    styleUrls: ['./advanced.component.css']
})
export class AdvancedComponent implements OnInit {

    user: User;

    site: string;
    basesite: string;
    subsite: string;
    subsiteCount: number;

    baseconfig: Config;
    config: Config;
    pref: Preferences;

    hasSubprojects: boolean;
    isSubproject: boolean;

    loading: boolean;
    progress: boolean;
    progressing: boolean;
    dropDownTyp: string;

    environment: any;

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private toastr: ToastrService,
        private errorService: ErrorService,
        private adminService: AdminService,
        private projectService: ProjectService,
        private loginService: LoginService,
        private configService: ConfigService
    ) {
        this.environment = environment;
        this.config = new Config();
        this.baseconfig = new Config();
        this.subsiteCount = 0;
        this.pref = new Preferences();
        this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    }

    ngOnInit() {
        // get login user
        this.user = this.loginService.user;
        this.loginService.loginEvent$.subscribe(
            user => {
                if (isDevMode()) { console.log('user=' + user); }
                this.user = user;
            }
        );

        // set site drop down
        this.site = this.route.snapshot.paramMap.get('site');
        this.dropDownTyp = this.site;
        if (this.site.indexOf('_') > 0) {
            this.basesite = this.site.substring(0, this.site.indexOf('_'));
            this.subsite = this.site.substring(this.site.indexOf('_') + 1);
        } else {
            this.basesite = this.site;
        }
        if (isDevMode()) { console.log('site=' + this.site + '; subsite=' + this.subsite + '; base=' + this.basesite); }

        this.loadData(this.basesite);
    }

    loadData(site: string) {
        this.loading = true;
        this.configService.getConfig(site).subscribe(
            config => {
                this.loading = false;
                this.baseconfig = config;
                if (this.baseconfig.subConfig) {
                    this.subsiteCount = Object.keys(this.baseconfig.subConfig).length;
                }
                if (this.site === this.basesite) {
                    this.config = config;
                } else {
                    if (config.subConfig[this.subsite]) {
                        this.config = config.subConfig[this.subsite];
                    } else {
                        // there is no base site, as a workaround set config
                        if (isDevMode()) { console.log('no base site'); }
                    }
                }

                // now load preferences
                this.loadPreferences(this.site);
            },
            error => {
                this.loading = false;
                this.errorService.handleError(site, error);
            }
        );
    }

    loadPreferences(site: string) {
        this.loading = true;
        this.adminService.getPreferences(site).subscribe(
            pref => {
                this.loading = false;
                this.pref = pref;

                if (pref.subSites) {
                    this.hasSubprojects = (Object.keys(pref.subSites).length > 0);
                }
                if (site.indexOf('_') > 0) {
                    this.isSubproject = true;
                }
            },
            error => {
                this.loading = false;
                if (error instanceof HttpErrorResponse) {
                    if (error.status === 401 || error.status === 404) {
                        if (isDevMode()) { console.log('you are not authenticated, so what'); }
                    } else {
                        this.toastr.error(error.error.text + ' (' + error.status + ')', 'Fehler aufgetreten');
                    }
                } else {
                    this.toastr.error(error.error.text, 'Fehler aufgetreten');
                }
            }
        );
    }

    onChange() {
        if (isDevMode()) {
            console.log('redirect to ' + this.dropDownTyp
                + '/advanced');
        }
        this.router.navigate(['/' + this.dropDownTyp
            + '/advanced']);
    }

    updatePreferences() {
        if (isDevMode()) { console.log('updatePreferencesAdvanced'); }
        this.progress = true;
        this.adminService.updatePreferencesAdvanced(this.site, this.pref).subscribe(
            pref => {
                this.progress = false;
                this.pref = pref;
                this.toastr.success('Ok');

            },
            error => {
                this.progress = false;
                if (error instanceof HttpErrorResponse) {
                    this.toastr.error(error.error.text + ' (' + error.status + ')', 'Fehler aufgetreten');
                } else {
                    this.toastr.error(error.error.text, 'Fehler aufgetreten');
                }
            }
        );
    }

    handleFileInput(files: FileList) {
        if (isDevMode()) { console.log('onSuccessUpload(' + files); }
        this.progressing = true;
        this.adminService.uploadProgramPackage(this.site, files.item(0)).subscribe(
            result => {
                this.progressing = false;
                this.toastr.success('Das Programmpaket wurde importiert.' + JSON.stringify(result));
            },
            error => {
                this.progressing = false;
                this.toastr.error(error.statusText + ' (' + error.status + ')', 'Fehler aufgetreten');
            }
        );
    }

    deleteAllProjects() {
        if (isDevMode()) { console.log('submit'); }
        if (confirm('Möchten Sie alle Projekte löschen?') === true) {
            this.progress = true;
            this.projectService.deleteProjects(this.site).subscribe(
                projects => {
                    this.progress = false;
                    this.toastr.success('Die Projekte wurden gelöscht.');
                },
                error => {
                    this.progress = false;
                    this.toastr.error(error.statusText + ' (' + error.status + ')', 'Fehler aufgetreten');
                }
            );
        }
    }

    fixProjects() {
        if (isDevMode()) { console.log('submit'); }
        if (confirm('Möchten Sie die ProjektIDs korrigieren? Dies sollte niemals während oder nach einer Wahl erfolgen') === true) {
            this.progress = true;
            this.projectService.fixProjects(this.site).subscribe(
                projects => {
                    this.progress = false;
                    this.toastr.success('Die ProjektIDs wurden korrigiert.');
                },
                error => {
                    this.progress = false;
                    this.toastr.error(error.statusText + ' (' + error.status + ')', 'Fehler aufgetreten');
                }
            );
        }
    }
}
