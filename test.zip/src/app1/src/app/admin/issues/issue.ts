export class Issue {
    message: string;
    severity: string;
    description: string;
}

export class Issues {
    maxSeverity: string;
    count: number;
    issues: Issue[];
    subIssues: Map<string, Issue[]>;
}
