import { Component, OnInit, isDevMode } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';

import { ConfigService } from '../../config.service';
import { Config } from '../../config';
import { ErrorService } from '../../error.service';
import { IssueService } from './issue.service';
import { Issues } from './issue';

@Component({
    selector: 'app-issues',
    templateUrl: './issues.component.html',
    styleUrls: ['./issues.component.css']
})
export class IssuesComponent implements OnInit {

    site: string;

    issues: Issues;
    loading: boolean;
    config: Config;
    subsites: string[];

    constructor(
        private route: ActivatedRoute,
        private toastr: ToastrService,
        private errorService: ErrorService,
        private configService: ConfigService,
        private issueService: IssueService
    ) {
        this.config = new Config();
    }

    ngOnInit() {
        this.site = this.route.snapshot.paramMap.get('site');

        this.loadData(this.site);
    }

    loadData(site: string) {
        this.loading = true;
        this.configService.getConfig(site).subscribe(
            config => {
                this.loading = false;
                this.config = config;
                if (this.config.subConfig) {
                    this.subsites = Object.keys(this.config.subConfig);
                } else {
                    this.subsites = [];
                }

                // now load issues
                this.loadIssues();
            },
            error => {
                this.loading = false;
                this.errorService.handleError(this.site, error);
            }
        );
    }

    loadIssues() {
        this.loading = true;
        this.issueService.getIssues(this.site).subscribe(
            issues => {
                this.loading = false;
                this.issues = issues;
            },
            error => {
                this.loading = false;
                if (error instanceof HttpErrorResponse) {
                    this.toastr.error(error.error.text + ' (' + error.status + ')',
                        'Die Fehler konnten nicht geladen werden.');
                } else {
                    this.toastr.error(error.error.text, 'Fehler aufgetreten');
                }
            }
        );
    }
}
