import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Issue, Issues } from './issue';

import { environment } from '../../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class IssueService {

    constructor(private http: HttpClient) { }

    getIssues(site: string): Observable<Issues> {
        return this.http.get<Issues>(environment.serviceUrl + '/ws/issue/' + site + '/list');
    }
}
