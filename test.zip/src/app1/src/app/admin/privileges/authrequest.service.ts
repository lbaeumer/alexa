import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { AuthRequest, Auth } from './authrequest';

import { environment } from '../../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class AuthRequestService {

    constructor(private http: HttpClient) { }

    getAuthRequests(site: string): Observable<AuthRequest[]> {
        return this.http.get<AuthRequest[]>(environment.serviceUrl + '/ws/authrequest/' + site + '/list');
    }

    grantAuthRequest(site: string, auth: Auth): Observable<AuthRequest[]> {
        return this.http.post<AuthRequest[]>(environment.serviceUrl + '/ws/authrequest/' + site + '/grant', auth);
    }

    deleteAuthRequest(site: string, authrequest: AuthRequest): Observable<AuthRequest[]> {
        return this.http.post<AuthRequest[]>(environment.serviceUrl + '/ws/authrequest/' + site + '/request/delete', authrequest);
    }

    getAuths(site: string): Observable<Auth[]> {
        return this.http.get<Auth[]>(environment.serviceUrl + '/ws/auth/' + site + '/list');
    }

    deleteAuth(site: string, auth: Auth): Observable<Auth[]> {
        return this.http.post<Auth[]>(environment.serviceUrl + '/ws/auth/' + site + '/delete', auth);
    }
}
