export class AuthRequest {
    email: string;
    provider: string;
}

export class Auth {
    email: string;
    provider: string;
    role: string;
}
