import { TestBed } from '@angular/core/testing';

import { AuthRequestService } from './authrequest.service';

describe('AuthRequestService', () => {
    beforeEach(() => TestBed.configureTestingModule({}));

    it('should be created', () => {
        const service: AuthRequestService = TestBed.inject(AuthRequestService);
        expect(service).toBeTruthy();
    });
});
