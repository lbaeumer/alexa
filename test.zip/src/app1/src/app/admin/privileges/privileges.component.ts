import { Component, OnInit, isDevMode } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';

import { AuthRequestService } from './authrequest.service';
import { AuthRequest, Auth } from './authrequest';
import { ErrorService } from '../../error.service';

@Component({
    selector: 'app-privileges',
    templateUrl: './privileges.component.html',
    styleUrls: ['./privileges.component.css']
})
export class PrivilegesComponent implements OnInit {

    site: string;

    authrequests: AuthRequest[];
    auths: Auth[];

    loading: boolean;

    constructor(
        private route: ActivatedRoute,
        private toastr: ToastrService,
        private errorService: ErrorService,
        private authRequestService: AuthRequestService
    ) {
    }

    ngOnInit() {
        this.site = this.route.snapshot.paramMap.get('site');

        // now load auth requests
        this.loadAuthRequests();
    }

    loadAuthRequests() {
        this.loading = true;
        this.authRequestService.getAuthRequests(this.site).subscribe(
            authrequests => {
                this.loading = false;
                this.authrequests = authrequests;
                this.loadAuth();
            },
            error => {
                this.loading = false;
                this.errorService.handleError(this.site, error);
            }
        );
    }

    loadAuth() {
        this.loading = true;
        this.authRequestService.getAuths(this.site).subscribe(
            auths => {
                this.loading = false;
                this.auths = auths;
            },
            error => {
                this.loading = false;
                if (error instanceof HttpErrorResponse) {
                    this.toastr.error(error.error.text + ' (' + error.status + ')',
                        'Die Berechtigungen konnten nicht geladen werden.');
                } else {
                    this.toastr.error(error.error.text, 'Fehler aufgetreten');
                }
            }
        );
    }

    grant(role: string, req: AuthRequest) {
        if (isDevMode()) { console.log('role' + role); }
        const auth: Auth = new Auth;
        auth.email = req.email;
        auth.provider = req.provider;
        auth.role = role;

        this.loading = true;
        this.authRequestService.grantAuthRequest(this.site, auth).subscribe(
            authrequests => {
                this.loading = false;
                this.authrequests = authrequests;
                this.loadAuth();
                this.toastr.success('Ok');
            },
            error => {
                this.loading = false;
                if (isDevMode()) { console.log('res=' + JSON.stringify(error)); }
                if (error instanceof HttpErrorResponse) {
                    this.toastr.error(error.error.text + ' (' + error.status + ')',
                        'Es ist ein Fehler beim Speichern aufgetreten.');
                } else {
                    this.toastr.error(error.error.text, 'Fehler aufgetreten');
                }
            }
        );
    }

    deleteRequest(req: AuthRequest) {
        this.loading = true;
        this.authRequestService.deleteAuthRequest(this.site, req).subscribe(
            authrequests => {
                this.loading = false;
                this.authrequests = authrequests;
                this.toastr.success('Ok');
            },
            error => {
                this.loading = false;
                if (isDevMode()) { console.log('res=' + JSON.stringify(error)); }
                if (error instanceof HttpErrorResponse) {
                    this.toastr.error(error.error.text + ' (' + error.status + ')',
                        'Es ist ein Fehler beim Löschen aufgetreten.');
                } else {
                    this.toastr.error(error.error.text, 'Fehler aufgetreten');
                }
            }
        );
    }

    deleteAuth(req: Auth) {
        if (confirm('Möchten Sie das Recht ' + req.role + ' für ' + req.email + ' wirklich löschen?') === true) {

            this.loading = true;
            this.authRequestService.deleteAuth(this.site, req).subscribe(
                auths => {
                    this.loading = false;
                    this.auths = auths;
                    this.toastr.success('Ok');
                },
                error => {
                    this.loading = false;
                    if (isDevMode()) { console.log('res=' + JSON.stringify(error)); }
                    if (error instanceof HttpErrorResponse) {
                        this.toastr.error(error.error.text + ' (' + error.status + ')',
                            'Es ist ein Fehler beim Löschen aufgetreten.');
                    } else {
                        this.toastr.error(error.error.text, 'Fehler aufgetreten');
                    }
                }
            );
        }
    }
}
