import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';

import { FeedbackService } from './feedback.service';
import { Feedback } from './feedback';

@Component({
    selector: 'app-feedback',
    templateUrl: './feedback.component.html',
    styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {

    site: string;

    feedbacks: Feedback[];
    loading: boolean;

    constructor(
        private route: ActivatedRoute,
        private toastr: ToastrService,
        private feedbackService: FeedbackService,
    ) {
    }

    ngOnInit() {
        this.loading = true;

        this.site = this.route.snapshot.paramMap.get('site');

        this.feedbackService.getFeedbacks(this.site).subscribe(
            feedbacks => {
                this.loading = false;
                this.feedbacks = feedbacks;
            },
            error => {
                this.loading = false;
                if (error instanceof HttpErrorResponse) {
                    this.toastr.error(error.error.text + ' (' + error.status + ')', 'Das Feedback konnte nicht geladen werden.');
                } else {
                    this.toastr.error(error.error.text, 'Fehler aufgetreten');
                }
            }
        );
    }
}
