export class Feedback {
    name: string;
    email: string;
    phone: string;
    text: string;
    created: string;
}
