import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Feedback } from './feedback';

import { environment } from '../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class FeedbackService {

    constructor(private http: HttpClient) { }

    getFeedbacks(site: string): Observable<Feedback[]> {
        return this.http.get<Feedback[]>(environment.serviceUrl + '/ws/feedback/' + site + '/list');
    }
}
