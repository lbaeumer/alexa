import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class SiteService {

    constructor(private http: HttpClient) { }

    getSites(): Observable<Sites> {
        return this.http.get<Sites>(environment.serviceUrl + '/ws/site/list');
    }
}

export class Sites {
    sites: string[];

    constructor() {
        this.sites = [];
    }
}
