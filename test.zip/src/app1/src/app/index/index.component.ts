import { Component, OnInit, isDevMode } from '@angular/core';
import { SiteService, Sites } from './site.service';

import { environment } from '../../environments/environment';

@Component({
    selector: 'app-index',
    templateUrl: './index.component.html',
    styleUrls: ['./index.component.css']
})
export class IndexComponent implements OnInit {
    sites: Sites;
    loading: boolean;
    environment: any;

    constructor(
        private siteService: SiteService
    ) {
        this.environment = environment;
        this.sites = new Sites;
    }

    ngOnInit() {
        this.loading = true;

        this.siteService.getSites().subscribe(
            sites => {
                this.loading = false;
                this.sites = sites;
            },
            error => {
                this.loading = false;
            }
        );
    }

    onSelect(site: string) {
        if (isDevMode) { console.log('redirect to ' + environment.adminUrl + '/' + site); }
        if (site !== '-') {
            window.location.href = environment.adminUrl + '/' + site;
        }
    }
}
