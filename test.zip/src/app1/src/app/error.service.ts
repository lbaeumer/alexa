import { Injectable, isDevMode } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';

@Injectable({
    providedIn: 'root'
})
export class ErrorService {

    constructor(
        private toastr: ToastrService
    ) { }

    handleError(site: string, error) {
        if (error instanceof HttpErrorResponse) {
            if (error.status === 401 || error.status === 404) {
                if (isDevMode()) { console.log('you are not authenticated, so what'); }
            } else if (error.status === 403) {
                this.toastr.error(
                    'Es wird eine Berechtigungsanfrage gesendet. Bitte versuchen Sie es in Kürze nochmal'
                    + ' oder stellen Sie <a href="/p/' + site + '/feedback">eine Anfrage</a>.',
                    'Sie sind nicht berechtigt, auf diese Seite zuzugreifen.',
                    {
                        enableHtml: true,
                        closeButton: true,
                        disableTimeOut: true
                    });
            } else {
                this.toastr.error(error.error.text + ' (' + error.status + ')', 'Fehler aufgetreten');
            }
        } else {
            this.toastr.error(error.error.text, 'Fehler aufgetreten');
        }
    }
}
