import { Component, OnInit, isDevMode } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';

import { PersonService } from './person.service';
import { Person } from '../person';
import { ConfigService } from '../config.service';
import { Config } from '../config';
import { ErrorService } from '../error.service';
import { LoginService } from '../login/login.service';
import { User } from '../login/user';

@Component({
    selector: 'app-person',
    templateUrl: './person.component.html',
    styleUrls: ['./person.component.css']
})
export class PersonComponent implements OnInit {

    user: User;

    site: string;
    basesite: string;
    subsite: string;
    subsiteCount: number;

    baseconfig: Config;
    config: Config;

    persons: Person[];
    loading: boolean;
    progressing: boolean;
    dropDownTyp: string;

    fileToUpload: File = null;

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private toastr: ToastrService,
        private errorService: ErrorService,
        private personService: PersonService,
        private loginService: LoginService,
        private configService: ConfigService
    ) {
        this.config = new Config();
        this.baseconfig = new Config();
        this.subsiteCount = 0;
        this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    }

    ngOnInit() {
        // get login user
        this.user = this.loginService.user;
        this.loginService.loginEvent$.subscribe(
            user => {
                if (isDevMode()) { console.log('user=' + user); }
                this.user = user;
            }
        );

        // set site drop down
        this.site = this.route.snapshot.paramMap.get('site');
        this.dropDownTyp = this.site;
        if (this.site.indexOf('_') > 0) {
            this.basesite = this.site.substring(0, this.site.indexOf('_'));
            this.subsite = this.site.substring(this.site.indexOf('_') + 1);
        } else {
            this.basesite = this.site;
        }
        if (isDevMode()) { console.log('site=' + this.site + '; subsite=' + this.subsite + '; base=' + this.basesite); }

        this.loadData(this.basesite);
    }

    loadData(site: string) {
        this.loading = true;
        this.configService.getConfig(site).subscribe(
            config => {
                this.loading = false;
                this.baseconfig = config;
                if (this.baseconfig.subConfig) {
                    this.subsiteCount = Object.keys(this.baseconfig.subConfig).length;
                }
                if (this.site === this.basesite) {
                    this.config = config;
                } else {
                    if (config.subConfig[this.subsite]) {
                        this.config = config.subConfig[this.subsite];
                    } else {
                        // there is no base site, as a workaround set config
                        if (isDevMode()) { console.log('no base site'); }
                    }
                }

                // now load person
                this.loadPerson();
            },
            error => {
                this.loading = false;
                this.errorService.handleError(site, error);
            }
        );
    }

    loadPerson() {
        this.loading = true;
        this.personService.getPersons(this.site).subscribe(
            persons => {
                this.loading = false;
                this.persons = persons;
            },
            error => {
                this.loading = false;
                if (error instanceof HttpErrorResponse) {
                    this.toastr.error(error.error.text + ' (' + error.status + ')',
                        'Die Daten konnten nicht geladen werden.');
                } else {
                    this.toastr.error(error.error.text, 'Fehler aufgetreten');
                }
            }
        );
    }

    onChange() {
        if (isDevMode()) {
            console.log('redirect to ' + this.dropDownTyp
                + '/person');
        }
        this.router.navigate(['/' + this.dropDownTyp
            + '/person']);
    }

    handleFileInput(files: FileList) {
        if (isDevMode()) { console.log('onSuccessUpload(' + files); }
        this.progressing = true;
        this.personService.uploadPersons(this.site, files.item(0)).subscribe(
            persons => {
                this.progressing = false;
                if (isDevMode()) { console.log('upload ok ' + persons.length); }
                if (persons.length > 0) {
                    this.persons = persons;
                }
                this.toastr.success('Es wurden ' + persons.length + ' Personen importiert.');
            },
            error => {
                this.progressing = false;
                if (isDevMode()) { console.log('upload ok'); }
                this.toastr.error(error.error.text + ' (' + error.status + ')', 'Fehler aufgetreten');
            }
        );
    }
}
