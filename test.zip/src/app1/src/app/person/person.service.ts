import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Person } from '../person';

import { environment } from '../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class PersonService {

    constructor(private http: HttpClient) { }

    getPersons(site: string): Observable<Person[]> {
        return this.http.get<Person[]>(environment.serviceUrl + '/ws/person/' + site + '/list');
    }

    uploadPersons(site: string, file): Observable<Person[]> {
        return this.http.post<Person[]>(environment.serviceUrl + '/ws/upload-persons/' + site, file);
    }
}
