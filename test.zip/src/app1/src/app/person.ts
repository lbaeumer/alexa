export class Person {
    name: string;
    surname: string;
    email: string;
    clazz: string;
    code: string;
    created: string;
}
