export class User {
    name: string;
    password: string;
    email: string;
    provider: string;
    role: string;
}
