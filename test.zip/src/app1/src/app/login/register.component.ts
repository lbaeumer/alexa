import { Component, OnInit, isDevMode } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';

import { LoginService } from './login.service';
import { RegisterUser } from './registeruser';

import { environment } from '../../environments/environment';

@Component({
    selector: 'app-register',
    templateUrl: './register.component.html',
    styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

    environment: any;
    site: string;
    loading: boolean;
    user: RegisterUser;
    imageUrl: string;

    constructor(
        private route: ActivatedRoute,
        private toastr: ToastrService,
        private loginService: LoginService) {
        this.user = new RegisterUser;
        this.environment = environment;
    }

    ngOnInit() {
        this.site = this.route.snapshot.paramMap.get('site');
        this.imageUrl = environment.imageUrl + '/' + this.site + '/logo.jpg';
        this.user.site = this.site;
    }

    register() {
        if (isDevMode()) { console.log('register=' + this.user); }
        this.loading = true;
        this.loginService.register(this.user).subscribe(
            u => {
                this.loading = false;
                this.toastr.success('Bitte kontrollieren Sie noch Ihre Email und bestätigen Sie den Account.', 'Zugang registriert',
                    {
                        enableHtml: true,
                        closeButton: true,
                        disableTimeOut: true
                    });
            },
            error => {
                this.loading = false;
                if (error instanceof HttpErrorResponse) {
                    if (isDevMode()) { console.log(JSON.stringify(error)); }
                    this.toastr.error(error.error.text, 'Fehler aufgetreten');
                } else {
                    this.toastr.error(error.error.text, 'Fehler aufgetreten');
                }
            }
        );
    }
}
