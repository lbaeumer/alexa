import { Injectable, isDevMode } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { User } from './user';
import { RegisterUser } from './registeruser';

import { environment } from '../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class LoginService {

    loginEventSource: Subject<User> = new Subject<User>();
    loginEvent$ = this.loginEventSource.asObservable();
    public user: User;

    loginEvent(user: User) {
        if (isDevMode()) { console.log('loginEvent ' + user); }
        this.user = user;
        this.loginEventSource.next(user);
    }

    constructor(private http: HttpClient) { }

    login(user: User, site: string): Observable<User> {
        return this.http.post<User>(environment.serviceUrl + '/ws/login/' + site + '/login', user);
    }

    logout(): Observable<string> {
        return this.http.post<string>(environment.serviceUrl + '/ws/login/logout', null);
    }

    register(user: RegisterUser): Observable<User> {
        return this.http.post<User>(environment.serviceUrl + '/ws/signup/register', user);
    }

    getSignup(key: string): Observable<User> {
        return this.http.get<User>(environment.serviceUrl + '/ws/signup/get/' + key);
    }

    activate(key: string): Observable<User> {
        return this.http.post<User>(environment.serviceUrl + '/ws/signup/activate/' + key, null);
    }

    getUser(site: string): Observable<User> {
        return this.http.get<User>(environment.serviceUrl + '/ws/login/' + site + '/info');
    }
}
