import { Component, OnInit, isDevMode } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';

import { LoginService } from './login.service';
import { User } from './user';

import { environment } from '../../environments/environment';

@Component({
    selector: 'app-signup',
    templateUrl: './signup.component.html',
    styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

    environment: any;
    site: string;
    loading: boolean;
    user: User;
    key: string;
    imageUrl: string;

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private toastr: ToastrService,
        private loginService: LoginService) {
        this.environment = environment;
        this.user = new User;
    }

    ngOnInit() {
        this.site = this.route.snapshot.paramMap.get('site');
        this.key = this.route.snapshot.paramMap.get('key');
        this.imageUrl = environment.imageUrl + '/' + this.site + '/logo.jpg';
        this.load();
    }

    load() {
        if (isDevMode()) { console.log('load=' + this.key); }
        this.loading = true;
        this.loginService.getSignup(this.key).subscribe(
            u => {
                this.loading = false;
                this.user = u;
            },
            error => {
                this.loading = false;
                if (error instanceof HttpErrorResponse) {
                    if (isDevMode()) { console.log(JSON.stringify(error)); }
                    this.toastr.error(error.error.text, 'Fehler aufgetreten');
                } else {
                    this.toastr.error(error.error.text, 'Fehler aufgetreten');
                }
            }
        );
    }

    activate() {
        if (isDevMode()) { console.log('activate=' + this.key); }
        this.loading = true;
        this.loginService.activate(this.key).subscribe(
            u => {
                this.loading = false;
                this.toastr.success('Sie können sich nun anmelden.', 'Zugang erstellt',
                    {
                        enableHtml: true,
                        closeButton: true,
                        disableTimeOut: true
                    });
                this.router.navigate(['/' + this.site + '/login'], { queryParams: { email: u.email } });
            },
            error => {
                this.loading = false;
                if (error instanceof HttpErrorResponse) {
                    if (isDevMode()) { console.log(JSON.stringify(error)); }
                    this.toastr.error(error.error.text, 'Fehler aufgetreten');
                } else {
                    this.toastr.error(error.error.text, 'Fehler aufgetreten');
                }
            }
        );
    }
}
