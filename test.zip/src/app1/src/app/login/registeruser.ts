export class RegisterUser {
    name: string;
    email: string;
    site: string;
    password: string;
    password2: string;
}
