import { Component, OnInit, isDevMode } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';

import { LoginService } from './login.service';
import { User } from './user';

import { environment } from '../../environments/environment';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

    environment: any;
    site: string;
    action: string;
    redirect: string;
    id: string;
    imageUrl: string;

    user: User;
    loading: boolean;

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private toastr: ToastrService,
        private loginService: LoginService
    ) {
        this.environment = environment;
    }

    ngOnInit() {
        this.site = this.route.snapshot.paramMap.get('site');
        this.imageUrl = environment.imageUrl + '/' + this.site + '/logo.jpg';
        this.user = new User;

        this.action = 'projects';
        this.route.queryParams.subscribe(
            params => {
                if (params['action']) {
                    this.action = params['action'];
                }
                if (params['email']) {
                    this.user.email = params['email'];
                }
                if (params['redirect']) {
                    this.redirect = params['redirect'];
                }
                if (params['error']) {
                    this.toastr.error('Login Fehler');
                }
            }
        );

        this.id = this.route.snapshot.paramMap.get('id');
        if (isDevMode()) { console.log('login onInit: found site=' + this.site); }

        if (this.id) {
            if (isDevMode()) { console.log('login ****' + this.id); }
            const u = new User;
            u.name = this.id;
            u.provider = 'external';
            this.login(u);
        }
    }

    login(user: User) {
        this.loading = true;
        if (isDevMode()) { console.log('login=' + user.name + '/' + this.site + '/' + this.redirect); }
        this.loginService.login(user, this.site).subscribe(
            u => {
                this.loading = false;
                this.loginService.loginEvent(u);
                if (!this.redirect) {
                    if (isDevMode()) { console.log('user ' + u.name + ' authenticated, navigate to ' + this.site + '/' + this.action); }
                    this.router.navigate(['/' + this.site + '/' + this.action]);
                } else {
                    if (isDevMode()) { console.log('user ' + u.name + ' authenticated, redirect to ' + this.redirect); }
                    window.location.href = this.redirect;
                }
            },
            error => {
                if (isDevMode()) { console.log('login failed'); }
                this.loading = false;
                if (error instanceof HttpErrorResponse) {
                    console.log(JSON.stringify(error));
                    if (error.status === 401) {
                        this.toastr.error(error.error.text, 'Login Fehler');
                    } else {
                        this.toastr.error(error.error.text, 'Fehler aufgetreten');
                    }
                } else {
                    this.toastr.error(error.error.text, 'Fehler aufgetreten');
                }
            }
        );
    }
}
