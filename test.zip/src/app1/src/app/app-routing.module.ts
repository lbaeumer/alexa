import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

import { AdminComponent } from './admin/admin.component';
import { AdvancedComponent } from './admin/advanced/advanced.component';
import { AssignmentComponent } from './assignment/assignment.component';
import { CodeComponent } from './code/code.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { IndexComponent } from './index/index.component';
import { InitComponent } from './init/init.component';
import { IssuesComponent } from './admin/issues/issues.component';
import { LoginComponent } from './login/login.component';
import { PersonComponent } from './person/person.component';
import { PrivilegesComponent } from './admin/privileges/privileges.component';
import { ProjectsComponent } from './projects/projects.component';
import { ProjectDetailComponent } from './projects/project-detail/project-detail.component';
import { RegisterComponent } from './login/register.component';
import { ReportComponent } from './report/report.component';
import { SelectionComponent } from './selection/selection.component';
import { SelectionDetailComponent } from './selection/selection-detail/selection-detail.component';
import { SignupComponent } from './login/signup.component';
import { ShellComponent } from './shell/shell.component';

const routes: Routes = [
    { path: '', pathMatch: 'full', component: IndexComponent },
    {
        path: '',
        component: ShellComponent,
        children: [
            { path: ':site/projects', component: ProjectsComponent },
            { path: ':site/projects/:id', component: ProjectDetailComponent },
            { path: ':site/assignment', component: AssignmentComponent },
            { path: ':site/report', component: ReportComponent },
            { path: ':site/selection', component: SelectionComponent },
            { path: ':site/selection/:id', component: SelectionDetailComponent },
            { path: ':site/code', component: CodeComponent },
            { path: ':site/person', component: PersonComponent },
            { path: ':site/feedback', component: FeedbackComponent },
            { path: ':site/admin', component: AdminComponent },
            { path: ':site/issues', component: IssuesComponent },
            { path: ':site/advanced', component: AdvancedComponent },
            { path: ':site/privileges', component: PrivilegesComponent },
            { path: ':site', pathMatch: 'full', redirectTo: ':site/projects' }
        ]
    },
    { path: ':site/login', component: LoginComponent },
    { path: ':site/login/:id', component: LoginComponent },
    { path: ':site/register', component: RegisterComponent },
    { path: ':site/signup/:key', component: SignupComponent }
];

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forRoot(routes, { useHash: false })
    ],
    exports: [
        RouterModule
    ],
    declarations: []
})
export class AppRoutingModule { }
