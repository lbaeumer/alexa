export const environment = {
    production: true,
    serviceUrl: 'https://api.quaestio24.de',
    adminUrl: 'https://admin.quaestio24.de',
    appUrl: 'https://quaestio24.de',
    globalUrl: 'https://global.quaestio24.de',
    imageUrl: 'https://storage.googleapis.com/quaestio24.appspot.com'
};
