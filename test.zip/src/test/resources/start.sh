echo create admin files
cat ../war/js/admin/adminapp.js \
	../war/js/admin/*ctrl.js \
	../war/js/admin/ng-google-chart.js \
	../war/js/admin/angular-number-picker.min.js \
	| java -jar yuicompressor-2.4.8.jar --type js -o ../war/js/admin/all-min.js

echo create std files
cat ../war/js/app.js \
	../war/js/controllers.js \
	| java -jar yuicompressor-2.4.8.jar --type js -o ../war/js/all-min.js
