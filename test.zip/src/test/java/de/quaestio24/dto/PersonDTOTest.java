package de.quaestio24.dto;

import org.junit.Assert;
import org.junit.Test;

public class PersonDTOTest {

    @Test
    public void normalize() {
        String in = "Hallo du da";
        Assert.assertEquals(PersonDTO.normalize(in, false), "hallo du da");
    }

    @Test
    public void normalize2() {
        String in = "Hallo du dä$";
        Assert.assertEquals(PersonDTO.normalize(in, false), "hallo du dae$");
    }

}
