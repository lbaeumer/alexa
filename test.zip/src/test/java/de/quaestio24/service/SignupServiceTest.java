package de.quaestio24.service;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.tools.development.testing.LocalDatastoreServiceTestConfig;
import com.google.appengine.tools.development.testing.LocalServiceTestHelper;
import de.quaestio24.dto.LoginStatDTO;
import de.quaestio24.dto.RegisterUserDTO;
import de.quaestio24.dto.UserDTO;
import de.quaestio24.exception.ValidationException;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

public class SignupServiceTest {

    private final LocalServiceTestHelper helper = new LocalServiceTestHelper(new LocalDatastoreServiceTestConfig());
    private LoginStatsService loginStatsService = new LoginStatsService();
    private SignupService signupService = new SignupService();
    private UserService userService = new UserService();

    @Before
    public void setUp() {
        helper.setUp();
    }

    @After
    public void tearDown() {
        helper.tearDown();
    }

    @Test(expected = ValidationException.class)
    public void testRegisterValFail() {

        new SiteService().addSite("junit1");
        NamespaceManager.set("junit1");

        RegisterUserDTO user = new RegisterUserDTO();
        user.email = "email2";
        user.password = "pw2123";
        user.password2 = "pw2123";
        user.site = "junit1";

        UserDTO reg = signupService.register(user);
        Assert.assertNotNull(reg);
    }

    @Test(expected = ValidationException.class)
    public void testRegisterValFail2() {

        new SiteService().addSite("junit1");
        NamespaceManager.set("junit1");

        RegisterUserDTO user = new RegisterUserDTO();
        user.name = "name";
        user.email = "email2";
        user.password = "pw2";
        user.password2 = "pw2";
        user.site = "junit1";

        UserDTO reg = signupService.register(user);
        Assert.assertNotNull(reg);
    }

    @Test(expected = SecurityException.class)
    public void testRegisterNotActivated() {

        new SiteService().addSite("junit1");
        NamespaceManager.set("junit1");

        RegisterUserDTO user = new RegisterUserDTO();
        user.name = "myname";
        user.email = "email2@localhost";
        user.password = "pw2123";
        user.password2 = "pw2123";
        user.site = "junit1";

        UserDTO reg = signupService.register(user);
        Assert.assertNotNull(reg);
        Assert.assertNotNull(reg.key);

        // user not activated
        user.provider = "login";
        userService.login(user);
    }

    @Test
    public void testRegisterOk() {

        new SiteService().addSite("junit1");

        RegisterUserDTO user = new RegisterUserDTO();
        user.name = "myname1";
        user.email = "email1@localhost";
        user.password = "pw21231";
        user.password2 = "pw21231";
        user.site = "junit1";

        UserDTO reg = signupService.register(user);
        Assert.assertNotNull(reg);
        Assert.assertNotNull(reg.key);

        // activate user
        UserDTO u1 = signupService.activate(reg.key);
        Assert.assertNotNull(u1);

        // login
        user.provider = "login";
        UserDTO u2 = userService.login(user);
        Assert.assertNotNull(u2);

        List<LoginStatDTO> l = loginStatsService.getLoginStats().logins;
        Assert.assertEquals(l.size(), 1);
        Assert.assertNull(l.get(0).lastFailedLogin);
        Assert.assertNotNull(l.get(0).lastSuccessLogin);
        Assert.assertEquals(l.get(0).loginCount, 1);
    }

    @Test(expected = ValidationException.class)
    public void testRegisterOk2() {

        new SiteService().addSite("junit1");
        NamespaceManager.set("junit1");

        RegisterUserDTO user = new RegisterUserDTO();
        user.name = "myname";
        user.email = "email2@localhost";
        user.password = "pw2123";
        user.password2 = "pw2123";
        user.site = "junit1";

        UserDTO reg = signupService.register(user);
        Assert.assertNotNull(reg);
        Assert.assertNotNull(reg.key);

        // activate user
        UserDTO u1 = signupService.activate(reg.key);
        Assert.assertNotNull(u1);

        // register again fails
        signupService.register(user);
    }
}
