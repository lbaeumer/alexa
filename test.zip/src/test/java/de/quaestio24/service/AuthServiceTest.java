package de.quaestio24.service;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.tools.development.testing.LocalDatastoreServiceTestConfig;
import com.google.appengine.tools.development.testing.LocalServiceTestHelper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import de.quaestio24.constant.RoleEnum;
import de.quaestio24.dto.AuthDTO;
import de.quaestio24.entity.Site;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

public class AuthServiceTest {

    private final LocalServiceTestHelper helper = new LocalServiceTestHelper(new LocalDatastoreServiceTestConfig());
    private AuthService authService = new AuthService();

    @Before
    public void setUp() {
        helper.setUp();
    }

    @After
    public void tearDown() {
        helper.tearDown();
    }

    @Test
    public void test2() {
        Site t = Site.valueOf("demo");
        Gson gson = new GsonBuilder().registerTypeAdapter(Site.class, new Site()).create();
        String j = gson.toJson(t);
        Assert.assertEquals(j, "\"demo\"");
    }

    @Test
    public void test() {
        NamespaceManager.set("junit1");
        List<RoleEnum> roleList = authService.getRoles("googleplus", "lui.baeumerx@gmail.com");
        Assert.assertEquals(0, roleList.size());

        AuthDTO auth = new AuthDTO();
        auth.email = "lui.baeumerx@gmail.com";
        auth.provider = "googleplus";
        authService.insertAuth(auth);

        auth = new AuthDTO();
        auth.email = "lui.baeumery@gmail.com";
        auth.provider = "googleplus";
        auth.role = RoleEnum.superadmin;
        authService.insertAuth(auth);

        roleList = authService.getRoles("googleplus", "lui.baeumerx@gmail.com");
        Assert.assertEquals(1, roleList.size());
        Assert.assertEquals(RoleEnum.teacher, roleList.get(0));

        // same role for subsites
        NamespaceManager.set("junit1_xyz");
        List<RoleEnum> roleList2 = authService.getRoles("googleplus", "lui.baeumerx@gmail.com");
        Assert.assertEquals(1, roleList2.size());
        Assert.assertEquals(RoleEnum.teacher, roleList2.get(0));

        NamespaceManager.set("junit2");
        auth = new AuthDTO();
        auth.email = "lui.baeumerx@gmail.com";
        auth.provider = "googleplus";
        authService.insertAuth(auth);

        NamespaceManager.set("junit1");
        roleList = authService.getRoles("googleplus", "lui.baeumerx@gmail.com");
        Assert.assertEquals(1, roleList.size());
        Assert.assertEquals(RoleEnum.teacher, roleList.get(0));

        NamespaceManager.set("junit2");
        roleList = authService.getRoles("googleplus", "lui.baeumerx@gmail.com");
        Assert.assertEquals(1, roleList.size());
        Assert.assertEquals(RoleEnum.teacher, roleList.get(0));

        NamespaceManager.set("junit1");
        List<AuthDTO> authList = authService.getAllAuths();
        Assert.assertEquals(2, authList.size());
        Assert.assertEquals(RoleEnum.superadmin, authList.get(1).role);
        Assert.assertEquals(RoleEnum.teacher, authList.get(0).role);

        NamespaceManager.set("junit2");
        authList = authService.getAllAuths();
        Assert.assertEquals(1, authList.size());
        Assert.assertEquals(RoleEnum.teacher, authList.get(0).role);

        NamespaceManager.set("junit2_xyz");
        authList = authService.getAllAuths();
        Assert.assertEquals(1, authList.size());
        Assert.assertEquals(RoleEnum.teacher, authList.get(0).role);
    }

    @Test
    public void testAdmin() {
        NamespaceManager.set("junit1");
        List<RoleEnum> roleList = authService.getRoles("googleplus", "lui.baeumerx@gmail.com");
        Assert.assertEquals(0, roleList.size());

        AuthDTO auth = new AuthDTO();
        auth.email = "lui.baeumerx@gmail.com";
        auth.provider = "googleplus";
        auth.role = RoleEnum.admin;
        authService.insertAuth(auth);

        roleList = authService.getRoles("googleplus", "lui.baeumerx@gmail.com");
        Assert.assertEquals(1, roleList.size());
        Assert.assertEquals(RoleEnum.admin, roleList.get(0));

        auth = new AuthDTO();
        auth.email = "lui.baeumerx@gmail.com";
        auth.provider = "googleplus";
        auth.role = RoleEnum.superadmin;

        authService.insertAuth(auth);

        NamespaceManager.set("junit2");
        authService.insertAuth(auth);

        NamespaceManager.set("junit1");
        roleList = authService.getRoles("googleplus", "lui.baeumerx@gmail.com");
        Assert.assertEquals(1, roleList.size());
        Assert.assertEquals(RoleEnum.superadmin, roleList.get(0));

        NamespaceManager.set("junit2");
        roleList = authService.getRoles("googleplus", "lui.baeumerx@gmail.com");
        Assert.assertEquals(1, roleList.size());
        Assert.assertEquals(RoleEnum.superadmin, roleList.get(0));
    }

    @Test
    public void testDeleteAuth() {
        NamespaceManager.set("junit1");
        List<RoleEnum> roleList = authService.getRoles("googleplus", "lui.baeumerx@gmail.com");
        Assert.assertEquals(0, roleList.size());

        // insert auth
        AuthDTO auth = new AuthDTO();
        auth.email = "lui.baeumerx@gmail.com";
        auth.provider = "googleplus";
        List<AuthDTO> l = authService.insertAuth(auth);
        Assert.assertEquals(l.size(), 1);
        Assert.assertEquals(l.get(0).email, "lui.baeumerx@gmail.com");

        // insert auth
        auth = new AuthDTO();
        auth.email = "lui.baeumerx@gmail.com";
        auth.provider = "googleplus";
        auth.role = RoleEnum.superadmin;
        l = authService.insertAuth(auth);
        Assert.assertEquals(l.size(), 2);
        Assert.assertEquals(l.get(0).email, "lui.baeumerx@gmail.com");
        Assert.assertEquals(l.get(0).role, RoleEnum.superadmin);
        Assert.assertEquals(l.get(1).email, "lui.baeumerx@gmail.com");
        Assert.assertEquals(l.get(1).role, RoleEnum.teacher);

        roleList = authService.getRoles("googleplus", "lui.baeumerx@gmail.com");
        Assert.assertEquals(1, roleList.size());
        Assert.assertEquals(RoleEnum.superadmin, roleList.get(0));

        // delete auth, do not delete
        auth.role = RoleEnum.admin;
        l = authService.deleteAuth(auth);
        Assert.assertEquals(l.size(), 2);
        Assert.assertEquals(l.get(0).email, "lui.baeumerx@gmail.com");
        Assert.assertEquals(l.get(0).role, RoleEnum.superadmin);
        Assert.assertEquals(l.get(1).email, "lui.baeumerx@gmail.com");
        Assert.assertEquals(l.get(1).role, RoleEnum.teacher);

        roleList = authService.getRoles("googleplus", "lui.baeumerx@gmail.com");
        Assert.assertEquals(1, roleList.size());
        Assert.assertEquals(RoleEnum.superadmin, roleList.get(0));

        NamespaceManager.set("junit1_xyz");
        auth.role = RoleEnum.teacher;
        l = authService.deleteAuth(auth);
        Assert.assertEquals(l.size(), 1);
        Assert.assertEquals(l.get(0).email, "lui.baeumerx@gmail.com");
        Assert.assertEquals(l.get(0).role, RoleEnum.superadmin);

        NamespaceManager.set("junit1_xxx");
        roleList = authService.getRoles("googleplus", "lui.baeumerx@gmail.com");
        Assert.assertEquals(1, roleList.size());
        Assert.assertEquals(RoleEnum.superadmin, roleList.get(0));
    }

    @Test
    public void testCreateDefaultAuth() {
        NamespaceManager.set("junit1");
        List<AuthDTO> auths = authService.getAllAuths();
        Assert.assertEquals(0, auths.size());

        authService.createDefaultAuth();

        auths = authService.getAllAuths();
        Assert.assertEquals(1, auths.size());
        Assert.assertEquals("lui.baeumer@gmail.com", auths.get(0).email);
    }
}
