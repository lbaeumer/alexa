package de.quaestio24.service;

import com.google.appengine.tools.development.testing.LocalDatastoreServiceTestConfig;
import com.google.appengine.tools.development.testing.LocalServiceTestHelper;
import de.quaestio24.dto.PersonDTO;
import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.dto.PreferencesDTO.DesignParameter;
import de.quaestio24.dto.PreferencesDTO.Parameter;
import de.quaestio24.dto.ProjectListDTO;
import de.quaestio24.dto.SelectionDTO;
import de.quaestio24.dto.SelectionResponseDTO;
import de.quaestio24.exception.ValidationException;
import org.apache.commons.collections4.map.HashedMap;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

@RunWith(MockitoJUnitRunner.class)
public class SelectionServiceNameTest {

    private final LocalServiceTestHelper helper = new LocalServiceTestHelper(new LocalDatastoreServiceTestConfig());

    @InjectMocks
    private SelectionService selService;

    @Mock
    private PreferencesService preferenceService;

    @Before
    public void setUp() {
        helper.setUp();

        long now = System.currentTimeMillis();
        PreferencesDTO pref = new PreferencesDTO();
        pref.parameter = new Parameter();
        pref.anonymous = false;
        pref.startDate = new Date(now);
        pref.endDate = new Date(now + 100000);
        Mockito.when(preferenceService.getPreference()).thenReturn(pref);
    }

    @After
    public void tearDown() {
        helper.tearDown();
    }

    @Test
    public void testOk1() {
        long now = System.currentTimeMillis();
        PreferencesDTO p = new PreferencesDTO();
        p.startDate = new Date(now - 100000);
        p.endDate = new Date(now + 100000);
        selService.validateTime(p);
    }

    @Test
    public void testOk2() {
        long now = System.currentTimeMillis();
        PreferencesDTO p = new PreferencesDTO();
        p.startDate = new Date(now - 300000);
        p.endDate = new Date(now - 200000);
        p.startDate2 = new Date(now - 100000);
        p.endDate2 = new Date(now + 100000);
        selService.validateTime(p);
    }

    @Test(expected = ValidationException.class)
    public void testToolEarly() {
        long now = System.currentTimeMillis();
        PreferencesDTO p = new PreferencesDTO();
        p.startDate = new Date(now + 100000);
        p.endDate = new Date(now + 200000);
        selService.validateTime(p);
    }

    @Test(expected = ValidationException.class)
    public void testTooLate() {
        long now = System.currentTimeMillis();
        PreferencesDTO p = new PreferencesDTO();
        p.startDate = new Date(now - 100000);
        p.endDate = new Date(now - 5000);
        selService.validateTime(p);
    }

    @Test(expected = ValidationException.class)
    public void testInMid() {
        long now = System.currentTimeMillis();
        PreferencesDTO p = new PreferencesDTO();
        p.startDate = new Date(now - 100000);
        p.endDate = new Date(now - 5000);
        p.startDate2 = new Date(now + 5000);
        p.endDate2 = new Date(now + 10000);
        selService.validateTime(p);
    }

    @Test(expected = ValidationException.class)
    public void testTooLate2() {
        long now = System.currentTimeMillis();
        PreferencesDTO p = new PreferencesDTO();
        p.startDate = new Date(now - 300000);
        p.endDate = new Date(now - 20000);
        p.startDate2 = new Date(now - 100000);
        p.endDate2 = new Date(now - 5000);
        selService.validateTime(p);
    }

    @Test
    public void validateSelection() {
        SelectionDTO sel = new SelectionDTO();
        sel.person = new PersonDTO();
        sel.person.name = "B";
        sel.person.surname = "Lui";
        sel.person.email = "Lui@xxx.de";
        sel.person.clazz = "1";
        sel.selections = new ArrayList<>();
        sel.selections.add(1);
        sel.selections.add(2);
        sel.selections.add(3);
        PreferencesDTO pr = new PreferencesDTO();
        pr.parameter = new Parameter();
        pr.anonymous = false;
        pr.design = new DesignParameter();
        pr.design.minSelections = 3;
        selService.validate(sel, pr);
    }

    @Test(expected = ValidationException.class)
    public void validateSelectionFailed() {
        SelectionDTO sel = new SelectionDTO();
        sel.person = new PersonDTO();
        sel.person.surname = "Lui";
        sel.person.email = "Lui@xxx.de";
        sel.person.clazz = "1";
        sel.selections = new ArrayList<>();
        sel.selections.add(1);
        sel.selections.add(2);
        sel.selections.add(3);
        PreferencesDTO pr = new PreferencesDTO();
        pr.design = new DesignParameter();
        pr.design.minSelections = 3;
        pr.parameter = new Parameter();
        pr.anonymous = false;
        selService.validate(sel, pr);
    }

    @Test
    public void selectionTest() {

        List<SelectionDTO> selections = selService.getAllSelection();
        Assert.assertEquals(selections.size(), 0);

        List<String> selectionIds = new ArrayList<>();

        for (int i = 1; i <= 20; i++) {
            SelectionDTO s = new SelectionDTO();
            s.created = new Date();
            s.person = new PersonDTO();
            s.person.name = "b" + i;
            s.person.surname = "s";
            s.person.email = "s@xyz.de";
            s.person.clazz = "1a";

            s.selections = new ArrayList<>();
            s.selections.add(21);
            s.selections.add(2);
            s.selections.add(22 + i);

            SelectionResponseDTO res = selService.insert(s, "localhost");
            Assert.assertNotNull(res);

            selectionIds.add(res.id);
        }

        // getAllSelections
        selections = selService.getAllSelection();
        Assert.assertEquals(selections.size(), 20);

        // getSelectionCount
        List<Integer> sc = selService.getSelectionCount();
        Assert.assertEquals((int) sc.get(0), 20);
        Assert.assertEquals((int) sc.get(1), 0);

        // getSelection
        SelectionDTO sel = selService.getSelection(selectionIds.get(0));
        Assert.assertNotNull(sel);
        Assert.assertEquals(sel.id, selectionIds.get(0));

        // deleteSelection
        selService.deleteSelection(selectionIds.get(0));
        selections = selService.getAllSelection();
        Assert.assertEquals(selections.size(), 19);

        // deleteAllSelection
        selService.deleteAllSelection();
        selections = selService.getAllSelection();
        Assert.assertEquals(selections.size(), 0);
    }

    @Test
    public void updateSelectionTest() {

        List<SelectionDTO> selections = selService.getAllSelection();
        Assert.assertEquals(selections.size(), 0);

        // insert selections
        for (int i = 1; i <= 20; i++) {
            SelectionDTO s = new SelectionDTO();
            s.created = new Date();
            s.person = new PersonDTO();
            s.person.name = "b" + i;
            s.person.surname = "s" + i;
            s.person.clazz = "c" + i;
            s.person.email = i + "s@xyz.de";

            s.selections = new ArrayList<>();
            s.selections.add(21 + i);
            s.selections.add(2 + i);
            s.selections.add(5 + i);

            SelectionResponseDTO res = selService.insert(s, "localhost");
            Assert.assertNotNull(res);
        }

        // getAllSelections
        List<SelectionDTO> origSel = selService.getAllSelection();

        selections = selService.getAllSelection();
        Assert.assertEquals(selections.size(), 20);

        Map<String, SelectionDTO> map = new HashedMap<>();
        for (SelectionDTO s : selections) {
            map.put(s.person.name, s);
        }
        Assert.assertEquals(map.size(), 20);

        // lookup name selection
        SelectionDTO sName = map.get("b18");
        Assert.assertEquals(sName.person.name, "b18");
        Assert.assertEquals(sName.person.surname, "s18");
        Assert.assertEquals(sName.person.clazz, "c18");
        Assert.assertEquals(sName.person.email, "18s@xyz.de");
        Assert.assertNull(sName.person.code);
        Assert.assertEquals(sName.id, "dcd23208317bd01e6fde74c60a446d1a");
        Assert.assertEquals((int) sName.selections.get(0), 39);
        Assert.assertEquals((int) sName.selections.get(2), 23);

        Assert.assertEquals(origSel, selections);

        // update an entry
        sName.person.name = "bx18";
        sName.selections = new ArrayList<>();
        sName.selections.add(6);

        SelectionResponseDTO sNameRes = selService.update(sName, "localhost");
        Assert.assertEquals(sNameRes.id, "53de7d512e934a80392c0a3e1888930d");

        // read again and check if update was successful
        List<SelectionDTO> newSel = selService.getAllSelection();
        map = new HashedMap<>();
        for (SelectionDTO s : newSel) {
            map.put(s.person.name, s);
        }
        Assert.assertEquals(map.size(), 20);

        SelectionDTO s1x = map.get("bx18");
        Assert.assertEquals((int) s1x.selections.get(0), 6);
        Assert.assertEquals(s1x.person.name, "bx18");
        Assert.assertEquals(s1x.person.surname, "s18");
        Assert.assertEquals(s1x.person.clazz, "c18");
        Assert.assertEquals(s1x.person.email, "18s@xyz.de");
        Assert.assertNull(sName.person.code);
        Assert.assertEquals(s1x.id, "53de7d512e934a80392c0a3e1888930d");
    }

    @Test
    public void getSelectionCsvTest() {
        List<SelectionDTO> selections = selService.getAllSelection();
        Assert.assertEquals(selections.size(), 0);
        selections = selService.getAllHistorySelection();
        Assert.assertEquals(selections.size(), 0);

        for (int i = 1; i <= 20; i++) {
            SelectionDTO s = new SelectionDTO();
            s.created = new Date();
            s.person = new PersonDTO();
            s.person.name = "b" + i;
            s.person.surname = "s";
            s.person.email = "s@xyz.de";
            s.person.clazz = "1a";

            s.selections = new ArrayList<>();
            s.selections.add(21);
            s.selections.add(2);
            s.selections.add(22 + i);

            SelectionResponseDTO res = selService.insert(s, "localhost");
            Assert.assertNotNull(res);

            if (i % 2 == 0) {
                ProjectListDTO resx = selService.verifySelection(res.id);
                Assert.assertEquals(resx.selection.id, res.id);
                Assert.assertEquals(resx.selection.selections.size(), 3);
            }
        }

        List<SelectionDTO> sel = selService.getAllSelection();
        Assert.assertEquals(sel.size(), 20);
        String st = selService.convertToCsv(sel);
        Assert.assertEquals("s=" + st, st.length(), 1274);

        List<SelectionDTO> hsel = selService.getAllHistorySelection();
        Assert.assertEquals(hsel.size(), 0);
        st = selService.convertToCsv(hsel);
        Assert.assertEquals("s=" + st, st.length(), 73);

        // create a history entry
        SelectionDTO s = new SelectionDTO();
        s.created = new Date();
        s.person = new PersonDTO();
        s.person.name = "b1";
        s.person.surname = "s";
        s.person.clazz = "1a";
        s.person.email = "s@localhost";

        s.selections = new ArrayList<>();
        s.selections.add(21);
        s.selections.add(2);
        s.selections.add(22);
        SelectionResponseDTO res = selService.insert(s, "xyz");
        Assert.assertNotNull(res);

        // check again
        sel = selService.getAllSelection();
        Assert.assertEquals(sel.size(), 20);
        st = selService.convertToCsv(sel);
        Assert.assertTrue("s=" + st.length(), st.length() > 1200 && st.length() < 1320);

        hsel = selService.getAllHistorySelection();
        Assert.assertEquals(hsel.size(), 1);
        Assert.assertEquals((int) hsel.get(0).selections.get(2), 23);
    }

    @Test
    public void insertSelectionDemo() throws IOException {

        // read selections
        List<SelectionDTO> selections;
        try (InputStream in = getClass().getResourceAsStream("/data/selections-demo.csv")) {
            selections = selService.parseSelectionCSV(in);
        }
        Assert.assertEquals(selections.size(), 607);

        // insert all
        for (SelectionDTO s : selections) {
            try {
                Thread.sleep(20);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            selService.insert(s, "import");
        }

        List<SelectionDTO> selections2 = selService.getAllSelection();
        Assert.assertEquals(selections2.size(), 607);

        for (int i = 0; i < 606; i++) {
            Assert.assertEquals("i=" + i, selections.get(i), selections2.get(i));
        }
    }
}
