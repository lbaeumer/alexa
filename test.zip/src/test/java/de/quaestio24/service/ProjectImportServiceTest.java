package de.quaestio24.service;

import com.google.appengine.tools.development.testing.LocalDatastoreServiceTestConfig;
import com.google.appengine.tools.development.testing.LocalServiceTestHelper;
import de.quaestio24.dto.ProjectDTO;
import de.quaestio24.dto.ProjectDTO.ProjectAttribute;
import de.quaestio24.dto.ProjectDetailsDTO;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

public class ProjectImportServiceTest {

    private final LocalServiceTestHelper helper = new LocalServiceTestHelper(new LocalDatastoreServiceTestConfig());
    private ProjectService service = new ProjectService();
    private ProjectImportService importService = new ProjectImportService();

    @Before
    public void setUp() {
        helper.setUp();

        new SiteService().addSite("junit1");

        for (int i = 1; i <= 20; i++) {
            ProjectDTO p = new ProjectDTO();
            p.title = "title" + i;
            p.maxSize = 10;
            p.maxGenderRate = 50;
            p.additional = new HashMap<>();
            p.additional.put(ProjectAttribute.clazz, "1-" + i);
            p.additional.put(ProjectAttribute.costs, "" + (10 + i));
            p.additional.put(ProjectAttribute.room, "r" + i);
            p.additional.put(ProjectAttribute.teacher, "Dumbledore" + i);
            p.details = new ProjectDetailsDTO();
            p.details.description = "This is a cool project " + i;

            service.addProject(p);

            List<ProjectDTO> projList = service.getProjects();
            Assert.assertEquals(i, projList.size());
            for (ProjectDTO x : projList) {
                Assert.assertNull(x.details);
            }

            List<ProjectDTO> projListd = service.getProjectsDetail();
            Assert.assertEquals(i, projList.size());
            for (ProjectDTO x : projListd) {
                Assert.assertNotNull(x.details.description);
            }
        }
    }

    @After
    public void tearDown() {
        helper.tearDown();
    }

    @Test
    public void readAndAddProject() throws IOException {

        // Java -> xls
        byte[] buffer = importService.getAllProjectsXls();
        // Assert.assertEquals(buffer.length, 7680);

        // xls -> Java
        ByteArrayInputStream imgStream = new ByteArrayInputStream(buffer);
        List<ProjectDTO> projects = importService.parseXLS(imgStream);

        check(projects);
    }

    @Test
    public void exportImport() throws IOException {

        // read xls
        byte[] buffer = importService.getAllProjectsXls();
        ByteArrayInputStream imgStream = new ByteArrayInputStream(buffer);

        // delete all projects
        service.deleteAllProjects();
        List<ProjectDTO> projects = service.getProjects();
        Assert.assertEquals(projects.size(), 0);

        // import xls
        importService.importProjectsXLS(imgStream);

        projects = service.getProjects();

        check(projects);
    }

    private void check(List<ProjectDTO> projects) {

        Assert.assertEquals(projects.size(), 20);
        Assert.assertEquals(projects.get(0).title, "title1");
        Assert.assertEquals(projects.get(19).additional.get(ProjectAttribute.clazz), "1 - 20");
        Assert.assertEquals(projects.get(15).additional.get(ProjectAttribute.teacher), "Dumbledore16");
        Assert.assertEquals(projects.get(10).additional.get(ProjectAttribute.room), "r11");
        Assert.assertEquals(projects.get(5).additional.get(ProjectAttribute.costs), "16");
    }
}
