package de.quaestio24.service;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.tools.development.testing.LocalDatastoreServiceTestConfig;
import com.google.appengine.tools.development.testing.LocalServiceTestHelper;
import de.quaestio24.dto.NotificationDTO;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

public class NotificationServiceTest {

    private final LocalServiceTestHelper helper = new LocalServiceTestHelper(new LocalDatastoreServiceTestConfig());
    private NotificationService cs = new NotificationService();

    @Before
    public void setUp() {
        helper.setUp();
        NamespaceManager.set("prjtest");
    }

    @After
    public void tearDown() {
        helper.tearDown();
    }

    @Test
    public void readNotifications() {
        List<NotificationDTO> l = cs.sendNotifications();
        Assert.assertEquals(1, l.size());
    }
}
