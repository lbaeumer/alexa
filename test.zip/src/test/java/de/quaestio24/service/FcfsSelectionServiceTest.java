package de.quaestio24.service;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.tools.development.testing.LocalDatastoreServiceTestConfig;
import com.google.appengine.tools.development.testing.LocalServiceTestHelper;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FcfsSelectionServiceTest {

    private final LocalServiceTestHelper helper = new LocalServiceTestHelper(new LocalDatastoreServiceTestConfig());
    private FcfsSelectionService selService = new FcfsSelectionService();

    @Before
    public void setUp() {
        helper.setUp();

        new SiteService().addSite("junit1");
        NamespaceManager.set("junit1");
    }

    @After
    public void tearDown() {
        helper.tearDown();
    }

    @Test
    public void testEmpty() {
        Map<Integer, List<Integer>> map = selService.getSelections();
        Assert.assertEquals(map.size(), 0);
    }

    @Test
    public void testAdd() {
        for (int projId = 1; projId < 20; projId++) {
            for (int j = 1; j <= 3; j++) {
                selService.saveSelections(projId, (j + projId) * 2, projId);
            }
        }
        List<Integer> v = selService.getSelections(7);
        Assert.assertEquals(v.get(0).intValue(), 8 * 2 + 9 * 2 + 10 * 2);
        Assert.assertEquals(v.get(1).intValue(), 3 * 7);

        Map<Integer, List<Integer>> map;
        map = selService.getSelections();
        Assert.assertEquals(map.get(1).get(0).intValue(), 2 * 2 + 3 * 2 + 4 * 2);
        Assert.assertEquals(map.get(5).get(0).intValue(), 6 * 2 + 7 * 2 + 8 * 2);
        Assert.assertEquals(map.get(15).get(0).intValue(), 16 * 2 + 17 * 2 + 18 * 2);
        Assert.assertEquals(map.get(7).get(0).intValue(), 8 * 2 + 9 * 2 + 10 * 2);
        Assert.assertEquals(map.get(7).get(1).intValue(), 21);

        Assert.assertNull(map.get(20));
    }

    @Test
    public void testAddAndDelete() {
        Map<Integer, List<Integer>> map = selService.getSelections();
        Assert.assertEquals(map.size(), 0);

        for (int i = 0; i < 20; i++) {
            selService.saveSelections(i % 5, 1, 2);
            selService.saveSelections(i % 5, 1, 2);
            selService.saveSelections(i % 5, -2, -4);
        }

        map = selService.getSelections();
        Assert.assertEquals(map.size(), 5);
        for (Map.Entry<Integer, List<Integer>> e : map.entrySet()) {
            Assert.assertEquals("m=" + map, e.getValue().get(0).intValue(), 0);
            Assert.assertEquals("m=" + map, e.getValue().get(1).intValue(), 0);
        }
    }

    @Test
    public void testDelta() {
        Map<Integer, List<Integer>> m1 = new HashMap<>();
        Map<Integer, List<Integer>> m2 = new HashMap<>();
        Map<Integer, List<Integer>> delta;

        m1.put(1, Arrays.asList(2, 1));
        delta = selService.calculateDelta(m1, m2);
        Assert.assertEquals(delta.size(), 1);
        Assert.assertEquals(delta.get(1).get(0).intValue(), 2);
        Assert.assertEquals(delta.get(1).get(1).intValue(), 1);

        m2.put(1, Arrays.asList(3, 5));
        delta = selService.calculateDelta(m1, m2);
        Assert.assertEquals(delta.size(), 1);
        Assert.assertEquals(delta.get(1).get(0).intValue(), -1);
        Assert.assertEquals(delta.get(1).get(1).intValue(), -4);

        m2.put(2, Arrays.asList(1, 5));
        m2.put(3, Arrays.asList(4, 6));
        delta = selService.calculateDelta(m1, m2);
        Assert.assertEquals(delta.size(), 3);
        Assert.assertEquals(delta.get(1).get(0).intValue(), -1);
        Assert.assertEquals(delta.get(1).get(1).intValue(), -4);
        Assert.assertEquals(delta.get(2).get(0).intValue(), -1);
        Assert.assertEquals(delta.get(2).get(1).intValue(), -5);
        Assert.assertEquals(delta.get(3).get(0).intValue(), -4);
        Assert.assertEquals(delta.get(3).get(1).intValue(), -6);

        m1.put(4, Arrays.asList(3, 6));
        delta = selService.calculateDelta(m1, m2);
        Assert.assertEquals(delta.size(), 4);
        Assert.assertEquals(delta.get(1).get(0).intValue(), -1);
        Assert.assertEquals(delta.get(2).get(0).intValue(), -1);
        Assert.assertEquals(delta.get(3).get(0).intValue(), -4);
        Assert.assertEquals(delta.get(4).get(0).intValue(), 3);
        Assert.assertEquals(delta.get(4).get(1).intValue(), 6);
    }
}
