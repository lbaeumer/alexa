package de.quaestio24.service;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.tools.development.testing.LocalDatastoreServiceTestConfig;
import com.google.appengine.tools.development.testing.LocalServiceTestHelper;
import de.quaestio24.dto.CodeDTO;
import de.quaestio24.dto.PersonDTO;
import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.dto.PreferencesDTO.DesignParameter;
import de.quaestio24.dto.PreferencesDTO.Parameter;
import de.quaestio24.dto.ProjectDTO;
import de.quaestio24.dto.SelectionDTO;
import de.quaestio24.dto.SelectionResponseDTO;
import de.quaestio24.dto.ValidationDTO;
import de.quaestio24.exception.ValidationException;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RunWith(MockitoJUnitRunner.class)
public class SelectionServiceCodeTest {

    private final LocalServiceTestHelper helper = new LocalServiceTestHelper(new LocalDatastoreServiceTestConfig());

    @InjectMocks
    private SelectionService selService;

    @Mock
    private PreferencesService preferenceService;

    private CodeService codeService = new CodeService();

    @Before
    public void setUp() {
        helper.setUp();

        long now = System.currentTimeMillis();
        PreferencesDTO pref = new PreferencesDTO();
        pref.parameter = new Parameter();
        pref.anonymous = true;
        pref.startDate = new Date(now);
        pref.endDate = new Date(now + 100000);
        Mockito.when(preferenceService.getPreference()).thenReturn(pref);
    }

    @After
    public void tearDown() {
        helper.tearDown();
    }

    @Test
    public void validateCodeSelection() {
        SelectionDTO sel = new SelectionDTO();
        sel.person = new PersonDTO();
        sel.person.code = "B1";
        sel.selections = new ArrayList<>();
        sel.selections.add(1);
        sel.selections.add(2);
        sel.selections.add(3);
        PreferencesDTO pr = new PreferencesDTO();
        pr.design = new DesignParameter();
        pr.design.minSelections = 3;
        pr.parameter = new Parameter();
        pr.anonymous = true;
        selService.validate(sel, pr);
    }

    @Test
    public void selectionTest() {

        List<CodeDTO> codes = new ArrayList<>();
        for (int i = 1; i <= 20; i++) {
            CodeDTO c = new CodeDTO();
            c.code = "b" + i;
            c.clazz = "b" + (i % 10);
            codes.add(c);
        }

        codeService.insertCodes(codes);

        List<SelectionDTO> selections = selService.getAllSelection();
        Assert.assertEquals(selections.size(), 0);

        List<String> selectionIds = new ArrayList<>();

        for (int i = 1; i <= 20; i++) {
            SelectionDTO s = new SelectionDTO();
            s.created = new Date();
            s.person = new PersonDTO();
            s.person.code = "b" + i;

            s.selections = new ArrayList<>();
            s.selections.add(21);
            s.selections.add(2);
            s.selections.add(22 + i);

            SelectionResponseDTO res = selService.insert(s, "localhost");
            Assert.assertNotNull(res);

            selectionIds.add(res.id);
        }

        // getAllSelections
        selections = selService.getAllSelection();
        Assert.assertEquals(selections.size(), 20);

        // getSelectionCount
        List<Integer> sc = selService.getSelectionCount();
        Assert.assertEquals((int) sc.get(0), 20);
        Assert.assertEquals((int) sc.get(1), 0);

        // getSelection
        SelectionDTO sel = selService.getSelection(selectionIds.get(0));
        Assert.assertNotNull(sel);
        Assert.assertEquals(sel.id, selectionIds.get(0));

        // deleteSelection
        selService.deleteSelection(selectionIds.get(0));
        selections = selService.getAllSelection();
        Assert.assertEquals(selections.size(), 19);

        // deleteAllSelection
        selService.deleteAllSelection();
        selections = selService.getAllSelection();
        Assert.assertEquals(selections.size(), 0);
    }

    @Test
    public void updateSelectionTest() {

        List<CodeDTO> codes = new ArrayList<>();
        for (int i = 1; i <= 20; i++) {
            CodeDTO c = new CodeDTO();
            c.code = "b" + i;
            c.clazz = "b" + (i % 10);
            codes.add(c);
        }

        codeService.insertCodes(codes);

        List<SelectionDTO> selections = selService.getAllSelection();
        Assert.assertEquals(selections.size(), 0);

        // insert selections
        for (int i = 1; i <= 20; i++) {
            SelectionDTO s = new SelectionDTO();
            s.created = new Date();
            s.person = new PersonDTO();
            s.person.code = "b" + i;

            s.selections = new ArrayList<>();
            s.selections.add(21 + i);
            s.selections.add(2 + i);
            s.selections.add(5 + i);

            SelectionResponseDTO res = selService.insert(s, "localhost");
            Assert.assertNotNull(res);
        }

        // getAllSelections
        List<SelectionDTO> origSel = selService.getAllSelection();

        selections = selService.getAllSelection();
        Assert.assertEquals(selections.size(), 20);

        Map<String, SelectionDTO> map = new HashMap<>();
        for (SelectionDTO s : selections) {
            map.put(s.person.code, s);
        }
        Assert.assertEquals(map.size(), 20);

        // lookup code selection
        SelectionDTO sCode = map.get("b7");
        Assert.assertEquals(sCode.person.code, "b7");
        Assert.assertNull(sCode.person.name);
        Assert.assertNull(sCode.person.surname);
        Assert.assertEquals(sCode.person.clazz, "b7");
        Assert.assertNull(sCode.person.email);
        Assert.assertEquals(sCode.id, "61dd5156a305ce72a31043aa7e06d854");
        Assert.assertEquals((int) sCode.selections.get(0), 28);
        Assert.assertEquals((int) sCode.selections.get(2), 12);

        Assert.assertEquals(origSel, selections);
    }

    @Test
    public void selectionCodeTest() {
        List<CodeDTO> codes = new ArrayList<>();
        CodeDTO c = new CodeDTO();
        c.code = "5b125";
        c.clazz = "5b";
        codes.add(c);
        c = new CodeDTO();
        c.code = "6b130";
        c.clazz = "6b";
        codes.add(c);
        c = new CodeDTO();
        c.code = "7b135";
        c.clazz = "7b";
        codes.add(c);
        c = new CodeDTO();
        c.code = "8b140";
        c.clazz = "8b";
        codes.add(c);
        c = new CodeDTO();
        c.code = "9b145";
        c.clazz = "9b";
        codes.add(c);
        codeService.insertCodes(codes);

        List<SelectionDTO> selections = selService.getAllSelection();
        Assert.assertEquals(selections.size(), 0);

        List<String> selectionIds = new ArrayList<>();

        for (int i = 5; i <= 9; i++) {
            SelectionDTO s = new SelectionDTO();
            s.created = new Date();
            s.person = new PersonDTO();
            s.person.code = i + (i % 2 == 0 ? "b" : "B") + (100 + 5 * i);
            s.selections = new ArrayList<>();
            s.selections.add(21 + i);
            s.selections.add(2 + i);
            s.selections.add(i + i);

            SelectionResponseDTO res = selService.insert(s, "localhost");
            Assert.assertNotNull(res);

            selectionIds.add(res.id);
        }

        System.out.println("selectionIds=" + selectionIds);
        // getAllSelections
        selections = selService.getAllSelection();
        Assert.assertEquals(selections.size(), 5);

        // check ok
        ValidationDTO v = selService.isCodeValid("5b125");
        Assert.assertNotNull(v);
        ValidationDTO v1 = selService.isCodeValid("5B125");
        Assert.assertNotNull(v1);
        Assert.assertEquals(v.selection.person.clazz, v1.selection.person.clazz);
        Assert.assertEquals(v.selection.person.code, "5b125");
        Assert.assertEquals(v1.selection.person.code, "5B125");

        Assert.assertEquals("selection=" + v.selection, v.selection.person.code, "5b125");
        Assert.assertEquals("selection=" + v.selection, v.selection.selections.get(0).intValue(), 26);

        v = selService.isCodeValid("8b140");
        Assert.assertNotNull(v);
        Assert.assertEquals("selection=" + v.selection, v.selection.person.code, "8b140");
        Assert.assertEquals("selection=" + v.selection, v.selection.selections.get(0).intValue(), 29);
    }

    @Test(expected = ValidationException.class)
    public void insertCodeSelectionNoCode() throws IOException {

        // read codes
        List<SelectionDTO> selections;
        try (InputStream in = getClass().getResourceAsStream("/data/selections-demo2.csv")) {
            selections = selService.parseSelectionCSV(in);
        }
        Assert.assertEquals(selections.size(), 607);

        SelectionDTO s = selections.get(0);
        selService.insert(s, "import");
    }

    @Test
    public void insertCodeSelectionDemo2() throws IOException {

        // read selections
        List<SelectionDTO> selections;
        try (InputStream in = getClass().getResourceAsStream("/data/selections-demo2.csv")) {
            selections = selService.parseSelectionCSV(in);
        }
        Assert.assertEquals(selections.size(), 607);

        // read codes
        List<CodeDTO> codes;
        try (InputStream in = getClass().getResourceAsStream("/data/codes-demo2.csv")) {
            codes = codeService.parseCodeCSV(in);
        }
        codeService.insertCodes(codes);

        Assert.assertEquals(codes.size(), 607);

        // insert all
        for (SelectionDTO s : selections) {
            selService.insert(s, "import");
        }

        List<SelectionDTO> selections2 = selService.getAllSelection();
        Assert.assertEquals(selections2.size(), 607);

        Assert.assertEquals(selections, selections2);
    }

    @Test(expected = ValidationException.class)
    public void selectionCodeTestFailed() {
        List<SelectionDTO> selections = selService.getAllSelection();
        Assert.assertEquals(selections.size(), 0);

        List<String> selectionIds = new ArrayList<>();

        int i = 5;
        SelectionDTO s = new SelectionDTO();
        s.created = new Date();
        s.person = new PersonDTO();
        s.person.code = i + "b" + (100 + 5 * i) + "  ";
        s.selections = new ArrayList<>();
        s.selections.add(21 + i);
        s.selections.add(2 + i);
        s.selections.add(i + i);

        SelectionResponseDTO res = selService.insert(s, "localhost");
        Assert.assertNotNull(res);

        selectionIds.add(res.id);

        System.out.println("selectionIds=" + selectionIds);
        // getAllSelections
        selections = selService.getAllSelection();
        Assert.assertEquals(selections.size(), 5);

        // check ok
        selService.isCodeValid("5b125b");
    }

    @Test
    public void getDemoStatusProjects() {
        NamespaceManager.set("prjtest");
        ProjectService projectService = new ProjectService();
        List<ProjectDTO> projects = projectService.getProjects();
        projectService.addStatus(projects);
        Assert.assertEquals(projects.size(), 12);

        Assert.assertNull(projects.get(0).status);
        Assert.assertEquals(projects.get(0).maxSize, 30);
        Assert.assertNull(projects.get(1).status);
        Assert.assertEquals(projects.get(1).maxSize, 32);
        Assert.assertNull(projects.get(2).status);
        Assert.assertEquals(projects.get(2).maxSize, 34);

        PreferencesService preferencesService = new PreferencesService();
        PreferencesDTO pref = preferencesService.getPreference();

        Date now = new Date();
        Assert.assertTrue(pref.endDate.after(now));
        Assert.assertTrue(pref.startDate.before(now));

        // import codes
        List<CodeDTO> codes = new ArrayList<>();
        for (int i = 100; i < 900; i++) {
            CodeDTO c = new CodeDTO();
            c.clazz = "" + i;
            c.code = "xxx" + i;
            codes.add(c);
        }
        codeService.insertCodes(codes);

        // insert selections
        SelectionService selectionService = new SelectionService();
        int cxx = 0;

        List<SelectionDTO> selections = new ArrayList<>();
        // fill project1 completely
        for (int i = 0; i < projects.get(0).maxSize; i++) {
            SelectionDTO s = new SelectionDTO();
            s.person = new PersonDTO();
            s.person.code = codes.get(cxx++).code;
            s.selections = Arrays.asList(projects.get(0).id, projects.get(1).id, projects.get(2).id);
            selections.add(s);
        }

        for (int i = 0; i < projects.get(1).maxSize - 1; i++) {
            SelectionDTO s = new SelectionDTO();
            s.person = new PersonDTO();
            s.person.code = codes.get(cxx++).code;
            s.selections = Arrays.asList(projects.get(1).id, projects.get(2).id, projects.get(3).id);
            selections.add(s);
        }
        for (int i = 0; i < projects.get(2).maxSize - 5; i++) {
            SelectionDTO s = new SelectionDTO();
            s.person = new PersonDTO();
            s.person.code = codes.get(cxx++).code;
            s.selections = Arrays.asList(projects.get(2).id, projects.get(3).id, projects.get(4).id);
            selections.add(s);
        }
        for (int i = 0; i < projects.get(3).maxSize - 8; i++) {
            SelectionDTO s = new SelectionDTO();
            s.person = new PersonDTO();
            s.person.code = codes.get(cxx++).code;
            s.selections = Arrays.asList(projects.get(3).id, projects.get(4).id, projects.get(5).id);
            selections.add(s);
        }
        selectionService.insertSelections(selections);

        // set end
        pref.endDate2 = pref.endDate;
        pref.endDate = now;
        pref.startDate2 = now;
        pref.includeStatus = true;
        preferencesService.updatePreference(pref);

        // read projects
        projects = projectService.getProjects();
        projectService.addStatus(projects);
        Assert.assertEquals(projects.size(), 12);

        Assert.assertEquals((int) projects.get(0).status, 2);
        Assert.assertEquals((int) projects.get(1).status, 1);
        Assert.assertEquals((int) projects.get(2).status, 1);
    }

    @Test
    public void importCodes() throws IOException {

        List<CodeDTO> codes;
        try (InputStream in = getClass().getResourceAsStream("/data/codes.csv")) {
            codes = codeService.parseCodeCSV(in);
        }
        codeService.insertCodes(codes);

        Assert.assertEquals(codes.size(), 7);

        Assert.assertEquals(selService.isCodeValid("5a12345").selection.person.code, "5a12345");
        Assert.assertEquals(selService.isCodeValid("5A12345").selection.person.code, "5A12345");
        Assert.assertEquals(selService.isCodeValid("5a12345").selection.person.clazz, "5a");
        Assert.assertEquals(selService.isCodeValid("5A12345").selection.person.clazz, "5a");
    }

    @Test
    public void checkClassMatch() {
        Assert.assertTrue(selService.isClazzMatch(null, "5a"));
        Assert.assertTrue(selService.isClazzMatch("5", "5d"));
        Assert.assertTrue(selService.isClazzMatch("5,", "5d"));
        Assert.assertTrue(selService.isClazzMatch("5-7,", "5a"));
        Assert.assertTrue(selService.isClazzMatch("5-7", "6b"));
        Assert.assertTrue(selService.isClazzMatch("5.,", "5d"));
        Assert.assertTrue(selService.isClazzMatch("5.-7.,", "5a"));
        Assert.assertTrue(selService.isClazzMatch("5. -7.", "6b"));
        Assert.assertTrue(selService.isClazzMatch("5-7", " 7A "));
        Assert.assertTrue(selService.isClazzMatch("5- Q1", "EF"));
        Assert.assertTrue(selService.isClazzMatch("5- Q1", "10A"));
        Assert.assertTrue(selService.isClazzMatch("5- 9,EF, Q1", "10A"));
        Assert.assertTrue(selService.isClazzMatch("8 -Q2", "8a"));
        Assert.assertTrue(selService.isClazzMatch("EF,Q1", "EF "));
        Assert.assertTrue(selService.isClazzMatch("EF,", "10d "));
        Assert.assertTrue(selService.isClazzMatch("EF, Q1", "10a "));
        Assert.assertTrue(selService.isClazzMatch("EF ,Q1", "EF "));
        Assert.assertTrue(selService.isClazzMatch("EF - Q1", "10a "));
        Assert.assertTrue(selService.isClazzMatch("8,9,EF - Q1", "9a "));
        Assert.assertTrue(selService.isClazzMatch("7, EF - Q1, q2", "q2 "));
    }

    @Test
    public void checkClassNoMatch() {
        Assert.assertFalse(selService.isClazzMatch("5", null));
        Assert.assertFalse(selService.isClazzMatch("7 ", "8a"));
        Assert.assertFalse(selService.isClazzMatch("5-7", "8a"));
        Assert.assertFalse(selService.isClazzMatch(", 5  -7,10-q2", "9b"));
        Assert.assertFalse(selService.isClazzMatch(" 5  -7,", "9b"));
        Assert.assertFalse(selService.isClazzMatch("5-7", " 4A "));
        Assert.assertFalse(selService.isClazzMatch("5- Q1", "q2"));
        Assert.assertFalse(selService.isClazzMatch(",5- Q1", "4a"));
        Assert.assertFalse(selService.isClazzMatch("8 -Q2,", "7e"));
        Assert.assertFalse(selService.isClazzMatch("8,10 -Q2", "7e"));
        Assert.assertFalse(selService.isClazzMatch("8,10 -Q2", "9e "));
        Assert.assertFalse(selService.isClazzMatch("7 -10,Q2", "q1 "));
    }
}
