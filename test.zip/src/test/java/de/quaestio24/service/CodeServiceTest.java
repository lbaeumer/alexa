package de.quaestio24.service;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.tools.development.testing.LocalDatastoreServiceTestConfig;
import com.google.appengine.tools.development.testing.LocalServiceTestHelper;
import de.quaestio24.dto.CodeDTO;
import de.quaestio24.dto.CodeStatDTO;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class CodeServiceTest {

    private final LocalServiceTestHelper helper = new LocalServiceTestHelper(new LocalDatastoreServiceTestConfig());

    private CodeService codeService = new CodeService();

    @Before
    public void setUp() {
        helper.setUp();
        new SiteService().addSite("junit1");
        NamespaceManager.set("junit1");
    }

    @After
    public void tearDown() {
        helper.tearDown();
    }

    @Test
    public void insertCodes() {
        List<CodeDTO> codes = new ArrayList<>();

        for (int i = 1; i <= 10; i++) {
            CodeDTO c = new CodeDTO();
            c.code = "hallo" + i;
            c.clazz = "ha";
            codes.add(c);
        }

        codeService.insertCodes(codes);

        List<CodeDTO> codes2 = codeService.getCodes();

        Assert.assertEquals(codes, codes2);
    }

    @Test
    public void insertCodeSelectionXls() throws IOException {

        // read codes
        List<CodeDTO> codes;
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (InputStream in = getClass().getResourceAsStream("/data/codes-demox.xlsx")) {
            int i;
            byte[] buffer = new byte[1024];
            while ((i = in.read(buffer)) > 0) {
                out.write(buffer, 0, i);
            }
        }
        out.flush();
        codes = codeService.parseCodeXLS(out.toByteArray());
        codeService.insertCodes(codes);

        Assert.assertEquals(codes.size(), 774);
    }

    @Test
    public void addCode() {
        List<CodeDTO> codes = codeService.getCodes();
        Assert.assertEquals(codes.size(), 0);

        List<CodeDTO> cs = new ArrayList<>();
        CodeDTO c = new CodeDTO();
        c.clazz = "c1";
        c.code = "1234567";
        cs.add(c);

        c = new CodeDTO();
        c.clazz = "c2";
        c.code = "1234568";
        cs.add(c);

        CodeStatDTO stats = codeService.insertCodes(cs);
        Assert.assertEquals(stats.addedCodes, 2);
        Assert.assertEquals(stats.removedCodes, 0);

        // add code
        c = new CodeDTO();
        c.clazz = "clz";
        c.code = "1234569";
        codeService.addCode(c);

        codes = codeService.getCodes();
        Assert.assertEquals(codes.size(), 3);
        Assert.assertEquals(c, codes.get(2));
    }

    @Test
    public void deleteCode() {
        List<CodeDTO> codes = codeService.getCodes();
        Assert.assertEquals(codes.size(), 0);

        List<CodeDTO> cs = new ArrayList<>();
        CodeDTO c = new CodeDTO();
        c.clazz = "c1";
        c.code = "1234567";
        cs.add(c);

        c = new CodeDTO();
        c.clazz = "c2";
        c.code = "1234568";
        cs.add(c);

        CodeStatDTO stats = codeService.insertCodes(cs);
        Assert.assertEquals(stats.addedCodes, 2);
        Assert.assertEquals(stats.removedCodes, 0);

        // add code
        c = new CodeDTO();
        c.clazz = "c2";
        c.code = "1234568";

        codes = codeService.deleteCode(c);

        Assert.assertEquals(codes.size(), 1);
    }
}
