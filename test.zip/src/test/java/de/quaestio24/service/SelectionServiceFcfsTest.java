package de.quaestio24.service;

import com.google.appengine.tools.development.testing.LocalDatastoreServiceTestConfig;
import com.google.appengine.tools.development.testing.LocalServiceTestHelper;
import com.google.gson.Gson;
import de.quaestio24.dao.ProjectDAO;
import de.quaestio24.dto.CodeDTO;
import de.quaestio24.dto.PersonDTO;
import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.dto.PreferencesDTO.Parameter;
import de.quaestio24.dto.ProjectDTO;
import de.quaestio24.dto.ProjectPackageDTO;
import de.quaestio24.dto.SelectionDTO;
import de.quaestio24.dto.SelectionResponseDTO;
import de.quaestio24.service.dto.AssignedProjectListIntDTO;
import de.quaestio24.service.strategy.AssignmentStrategy;
import de.quaestio24.service.strategy.FirstComeFirstServeAssignmentStrategy;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.LogManager;

import static de.quaestio24.dto.PreferencesDTO.StrategyEnum.fcfs;

@RunWith(MockitoJUnitRunner.class)
public class SelectionServiceFcfsTest {

    private final LocalServiceTestHelper helper = new LocalServiceTestHelper(new LocalDatastoreServiceTestConfig());

    private SelectionService selService = new SelectionService();

    private PreferencesService preferenceService = new PreferencesService();

    private CodeService codeService = new CodeService();

    private ProjectService projectService = new ProjectService();

    private FcfsSelectionService fcfsSelectionService = new FcfsSelectionService();

    @Before
    public void setUp() throws IOException {
        //LogManager.getLogManager().readConfiguration(this.getClass().getResourceAsStream("/logging.properties"));
        helper.setUp();

        long now = System.currentTimeMillis();
        PreferencesDTO pref = new PreferencesDTO();
        pref.parameter = new Parameter();
        pref.anonymous = true;
        pref.parameter.strategy = fcfs;
        pref.parameter.randomize = false;
        pref.startDate = new Date(now);
        pref.endDate = new Date(now + 100000);
        preferenceService.updatePreference(pref);

        // codes B1 (class 1), B2 (class 2), B3, ... B10 (class 10),
        List<CodeDTO> codes = new ArrayList<>();
        for (int i = 1; i <= 100; i++) {
            CodeDTO c = new CodeDTO();
            c.code = "B" + i;
            c.clazz = "" + (1 + ((i - 1) % 10)); // 1, ... 10
            codes.add(c);
        }
        codeService.insertCodes(codes);

        // p1, ... p100
        List<ProjectDTO> projects = new ArrayList<>();
        for (int i = 1; i <= 100; i++) {
            ProjectDTO p = new ProjectDTO();
            p.id = i;
            p.maxSize = 10;
            p.title = "p" + i;
            p.maxGenderRate = 100;
            p.additional = new HashMap<>();
            p.additional.put(ProjectDTO.ProjectAttribute.clazz, "1 - EF");

            projects.add(p);
        }
        projectService.addProjects(projects, false);

    }

    @After
    public void tearDown() {
        helper.tearDown();
    }

    @Test
    public void validateSingleCodeSelection() {
        SelectionDTO sel = new SelectionDTO();
        sel.person = new PersonDTO();
        sel.selections = new ArrayList<>();
        sel.selections.add(1);
        sel.selections.add(2);
        sel.selections.add(3);

        SelectionResponseDTO res;
        Map<Integer, List<Integer>> selectionStats = fcfsSelectionService.getSelections();
        Assert.assertEquals(selectionStats.size(), 0);

        // insert selection 1
        sel.person.code = "B1";
        res = selService.insert(sel, "import");
        Assert.assertEquals(res.person.code, "B1");
        Assert.assertEquals(res.person.clazz, "1");
        Assert.assertEquals(res.projects.size(), 3);
        Assert.assertEquals(res.projects.get(0).title, "p1");

        selectionStats = fcfsSelectionService.getSelections();
        Assert.assertEquals(selectionStats.get(1).get(0).intValue(), 1);
        Assert.assertEquals(selectionStats.get(1).get(1).intValue(), 0);
        Assert.assertNull(selectionStats.get(2));

        // insert selection 2
        sel.person.code = "B2";
        res = selService.insert(sel, "import");
        Assert.assertEquals(res.person.code, "B2");
        Assert.assertEquals(res.person.clazz, "2");
        Assert.assertEquals(res.projects.size(), 3);
        Assert.assertEquals(res.projects.get(0).title, "p1");

        selectionStats = fcfsSelectionService.getSelections();
        Assert.assertEquals(selectionStats.get(1).get(0).intValue(), 2);
        Assert.assertEquals(selectionStats.get(1).get(1).intValue(), 0);
        Assert.assertNull(selectionStats.get(2));

        // insert selection 3
        sel.person.code = "B3";
        res = selService.insert(sel, "import");
        Assert.assertEquals(res.person.code, "B3");
        Assert.assertEquals(res.person.clazz, "3");
        Assert.assertEquals(res.projects.size(), 3);
        Assert.assertEquals(res.projects.get(0).title, "p1");

        selectionStats = fcfsSelectionService.getSelections();
        Assert.assertEquals(selectionStats.get(1).get(0).intValue(), 3);
        Assert.assertEquals(selectionStats.get(1).get(1).intValue(), 0);
        Assert.assertNull(selectionStats.get(2));

        // insert selection 1 again
        sel.person.code = "B1";
        sel.selections.set(0, 4);
        res = selService.insert(sel, "import");
        Assert.assertEquals(res.person.code, "B1");
        Assert.assertEquals(res.person.clazz, "1");
        Assert.assertEquals(res.projects.size(), 3);
        Assert.assertEquals(res.projects.get(0).title, "p4");

        selectionStats = fcfsSelectionService.getSelections();
        Assert.assertEquals(selectionStats.get(1).get(0).intValue(), 2);
        Assert.assertEquals(selectionStats.get(4).get(0).intValue(), 1);
        Assert.assertNull(selectionStats.get(2));

        // insert selection 1 again
        sel.person.code = "B1";
        sel.selections.set(0, 5);
        res = selService.insert(sel, "import");
        Assert.assertEquals(res.person.code, "B1");
        Assert.assertEquals(res.person.clazz, "1");
        Assert.assertEquals(res.projects.size(), 3);
        Assert.assertEquals(res.projects.get(0).title, "p5");

        selectionStats = fcfsSelectionService.getSelections();
        Assert.assertEquals(selectionStats.get(1).get(0).intValue(), 2);
        Assert.assertEquals(selectionStats.get(1).get(1).intValue(), 0);
        Assert.assertEquals(selectionStats.get(5).get(0).intValue(), 1);
        Assert.assertEquals(selectionStats.get(5).get(1).intValue(), 0);
        Assert.assertNull(selectionStats.get(2));
        Assert.assertEquals(selectionStats.get(4).get(0).intValue(), 0);

        // insert selection 4
        sel.person.code = "B4";
        sel.selections.set(0, 5);
        res = selService.insert(sel, "import");
        Assert.assertEquals(res.person.code, "B4");
        Assert.assertEquals(res.person.clazz, "4");
        Assert.assertEquals(res.projects.size(), 3);
        Assert.assertEquals(res.projects.get(0).title, "p5");

        selectionStats = fcfsSelectionService.getSelections();
        Assert.assertEquals(selectionStats.get(1).get(0).intValue(), 2);
        Assert.assertEquals(selectionStats.get(5).get(0).intValue(), 2);
        Assert.assertNull(selectionStats.get(2));
        Assert.assertEquals(selectionStats.get(4).get(0).intValue(), 0);
    }

    @Test
    public void validateMassCodeSelection() {

        SelectionResponseDTO res;
        Map<Integer, List<Integer>> selectionStats = fcfsSelectionService.getSelections();
        Assert.assertEquals(selectionStats.size(), 0);

        // enter first 12 selections
        for (int i = 0; i < 12; i++) {
            SelectionDTO sel = new SelectionDTO();
            sel.person = new PersonDTO();
            sel.selections = new ArrayList<>();
            sel.selections.add(1);
            sel.selections.add(2);
            sel.selections.add(3);
            sel.person.code = "B" + (i + 1);

            res = selService.insert(sel, "import");
            Assert.assertEquals(res.person.code, "B" + (i + 1));
            Assert.assertEquals(res.projects.size(), 3);
            Assert.assertEquals(res.projects.get(0).title, "p1");
        }

        Map<Integer, List<Integer>> syncMap = fcfsSelectionService.sync(true);
        Assert.assertEquals("syncMap=" + syncMap, syncMap.size(), 0);

        selectionStats = fcfsSelectionService.getSelections();
        Assert.assertEquals("stats=" + selectionStats, selectionStats.size(), 2);
        Assert.assertEquals(selectionStats.get(1).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(2).get(0).intValue(), 2);

        // enter next 12 selections
        for (int i = 12; i < 24; i++) {
            SelectionDTO sel = new SelectionDTO();
            sel.person = new PersonDTO();
            sel.selections = new ArrayList<>();
            sel.selections.add(2);
            sel.selections.add(3);
            sel.selections.add(4);
            sel.person.code = "B" + (i + 1);

            res = selService.insert(sel, "import");
            Assert.assertEquals(res.person.code, "B" + (i + 1));
            Assert.assertEquals(res.projects.size(), 3);
            Assert.assertEquals(res.projects.get(0).title, "p2");
        }

        syncMap = fcfsSelectionService.sync(true);
        Assert.assertEquals("syncMap=" + syncMap, syncMap.size(), 0);

        selectionStats = fcfsSelectionService.getSelections();
        Assert.assertEquals("stats=" + selectionStats, selectionStats.size(), 3);
        Assert.assertEquals(selectionStats.get(1).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(1).get(1).intValue(), 2);
        Assert.assertEquals(selectionStats.get(2).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(2).get(1).intValue(), 4);
        Assert.assertEquals(selectionStats.get(3).get(0).intValue(), 4);
        Assert.assertEquals(selectionStats.get(3).get(1).intValue(), 0);

        // enter next 12 selections
        for (int i = 24; i < 36; i++) {
            SelectionDTO sel = new SelectionDTO();
            sel.person = new PersonDTO();
            sel.selections = new ArrayList<>();
            sel.selections.add(3);
            sel.selections.add(4);
            sel.selections.add(5);
            sel.person.code = "B" + (i + 1);

            res = selService.insert(sel, "import");
            Assert.assertEquals(res.person.code, "B" + (i + 1));
            Assert.assertEquals(res.projects.size(), 3);
            Assert.assertEquals(res.projects.get(0).title, "p3");
        }

        syncMap = fcfsSelectionService.sync(true);
        Assert.assertEquals("syncMap=" + syncMap, syncMap.size(), 0);

        selectionStats = fcfsSelectionService.getSelections();
        Assert.assertEquals("stats=" + selectionStats, selectionStats.size(), 4);
        Assert.assertEquals(selectionStats.get(1).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(2).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(3).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(4).get(0).intValue(), 6);
        Assert.assertEquals(selectionStats.get(4).get(1).intValue(), 0);

        // enter next 12 selections
        for (int i = 36; i < 48; i++) {
            SelectionDTO sel = new SelectionDTO();
            sel.person = new PersonDTO();
            sel.selections = new ArrayList<>();
            sel.selections.add(4);
            sel.selections.add(5);
            sel.selections.add(6);
            sel.person.code = "B" + (i + 1);

            res = selService.insert(sel, "import");
            Assert.assertEquals(res.person.code, "B" + (i + 1));
            Assert.assertEquals(res.projects.size(), 3);
            Assert.assertEquals(res.projects.get(0).title, "p4");
        }

        syncMap = fcfsSelectionService.sync(true);
        Assert.assertEquals("syncMap=" + syncMap, syncMap.size(), 0);

        selectionStats = fcfsSelectionService.getSelections();
        Assert.assertEquals("stats=" + selectionStats, selectionStats.size(), 5);
        Assert.assertEquals(selectionStats.get(1).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(2).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(3).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(4).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(4).get(1).intValue(), 8);
        Assert.assertEquals(selectionStats.get(5).get(0).intValue(), 8);
        Assert.assertEquals(selectionStats.get(5).get(1).intValue(), 0);

        // enter next 12 selections
        for (int i = 48; i < 60; i++) {
            SelectionDTO sel = new SelectionDTO();
            sel.person = new PersonDTO();
            sel.selections = new ArrayList<>();
            sel.selections.add(5);
            sel.selections.add(6);
            sel.selections.add(7);
            sel.person.code = "B" + (i + 1);

            res = selService.insert(sel, "import");
            Assert.assertEquals(res.person.code, "B" + (i + 1));
            Assert.assertEquals(res.projects.size(), 3);
            Assert.assertEquals(res.projects.get(0).title, "p5");
        }

        syncMap = fcfsSelectionService.sync(true);
        Assert.assertEquals("syncMap=" + syncMap, syncMap.size(), 0);

        selectionStats = fcfsSelectionService.getSelections();
        Assert.assertEquals("stats=" + selectionStats, selectionStats.size(), 6);
        Assert.assertEquals(selectionStats.get(1).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(2).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(3).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(4).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(5).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(5).get(1).intValue(), 10);
        Assert.assertEquals(selectionStats.get(6).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(6).get(1).intValue(), 0);

        // enter next 12 selections
        for (int i = 60; i < 72; i++) {
            SelectionDTO sel = new SelectionDTO();
            sel.person = new PersonDTO();
            sel.selections = new ArrayList<>();
            sel.selections.add(7);
            sel.selections.add(8);
            sel.selections.add(9);
            sel.person.code = "B" + (i + 1);

            res = selService.insert(sel, "import");
            Assert.assertEquals(res.person.code, "B" + (i + 1));
            Assert.assertEquals(res.projects.size(), 3);
            Assert.assertEquals(res.projects.get(0).title, "p7");
        }

        syncMap = fcfsSelectionService.sync(true);
        Assert.assertEquals("syncMap=" + syncMap, syncMap.size(), 0);

        selectionStats = fcfsSelectionService.getSelections();
        Assert.assertEquals("stats=" + selectionStats, selectionStats.size(), 8);
        Assert.assertEquals(selectionStats.get(1).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(2).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(3).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(4).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(5).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(6).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(7).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(7).get(1).intValue(), 2);
        Assert.assertEquals(selectionStats.get(8).get(0).intValue(), 2);
        Assert.assertEquals(selectionStats.get(8).get(1).intValue(), 0);

        // enter next 12 selections
        for (int i = 72; i < 84; i++) {
            SelectionDTO sel = new SelectionDTO();
            sel.person = new PersonDTO();
            sel.selections = new ArrayList<>();
            sel.selections.add(8);
            sel.selections.add(9);
            sel.selections.add(10);
            sel.person.code = "B" + (i + 1);

            res = selService.insert(sel, "import");
            Assert.assertEquals(res.person.code, "B" + (i + 1));
            Assert.assertEquals(res.projects.size(), 3);
            Assert.assertEquals(res.projects.get(0).title, "p8");
        }

        syncMap = fcfsSelectionService.sync(true);
        Assert.assertEquals("syncMap=" + syncMap, syncMap.size(), 0);

        selectionStats = fcfsSelectionService.getSelections();
        Assert.assertEquals("stats=" + selectionStats, selectionStats.size(), 9);
        Assert.assertEquals(selectionStats.get(1).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(2).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(3).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(4).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(5).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(6).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(7).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(8).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(8).get(1).intValue(), 4);
        Assert.assertEquals(selectionStats.get(9).get(0).intValue(), 4);
        Assert.assertEquals(selectionStats.get(9).get(1).intValue(), 0);

        // enter next 16 selections
        for (int i = 84; i < 100; i++) {
            SelectionDTO sel = new SelectionDTO();
            sel.person = new PersonDTO();
            sel.selections = new ArrayList<>();
            sel.selections.add(9);
            sel.selections.add(10);
            sel.selections.add(1);
            sel.person.code = "B" + (i + 1);

            res = selService.insert(sel, "import");
            Assert.assertEquals(res.person.code, "B" + (i + 1));
            Assert.assertEquals(res.projects.size(), 3);
            Assert.assertEquals(res.projects.get(0).title, "p9");
        }

        syncMap = fcfsSelectionService.sync(true);
        Assert.assertEquals("syncMap=" + syncMap, syncMap.size(), 0);

        selectionStats = fcfsSelectionService.getSelections();
        Assert.assertEquals("stats=" + selectionStats, selectionStats.size(), 10);
        Assert.assertEquals(selectionStats.get(1).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(1).get(1).intValue(), 2);
        Assert.assertEquals(selectionStats.get(2).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(2).get(1).intValue(), 4);
        Assert.assertEquals(selectionStats.get(3).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(3).get(1).intValue(), 6);
        Assert.assertEquals(selectionStats.get(4).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(4).get(1).intValue(), 8);
        Assert.assertEquals(selectionStats.get(5).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(5).get(1).intValue(), 10);
        Assert.assertEquals(selectionStats.get(6).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(6).get(1).intValue(), 0);
        Assert.assertEquals(selectionStats.get(7).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(7).get(1).intValue(), 2);
        Assert.assertEquals(selectionStats.get(8).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(8).get(1).intValue(), 4);
        Assert.assertEquals(selectionStats.get(9).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(9).get(1).intValue(), 10);
        Assert.assertEquals(selectionStats.get(10).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(10).get(1).intValue(), 0);
    }

    @Test
    public void massSelWithUpdate() {
        SelectionResponseDTO res;
        Map<Integer, List<Integer>> selectionStats = fcfsSelectionService.getSelections();
        Assert.assertEquals(selectionStats.size(), 0);

        // enter first 50 selections
        for (int i = 0; i < 50; i++) {
            SelectionDTO sel = new SelectionDTO();
            sel.person = new PersonDTO();
            sel.selections = new ArrayList<>();
            sel.selections.add(1 + (i % 10));
            sel.selections.add(1 + ((i + 1) % 10));
            sel.selections.add(1 + ((i + 2) % 10));
            sel.person.code = "B" + (1 + i);

            res = selService.insert(sel, "import");
            Assert.assertEquals(res.person.code, "B" + (1 + i));
            Assert.assertEquals(res.projects.size(), 3);
            Assert.assertEquals(res.projects.get(0).title, "p" + (1 + (i % 10)));
        }

        Map<Integer, List<Integer>> syncMap = fcfsSelectionService.sync(true);
        Assert.assertEquals("syncMap=" + syncMap, syncMap.size(), 0);

        selectionStats = fcfsSelectionService.getSelections();
        Assert.assertEquals("stats=" + selectionStats, selectionStats.size(), 10);
        Assert.assertEquals(selectionStats.get(1).get(0).intValue(), 5);
        Assert.assertEquals(selectionStats.get(2).get(0).intValue(), 5);
        Assert.assertEquals(selectionStats.get(9).get(0).intValue(), 5);
        Assert.assertEquals(selectionStats.get(10).get(0).intValue(), 5);

        // update 50 selections
        for (int i = 0; i < 50; i++) {
            SelectionDTO sel = new SelectionDTO();
            sel.person = new PersonDTO();
            sel.selections = new ArrayList<>();
            sel.selections.add(1 + ((i + 2) % 5));
            sel.selections.add(1 + ((i + 3) % 5));
            sel.selections.add(1 + ((i + 4) % 5));
            sel.person.code = "B" + (1 + i);

            res = selService.insert(sel, "import");
            Assert.assertEquals(res.person.code, "B" + (1 + i));
            Assert.assertEquals(res.projects.size(), 3);
            Assert.assertEquals(res.projects.get(0).title, "p" + (1 + (i + 2) % 5));
        }

        syncMap = fcfsSelectionService.sync(true);
        Assert.assertEquals("syncMap=" + syncMap, syncMap.size(), 0);

        selectionStats = fcfsSelectionService.getSelections();
        Assert.assertEquals("stats=" + selectionStats, selectionStats.size(), 10);
        Assert.assertEquals(selectionStats.get(1).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(2).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(3).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(4).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(5).get(0).intValue(), 10);
        Assert.assertEquals(selectionStats.get(6).get(0).intValue(), 0);
        Assert.assertEquals(selectionStats.get(7).get(0).intValue(), 0);
        Assert.assertEquals(selectionStats.get(10).get(0).intValue(), 0);
    }


    @Test
    public void testAll() {
        ProjectService prjService = new ProjectService();

        Gson gson = new Gson();
        ProjectPackageDTO pkg = gson.fromJson(
                new InputStreamReader(this.getClass().getResourceAsStream("/data/hhgonline.qpkg"), StandardCharsets.UTF_8),
                ProjectPackageDTO.class);

        pkg.prefs.parameter.strategy = fcfs;
        GregorianCalendar cal = new GregorianCalendar();
        cal.add(Calendar.HOUR, 1);
        pkg.prefs.endDate = cal.getTime();
        pkg.prefs.startDate2 = null;
        pkg.prefs.endDate2 = null;
        pkg.prefs.parameter.randomize = false;
        List<SelectionDTO> selections = pkg.selections;
        pkg.selections = null;

        // import data
        ProjectPackageService projectPackageService = new ProjectPackageService();
        projectPackageService.importAll(pkg);

        // check if projects + codes imported correctly
        List<ProjectDTO> projects = prjService.getProjects();
        Assert.assertEquals(projects.size(), 36);

        CodeService codeService = new CodeService();
        List<CodeDTO> codes = codeService.getCodes();
        Assert.assertEquals(codes.size(), 784);

        Assert.assertEquals(selections.size(), 746);

        SelectionService selectionService = new SelectionService();
        ReportingService reportingService = new ReportingService();

        for (int j = 1; j <= 3; j++) {
            int i;
            for (i = 1 + 30 * (j - 1); i <= 30 * j; i++) {
                selectionService.insert(selections.get(i - 1), "localhost");
            }

            AssignedProjectListIntDTO res = reportingService.getAssignedProjects(null);

            testAfterX(j, res);

            Map<Integer, List<Integer>> syncMap = fcfsSelectionService.sync(true);
            Assert.assertEquals("syncMap=" + syncMap, syncMap.size(), 0);
        }

        Map<Integer, List<Integer>> syncMap = fcfsSelectionService.sync(true);
        Assert.assertEquals("syncMap=" + syncMap, syncMap.size(), 0);

        // now provoke a delte
        fcfsSelectionService.saveSelections(1, 1, 0);
        fcfsSelectionService.saveSelections(2, 0, 1);

        syncMap = fcfsSelectionService.sync(true);
        Assert.assertEquals("syncMap=" + syncMap, syncMap.size(), 2);
        Assert.assertEquals("syncMap=" + syncMap, syncMap.get(1).get(0).intValue(), -1);
        Assert.assertEquals("syncMap=" + syncMap, syncMap.get(1).get(1).intValue(), 0);
        Assert.assertEquals("syncMap=" + syncMap, syncMap.get(2).get(0).intValue(), 0);
        Assert.assertEquals("syncMap=" + syncMap, syncMap.get(2).get(1).intValue(), -1);

        // now sync
        fcfsSelectionService.sync(false);

        syncMap = fcfsSelectionService.sync(true);
        Assert.assertEquals("syncMap=" + syncMap, syncMap.size(), 0);
    }

    @Test
    @Ignore
    public void testAll2() {
        ProjectService prjService = new ProjectService();

        Gson gson = new Gson();
        ProjectPackageDTO pkg = gson.fromJson(
                new InputStreamReader(this.getClass().getResourceAsStream("/data/hhgonline.qpkg"), StandardCharsets.UTF_8),
                ProjectPackageDTO.class);

        pkg.prefs.parameter.strategy = fcfs;
        GregorianCalendar cal = new GregorianCalendar();
        cal.add(Calendar.HOUR, 1);
        pkg.prefs.endDate = cal.getTime();
        pkg.prefs.startDate2 = null;
        pkg.prefs.endDate2 = null;
        pkg.prefs.parameter.randomize = false;
        List<SelectionDTO> selections = pkg.selections;
        pkg.selections = null;

        // import data
        ProjectPackageService projectPackageService = new ProjectPackageService();
        projectPackageService.importAll(pkg);

        // check if projects + codes imported correctly
        List<ProjectDTO> projects = prjService.getProjects();
        Assert.assertEquals(projects.size(), 36);

        CodeService codeService = new CodeService();
        List<CodeDTO> codes = codeService.getCodes();
        Assert.assertEquals(codes.size(), 784);

        Assert.assertEquals(selections.size(), 746);

        SelectionService selectionService = new SelectionService();
        ReportingService reportingService = new ReportingService();

        // import history data
        InputStream in = getClass().getResourceAsStream("/data/history-hhgonline.csv");
        List<SelectionDTO> histSelectins = selectionService.parseSelectionCSV(in);

        new FirstComeFirstServeAssignmentStrategy(null);
        LogManager.getLogManager().getLogger(ReportingService.class.getName()).setLevel(Level.WARNING);
        LogManager.getLogManager().getLogger(AssignmentStrategy.class.getName()).setLevel(Level.WARNING);
        LogManager.getLogManager().getLogger(FirstComeFirstServeAssignmentStrategy.class.getName()).setLevel(Level.WARNING);
        LogManager.getLogManager().getLogger(CodeService.class.getName()).setLevel(Level.WARNING);
        LogManager.getLogManager().getLogger(PreferencesService.class.getName()).setLevel(Level.WARNING);
        LogManager.getLogManager().getLogger(ProjectService.class.getName()).setLevel(Level.WARNING);
        LogManager.getLogManager().getLogger(ProjectDAO.class.getName()).setLevel(Level.WARNING);

        Assert.assertEquals(histSelectins.size(), 694);

        // insert history data
        for (SelectionDTO s : histSelectins) {
            s.created = new Date();
            selectionService.insert(s, "localhost");
        }

        Map<Integer, List<Integer>> syncMap = fcfsSelectionService.sync(true);
        Assert.assertEquals(syncMap.size(), 0);

        // insert current data
        int i = 0;
        for (SelectionDTO s : selections) {
            i++;
            s.created = new Date();
            selectionService.insert(s, "localhost");
            syncMap = fcfsSelectionService.sync(true);
            Assert.assertEquals(i + ". syncMap=" + syncMap + ";" + s,
                    syncMap.size(), 0);
        }
    }

    private void testAfterX(int j, AssignedProjectListIntDTO res) {
        int[] c1 = {2, 3, 3};
        int[] c2 = {8, 15, 15};
        int[] c3 = {8, 11, 14};
        int[] c4 = {2, 6, 8};


        List<PersonDTO> persons = res.assignedPersons.get(new ProjectDTO(1));//24
        Assert.assertEquals("loop" + j, persons.size(), c1[j - 1]);
        Assert.assertEquals("loop" + j, persons.get(0).code, "VPPY023");
        Assert.assertEquals("loop" + j, persons.get(1).code, "ISXG088");
        if (j >= 2) {
            Assert.assertEquals(persons.get(2).code, "VPUN211");
        }

        persons = res.assignedPersons.get(new ProjectDTO(4));
        Assert.assertEquals("loop" + j, persons.size(), c2[j - 1]);//15
        Assert.assertEquals("loop" + j, persons.get(0).code, "IUOH848");
        Assert.assertEquals("loop" + j, persons.get(1).code, "UKEM608");
        Assert.assertEquals("loop" + j, persons.get(2).code, "ZNKM763");
        Assert.assertEquals("loop" + j, persons.get(7).code, "Lbrj537");
        if (j >= 2) {
            Assert.assertEquals(persons.get(8).code, "NJMF663");
            Assert.assertEquals(persons.get(14).code, "QFTZ462");
        }


        persons = res.assignedPersons.get(new ProjectDTO(36));
        Assert.assertEquals("loop" + j, persons.size(), c3[j - 1]);//21
        Assert.assertEquals("loop" + j, persons.get(0).code, "GTRO816");
        Assert.assertEquals("loop" + j, persons.get(1).code, "WTSV060");
        Assert.assertEquals("loop" + j, persons.get(7).code, "TCTU731");


        persons = res.assignedPersons.get(new ProjectDTO(5));
        Assert.assertEquals("loop" + j, persons.size(), c4[j - 1]);//22
        Assert.assertEquals("loop" + j, persons.get(0).code, "RUED345");
        Assert.assertEquals("loop" + j, persons.get(1).code, "HVNS653");
        if (j >= 2) {
            Assert.assertEquals("loop" + j, persons.get(2).code, "OQLQ034");
            Assert.assertEquals("loop" + j, persons.get(3).code, "CZBK960");
        }
    }
}
