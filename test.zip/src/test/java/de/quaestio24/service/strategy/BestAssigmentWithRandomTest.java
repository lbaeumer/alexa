package de.quaestio24.service.strategy;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.tools.development.testing.LocalDatastoreServiceTestConfig;
import com.google.appengine.tools.development.testing.LocalServiceTestHelper;
import com.google.gson.Gson;
import de.quaestio24.dto.CodeDTO;
import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.dto.PreferencesDTO.Parameter;
import de.quaestio24.dto.ProjectDTO;
import de.quaestio24.dto.ProjectPackageDTO;
import de.quaestio24.dto.SelectionDTO;
import de.quaestio24.service.PreferencesService;
import de.quaestio24.service.dto.EvaluationResultDTO;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BestAssigmentWithRandomTest {

    private final LocalServiceTestHelper helper = new LocalServiceTestHelper(new LocalDatastoreServiceTestConfig());

    @Before
    public void setUp() {
        helper.setUp();
        NamespaceManager.set("hhonline");
        // default pref do not exist for prjtest
        new PreferencesService().createDefaultPreference(null);
    }

    @After
    public void tearDown() {
        helper.tearDown();
    }

    @Test
    public void testNonVoters() {
        Gson gson = new Gson();
        ProjectPackageDTO pkg = gson.fromJson(
                new InputStreamReader(this.getClass().getResourceAsStream("/data/hhgonline.qpkg")),
                ProjectPackageDTO.class);

        List<SelectionDTO> selections = pkg.selections;
        List<CodeDTO> codes = pkg.codes;
        Assert.assertEquals(selections.size(), 746);
        Assert.assertNull(selections.get(744).addAfterAssignment);
        Assert.assertEquals(selections.get(745).addAfterAssignment, true);
        Assert.assertEquals(selections.get(0).created.getTime(), 1567780018058L);
        Assert.assertEquals(selections.get(745).created.getTime(), 1568836484044L);
        Assert.assertEquals(codes.size(), 784);
        Assert.assertEquals(codes.get(783).code, "LTCR329");

        PreferencesDTO prefs = pkg.prefs;
        Parameter parameter = prefs.parameter;

        Map<Integer, ProjectDTO> projectById = new HashMap<>();
        for (ProjectDTO p : pkg.projects) {
            projectById.put(p.id, p);
        }

        List<Date> dates = new ArrayList<>();
        if (prefs.endDate != null) {
            dates.add(prefs.endDate);
        }
        if (prefs.endDate2 != null) {
            dates.add(prefs.endDate2);
        }

        // run for non voters
        parameter.addNonVoters = false;
        BestAssignmentStrategy strategy = new BestAssignmentStrategy(prefs);
        EvaluationResultDTO result = strategy.calculateAssignment(projectById, selections, codes, dates);

        Assert.assertEquals(result.assignedPersons.size(), 36);
        Assert.assertEquals(result.unassignedPersons.size(), 0);
        Assert.assertEquals(result.nonVoters.size(), 38);

        ProjectDTO p = new ProjectDTO();
        p.id = 10;
        Assert.assertEquals(result.assignedPersons.get(p).size(), 6);
        p.id = 12;
        Assert.assertEquals(result.assignedPersons.get(p).size(), 17);
        p.id = 15;
        Assert.assertEquals(result.assignedPersons.get(p).size(), 4);
        p.id = 18;
        Assert.assertEquals(result.assignedPersons.get(p).size(), 5);
        p.id = 23;
        Assert.assertEquals(result.assignedPersons.get(p).size(), 8);
        p.id = 24;
        Assert.assertEquals(result.assignedPersons.get(p).size(), 29);
        p.id = 26;
        Assert.assertEquals(result.assignedPersons.get(p).size(), 8);
        p.id = 28;
        Assert.assertEquals(result.assignedPersons.get(p).size(), 8);
        p.id = 31;
        Assert.assertEquals(result.assignedPersons.get(p).size(), 27);
        p.id = 33;
        Assert.assertEquals(result.assignedPersons.get(p).size(), 14);

        p.id = 35;
        Assert.assertEquals(result.assignedPersons.get(p).size(), 25);
        p.id = 36;
        Assert.assertEquals(result.assignedPersons.get(p).size(), 21);

        int students = 0;
        for (ProjectDTO pr : projectById.values()) {
            students += result.assignedPersons.get(pr).size();
            if (pr.id == 35) {
                Assert.assertEquals(pr.maxSize, result.assignedPersons.get(pr).size() - 1);
            } else {
                Assert.assertTrue(pr.maxSize >= result.assignedPersons.get(pr).size());
            }
        }
        Assert.assertEquals(students, 746);
    }

    @Test
    public void testAddNonVoters() {
        Gson gson = new Gson();
        ProjectPackageDTO pkg = gson.fromJson(
                new InputStreamReader(this.getClass().getResourceAsStream("/data/hhgonline.qpkg")),
                ProjectPackageDTO.class);

        List<SelectionDTO> selections = pkg.selections;
        List<CodeDTO> codes = pkg.codes;
        Assert.assertEquals(selections.size(), 746);
        Assert.assertNull(selections.get(744).addAfterAssignment);
        Assert.assertEquals(selections.get(745).addAfterAssignment, true);
        Assert.assertEquals(selections.get(0).created.getTime(), 1567780018058L);
        Assert.assertEquals(selections.get(745).created.getTime(), 1568836484044L);
        Assert.assertEquals(codes.size(), 784);
        Assert.assertEquals(codes.get(783).code, "LTCR329");

        PreferencesDTO prefs = pkg.prefs;
        Parameter parameter = prefs.parameter;

        Map<Integer, ProjectDTO> projectById = new HashMap<>();
        for (ProjectDTO p : pkg.projects) {
            projectById.put(p.id, p);
        }

        List<Date> dates = new ArrayList<>();
        if (prefs.endDate != null) {
            dates.add(prefs.endDate);
        }
        if (prefs.endDate2 != null) {
            dates.add(prefs.endDate2);
        }

        // run for non voters
        parameter.addNonVoters = true;
        BestAssignmentStrategy strategy = new BestAssignmentStrategy(prefs);
        EvaluationResultDTO result = strategy.calculateAssignment(projectById, selections, codes, dates);

        Assert.assertEquals(result.assignedPersons.size(), 36);
        Assert.assertEquals(result.unassignedPersons.size(), 0);
        Assert.assertEquals(result.nonVoters.size(), 0);

        ProjectDTO p = new ProjectDTO();
        p.id = 10;
        Assert.assertEquals(result.assignedPersons.get(p).size(), 6 + 4);
        p.id = 12;
        Assert.assertEquals(result.assignedPersons.get(p).size(), 17 + 3);
        p.id = 15;
        Assert.assertEquals(result.assignedPersons.get(p).size(), 4 + 4);
        p.id = 18;
        Assert.assertEquals(result.assignedPersons.get(p).size(), 5 + 4);
        p.id = 23;
        Assert.assertEquals(result.assignedPersons.get(p).size(), 8 + 4);
        p.id = 24;
        Assert.assertEquals(result.assignedPersons.get(p).size(), 29 + 3);
        p.id = 26;
        Assert.assertEquals(result.assignedPersons.get(p).size(), 8 + 3);
        p.id = 28;
        Assert.assertEquals(result.assignedPersons.get(p).size(), 8 + 4);
        p.id = 31;
        Assert.assertEquals(result.assignedPersons.get(p).size(), 27 + 3);
        p.id = 33;
        Assert.assertEquals(result.assignedPersons.get(p).size(), 14 + 3);

        p.id = 35;
        Assert.assertEquals(result.assignedPersons.get(p).size(), 25);
        p.id = 36;
        Assert.assertEquals(result.assignedPersons.get(p).size(), 21);

        int students = 0;
        for (ProjectDTO pr : projectById.values()) {
            students += result.assignedPersons.get(pr).size();
            if (pr.id == 35) {
                Assert.assertEquals(pr.maxSize, result.assignedPersons.get(pr).size() - 1);
            } else {
                Assert.assertTrue(pr.maxSize >= result.assignedPersons.get(pr).size());
            }
        }
        Assert.assertEquals(students, 746 + 38);
    }

    @Test
    public void testAddNonVotersIteratively() {
        Gson gson = new Gson();
        ProjectPackageDTO pkg = gson.fromJson(
                new InputStreamReader(this.getClass().getResourceAsStream("/data/hhgonline.qpkg")),
                ProjectPackageDTO.class);

        List<SelectionDTO> selections = pkg.selections;
        List<CodeDTO> codes = pkg.codes;
        Assert.assertEquals(selections.size(), 746);
        Assert.assertNull(selections.get(744).addAfterAssignment);
        Assert.assertEquals(selections.get(745).addAfterAssignment, true);
        Assert.assertEquals(selections.get(0).created.getTime(), 1567780018058L);
        Assert.assertEquals(selections.get(745).created.getTime(), 1568836484044L);
        Assert.assertEquals(codes.size(), 784);
        Assert.assertEquals(codes.get(783).code, "LTCR329");

        PreferencesDTO prefs = pkg.prefs;
        Parameter parameter = prefs.parameter;

        Map<Integer, ProjectDTO> projectById = new HashMap<>();
        for (ProjectDTO p : pkg.projects) {
            projectById.put(p.id, p);
        }

        List<Date> dates = new ArrayList<>();
        if (prefs.endDate != null) {
            dates.add(prefs.endDate);
        }
        if (prefs.endDate2 != null) {
            dates.add(prefs.endDate2);
        }

        // run for non voters
        parameter.addNonVoters = true;
        BestAssignmentStrategy strategy = new BestAssignmentStrategy(prefs);
        for (int i = 0; i < 10; i++) {
            List<SelectionDTO> sels = new ArrayList<>(selections.subList(0, selections.size() / 10 * i + 1));
            EvaluationResultDTO result = strategy.calculateAssignment(projectById, sels, codes, dates);

            Assert.assertEquals(result.assignedPersons.size(), 36);
            Assert.assertEquals("i=" + i, result.unassignedPersons.size(), 0);
            Assert.assertEquals(result.nonVoters.size(), 0);

            int students = 0;
            for (ProjectDTO pr : projectById.values()) {
                students += result.assignedPersons.get(pr).size();
                Assert.assertTrue(pr.maxSize >= result.assignedPersons.get(pr).size());
            }
            Assert.assertEquals(students, 746 + 38);
        }
    }
}
