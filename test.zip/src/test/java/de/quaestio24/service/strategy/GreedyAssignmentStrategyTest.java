package de.quaestio24.service.strategy;

import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.dto.PreferencesDTO.Parameter;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class GreedyAssignmentStrategyTest extends AbstractAssignmentStrategyTest {

    public GreedyAssignmentStrategyTest() {
        PreferencesDTO prefs = new PreferencesDTO();
        prefs.parameter = new Parameter();
        GregorianCalendar c = new GregorianCalendar();
        c.add(Calendar.DAY_OF_MONTH, 1);
        prefs.endDate = c.getTime();
        strategy = new GreedyAssignmentStrategy(prefs);
    }
}
