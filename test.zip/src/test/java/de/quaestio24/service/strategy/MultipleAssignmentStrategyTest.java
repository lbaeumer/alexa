package de.quaestio24.service.strategy;

import de.quaestio24.dto.PersonDTO;
import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.dto.ProjectDTO;
import de.quaestio24.dto.SelectionDTO;
import de.quaestio24.service.dto.EvaluationResultDTO;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class MultipleAssignmentStrategyTest {

    private AssignmentStrategy strategy;

    @Before
    public void setUp() {
        strategy = new MultipleAssignmentStrategy(new PreferencesDTO());
    }

    @Test
    public void testNoSelections() {
        Map<Integer, ProjectDTO> projectById = new HashMap<>();
        for (int i = 1; i <= 100; i++) {
            ProjectDTO p = new ProjectDTO();
            p.id = i;
            projectById.put(i, p);
            p.maxSize = 5;
        }

        List<SelectionDTO> selections = new ArrayList<>();

        EvaluationResultDTO a = strategy.calculateAssignment(projectById, selections);
        SelectionValidation.validateAssignment(a, projectById, selections);

        Assert.assertEquals(0, a.assignedPersons.size());
        Assert.assertEquals(0, a.unassignedPersons.size());
    }

    @Test
    public void testRandom1() {
        for (int i = 1; i < 200; i++) {
            testRandom(i);
        }
    }

    /*
     * @Ignore
     *
     * @Test public void testRandom500() { testRandom(500); }
     *
     * @Ignore
     *
     * @Test public void testRandom600() { testRandom(600); }
     */
    protected final void testRandom(int MAX_PROJECTS) {
        Random r1 = new Random(1);

        int maxPlaces = 0;
        Map<Integer, ProjectDTO> projectById = new HashMap<>();
        for (int i = 0; i < MAX_PROJECTS; i++) {
            ProjectDTO p = new ProjectDTO();
            p.id = i;
            projectById.put(i, p);
            p.maxSize = 5 + r1.nextInt(20);
            maxPlaces += p.maxSize;
        }

        List<SelectionDTO> selections = new ArrayList<>();
        for (int i = 0; i < 1 + maxPlaces / 100 * 110; i++) {

            SelectionDTO s = new SelectionDTO();
            selections.add(s);
            s.selections = new ArrayList<>();
            s.person = new PersonDTO();
            s.person.name = "P" + i;

            int maxSel = 2 + r1.nextInt(5);
            for (int j = 0; j < maxSel; j++) {
                s.selections.add(r1.nextInt(MAX_PROJECTS));
            }
            if (selections.size() % 20 == 0 && MAX_PROJECTS > 200) {
                EvaluationResultDTO a = strategy.calculateAssignment(projectById, selections);
                SelectionValidation.validateAssignment(a, projectById, selections);
            }
            if (selections.size() % 10000 == 0) {
                System.out.println(
                        new Date() + "; #selec" + selections.size() + "; " + i + "/" + (maxPlaces / 100 * 110));
            }
        }
    }

    @Test
    public void testAssignAll() {
        Map<Integer, ProjectDTO> projectById = new HashMap<>();
        for (int i = 1; i <= 100; i++) {
            ProjectDTO p = new ProjectDTO();
            p.id = i;
            projectById.put(p.id, p);
            p.maxSize = 5;
        }

        List<SelectionDTO> selections = new ArrayList<>();
        for (int i = 0; i < 500; i++) {
            SelectionDTO s = new SelectionDTO();
            s.person = new PersonDTO();
            s.person.name = "Person " + i;
            s.selections = new ArrayList<>();
            s.selections.add(1 + (i % 100));

            selections.add(s);
        }

        EvaluationResultDTO a = strategy.calculateAssignment(projectById, selections);
        SelectionValidation.validateAssignment(a, projectById, selections);

        Assert.assertEquals(projectById.size(), a.assignedPersons.size());
        for (ProjectDTO p : projectById.values()) {
            List<PersonDTO> l = a.assignedPersons.get(p);
            Assert.assertEquals(5, l.size());
        }
        Assert.assertEquals(0, a.unassignedPersons.size());
    }
}
