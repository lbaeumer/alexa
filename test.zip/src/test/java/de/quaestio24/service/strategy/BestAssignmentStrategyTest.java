package de.quaestio24.service.strategy;

import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.dto.PreferencesDTO.Parameter;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class BestAssignmentStrategyTest extends AbstractAssignmentStrategyTest {

    public BestAssignmentStrategyTest() {
        PreferencesDTO prefs = new PreferencesDTO();
        Parameter pa = new Parameter();
        prefs.parameter = pa;
        GregorianCalendar c = new GregorianCalendar();
        c.add(Calendar.DAY_OF_MONTH, 1);
        prefs.endDate = c.getTime();
        pa.randomize = true;
        strategy = new BestAssignmentStrategy(prefs);
    }

    // @Test
    public void testRandom1x() {
        for (int j = 1; j < 500; j++) {
            for (int i = 1; i < 200; i++) {
                testRandom(i);
            }
        }
    }
}
