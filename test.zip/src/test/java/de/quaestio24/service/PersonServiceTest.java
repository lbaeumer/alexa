package de.quaestio24.service;

import com.google.appengine.tools.development.testing.LocalDatastoreServiceTestConfig;
import com.google.appengine.tools.development.testing.LocalServiceTestHelper;
import de.quaestio24.dto.PersonDTO;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class PersonServiceTest {

    private final LocalServiceTestHelper helper = new LocalServiceTestHelper(new LocalDatastoreServiceTestConfig());

    private PersonService personService = new PersonService();

    @Before
    public void setUp() {
        helper.setUp();
    }

    @After
    public void tearDown() {
        helper.tearDown();
    }

    @Test
    public void insertPersons() {
        List<PersonDTO> persons = new ArrayList<>();

        for (int i = 1; i <= 10; i++) {
            PersonDTO c = new PersonDTO();
            c.clazz = "ha" + i;
            c.name = "name=" + i;
            c.surname = "surname" + i;
            persons.add(c);
        }

        personService.insertPersons(persons);

        List<PersonDTO> persons2 = personService.getPersons();

        Assert.assertEquals(persons, persons2);
    }

    @Test
    public void importPerson() throws IOException {

        List<PersonDTO> persons;
        try (InputStream in = getClass().getResourceAsStream("/data/persons.csv")) {
            persons = personService.parsePersonCSV(in);
        }
        personService.insertPersons(persons);

        persons = personService.getPersons();
        Assert.assertEquals(persons.size(), 3);

        Assert.assertEquals(persons.get(0).name, "Fritz");
        Assert.assertEquals(persons.get(1).surname, "Rainer");
        Assert.assertEquals(persons.get(2).clazz, "11a");
    }
}
