package de.quaestio24.service;

import com.google.appengine.tools.development.testing.LocalDatastoreServiceTestConfig;
import com.google.appengine.tools.development.testing.LocalServiceTestHelper;
import de.quaestio24.dto.IpfilterDTO;
import de.quaestio24.exception.ValidationException;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

public class IpfilterTest {

    private final LocalServiceTestHelper helper = new LocalServiceTestHelper(new LocalDatastoreServiceTestConfig());
    private IpfilterService service = new IpfilterService();

    @Before
    public void setUp() {
        helper.setUp();

        new SiteService().addSite("junit1");
    }

    @After
    public void tearDown() {
        helper.tearDown();
    }

    @Test
    public void testOk() {
        IpfilterDTO f = null;
        for (int i = 0; i < IpfilterService.THRESHOLD[0]; i++) {
            f = service.checkAndIncreaseLastAccess("myfnc", "localhost", "ua");
        }
        Assert.assertEquals(IpfilterService.THRESHOLD[0], f.cnt);
    }

    @Ignore
    @Test(expected = ValidationException.class)
    public void testNOk() {
        for (int i = 0; i < IpfilterService.THRESHOLD[0] + 1; i++) {
            service.checkAndIncreaseLastAccess("myfnc", "localhost", "ua");
        }
    }

    private void validate(int idx) {
        IpfilterDTO f = null;
        for (int i = 0; i < IpfilterService.THRESHOLD[idx]; i++) {
            f = service.checkAndIncreaseLastAccess("myfnc", "localhost", "ua");
            if (i == 3) {
                try {
                    System.out.println("sleeping for " + (IpfilterService.THRESHOLD[idx - 1]) + "s");
                    Thread.sleep(IpfilterService.THRESHOLD[idx - 1] * 1000 + 400);
                } catch (InterruptedException ignored) {
                }
            }
        }
        Assert.assertEquals(IpfilterService.THRESHOLD[idx], f.cnt);
    }

    @Test
    public void testOk2() {
        validate(2);
    }

    @Ignore
    @Test(expected = ValidationException.class)
    public void testNOk2() {
        validate(2);
        service.checkAndIncreaseLastAccess("myfnc", "localhost", "ua");
    }

    // @Test
    public void testOk4() {
        validate(4);
    }

    // @Test(expected = ValidationException.class)
    public void testNOk4() {
        validate(4);
        service.checkAndIncreaseLastAccess("myfnc", "localhost", "ua");
    }
}
