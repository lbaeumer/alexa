package de.quaestio24.service;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.repackaged.com.google.gson.Gson;
import com.google.appengine.tools.development.testing.LocalDatastoreServiceTestConfig;
import com.google.appengine.tools.development.testing.LocalServiceTestHelper;
import de.quaestio24.dto.IssueDTO;
import de.quaestio24.dto.IssueDTO.Severity;
import de.quaestio24.dto.IssuesDTO;
import de.quaestio24.dto.ProjectPackageDTO;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStreamReader;
import java.util.List;

public class IssueServiceTest {

    private final LocalServiceTestHelper helper = new LocalServiceTestHelper(new LocalDatastoreServiceTestConfig());
    ProjectPackageService pkgService = new ProjectPackageService();
    private IssueService issueService = new IssueService();

    @Before
    public void setUp() {
        helper.setUp();

        new SiteService().addSite("junit1");
        NamespaceManager.set("junit1");
    }

    @After
    public void tearDown() {
        helper.tearDown();
    }

    @Test
    public void testIssue() {
        Gson gson = new Gson();
        ProjectPackageDTO projectPackage = gson.fromJson(
                new InputStreamReader(this.getClass().getResourceAsStream("/demo3.qpkg")), ProjectPackageDTO.class);
        projectPackage.selections = null;
        projectPackage.subPackages.forEach((k, v) -> v.selections = null);
        pkgService.importAll(projectPackage);

        IssuesDTO issues = issueService.getAllIssues();
        Assert.assertNotNull(issues);
        Assert.assertEquals(issues.count, 8);

        // base
        Assert.assertEquals(issues.issues.size(), 1);
        Assert.assertEquals(2, issues.subIssues.size());

        Assert.assertEquals(issues.issues.get(0).severity, Severity.info);
        Assert.assertTrue(issues.issues.get(0).message.contains("keine Email"));

        // tag1
        Assert.assertEquals(issues.subIssues.get("tag1").size(), 4);
        Assert.assertEquals(issues.subIssues.get("tag1").get(0).severity, Severity.error);
        Assert.assertTrue(issues.subIssues.get("tag1").get(0).message.contains("Ende der Wahl"));
        Assert.assertEquals(issues.subIssues.get("tag1").get(1).severity, Severity.error);
        Assert.assertTrue(issues.subIssues.get("tag1").get(1).message.contains("Beginn der Wahl"));
        Assert.assertEquals(issues.subIssues.get("tag1").get(2).severity, Severity.warning);
        Assert.assertTrue(issues.subIssues.get("tag1").get(2).message.contains("minimale Projektgröße"));
        Assert.assertEquals(issues.subIssues.get("tag1").get(3).severity, Severity.info);
        Assert.assertTrue(issues.subIssues.get("tag1").get(3).message.contains("unterschiedliche Wahl"));

        // tag2
        Assert.assertEquals(issues.subIssues.get("tag2").size(), 3);
        Assert.assertEquals(issues.subIssues.get("tag2").get(0).severity, Severity.error);
        Assert.assertTrue(issues.subIssues.get("tag2").get(0).message.contains("Ende der Wahl"));
        Assert.assertEquals(issues.subIssues.get("tag2").get(1).severity, Severity.error);
        Assert.assertTrue(issues.subIssues.get("tag2").get(1).message.contains("Beginn der Wahl"));
        Assert.assertEquals(issues.subIssues.get("tag2").get(2).severity, Severity.warning);
        Assert.assertTrue(issues.subIssues.get("tag2").get(2).message.contains("minimale Projektgröße"));

        List<IssueDTO> authIssues = issueService.getAuthenticationIssues();
        Assert.assertEquals(authIssues.size(), 0);
    }
}
