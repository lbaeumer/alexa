package de.quaestio24.service;

import com.google.appengine.tools.development.testing.LocalDatastoreServiceTestConfig;
import com.google.appengine.tools.development.testing.LocalServiceTestHelper;
import de.quaestio24.dto.FeedbackDTO;
import de.quaestio24.exception.ValidationException;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

public class FeedbackServiceTest {

    private final LocalServiceTestHelper helper = new LocalServiceTestHelper(new LocalDatastoreServiceTestConfig());
    private FeedbackService feedbackService = new FeedbackService();

    @Before
    public void setUp() {
        helper.setUp();

        new SiteService().addSite("junit1");
    }

    @After
    public void tearDown() {
        helper.tearDown();
    }

    @Test
    public void testFeedback() {
        List<FeedbackDTO> feeds = feedbackService.getAllFeedback();
        Assert.assertEquals(feeds.size(), 0);

        FeedbackDTO f = new FeedbackDTO();
        f.email = "lui@xx.de";
        f.name = "name";
        f.text = "txt";

        // save
        feedbackService.saveFeedback(f);

        // get
        feeds = feedbackService.getAllFeedback();
        Assert.assertEquals(feeds.size(), 1);
    }

    @Test(expected = ValidationException.class)
    public void testFeedbackNok() {
        List<FeedbackDTO> feeds = feedbackService.getAllFeedback();
        Assert.assertEquals(feeds.size(), 0);

        FeedbackDTO f = new FeedbackDTO();
        f.name = "name";
        f.text = "txt";
        f.email = "invalid";

        // save
        feedbackService.saveFeedback(f);
    }
}
