package de.quaestio24.service;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.tools.development.testing.LocalDatastoreServiceTestConfig;
import com.google.appengine.tools.development.testing.LocalServiceTestHelper;
import de.quaestio24.dto.PersonDTO;
import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.dto.PreferencesDTO.Parameter;
import de.quaestio24.dto.ProjectDTO;
import de.quaestio24.dto.SelectionDTO;
import de.quaestio24.service.dto.AssignedProjectListIntDTO;
import de.quaestio24.service.dto.EvaluationResultDTO;
import de.quaestio24.service.strategy.BestAssignmentStrategy;
import de.quaestio24.service.strategy.SelectionValidation;
import de.quaestio24.util.CacheUtil;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import static de.quaestio24.dto.PreferencesDTO.StrategyEnum.greedy;

@Ignore
public class AssignmentTest {

    private final LocalServiceTestHelper helper = new LocalServiceTestHelper(new LocalDatastoreServiceTestConfig());
    private SelectionService selService = new SelectionService();
    private ProjectService projService = new ProjectService();
    private ProjectImportService projImportService = new ProjectImportService();
    private ReportingService reportService = new ReportingService();

    @Before
    public void setUp() {
        helper.setUp();
        new SiteService().addSite("junit1");
    }

    @After
    public void tearDown() {
        helper.tearDown();
    }

    @Test
    public void testAssignment() throws IOException {
        NamespaceManager.set("junit1");
        InputStream in = this.getClass().getResourceAsStream("/data/projects-annefrankbk.xls");
        try {
            projImportService.importProjectsXLS(in);
        } finally {
            in.close();
        }

        List<ProjectDTO> projs = projService.getProjects();
        Assert.assertEquals(projs.size(), 44);
        Map<Integer, ProjectDTO> projectById = new HashMap<>();
        for (ProjectDTO p : projs) {
            projectById.put(p.id, p);
        }

        // import selection
        in = this.getClass().getResourceAsStream("/data/selections-annefrankbk.csv");

        List<SelectionDTO> selections = selService.parseSelectionCSV(in);
        Assert.assertEquals(selections.size(), 735);
        List<SelectionDTO> sels = new ArrayList<>();

        try {
            selService.skipValidation(true);
            int cnt = 0;
            for (SelectionDTO s : selections) {
                cnt++;
                try {
                    sels.add(s);
                    selService.insert(s, "import");

                    CacheUtil.clear();

                    Parameter parameter = new Parameter();
                    AssignedProjectListIntDTO res = reportService.getAssignedProjects(parameter);
                    checkResult(res, cnt, projectById, sels);

                    parameter.skipMinimum = true;
                    res = reportService.getAssignedProjects(parameter);
                    checkResult(res, cnt, projectById, sels);

                    parameter.randomize = true;
                    res = reportService.getAssignedProjects(parameter);
                    checkResult(res, cnt, projectById, sels);

                    parameter.strategy = greedy;
                    res = reportService.getAssignedProjects(parameter);
                    checkResult(res, cnt, projectById, sels);
                } catch (Exception e) {
                    System.out.println("failed in loop " + s + cnt);
                    throw new RuntimeException("failed" + cnt, e);
                }
            }
        } finally {
            selService.skipValidation(false);
        }
    }

    private void checkResult(AssignedProjectListIntDTO res, int cnt, Map<Integer, ProjectDTO> projectById,
                             List<SelectionDTO> selections) {
        Assert.assertNotNull(res);
        int sum = 0;
        for (Map.Entry<ProjectDTO, List<PersonDTO>> entry : res.assignedPersons.entrySet()) {
            sum += entry.getValue().size();
            Assert.assertNotNull(entry.getKey().title);
        }
        sum += res.unassignedPersons.size();

        EvaluationResultDTO ret = new EvaluationResultDTO();
        ret.assignedPersons = res.assignedPersons;
        ret.unassignedPersons = new ArrayList<>();
        ret.unassignedPersons.addAll(res.unassignedPersons);

        SelectionValidation.validateAssignment(ret, projectById, selections);
        Assert.assertEquals(sum, cnt);
    }

    @Test
    public void testAssignment2() throws IOException {
        InputStream in = this.getClass().getResourceAsStream("/data/projects-annefrankbk.xls");
        List<ProjectDTO> projs;
        try {
            projs = projImportService.parseXLS(in);
        } finally {
            in.close();
        }
        Assert.assertEquals(projs.size(), 44);
        Map<Integer, ProjectDTO> projectById = new HashMap<>();
        for (ProjectDTO p : projs) {
            projectById.put(p.id, p);
        }

        // import selection
        in = this.getClass().getResourceAsStream("/data/selections-annefrankbk.csv");
        List<SelectionDTO> selections;
        try {
            selections = selService.parseSelectionCSV(in);
        } finally {
            in.close();
        }
        Assert.assertEquals(selections.size(), 735);

        for (int cnt = 1; cnt < selections.size(); cnt++) {
            List<SelectionDTO> sel = new ArrayList<>();
            for (int i = 0; i < cnt; i++) {
                sel.add(selections.get(i));
            }

            // try {
            PreferencesDTO prefs = new PreferencesDTO();
            Parameter parameter = new Parameter();
            prefs.parameter = parameter;
            BestAssignmentStrategy strategy = new BestAssignmentStrategy(prefs);
            strategy.calculateAssignment(projectById, sel, Collections.emptyList(),
                    Collections.singletonList(new Date()));

            parameter.skipMinimum = true;
            strategy = new BestAssignmentStrategy(prefs);
            strategy.calculateAssignment(projectById, sel, Collections.emptyList(),
                    Collections.singletonList(new Date()));

            parameter.randomize = true;
            strategy = new BestAssignmentStrategy(prefs);
            strategy.calculateAssignment(projectById, sel, Collections.emptyList(),
                    Collections.singletonList(new Date()));

            parameter.strategy = greedy;
            strategy = new BestAssignmentStrategy(prefs);
            strategy.calculateAssignment(projectById, sel, Collections.emptyList(),
                    Collections.singletonList(new Date()));

            // } catch (Exception e) {
            // throw new RuntimeException("failed in loop " + cnt, e);
            // }
        }
    }

    @Test
    public void testAssignmentBestAssignment() throws IOException {
        ProjectService projService = new ProjectService();
        InputStream in = this.getClass().getResourceAsStream("/data/projects-annefrankbk.xls");
        try {
            projImportService.importProjectsXLS(in);
        } finally {
            in.close();
        }

        List<ProjectDTO> projs = projService.getProjects();
        Assert.assertEquals(projs.size(), 44);
        Map<Integer, ProjectDTO> projectById = new HashMap<>();
        for (ProjectDTO p : projs) {
            projectById.put(p.id, p);
        }

        // import selection
        in = this.getClass().getResourceAsStream("/data/selections-annefrankbk.csv");

        SelectionService selService = new SelectionService();
        List<SelectionDTO> selections = selService.parseSelectionCSV(in);
        Assert.assertEquals(selections.size(), 735);

        List<Date> untilArray = new ArrayList<>();

        GregorianCalendar cal1 = new GregorianCalendar(2017, Calendar.SEPTEMBER, 25, 0, 0);
        GregorianCalendar cal2 = new GregorianCalendar(2017, Calendar.SEPTEMBER, 30, 0, 0);
        untilArray.add(cal1.getTime());
        untilArray.add(cal2.getTime());
        System.out.println("array=" + untilArray);

        PreferencesDTO prefs = new PreferencesDTO();
        Parameter pa = new Parameter();
        prefs.parameter = pa;
        pa.randomize = true;
        BestAssignmentStrategy strategy = new BestAssignmentStrategy(prefs);
        for (int i = 699; i < 736; i++) {
            List<SelectionDTO> sel = selections.subList(0, i);
            Assert.assertEquals(sel.size(), i);
            EvaluationResultDTO res = strategy.calculateAssignment(projectById, sel, Collections.emptyList(),
                    untilArray);

            checkHash(res, i, selections);
        }
    }

    private void checkHash(EvaluationResultDTO res, int j, List<SelectionDTO> sel) {

        Assert.assertEquals(res.assignedPersons.size(), 44);
        System.out.println(j + " " + res);
        Set<PersonDTO> personsAfterDate = new HashSet<>();
        if (sel.size() > 699) {
            for (SelectionDTO s : sel.subList(699, sel.size())) {
                personsAfterDate.add(s.person);
            }
        }

        int cnt = 0;
        int hash = 1;
        int i = 1;
        for (Entry<ProjectDTO, List<PersonDTO>> entry : res.assignedPersons.entrySet()) {

            int jj = 0;
            cnt += entry.getValue().size();
            for (PersonDTO ps : entry.getValue()) {
                if (personsAfterDate.contains(ps)) {
                    System.out.println("skip person " + ps);
                    continue;
                }
                hash += (jj + i) * ps.name.hashCode();
                jj++;
            }
            i++;
        }
        cnt += res.unassignedPersons.size();

        Assert.assertEquals(cnt, j);

    }
}
