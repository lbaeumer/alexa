package de.quaestio24.service;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.tools.development.testing.LocalDatastoreServiceTestConfig;
import com.google.appengine.tools.development.testing.LocalServiceTestHelper;
import com.google.gson.Gson;
import de.quaestio24.dto.CodeDTO;
import de.quaestio24.dto.ConfigDTO;
import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.dto.ProjectDTO;
import de.quaestio24.dto.ProjectPackageDTO;
import de.quaestio24.dto.SelectionDTO;
import de.quaestio24.service.dto.AssignedProjectListIntDTO;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.List;

import static de.quaestio24.dto.PreferencesDTO.StrategyEnum.greedy;

public class ProjectPackageServiceTest {

    private final LocalServiceTestHelper helper = new LocalServiceTestHelper(new LocalDatastoreServiceTestConfig());
    private final ProjectPackageService service = new ProjectPackageService();
    private final SiteService siteService = new SiteService();
    private final PreferencesService prefService = new PreferencesService();
    private final ConfigService configService = new ConfigService();
    int psum = 0;

    @Before
    public void setUp() {
        helper.setUp();
        NamespaceManager.set("prjtest");
        // default pref do not exist for prjtest
        new PreferencesService().createDefaultPreference(null);
    }

    @After
    public void tearDown() {
        helper.tearDown();
    }

    @Test
    public void testPackage() {
        ProjectPackageDTO projectPackage = service.exportAll();
        Assert.assertEquals(projectPackage.projects.size(), 12);
        Assert.assertEquals(projectPackage.codes.size(), 0);

        NamespaceManager.set("junit");
        service.importAll(projectPackage);

        ProjectPackageDTO projectPackage2 = service.exportAll();
        Assert.assertEquals(projectPackage2.projects.size(), 12);
        Assert.assertEquals(projectPackage2.codes.size(), 0);

        Assert.assertEquals(projectPackage.projects, projectPackage2.projects);
        Assert.assertEquals(projectPackage.codes, projectPackage2.codes);
    }

    @Test
    public void testPackageImport() {
        ProjectPackageDTO projectPackage = service.exportAll();
        Assert.assertEquals(projectPackage.projects.size(), 12);
        Assert.assertEquals(projectPackage.codes.size(), 0);

        long id = service.saveProjectPackage(projectPackage);

        ProjectPackageDTO projectPackage2 = service.getProjectPackage(id);
        Assert.assertEquals(projectPackage2.projects.size(), projectPackage.projects.size());
    }

    @Test
    public void testPackageImport2() {
        Gson gson = new Gson();
        ProjectPackageDTO pkg = gson.fromJson(
                new InputStreamReader(this.getClass().getResourceAsStream("/data/aregymnasium.qpkg")),
                ProjectPackageDTO.class);

        Assert.assertEquals(pkg.codes.size(), 161);
        Assert.assertTrue(pkg.prefs.auth);
        Assert.assertFalse(pkg.prefs.includeStatus);
        Assert.assertEquals(pkg.prefs.design.city, "Bad Neuenahr");
        Assert.assertTrue(pkg.prefs.design.txtInfoJumbotron.contains("${"));

        Assert.assertEquals(pkg.projects.size(), 0);
        Assert.assertEquals(pkg.selections.size(), 0);
        Assert.assertEquals(pkg.subPackages.size(), 3);

        // tag1
        Assert.assertEquals(pkg.subPackages.get("tag1").codes.size(), 161);
        Assert.assertTrue(pkg.subPackages.get("tag1").prefs.auth);
        Assert.assertFalse(pkg.subPackages.get("tag1").prefs.includeStatus);
        Assert.assertEquals(pkg.subPackages.get("tag1").prefs.design.event, "Wahl Mi, 23.01.");

        Assert.assertEquals(pkg.subPackages.get("tag1").projects.size(), 7);
        Assert.assertEquals(pkg.subPackages.get("tag1").selections.size(), 135);
        Assert.assertNull(pkg.subPackages.get("tag1").subPackages);

        // tag2
        Assert.assertEquals(pkg.subPackages.get("tag2").codes.size(), 161);
        Assert.assertTrue(pkg.subPackages.get("tag2").prefs.auth);
        Assert.assertFalse(pkg.subPackages.get("tag2").prefs.includeStatus);
        Assert.assertEquals(pkg.subPackages.get("tag2").prefs.design.event, "Wahl Do, 24.01.");

        Assert.assertEquals(pkg.subPackages.get("tag2").projects.size(), 7);
        Assert.assertEquals(pkg.subPackages.get("tag2").selections.size(), 134);
        Assert.assertNull(pkg.subPackages.get("tag2").subPackages);

        // tag3
        Assert.assertEquals(pkg.subPackages.get("tag3").codes.size(), 161);
        Assert.assertTrue(pkg.subPackages.get("tag3").prefs.auth);
        Assert.assertFalse(pkg.subPackages.get("tag3").prefs.includeStatus);
        Assert.assertEquals(pkg.subPackages.get("tag3").prefs.design.event, "Wahl Fr, 25.01.");

        Assert.assertEquals(pkg.subPackages.get("tag3").projects.size(), 6);
        Assert.assertEquals(pkg.subPackages.get("tag3").selections.size(), 136);
        Assert.assertNull(pkg.subPackages.get("tag3").subPackages);
    }

    @Test
    public void testSubPackage() {
        ProjectPackageDTO projectPackage = service.exportAll();
        Assert.assertEquals(projectPackage.projects.size(), 12);
        Assert.assertEquals(projectPackage.codes.size(), 0);

        NamespaceManager.set("junit");
        service.importAll(projectPackage);

        // adding subsite
        siteService.addSubSite("tag1");
        siteService.addSubSite("tag2");

        NamespaceManager.set("junit_tag1");
        PreferencesDTO p = prefService.getPreference(false);
        p.design.event = "Tag1";
        prefService.updatePreference(p);

        NamespaceManager.set("junit_tag2");
        p = prefService.getPreference(false);
        p.design.event = "Tag2";
        prefService.updatePreference(p);

        // export and validate
        NamespaceManager.set("junit");
        ProjectPackageDTO projectPackage2 = service.exportAll();
        Assert.assertEquals(projectPackage2.projects.size(), 12);
        Assert.assertEquals(projectPackage2.codes.size(), 0);

        Assert.assertEquals(projectPackage.projects, projectPackage2.projects);
        Assert.assertEquals(projectPackage.codes, projectPackage2.codes);

        Assert.assertEquals(projectPackage.prefs.design.event, "Projektwoche");

        ConfigDTO d = configService.getConfig(false);
        Assert.assertEquals(d.pref.design.event, "Projektwoche");
        Assert.assertEquals(d.pref.subSites.size(), 2);
        Assert.assertEquals(d.subConfig.get("tag1").pref.design.event, "Tag1");
        Assert.assertEquals(d.subConfig.get("tag2").pref.design.event, "Tag2");
    }

    @Test
    public void testPackageImport3() {
        Gson gson = new Gson();
        ProjectPackageDTO pkg = gson.fromJson(
                new InputStreamReader(this.getClass().getResourceAsStream("/data/hhgonline.qpkg"), StandardCharsets.UTF_8),
                ProjectPackageDTO.class);

        Assert.assertEquals(pkg.codes.size(), 784);
        Assert.assertTrue(pkg.prefs.auth);
        Assert.assertFalse(pkg.prefs.includeStatus);
        Assert.assertFalse(pkg.prefs.parameter.addNonVoters);
        Assert.assertEquals(pkg.prefs.design.city, "Köln");
        Assert.assertTrue(pkg.prefs.design.txtInfoJumbotron.contains("${"));

        Assert.assertEquals(pkg.projects.size(), 36);
        int i = 1;
        for (ProjectDTO p : pkg.projects) {
            if (i == 25)
                i++;
            if (i == 27)
                i++;
            Assert.assertEquals(p.id, i++);
        }
        Assert.assertEquals(pkg.selections.size(), 746);
        Assert.assertNull(pkg.subPackages);

        NamespaceManager.set("junit");
        service.importAll(pkg);

        ProjectPackageDTO p2 = service.exportAll();
        Assert.assertEquals(pkg.codes, p2.codes);
        Assert.assertEquals(pkg.persons, p2.persons);
        Assert.assertEquals(pkg.prefs, p2.prefs);
        Assert.assertEquals(pkg.selections.size(), p2.selections.size());
        for (i = 0; i < pkg.selections.size(); i++) {
            Assert.assertEquals("i=" + i + ": " + pkg.selections.get(i) + "\n    " + p2.selections.get(i),
                    pkg.selections.get(i), p2.selections.get(i));
        }
        Assert.assertEquals(pkg.subPackages, p2.subPackages);
        Assert.assertEquals("p2=" + p2.projects, pkg.projects.size(), p2.projects.size());
        Assert.assertEquals(pkg.projects, p2.projects);
    }

    @Test
    public void testProjDemo2BestEffort() {
        NamespaceManager.set("demo2");
        Gson gson = new Gson();
        ProjectPackageDTO pkg = gson.fromJson(
                new InputStreamReader(this.getClass().getResourceAsStream("/demo2.qpkg"), StandardCharsets.UTF_8),
                ProjectPackageDTO.class);

        Assert.assertEquals(pkg.projects.size(), 37);
        Assert.assertEquals(pkg.selections.size(), 607);
        Assert.assertEquals(pkg.codes.size(), 607);

        Assert.assertNotEquals(pkg.prefs.parameter.strategy, greedy);
        Assert.assertTrue(pkg.prefs.parameter.randomize);
        Assert.assertFalse(pkg.prefs.includeStatus);

        ProjectService prjService = new ProjectService();
        CodeService codeService = new CodeService();

        // insert projects
        prefService.updatePreference(pkg.prefs);
        prjService.addProjects(pkg.projects, true);
        codeService.insertCodes(pkg.codes);

        // cross check if projects have been inserted correctly
        List<ProjectDTO> ps = prjService.getProjects();
        List<CodeDTO> cs = codeService.getCodes();
        Assert.assertEquals(ps, pkg.projects);
        Assert.assertEquals(cs, pkg.codes);

        // insert selections
        SelectionService selectionService = new SelectionService();
        selectionService.insertSelections(pkg.selections);
        List<SelectionDTO> ss = selectionService.getAllSelection();
        Assert.assertEquals(ss, pkg.selections);

        // check report, all persons have been assigned
        ReportingService reportingService = new ReportingService();
        AssignedProjectListIntDTO ret = reportingService.getAssignedProjects(null);
        Assert.assertTrue(ret.unassignedPersons.size() <= 2);
        psum = ret.unassignedPersons.size();
        Assert.assertEquals(ret.assignedPersons.size(), 37);
        ret.assignedPersons.forEach((p, l) -> psum += l.size());
        Assert.assertEquals(psum, 607);

        // check status
        ps = prjService.getProjects();
        ps.forEach(p -> Assert.assertNull(p.status));
    }

    @Test
    public void testProjDemo2Greedy() {
        NamespaceManager.set("demo2");
        Gson gson = new Gson();
        ProjectPackageDTO pkg = gson.fromJson(
                new InputStreamReader(this.getClass().getResourceAsStream("/demo2.qpkg"), StandardCharsets.UTF_8),
                ProjectPackageDTO.class);

        Assert.assertEquals(pkg.projects.size(), 37);
        Assert.assertEquals(pkg.selections.size(), 607);
        Assert.assertEquals(pkg.codes.size(), 607);

        Assert.assertNotEquals(pkg.prefs.parameter.strategy, greedy);
        Assert.assertTrue(pkg.prefs.parameter.randomize);

        ProjectService prjService = new ProjectService();
        CodeService codeService = new CodeService();

        // insert projects
        pkg.prefs.parameter.strategy = greedy;
        pkg.prefs.parameter.randomize = false;
        pkg.prefs.includeStatus = true;
        prefService.updatePreference(pkg.prefs);
        prjService.addProjects(pkg.projects, true);
        codeService.insertCodes(pkg.codes);

        // cross check if projects have been inserted correctly
        List<ProjectDTO> ps = prjService.getProjects();
        List<CodeDTO> cs = codeService.getCodes();
        Assert.assertEquals(ps, pkg.projects);
        Assert.assertEquals(cs, pkg.codes);

        // insert selections
        SelectionService selectionService = new SelectionService();
        selectionService.insertSelections(pkg.selections);
        List<SelectionDTO> ss = selectionService.getAllSelection();
        Assert.assertEquals(ss, pkg.selections);

        // check report, all persons have been assigned
        ReportingService reportingService = new ReportingService();
        AssignedProjectListIntDTO ret = reportingService.getAssignedProjects(null);
        Assert.assertEquals(ret.unassignedPersons.size(), 13);
        psum = ret.unassignedPersons.size();
        Assert.assertEquals(ret.assignedPersons.size(), 37);
        ret.assignedPersons.forEach((p, l) -> psum += l.size());
        Assert.assertEquals(psum, 607);

        // check status
        ps = prjService.getProjectsDetail();
        prjService.addStatus(ps);
        Integer[] expected = {2, 2, null, 2, 2, 2, 2, 1, 2, 2, 2, null, null, null, 1, null, null, null, null, null, null, null, 2, 2, 2, null, 1, 1, 2, null, null, null, null, null, null, 2, 2};

        for (int i = 0; i < ps.size(); i++) {
            Assert.assertEquals(ps.get(i).status, expected[i]);
        }

        // cross check maxSize
        Integer[] maxSize = {12, 14, 25, 15, 10, 20, 20, 30, 25, 25, 30, 16, 30, 20, 30, 30, 20, 25, 30, 25, 25, 25, 15, 30, 12, 30, 25, 20, 10, 12, 30, 25, 30, 20, 30, 10, 16};
        for (int i = 0; i < ps.size(); i++) {
            Assert.assertEquals(maxSize[i].intValue(), ps.get(i).maxSize);
        }

        // cross check status
        Integer[] assigned = {12, 14, 15, 15, 10, 20, 20, 29, 25, 25,
                30, 8, 10, 15, 25, 12, 12, 10,
                10, 16, 12, 7, 15, 30, 12, 16,
                24, 17, 10, 8, 23, 18, 13, 13, 17, 10, 16};
        int sump = 0;
        for (int i = 0; i < ps.size(); i++) {
            sump += assigned[i];
            Assert.assertEquals(assigned[i].intValue(), ret.assignedPersons.get(ps.get(i)).size());
        }
        Assert.assertEquals(sump, 607 - 13);
    }
}
