package de.quaestio24.service;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.tools.development.testing.LocalDatastoreServiceTestConfig;
import com.google.appengine.tools.development.testing.LocalServiceTestHelper;
import de.quaestio24.dto.ProjectDTO;
import de.quaestio24.dto.ProjectDTO.ProjectAttribute;
import de.quaestio24.dto.ProjectDetailsDTO;
import de.quaestio24.exception.ValidationException;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ProjectServiceTest {

    private final LocalServiceTestHelper helper = new LocalServiceTestHelper(new LocalDatastoreServiceTestConfig());
    private ProjectService service = new ProjectService();

    @Before
    public void setUp() {
        helper.setUp();
        new SiteService().addSite("junit1");
        NamespaceManager.set("junit1");
    }

    @After
    public void tearDown() {
        helper.tearDown();
    }

    @Test
    public void readInitial() {
        List<ProjectDTO> projList = service.getProjects();
        Assert.assertEquals(0, projList.size());
    }

    @Test
    public void readAndAddProject() {
        for (int i = 1; i <= 30; i++) {
            ProjectDTO p = new ProjectDTO();
            p.title = "title" + i;
            p.maxSize = 10;
            p.maxGenderRate = 50;
            p.additional = new HashMap<>();
            p.additional.put(ProjectAttribute.clazz, (i % 9 + 1) + " - " + (i % 9 + 91));
            p.additional.put(ProjectAttribute.costs, "10");
            p.additional.put(ProjectAttribute.room, "p1");
            p.additional.put(ProjectAttribute.teacher, "Dumbledore");
            p.details = new ProjectDetailsDTO();
            p.details.description = "This is a cool project " + i;
            p.id = i * 3;

            service.addProject(p);

            List<ProjectDTO> projList = service.getProjects();
            Assert.assertEquals(i, projList.size());
            for (ProjectDTO x : projList) {
                Assert.assertNull(x.details);
            }

            List<ProjectDTO> projListd = service.getProjectsDetail();
            Assert.assertEquals(i, projList.size());
            for (ProjectDTO x : projListd) {
                Assert.assertNotNull(x.details.description);
                Assert.assertTrue(x.details.description.startsWith("This is a cool project "));
            }
        }

        // delete a project
        List<ProjectDTO> projList = service.getProjects();
        int id = projList.get(5).id;
        Assert.assertNotEquals(id, 0);

        service.deleteProject(id);

        projList = service.getProjects();
        Assert.assertEquals(29, projList.size());

        // update a project
        ProjectDTO prjToUpdate = projList.get(10);
        id = prjToUpdate.id;
        prjToUpdate.title = "new title";
        Assert.assertNotEquals(id, 0);

        service.updateProject(prjToUpdate);

        ProjectDTO newPro = service.getProject(id);

        Assert.assertEquals(prjToUpdate, newPro);
        Assert.assertEquals(prjToUpdate.title, newPro.title);
        Assert.assertEquals(prjToUpdate.additional.get(ProjectAttribute.teacher),
                newPro.additional.get(ProjectAttribute.teacher));

        projList = service.getProjectsDetail();
        Assert.assertEquals(29, projList.size());

        // fixNumbers
        Map<Integer, Integer> map = service.fixNumbers();
        Assert.assertEquals("map=" + map, 27, map.size());

        List<ProjectDTO> projList2 = service.getProjectsDetail();
        Assert.assertEquals(29, projList2.size());

        Set<String> mp1 = new HashSet<>();
        for (ProjectDTO p : projList) {
            mp1.add(p.title + ";" + p.maxSize + ";" + p.minSize + ";" + p.additional);
        }

        Set<Integer> ids = new HashSet<>();
        Set<String> mp2 = new HashSet<>();
        for (ProjectDTO p : projList2) {
            mp2.add(p.title + ";" + p.maxSize + ";" + p.minSize + ";" + p.additional);
            ids.add(p.id);
        }

        Assert.assertEquals(mp1.size(), mp2.size());
        Assert.assertEquals(ids.size(), mp2.size());
        Assert.assertEquals(mp1, mp2);

        Assert.assertTrue("val=" + projList2.get(0).additional.get(ProjectAttribute.clazz),
                projList2.get(0).additional.get(ProjectAttribute.clazz).startsWith("1 - "));
        Assert.assertTrue("val=" + projList2.get(28).additional.get(ProjectAttribute.clazz),
                projList2.get(28).additional.get(ProjectAttribute.clazz).startsWith("9 - 99"));

        for (ProjectDTO p : projList2) {
            Assert.assertTrue(p.id >= 1);
            Assert.assertTrue(p.id <= ids.size());
        }

        // delete all
        service.deleteAllProjects();
        projList = service.getProjectsDetail();
        Assert.assertEquals(0, projList.size());

        projList = service.getProjects();
        Assert.assertEquals(0, projList.size());
    }

    @Test
    public void validateOk() {
        ProjectDTO p = new ProjectDTO();
        p.details = new ProjectDetailsDTO();
        p.details.description = "hallo";
        p.maxGenderRate = 100;
        p.maxSize = 10;
        p.additional = new HashMap<>();
        p.additional.put(ProjectAttribute.clazz, "5a");
        p.additional.put(ProjectAttribute.costs, "10");
        p.additional.put(ProjectAttribute.room, "3");
        p.additional.put(ProjectAttribute.teacher, "dumbledore");
        p.title = "title";
        service.validate(p);
    }

    @Test(expected = ValidationException.class)
    public void validateNOk() {
        ProjectDTO p = new ProjectDTO();
        p.details = new ProjectDetailsDTO();
        p.details.description = "hallo";
        p.maxGenderRate = 100;
        p.maxSize = 10;
        p.additional = new HashMap<>();
        p.additional.put(ProjectAttribute.clazz, "5a");
        p.additional.put(ProjectAttribute.costs, "10");
        p.additional.put(ProjectAttribute.room, "3");
        service.validate(p);
    }

    @Test
    public void getDemoProjects() {
        NamespaceManager.set("prjtest");
        List<ProjectDTO> projects = service.getProjects();
        Assert.assertEquals(projects.size(), 12);

        NamespaceManager.set("prjtest2");
        projects = service.getProjects();
        Assert.assertEquals(projects.size(), 500);
    }
}
