package de.quaestio24.service;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.tools.development.testing.LocalDatastoreServiceTestConfig;
import com.google.appengine.tools.development.testing.LocalServiceTestHelper;
import de.quaestio24.dto.LoginStatDTO;
import de.quaestio24.dto.UserDTO;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

public class LoginStatsServiceTest {

    private final LocalServiceTestHelper helper = new LocalServiceTestHelper(new LocalDatastoreServiceTestConfig());
    private LoginStatsService loginStatsService = new LoginStatsService();
    private UserService userService = new UserService();

    @Before
    public void setUp() {
        helper.setUp();
    }

    @After
    public void tearDown() {
        helper.tearDown();
    }

    @Test
    public void testLoginStatsFailed() {

        new SiteService().addSite("junit1");
        NamespaceManager.set("junit1");
        List<LoginStatDTO> l = loginStatsService.getLoginStats().logins;
        Assert.assertEquals(l.size(), 0);

        UserDTO user = new UserDTO();
        user.email = "email";
        user.password = "pw";
        user.site = "junit1";
        user.provider = "login";
        try {
            userService.login(user);
            Assert.fail();
        } catch (SecurityException e) {
            l = loginStatsService.getLoginStats().logins;
            Assert.assertEquals(l.size(), 1);
            Assert.assertNotNull(l.get(0).lastFailedLogin);
            Assert.assertNull(l.get(0).lastSuccessLogin);
            Assert.assertEquals(l.get(0).loginCount, 1);
        }
    }

    @Test
    public void testLoginStats() {

        new SiteService().addSite("junit1");
        NamespaceManager.set("junit1");
        List<LoginStatDTO> l = loginStatsService.getLoginStats().logins;
        Assert.assertEquals(l.size(), 0);

        UserDTO user = new UserDTO();
        user.email = "email";
        user.password = "pw";
        user.site = "junit1";
        user.provider = "amazon";
        UserDTO u = userService.login(user);
        Assert.assertEquals(u.email, user.email);

        l = loginStatsService.getLoginStats().logins;
        Assert.assertEquals(l.size(), 1);
    }
}
