package de.quaestio24.service;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.tools.development.testing.LocalDatastoreServiceTestConfig;
import com.google.appengine.tools.development.testing.LocalServiceTestHelper;
import de.quaestio24.dto.PersonDTO;
import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.dto.PreferencesDTO.Parameter;
import de.quaestio24.dto.ProjectDTO;
import de.quaestio24.dto.ProjectDTO.ProjectAttribute;
import de.quaestio24.dto.ReportDTO;
import de.quaestio24.dto.SelectionDTO;
import de.quaestio24.service.dto.AssignedProjectListIntDTO;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RunWith(MockitoJUnitRunner.class)
public class ReportServiceTest {

    private final LocalServiceTestHelper helper = new LocalServiceTestHelper(new LocalDatastoreServiceTestConfig());

    @Mock
    private ProjectService projectService;

    @Mock
    private SelectionService selectionService;

    @Mock
    private PreferencesService preferenceService;

    @InjectMocks
    private ReportingService reportService;

    @Before
    public void setUp() {
        helper.setUp();
        long now = System.currentTimeMillis();
        List<ProjectDTO> proj;
        List<SelectionDTO> selections;
        PreferencesDTO pref;

        // Usecase1: annefrank
        // prepare project
        proj = new ArrayList<>();
        ProjectDTO p = new ProjectDTO();
        p.id = 100;
        p.title = "title";
        p.additional = new HashMap<>();
        p.additional.put(ProjectAttribute.clazz, "1-9");
        p.maxSize = 1;
        p.maxGenderRate = 50;
        proj.add(p);

        Mockito.when(projectService.getProjects()).thenReturn(proj);

        // selection
        selections = new ArrayList<>();
        SelectionDTO s = new SelectionDTO();
        s.created = new Date(now);
        s.person = new PersonDTO();
        s.person.name = "b1";
        s.selections = Collections.singletonList(100);
        selections.add(s);

        s = new SelectionDTO();
        s.created = new Date(now + 100);
        s.person = new PersonDTO();
        s.person.name = "b2";
        s.selections = Collections.singletonList(100);
        selections.add(s);

        Mockito.when(selectionService.getAllSelection()).thenReturn(selections);

        pref = new PreferencesDTO();
        pref.endDate = new Date(now + 100000);
        pref.parameter = new Parameter();
        Mockito.when(preferenceService.getPreference()).thenReturn(pref);
    }

    @After
    public void tearDown() {
        helper.tearDown();
    }

    @Test
    public void testSort() {
        Map<String, Integer> m2 = new HashMap<>();
        m2.put("lui", 69);
        m2.put("a", 1);
        m2.put("a1", 1);
        m2.put("b", 7);
        m2.put("b1", 7);
        m2.put("c", 9);
        m2.put("d", 2);
        m2.put("x", 0);
        Map<String, Integer> m1 = new ReportingService().sort(m2);

        Assert.assertEquals(m1, m2);

        List<String> l = new ArrayList<>(m1.keySet());

        int i = 0;
        Assert.assertEquals("" + l, "lui", l.get(i++));
        Assert.assertEquals("" + l, "c", l.get(i++));
        Assert.assertEquals("" + l, "b1", l.get(i++));
        Assert.assertEquals("" + l, "b", l.get(i++));
        Assert.assertEquals("" + l, "d", l.get(i++));
        Assert.assertEquals("" + l, "a1", l.get(i++));
        Assert.assertEquals("" + l, "a", l.get(i++));
        Assert.assertEquals("" + l, "x", l.get(i));

    }

    @Test
    public void assignedProjectsAf() {

        AssignedProjectListIntDTO res = reportService.getAssignedProjects(null);

        // assigned, unassignedPerson
        Assert.assertNotNull(res);
        Assert.assertEquals(res.assignedPersons.size(), 1);
        Assert.assertEquals(res.unassignedPersons.size(), 1);

        Assert.assertTrue(res.unassignedPersons.get(0).name.startsWith("b"));
        Assert.assertFalse(res.unassignedPersons.get(0).selections.isEmpty());

        ProjectDTO p = new ProjectDTO();
        p.id = 100;
        List<PersonDTO> persons = res.assignedPersons.get(p);
        Assert.assertEquals(persons.size(), 1);
        PersonDTO assignedPerson = persons.get(0);
        Assert.assertTrue(assignedPerson.name.startsWith("b"));

        // posByPerson
        Assert.assertEquals((int) res.posByPerson.get(assignedPerson), 1);

        // countByPos
        Assert.assertEquals((int) res.countByPos.get(1), 1);

        // countByProject
        Assert.assertEquals((int) res.countByProject.get("title"), 2);
    }

    @Test
    public void assignedProjectsXLS() {
        NamespaceManager.set("junit");
        byte[] buffer = reportService.getAssignedReportXLS(null);
        Assert.assertNotNull(buffer);
        Assert.assertEquals(buffer.length, 32256);
    }

    @Test
    public void getReport() {
        ReportDTO stats = reportService.getReport();
        Assert.assertNotNull(stats.report1);
        Assert.assertNotNull(stats.report2);
        Assert.assertNotNull(stats.report3);
    }

    @Test
    public void checkDist() {
        PersonDTO p1 = new PersonDTO();
        p1.name = "Müller";
        p1.surname = "Peter";
        p1.clazz = "5";

        PersonDTO p2 = new PersonDTO();
        p2.name = "Muxller";
        p2.surname = "Peter John";
        p2.clazz = "5";
        Assert.assertTrue(reportService.isPersonMatch(p1, p2));
    }

    @Test
    public void checkDist2() {
        PersonDTO p1 = new PersonDTO();
        p1.name = "Müller";
        p1.surname = "Peter";
        p1.clazz = "5";

        PersonDTO p2 = new PersonDTO();
        p2.name = "Mueller";
        p2.surname = "Piter";
        p2.clazz = "5";
        Assert.assertTrue(reportService.isPersonMatch(p1, p2));
    }

    @Test
    public void checkDist3() {
        PersonDTO p1 = new PersonDTO();
        p1.name = "Blažinčić";
        p1.surname = "Luca-yannick";
        p1.clazz = "5";

        PersonDTO p2 = new PersonDTO();
        p2.name = "Blazincic";
        p2.surname = "Luca";
        p2.clazz = "5";
        Assert.assertTrue(reportService.isPersonMatch(p1, p2));
    }

    @Test
    public void checkDistNo() {
        PersonDTO p1 = new PersonDTO();
        p1.name = "Müller";
        p1.surname = "Peter";
        p1.clazz = "5";

        PersonDTO p2 = new PersonDTO();
        p2.name = "Muxller";
        p2.surname = "Petra";
        p2.clazz = "5";
        Assert.assertFalse(reportService.isPersonMatch(p1, p2));
    }

    @Test
    public void checkDistNo2() {
        PersonDTO p1 = new PersonDTO();
        p1.name = "Müller";
        p1.surname = "Peter";
        p1.clazz = "6";

        PersonDTO p2 = new PersonDTO();
        p2.name = "Muxller";
        p2.surname = "Peter";
        p2.clazz = "5";
        Assert.assertFalse(reportService.isPersonMatch(p1, p2));
    }
}
