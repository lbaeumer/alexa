package de.quaestio24.service;

import com.google.appengine.tools.development.testing.LocalDatastoreServiceTestConfig;
import com.google.appengine.tools.development.testing.LocalServiceTestHelper;
import de.quaestio24.dto.PersonDTO;
import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.dto.PreferencesDTO.Parameter;
import de.quaestio24.dto.ProjectDTO;
import de.quaestio24.dto.ProjectDTO.ProjectAttribute;
import de.quaestio24.dto.SelectionDTO;
import de.quaestio24.service.dto.AssignedProjectListIntDTO;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class Report2ServiceTest {

    private final LocalServiceTestHelper helper = new LocalServiceTestHelper(new LocalDatastoreServiceTestConfig());

    @Mock
    private ProjectService projectService;

    @Mock
    private SelectionService selectionService;

    @Mock
    private PreferencesService preferenceService;

    @InjectMocks
    private ReportingService reportService;

    @Before
    public void setUp() {
        helper.setUp();
        long now = System.currentTimeMillis();
        List<ProjectDTO> proj;
        List<SelectionDTO> selections;
        PreferencesDTO pref;

        // Usecase2: ohg
        // prepare project
        proj = new ArrayList<>();
        ProjectDTO p = new ProjectDTO();
        p.id = 100;
        p.title = "ohgtitle1";
        p.additional = new HashMap<>();
        p.additional.put(ProjectAttribute.clazz, "1-9");
        p.maxSize = 10;
        p.maxGenderRate = 100;
        proj.add(p);

        p = new ProjectDTO();
        p.id = 101;
        p.title = "ohgtitle2";
        p.additional = new HashMap<>();
        p.additional.put(ProjectAttribute.clazz, "1-9");
        p.maxSize = 10;
        p.maxGenderRate = 100;
        proj.add(p);

        p = new ProjectDTO();
        p.id = 102;
        p.title = "ohgtitle3";
        p.additional = new HashMap<>();
        p.additional.put(ProjectAttribute.clazz, "1-9");
        p.maxSize = 10;
        p.maxGenderRate = 100;
        proj.add(p);

        Mockito.when(projectService.getProjects()).thenReturn(proj);

        // selection in 1st phase
        selections = new ArrayList<>();
        for (int i = 0; i < 20; i++) {
            SelectionDTO s = new SelectionDTO();
            s.created = new Date(now + i);
            s.person = new PersonDTO();
            s.person.name = "assigned" + i;
            s.person.surname = "s" + i;
            s.selections = new ArrayList<>();
            s.selections.add(100);
            s.selections.add(101);
            s.selections.add(102);
            selections.add(s);
        }

        for (int i = 0; i < 20; i++) {
            SelectionDTO s = new SelectionDTO();
            s.created = new Date(now + 250000 + i);
            s.person = new PersonDTO();
            s.person.name = "notassigned" + i;
            s.selections = new ArrayList<>();
            s.selections.add(100);
            s.selections.add(101);
            s.selections.add(102);
            selections.add(s);
        }

        Mockito.when(selectionService.getAllSelection()).thenReturn(selections);

        pref = new PreferencesDTO();
        pref.endDate = new Date(now + 100000);
        pref.startDate2 = new Date(now + 200000);
        pref.endDate2 = new Date(now + 300000);
        pref.parameter = new Parameter();
        Mockito.when(preferenceService.getPreference()).thenReturn(pref);
    }

    @After
    public void tearDown() {
        helper.tearDown();
    }

    @Test
    public void assignedProjectsOhg() {
        AssignedProjectListIntDTO res = reportService.getAssignedProjects(null);

        // countByPos
        Assert.assertEquals(res.countByPos.size(), 3);
        Assert.assertEquals((int) res.countByPos.get(1), 10);
        Assert.assertEquals((int) res.countByPos.get(2), 10);
        Assert.assertEquals((int) res.countByPos.get(3), 10);

        // countByProject
        Assert.assertEquals("res=" + res.countByProject, res.countByProject.size(), 1);
        Assert.assertEquals((int) res.countByProject.get("ohgtitle1"), 40);

        // assigned, unassignedPerson
        Assert.assertNotNull("res=" + res, res);
        Assert.assertEquals(res.assignedPersons.size(), 3);
        Assert.assertEquals(res.unassignedPersons.size(), 10);

        // check assigned
        for (ProjectDTO p : res.assignedPersons.keySet()) {
            Assert.assertTrue("p=" + p, p.id >= 100 && p.id <= 102);
            List<PersonDTO> pers = res.assignedPersons.get(p);
            Assert.assertEquals(pers.size(), 10);

            if (p.id <= 101) {
                for (PersonDTO pe : pers) {
                    Assert.assertTrue(pe.name.startsWith("assigned"));
                }
            } else if (p.id == 102) {
                for (PersonDTO pe : pers) {
                    Assert.assertTrue(pe.name.startsWith("notassigned"));
                }
            }
        }

        // check not assigned
        for (PersonDTO pe : res.unassignedPersons) {
            Assert.assertTrue(pe.name, pe.name.startsWith("notassigned"));
        }

        ProjectDTO p = new ProjectDTO();
        p.id = 100;
        List<PersonDTO> persons = res.assignedPersons.get(p);
        Assert.assertEquals(persons.size(), 10);
        PersonDTO assignedPerson = persons.get(0);
        Assert.assertTrue(assignedPerson.name.startsWith("assigned"));
    }
}
