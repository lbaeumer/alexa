package de.quaestio24.service;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.tools.development.testing.LocalDatastoreServiceTestConfig;
import com.google.appengine.tools.development.testing.LocalServiceTestHelper;
import de.quaestio24.dto.AuthDTO;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

public class SiteServiceTest {

    private final LocalServiceTestHelper helper = new LocalServiceTestHelper(new LocalDatastoreServiceTestConfig());
    private SiteService siteService = new SiteService();

    @Before
    public void setUp() {
        helper.setUp();
    }

    @After
    public void tearDown() {
        helper.tearDown();
    }

    @Test
    public void addAndRead() {

        NamespaceManager.set("junit1");
        new SiteService().addSite("junit1");
        NamespaceManager.set("junit2");
        new SiteService().addSite("junit2");

        List<String> all = siteService.getSettings().sites;
        Assert.assertEquals("all=" + all, all.size(), 8);
        Assert.assertEquals(all.get(0), "demo");
        Assert.assertEquals(all.get(6), "junit1");
        Assert.assertEquals(all.get(7), "junit2");

        NamespaceManager.set("junit4");
        new SiteService().addSite("junit4");

        all = siteService.getSettings().sites;
        Assert.assertEquals(all.size(), 9);
        Assert.assertEquals(all.get(8), "junit4");

        AuthService authService = new AuthService();

        NamespaceManager.set("junit1");
        List<AuthDTO> l = authService.getAllAuths();
        Assert.assertEquals(l.size(), 1);
        Assert.assertEquals(l.get(0).email, "lui.baeumer@gmail.com");
    }
}
