package de.quaestio24.service;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.tools.development.testing.LocalDatastoreServiceTestConfig;
import com.google.appengine.tools.development.testing.LocalServiceTestHelper;
import de.quaestio24.dto.ConfigDTO;
import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.dto.PreferencesDTO.DesignParameter;
import de.quaestio24.dto.PreferencesDTO.Parameter;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;

public class ConfigServiceTest {

    private final LocalServiceTestHelper helper = new LocalServiceTestHelper(new LocalDatastoreServiceTestConfig());
    private ConfigService configService = new ConfigService();
    private PreferencesService prefService = new PreferencesService();
    private SiteService siteService = new SiteService();

    @Before
    public void setUp() {
        helper.setUp();
    }

    @After
    public void tearDown() {
        helper.tearDown();
    }

    @Test(expected = IllegalStateException.class)
    public void testConfigDoesNotExist() {
        NamespaceManager.set("junit5");
        configService.getConfig(false);
    }

    @Test
    public void test2() {
        siteService.addSite("junit1");
        NamespaceManager.set("junit1");
        ConfigDTO config = configService.getConfig(false);
        Assert.assertEquals(config.subConfig.size(), 0);
        Assert.assertEquals(config.pref.design.event, "Projektwoche");

        PreferencesDTO pref = prefService.getPreference();
        Assert.assertEquals(pref.design.event, "Projektwoche");

        // adding subsites
        pref.subSites = new ArrayList<>();
        pref.subSites.add("day1");
        pref.subSites.add("day2");
        prefService.updatePreference(pref);

        NamespaceManager.set("junit1_day1");
        PreferencesDTO p1 = new PreferencesDTO();
        p1.parameter = new Parameter();
        p1.design = new DesignParameter();
        p1.design.event = "day one";
        prefService.updatePreference(p1);

        NamespaceManager.set("junit1_day2");
        PreferencesDTO p2 = new PreferencesDTO();
        p2.parameter = new Parameter();
        p2.design = new DesignParameter();
        p2.design.event = "day two";
        prefService.updatePreference(p2);

        // reading subsites
        NamespaceManager.set("junit1");
        config = configService.getConfig(false);
        Assert.assertEquals(config.subConfig.size(), 2);
        Assert.assertEquals(config.pref.design.event, "Projektwoche");
        Assert.assertEquals(config.subConfig.get("day1").pref.design.event, "day one");
        Assert.assertEquals(config.subConfig.get("day1").site, "junit1_day1");
        Assert.assertEquals(config.subConfig.get("day2").pref.design.event, "day two");
        Assert.assertEquals(config.subConfig.get("day2").site, "junit1_day2");

    }

    @Test
    public void addSubSite() {

        siteService.addSite("junit1");
        NamespaceManager.set("junit1");
        siteService.addSubSite("tag1");
        siteService.addSubSite("tag2");

        ConfigDTO config = configService.getConfig(false);
        Assert.assertEquals(config.subConfig.size(), 2);
        Assert.assertEquals(config.pref.design.event, "Projektwoche");
        Assert.assertEquals(config.subConfig.get("tag1").pref.design.event, "tag1");
        Assert.assertEquals(config.subConfig.get("tag2").pref.design.event, "tag2");
        Assert.assertEquals(config.subConfig.get("tag1").site, "junit1_tag1");
        Assert.assertEquals(config.subConfig.get("tag2").site, "junit1_tag2");
    }
}
