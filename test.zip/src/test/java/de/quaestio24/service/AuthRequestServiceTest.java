package de.quaestio24.service;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.tools.development.testing.LocalDatastoreServiceTestConfig;
import com.google.appengine.tools.development.testing.LocalServiceTestHelper;
import de.quaestio24.constant.RoleEnum;
import de.quaestio24.dto.AuthDTO;
import de.quaestio24.dto.AuthRequestDTO;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

public class AuthRequestServiceTest {

    private final LocalServiceTestHelper helper = new LocalServiceTestHelper(new LocalDatastoreServiceTestConfig());
    private AuthRequestService authRequestService = new AuthRequestService();
    private AuthService authService = new AuthService();

    @Before
    public void setUp() {
        helper.setUp();
    }

    @After
    public void tearDown() {
        helper.tearDown();
    }

    @Test
    public void testAuthRequest() {
        NamespaceManager.set("demo");
        List<AuthRequestDTO> requs = authRequestService.getAuthRequests();
        Assert.assertEquals(requs.size(), 0);

        // insert auth request
        AuthRequestDTO request = new AuthRequestDTO();
        request.email = "email";
        request.provider = "prov";
        boolean b = authRequestService.insertAuthRequest(request);
        Assert.assertTrue(b);

        // insert auth
        AuthDTO auth = new AuthDTO();
        auth.email = "email2";
        auth.provider = "prov2";
        authService.insertAuth(auth);

        requs = authRequestService.getAuthRequests();
        Assert.assertEquals(requs.size(), 1);
        Assert.assertEquals(requs.get(0).email, "email");
        Assert.assertEquals(requs.get(0).provider, "prov");

        // now delete and test again
        requs = authRequestService.deleteAuthRequest(requs.get(0));
        Assert.assertEquals(requs.size(), 0);

        requs = authRequestService.getAuthRequests();
        Assert.assertEquals(requs.size(), 0);
    }

    @Test
    public void testAuthRequestSubSite() {
        NamespaceManager.set("demo");
        List<AuthRequestDTO> requs = authRequestService.getAuthRequests();
        Assert.assertEquals(requs.size(), 0);

        // insert auth request
        NamespaceManager.set("demo_xyz1");
        AuthRequestDTO request = new AuthRequestDTO();
        request.email = "email";
        request.provider = "prov";
        boolean b = authRequestService.insertAuthRequest(request);
        Assert.assertTrue(b);

        // insert auth
        NamespaceManager.set("demo_xyz2");
        AuthDTO auth = new AuthDTO();
        auth.email = "email2";
        auth.provider = "prov2";
        authService.insertAuth(auth);

        NamespaceManager.set("demo");
        requs = authRequestService.getAuthRequests();
        Assert.assertEquals(requs.size(), 1);
        Assert.assertEquals(requs.get(0).email, "email");
        Assert.assertEquals(requs.get(0).provider, "prov");

        NamespaceManager.set("demo_xxx");
        requs = authRequestService.getAuthRequests();
        Assert.assertEquals(requs.size(), 1);
        Assert.assertEquals(requs.get(0).email, "email");
        Assert.assertEquals(requs.get(0).provider, "prov");

        // now delete and test again
        NamespaceManager.set("demo_xyz3");
        requs = authRequestService.deleteAuthRequest(requs.get(0));
        Assert.assertEquals(requs.size(), 0);

        NamespaceManager.set("demo_xyz4");
        requs = authRequestService.getAuthRequests();
        Assert.assertEquals(requs.size(), 0);
    }

    @Test
    public void testGrantAuthRequest() {
        NamespaceManager.set("demo");
        List<AuthRequestDTO> requs = authRequestService.getAuthRequests();
        Assert.assertEquals(requs.size(), 0);

        // insert auth request
        AuthRequestDTO request = new AuthRequestDTO();
        request.email = "email";
        request.provider = "prov";
        boolean b = authRequestService.insertAuthRequest(request);
        Assert.assertTrue(b);

        // now grant
        List<AuthRequestDTO> requests = authRequestService.grantAuthRequest(request, RoleEnum.superadmin);
        Assert.assertEquals("req=" + requests, requests.size(), 0);

        // check result
        requests = authRequestService.getAuthRequests();
        Assert.assertEquals(requests.size(), 0);

        List<RoleEnum> roles = authService.getRoles(request.provider, request.email);
        Assert.assertEquals(roles.size(), 1);
        Assert.assertEquals(roles.get(0), RoleEnum.superadmin);
    }
}
