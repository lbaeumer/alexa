package de.quaestio24.service;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.tools.development.testing.LocalDatastoreServiceTestConfig;
import com.google.appengine.tools.development.testing.LocalServiceTestHelper;
import de.quaestio24.dto.PreferencesDTO;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class PreferenceServiceTest {

    private final LocalServiceTestHelper helper = new LocalServiceTestHelper(new LocalDatastoreServiceTestConfig());
    private PreferencesService prefService = new PreferencesService();

    @Before
    public void setUp() {
        helper.setUp();

        new SiteService().addSite("junit1");
        NamespaceManager.set("junit1");
    }

    @After
    public void tearDown() {
        helper.tearDown();
    }

    @Test
    public void testPreferences() {
        PreferencesDTO pref = prefService.getPreference(false);
        Assert.assertNotNull(pref);
        Assert.assertNotNull(pref.startDate);
        Assert.assertEquals(pref.design.paginateCount, 50);

        Assert.assertEquals(pref.design.txtSelectionFormCodeText,
                "Bitte geben Sie den ${minCodeLen}-stelligen Code ein, den Sie in der Schule bekommen haben.");

        pref = prefService.getPreference(true);
        Assert.assertNotNull(pref);
        Assert.assertNotNull(pref.startDate);
        Assert.assertEquals(pref.design.paginateCount, 50);

        Assert.assertEquals(pref.design.minCodeLen, 7);
        Assert.assertEquals(pref.design.txtSelectionFormCodeText,
                "Bitte geben Sie den 7-stelligen Code ein, den Sie in der Schule bekommen haben.");
    }

    @Test
    public void update() {
        new SiteService().addSite("junit3");
        NamespaceManager.set("junit3");
        PreferencesDTO pref = prefService.getPreference(false);

        pref.emailcc = "lui@xxx.de";
        PreferencesDTO p = prefService.updatePreference(pref);

        Assert.assertEquals(pref.startDate, p.startDate);
        Assert.assertEquals(pref.emailcc, p.emailcc);

        Assert.assertEquals(pref.design.txtSelectionFormCodeText,
                "Bitte geben Sie den ${minCodeLen}-stelligen Code ein, den Sie in der Schule bekommen haben.");
    }

    @Test
    public void addSite() {
        NamespaceManager.set("junit1");
        PreferencesDTO pref = prefService.getPreference(false);

        pref.subSites.add("hallosub1");
        pref.subSites.add("hallosub1");
        PreferencesDTO p = prefService.updatePreference(pref);

        Assert.assertEquals(pref.startDate, p.startDate);
        Assert.assertEquals(pref.emailcc, p.emailcc);

        Assert.assertEquals(pref.design.txtSelectionFormCodeText,
                "Bitte geben Sie den ${minCodeLen}-stelligen Code ein, den Sie in der Schule bekommen haben.");

        Assert.assertEquals(pref.subSites.size(), 2);
        Assert.assertEquals(pref.subSites.get(0), "hallosub1");
        Assert.assertEquals(pref.design.paginateCount, 50);
    }
}
