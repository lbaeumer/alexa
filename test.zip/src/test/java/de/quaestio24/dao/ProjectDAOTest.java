package de.quaestio24.dao;

import de.quaestio24.dto.ProjectDTO;
import de.quaestio24.dto.ProjectDTO.ProjectAttribute;
import org.junit.Assert;
import org.junit.Test;

import java.util.HashMap;

public class ProjectDAOTest {

    private ProjectDAO dao = new ProjectDAO();

    @Test
    public void testFixClass() {
        ProjectDTO p = new ProjectDTO();
        p.additional = new HashMap<>();

        // test -
        p.additional.put(ProjectAttribute.clazz, "8-9");
        dao.fixClass(p);
        Assert.assertEquals(p.additional.get(ProjectAttribute.clazz), "8 - 9");

        // test -
        p.additional.put(ProjectAttribute.clazz, "8-  9");
        dao.fixClass(p);
        Assert.assertEquals(p.additional.get(ProjectAttribute.clazz), "8 - 9");

        // test -
        p.additional.put(ProjectAttribute.clazz, "   8 - 9");
        dao.fixClass(p);
        Assert.assertEquals(p.additional.get(ProjectAttribute.clazz), "8 - 9");

        // test ,
        p.additional.put(ProjectAttribute.clazz, "8,9");
        dao.fixClass(p);
        Assert.assertEquals(p.additional.get(ProjectAttribute.clazz), "8, 9");

        // test ,
        p.additional.put(ProjectAttribute.clazz, "8  ,  9");
        dao.fixClass(p);
        Assert.assertEquals(p.additional.get(ProjectAttribute.clazz), "8, 9");

        // test ,
        p.additional.put(ProjectAttribute.clazz, "   8 , 9");
        dao.fixClass(p);
        Assert.assertEquals(p.additional.get(ProjectAttribute.clazz), "8, 9");
    }
}
