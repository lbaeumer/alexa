package de.quaestio24.dao;

import com.google.appengine.tools.development.testing.LocalDatastoreServiceTestConfig;
import com.google.appengine.tools.development.testing.LocalServiceTestHelper;
import de.quaestio24.constant.RoleEnum;
import de.quaestio24.dao.AuthDAO.AuthRegExDTO;
import de.quaestio24.dto.AuthDTO;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class AuthDAOTest {

    private final LocalServiceTestHelper helper = new LocalServiceTestHelper(new LocalDatastoreServiceTestConfig());
    private AuthDAO dao = new AuthDAO();

    @Before
    public void setUp() {
        helper.setUp();
    }

    @After
    public void tearDown() {
        helper.tearDown();
    }

    @Test
    public void empty() {
        List<AuthRegExDTO> al = new ArrayList<>();
        Assert.assertEquals(dao.buildResult(al).size(), 0);
    }

    @Test
    public void single() {
        List<AuthRegExDTO> al = new ArrayList<>();
        AuthRegExDTO d = new AuthRegExDTO();
        d.email = "email";
        d.provider = "prov";
        d.role = RoleEnum.teacher;
        al.add(d);

        AuthDTO a = dao.buildResult(al).get(0);
        Assert.assertEquals(dao.buildResult(al).size(), 1);
        Assert.assertEquals(a.email, d.email);
        Assert.assertEquals(a.provider, d.provider);
        Assert.assertEquals(a.role, d.role);
    }

    @Test
    public void regEx() {
        List<AuthRegExDTO> al = new ArrayList<>();
        AuthRegExDTO d = new AuthRegExDTO();
        d.email = "email";
        d.provider = "prov";
        d.role = RoleEnum.teacher;
        al.add(d);

        d = new AuthRegExDTO();
        d.email = "email";
        d.provider = "prov";
        d.role = RoleEnum.admin;
        al.add(d);

        List<AuthDTO> res = dao.buildResult(al);
        Assert.assertEquals(res.size(), 2);

        Assert.assertEquals(res.get(0).email, d.email);
        Assert.assertEquals(res.get(0).provider, d.provider);
        Assert.assertEquals(res.get(0).role, RoleEnum.admin);
        Assert.assertEquals(res.get(1).email, d.email);
        Assert.assertEquals(res.get(1).provider, d.provider);
        Assert.assertEquals(res.get(1).role, RoleEnum.teacher);
    }

    @Test
    public void regEx2() {
        List<AuthRegExDTO> al = new ArrayList<>();
        AuthRegExDTO d = new AuthRegExDTO();
        d.email = "email";
        d.provider = "prov";
        d.role = RoleEnum.teacher;
        al.add(d);

        d = new AuthRegExDTO();
        d.email = "email";
        d.provider = "prov";
        d.role = RoleEnum.superadmin;
        al.add(d);

        List<AuthDTO> res = dao.buildResult(al);
        Assert.assertEquals(res.size(), 2);

        Assert.assertEquals(res.get(0).email, d.email);
        Assert.assertEquals(res.get(0).provider, d.provider);
        Assert.assertEquals(res.get(0).role, RoleEnum.superadmin);

        Assert.assertEquals(res.get(1).email, d.email);
        Assert.assertEquals(res.get(1).provider, d.provider);
        Assert.assertEquals(res.get(1).role, RoleEnum.teacher);
    }

    @Test
    public void regEx3() {
        List<AuthRegExDTO> al = new ArrayList<>();
        AuthRegExDTO d = new AuthRegExDTO();
        d.email = "email";
        d.provider = "prov";
        d.role = RoleEnum.superadmin;
        al.add(d);

        d = new AuthRegExDTO();
        d.email = "email";
        d.provider = "prov";
        d.role = RoleEnum.teacher;
        al.add(d);

        List<AuthDTO> res = dao.buildResult(al);
        Assert.assertEquals(res.size(), 2);

        Assert.assertEquals(res.get(0).email, d.email);
        Assert.assertEquals(res.get(0).provider, d.provider);
        Assert.assertEquals(res.get(0).role, RoleEnum.superadmin);

        Assert.assertEquals(res.get(1).email, d.email);
        Assert.assertEquals(res.get(1).provider, d.provider);
        Assert.assertEquals(res.get(1).role, RoleEnum.teacher);
    }
}
