package de.quaestio24.util;

import org.junit.Assert;
import org.junit.Test;

public class CryptoUtilTest {

    @Test
    public void testCrypto() {
        for (String s : new String[]{"hallo", "lui@xxx", "ahdsj4öäü++~?ßß", "12n!\"§$%&/()=?}ÖÄÜöä-.,;:_yy<><|^"}) {
            String enc = CryptoUtil.encrypt(s);
            String y = CryptoUtil.decrypt(enc);
            Assert.assertEquals(s, y);
        }
    }
}
