package de.quaestio24.util;

import org.junit.Assert;
import org.junit.Test;

public class XsrfUtilTest {

    @Test
    public void testOk() {
        String token1 = XsrfUtil.encode("myu:ser");
        String token2 = XsrfUtil.encode("myu:ser");
        String token3 = XsrfUtil.encode("myu:ser");

        Assert.assertTrue(XsrfUtil.verify("myu:ser", token1));
        Assert.assertTrue(XsrfUtil.verify("myu:ser", token2));
        Assert.assertTrue(XsrfUtil.verify("myu:ser", token3));

        Assert.assertNotEquals(token1, token2);
        Assert.assertNotEquals(token1, token3);
        Assert.assertNotEquals(token2, token3);
    }

    @Test
    public void testWrongUser() {
        String token1 = XsrfUtil.encode("myuser");
        Assert.assertFalse(XsrfUtil.verify("myuse", token1));
    }
}
