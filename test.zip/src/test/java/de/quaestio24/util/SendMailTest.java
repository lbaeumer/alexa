package de.quaestio24.util;

import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;

public class SendMailTest {

    @Test
    public void testGetContent() throws IOException {
        String txt = "hallo du da";
        String res = new SendMail().getContent(txt);

        Assert.assertTrue(res.contains("Quaestio24.de"));
        Assert.assertTrue(res.contains("Online Wahl für Schulen"));
        Assert.assertTrue(res.contains(txt));
    }
}
