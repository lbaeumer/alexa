package de.quaestio24.util;

import com.google.appengine.tools.development.testing.LocalDatastoreServiceTestConfig;
import com.google.appengine.tools.development.testing.LocalServiceTestHelper;
import de.quaestio24.entity.Site;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;

public class UrlUtilTest {

    private final LocalServiceTestHelper helper = new LocalServiceTestHelper(new LocalDatastoreServiceTestConfig());

    @Before
    public void setUp() {
        helper.setUp();
    }

    @After
    public void tearDown() {
        helper.tearDown();
    }

    @Test
    public void testType() {
        for (Site e : Site.values()) {
            String en = e.toString();
            Assert.assertEquals(e, UrlUtil.getSite("/ws/selection/" + en));
            Assert.assertEquals(e, UrlUtil.getSite("/ws/project/" + en));
            Assert.assertEquals(e, UrlUtil.getSite("/ws/project/" + en + "/"));
            Assert.assertEquals(e, UrlUtil.getSite("/ws/project/" + en + "/xxx"));
            Assert.assertEquals(e, UrlUtil.getSite("/ws/project/" + en + "/assigned.json"));
        }

        Assert.assertNull(UrlUtil.getSite(""));
        Assert.assertNull(UrlUtil.getSite("/admin/demo/"));
        Assert.assertNull(UrlUtil.getSite("/ws/"));
        Assert.assertNull(UrlUtil.getSite("/ws/selection"));
        Assert.assertNull(UrlUtil.getSite("/ws/selection/"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testType1() {
        UrlUtil.getSite("/ws/selection/unknown");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testType2() {
        UrlUtil.getSite("/ws/selection/unknown/");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testType3() {
        UrlUtil.getSite("/ws/selection/unknown/xxx");
    }

    @Test
    public void guessPositive() {
        System.out.println(Arrays.asList(Site.values()));
        Assert.assertEquals(Site.valueOf("demo"), UrlUtil.guessSite("demo"));
        Assert.assertEquals(Site.valueOf("demo"), UrlUtil.guessSite("dem0"));
        Assert.assertEquals(Site.valueOf("demo"), UrlUtil.guessSite("DEM0"));
        Assert.assertEquals(Site.valueOf("demo2"), UrlUtil.guessSite("dem2"));
        Assert.assertEquals(Site.valueOf("junit"), UrlUtil.guessSite("juni"));
        Assert.assertEquals(Site.valueOf("junit"), UrlUtil.guessSite("jun1t"));
        Assert.assertEquals(Site.valueOf("junit"), UrlUtil.guessSite("JUN1T"));
        Assert.assertEquals(Site.valueOf("prjtest"), UrlUtil.guessSite("prjtes1"));
    }

    @Test
    public void guessNegative() {
        System.out.println(Arrays.asList(Site.values()));
        Assert.assertNull(UrlUtil.guessSite("dexx"));
        Assert.assertNull(UrlUtil.guessSite("jun1tt"));
        Assert.assertNull(UrlUtil.guessSite("prjtxtt"));
        Assert.assertNull(UrlUtil.guessSite("dprjtes1"));
    }
}
