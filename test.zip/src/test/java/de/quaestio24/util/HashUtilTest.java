package de.quaestio24.util;

import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.dto.PreferencesDTO.DesignParameter;
import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;

public class HashUtilTest {

    @Test
    public void testEncode() throws IOException, ClassNotFoundException {
        String s = "Hallo, du da";
        byte[] b = HashUtil.encode(s);
        String s1 = (String) HashUtil.decode(b);

        Assert.assertEquals(s, s1);
    }

    @Test
    public void testMd5() {
        String s = "Hallo, du da";
        String s1 = HashUtil.md5(s.getBytes());

        Assert.assertEquals(s1, "c2a7404022bc75113a3ab6aa6b8ea13e");
    }

    @Test
    public void testclone() {

        PreferencesDTO p = new PreferencesDTO();
        p.design = new DesignParameter();
        p.design.city = "mycity";
        p.design.event = "event";

        PreferencesDTO p2 = (PreferencesDTO) HashUtil.clone(p);

        Assert.assertEquals(p.design.city, p2.design.city);
        Assert.assertEquals(p.design.event, p2.design.event);
    }
}
