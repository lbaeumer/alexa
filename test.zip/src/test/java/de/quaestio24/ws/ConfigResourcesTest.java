package de.quaestio24.ws;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.tools.development.testing.LocalDatastoreServiceTestConfig;
import com.google.appengine.tools.development.testing.LocalServiceTestHelper;
import com.google.gson.Gson;
import de.quaestio24.constant.SiteStateEnum;
import de.quaestio24.dto.ConfigDTO;
import de.quaestio24.entity.Site;
import de.quaestio24.service.SiteService;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class ConfigResourcesTest {

    private final LocalServiceTestHelper helper = new LocalServiceTestHelper(new LocalDatastoreServiceTestConfig());
    private ConfigResources resources = new ConfigResources();
    private Gson gson = new Gson();

    @Before
    public void setUp() {
        helper.setUp();

        new SiteService().addSite("junit1");
        NamespaceManager.set("junit1");
    }

    @After
    public void tearDown() {
        helper.tearDown();
    }

    @Test
    public void testConfig() {
        String str = resources.getConfig(null, Site.valueOf("junit1").name(), true).getEntity().toString();
        ConfigDTO config = gson.fromJson(str, ConfigDTO.class);
        Assert.assertNotNull(config);
        Assert.assertNotNull(config.pref);
        Assert.assertEquals(config.state, SiteStateEnum.undefined);
        Assert.assertFalse(config.pref.auth);
        Assert.assertEquals("", config.pref.emailcc);
        Assert.assertEquals(config.pref.startDate.getTime(), 0);
    }
}
