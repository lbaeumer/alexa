package de.quaestio24.exception;

import de.quaestio24.dto.ErrorDTO;

import java.io.IOException;

public class WebServiceException extends IOException {
    private static final long serialVersionUID = 1L;

    public ErrorDTO error;

    public WebServiceException(ErrorDTO e) {
        error = e;
    }

    @Override
    public String toString() {
        return "WebServiceException [error=" + error + "]";
    }
}
