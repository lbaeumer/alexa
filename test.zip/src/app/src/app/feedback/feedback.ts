export class Feedback {
    name: string;
    email: string;
    text: string;
}
