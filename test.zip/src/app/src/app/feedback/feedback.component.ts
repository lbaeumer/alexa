import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { ToastrService } from 'ngx-toastr';

import { Feedback } from './feedback';
import { FeedbackService } from './feedback.service';
import { StateService } from '../state.service';

@Component({
    selector: 'app-feedback',
    templateUrl: './feedback.component.html',
    styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {

    type: string;
    model: Feedback = new Feedback;
    progress: boolean;

    constructor(
        private feedbackService: FeedbackService,
        private route: ActivatedRoute,
        private toastr: ToastrService,
        private stateService: StateService) {
        this.stateService.emitChange(3);
    }

    ngOnInit() {
        this.type = this.route.snapshot.paramMap.get('type');
    }

    onSubmit() {
        this.progress = true;
        this.feedbackService.insert(this.type, this.model).subscribe(
            result => {
                this.progress = false;
                this.toastr.success('Vielen Dank für das Feedback.');
            },
            error => {
                this.progress = false;
                this.toastr.error('Es ist ein Fehler aufgetreten.');
            }
        );
    }
}
