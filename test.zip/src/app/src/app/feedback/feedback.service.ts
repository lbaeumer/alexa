import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Feedback } from './feedback';

import { environment } from '../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class FeedbackService {

    constructor(private http: HttpClient) { }

    insert(type: string, feedback: Feedback): Observable<Object> {
        return this.http.post<Feedback>(environment.serviceUrl + '/ws/feedback/' + type + '/insert',
            feedback);
    }
}
