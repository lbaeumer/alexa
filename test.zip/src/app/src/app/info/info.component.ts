import { Component, OnInit, isDevMode } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';

import { ToastrService } from 'ngx-toastr';

import { Config } from '../config';
import { ConfigService } from '../config.service';
import { StateService } from '../state.service';

@Component({
    selector: 'app-info',
    templateUrl: './info.component.html',
    styleUrls: ['./info.component.css']
})
export class InfoComponent implements OnInit {

    basetype: string;
    config: Config;
    loading: boolean;

    constructor(private configService: ConfigService,
        private route: ActivatedRoute,
        private toastr: ToastrService,
        private stateService: StateService) {
        this.config = new Config();
        this.stateService.emitChange(1);
    }

    ngOnInit() {
        this.loading = true;
        let t = this.route.snapshot.paramMap.get('type');
        const pos = t.indexOf('_');
        if (pos > 1) {
            t = t.substring(0, pos);
        }
        this.basetype = t;

        this.configService.getConfig(this.basetype).subscribe(
            config => {
                this.loading = false;
                this.config = config;
            },
            error => {
                this.loading = false;
                if (isDevMode()) { console.error('An error occurred:' + JSON.stringify(error)); }
                setTimeout(() => {
                    if (error instanceof HttpErrorResponse) {
                        if (error.status !== 404) {
                            // do not show error if not found
                            this.toastr.error(error.statusText + ' (' + error.status + ')', 'Fehler aufgetreten');
                        }
                    } else {
                        this.toastr.error(error.error.text, 'Fehler aufgetreten');
                    }
                });
            }
        );
    }

}
