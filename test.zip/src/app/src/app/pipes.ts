import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'dots',
    pure: false
})
export class DotsPipe implements PipeTransform {
    transform(value: string, replace: string): any {

        if (!value) {
            return replace;
        } else {
            return value;
        }
    }
}
