import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Selection, ValidationResult } from './selection';

import { environment } from '../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class SelectionService {

    constructor(private http: HttpClient) {
    }

    validate(type: string, code: string): Observable<ValidationResult> {
        return this.http.get<ValidationResult>(environment.serviceUrl + '/ws/selection/' + type + '/validate?code=' + code);
    }

    validateClazz(type: string, clazz: string): Observable<ValidationResult> {
        return this.http.get<ValidationResult>(environment.serviceUrl + '/ws/selection/' + type + '/validate?clazz=' + clazz);
    }

    insert(type: string, selection: Selection): Observable<Object> {
        return this.http.post<Object>(environment.serviceUrl + '/ws/selection/' + type + '/insert',
            selection);
    }
}
