import { Component, Input } from '@angular/core';

import { Config } from '../../config';

import { SelectionProject } from '../selection';

@Component({
    selector: 'app-prioritize',
    templateUrl: './prioritize.component.html',
    styleUrls: ['./prioritize.component.css']
})
export class PrioritizeComponent {

    @Input() config: Config;
    @Input() selectedProjects: SelectionProject[];

    setDown(id: number) {
        if (id + 1 >= this.selectedProjects.length) {
            return;
        }
        const sp: SelectionProject = this.selectedProjects[id];
        this.selectedProjects[id] = this.selectedProjects[id + 1];
        this.selectedProjects[id + 1] = sp;
    }

    setUp(id: number) {
        if (id <= 0) {
            return;
        }
        const sp: SelectionProject = this.selectedProjects[id - 1];
        this.selectedProjects[id - 1] = this.selectedProjects[id];
        this.selectedProjects[id] = sp;
    }
}
