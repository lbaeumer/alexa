import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { ProjectList, Project } from './projectlist';

import { environment } from '../../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class ProjectService {

    constructor(private http: HttpClient) { }

    getProjects(type: string): Observable<ProjectList> {
        return this.http.get<ProjectList>(environment.serviceUrl + '/ws/project/' + type + '/list');
    }

    getProject(type: string, id: number): Observable<Project> {
        return this.http.get<Project>(environment.serviceUrl + '/ws/project/' + type + '/' + id);
    }
}
