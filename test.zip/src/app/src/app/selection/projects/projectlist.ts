export class ProjectList {
    projects: Project[];
}

export class ProjectAdditional {
    clazz: string;
    teacher: string;
    costs: string;
    room: string;
    shift: string;
}

export class ProjectDetails {
    description: string;
}

export class Project {
    constructor() {
        this.additional = new ProjectAdditional;
        this.details = new ProjectDetails;
    }
    id: number;
    title: string;
    additional: ProjectAdditional;
    checked: boolean;
    hide: boolean;
    status: number;
    details: ProjectDetails;
    maxSize: number;
}
