import { Pipe, PipeTransform } from '@angular/core';

import { Project } from './projectlist';

@Pipe({
    name: 'clazzfilter',
    pure: false
})
export class ClazzFilterPipe implements PipeTransform {
    transform(projects: Project[]): any {

        if (!projects) {
            return [];
        }

        return projects.filter(project => {
            return !project.hide;
        });
    }
}
