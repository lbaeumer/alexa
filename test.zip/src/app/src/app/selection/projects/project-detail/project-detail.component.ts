import { Component, OnInit, isDevMode } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';

import { ToastrService } from 'ngx-toastr';

import { Project } from '../projectlist';
import { ProjectService } from '../project.service';

@Component({
    selector: 'app-project-detail',
    templateUrl: './project-detail.component.html',
    styleUrls: ['./project-detail.component.css']
})
export class ProjectDetailComponent implements OnInit {

    type: string;
    subtype: string;

    id: number;
    status: number;
    project: Project;
    loading: boolean;

    constructor(private projectService: ProjectService,
        private route: ActivatedRoute,
        private location: Location,
        private toastr: ToastrService,
        private router: Router) {
        this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    }

    ngOnInit() {
        this.project = new Project;
        if (isDevMode()) { console.log('map=' + JSON.stringify(this.route.snapshot.paramMap)); }

        const t = this.route.snapshot.paramMap.get('type');
        this.subtype = this.route.snapshot.paramMap.get('subtype');
        if (this.subtype) {
            this.type = t + '_' + this.subtype;
        } else {
            this.type = t;
        }
        this.id = +this.route.snapshot.paramMap.get('id');

        this.loading = true;
        this.projectService.getProject(this.type, this.id).subscribe(
            project => {
                this.loading = false;
                this.project = project;
            }, error => {
                this.loading = false;
                this.toastr.error(error.error.text + ' (' + error.error.code + ')');
            }
        );
    }

    goBack() {
        this.location.back();
    }
}
