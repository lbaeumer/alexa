import { Component, OnInit, Input, isDevMode } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { Config } from '../../config';
import { Project } from './projectlist';
import { SelectionProject, Person } from '../selection';

@Component({
    selector: 'app-projects',
    templateUrl: './projects.component.html',
    styleUrls: ['./projects.component.css']
})
export class ProjectsComponent implements OnInit {

    @Input() projects: Project[] = [];
    @Input() config: Config;
    @Input() selectedProjects: SelectionProject[];
    @Input() person: Person;

    type: string;
    subtype: string;
    prjurl: string;

    p = 1;

    constructor(
        private route: ActivatedRoute) { }

    ngOnInit() {
        this.type = this.route.snapshot.paramMap.get('type');
        this.subtype = this.route.snapshot.paramMap.get('subtype');

        if (this.subtype) {
            this.prjurl = 'subproject/' + this.subtype;
        } else {
            this.prjurl = 'project';
        }
    }

    onChange(project: Project) {
        if (isDevMode()) { console.log('project=' + JSON.stringify(project)); }

        if (project.checked) {
            this.selectedProjects.push(new SelectionProject(project.id, project.title));
            if (isDevMode()) { console.log('sel=' + JSON.stringify(this.selectedProjects)); }
        } else {
            let i: number;
            for (i = 0; i < this.selectedProjects.length; i++) {
                if (this.selectedProjects[i].id === project.id) {
                    this.selectedProjects.splice(i, 1);
                    break;
                }
            }
            if (isDevMode()) { console.log('sel=' + JSON.stringify(this.selectedProjects)); }
        }
    }
}
