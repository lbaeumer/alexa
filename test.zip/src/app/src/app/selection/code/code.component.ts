import { Component, OnInit, Input, isDevMode } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { ToastrService } from 'ngx-toastr';

import { Config } from '../../config';
import { Project } from '../projects/projectlist';
import { SelectionService } from '../selection.service';
import { SelectionProject, Person } from '../selection';

@Component({
    selector: 'app-code',
    templateUrl: './code.component.html',
    styleUrls: ['./code.component.css']
})
export class CodeComponent implements OnInit {

    @Input() config: Config;
    @Input() person: Person;
    @Input() projects: Project[];
    @Input() selectedProjects: SelectionProject[];

    type: string;
    subtype: string;
    loading: boolean;

    constructor(private route: ActivatedRoute,
        private toastr: ToastrService,
        private selectionService: SelectionService) { }

    ngOnInit() {
        this.type = this.route.snapshot.paramMap.get('type');
        this.subtype = this.route.snapshot.paramMap.get('subtype');

        if (this.subtype) {
            this.type = this.type + '_' + this.subtype;
        }
    }

    validate(code: string) {
        // changes.prop contains the old and the new value...
        if (isDevMode()) { console.log('validate' + code); }
        if (!code
            || code.length < this.config.pref.design.minCodeLen
            || code.length > this.config.pref.design.maxCodeLen) {
            this.person.valid = false;
            this.person.clazz = null;

            // clear old state
            if (this.selectedProjects.length > 0) {
                this.selectedProjects.splice(0, this.selectedProjects.length);
            }

            if (this.projects) {
                this.projects.forEach(function (p) {
                    p.hide = false;
                    p.checked = false;
                });
            }
        } else {
            this.loading = true;
            this.selectionService.validate(this.type, this.person.code).subscribe(
                result => {
                    this.loading = false;
                    if (isDevMode()) { console.log('result=' + JSON.stringify(result)); }

                    this.person.valid = true;
                    this.person.clazz = result.selection.person.clazz;

                    // clear old state
                    if (this.selectedProjects.length > 0) {
                        this.selectedProjects.splice(0, this.selectedProjects.length);
                    }

                    if (this.projects) {

                        // set of projects to be shown in filter
                        const showProjectSet = new Set();
                        result.filteredProjects.forEach(function (p) { showProjectSet.add(p); });

                        const prjMap = new Map();
                        this.projects.forEach(function (p) {
                            p.checked = false;
                            p.hide = !showProjectSet.has(p.id);
                            if (!p.hide) {
                                prjMap.set(p.id, p);
                            }
                        });

                        if (result.selection.selections
                            && result.selection.selections.length > 0) {

                            // set the selected if there had been a previous selection
                            if (isDevMode()) { console.log('found previous selections ' + result.selection.selections.length); }

                            // check user selected projects
                            const selectedProjects = this.selectedProjects;
                            result.selection.selections.forEach(function (s) {
                                const p = prjMap.get(s);
                                if (p) {
                                    p.checked = true;
                                    selectedProjects.push(new SelectionProject(p.id, p.title));
                                } else {
                                    if (isDevMode()) { console.log('project ' + s + ' is invalid'); }
                                }
                            });

                            this.toastr.success('Die vorherige Wahl wurde übernommen.');

                        } else {

                            this.toastr.success('Code korrekt');
                        }
                    }
                },
                error => {
                    this.loading = false;
                    if (isDevMode()) { console.log('error=' + JSON.stringify(error)); }
                    this.toastr.error(error.error.text + ' (' + error.error.code + ')');
                    this.person.valid = false;
                    this.person.clazz = null;

                    // clear old state
                    if (this.selectedProjects.length > 0) {
                        this.selectedProjects.splice(0, this.selectedProjects.length);
                    }

                    if (this.projects) {
                        this.projects.forEach(function (p) {
                            p.hide = false;
                            p.checked = false;
                        });
                    }
                }
            );
        }
    }
}
