import { Component, OnInit, OnChanges, Input, isDevMode, SimpleChanges } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';

import { Config } from '../../config';
import { Project } from '../projects/projectlist';
import { SelectionService } from '../selection.service';
import { SelectionProject, Person } from '../selection';

@Component({
    selector: 'app-name',
    templateUrl: './name.component.html',
    styleUrls: ['./name.component.css']
})
export class NameComponent implements OnInit, OnChanges {

    @Input() config: Config;
    @Input() person: Person;
    @Input() projects: Project[];
    @Input() selectedProjects: SelectionProject[];

    type: string;
    subtype: string;
    loading: boolean;

    clazzes: string[];
    isDevMode: boolean;

    constructor(private route: ActivatedRoute,
        private selectionService: SelectionService) {
        this.isDevMode = isDevMode();
    }

    ngOnInit() {
        this.type = this.route.snapshot.paramMap.get('type');
        this.subtype = this.route.snapshot.paramMap.get('subtype');

        if (this.subtype) {
            this.type = this.type + '_' + this.subtype;
        }
    }

    onChangeClazz(form: NgForm) {
        if (isDevMode()) { console.log('validate clazz' + this.person.clazz); }
        this.person.valid = form.valid;
        this.loading = true;
        this.selectionService.validateClazz(this.type, this.person.clazz).subscribe(
            result => {
                this.loading = false;
                if (isDevMode()) { console.log('result=' + JSON.stringify(result)); }

                // clear old state
                if (this.selectedProjects.length > 0) {
                    this.selectedProjects.splice(0, this.selectedProjects.length);
                }

                if (this.projects) {

                    // set of projects to be shown in filter
                    const showProjectSet = new Set();
                    result.filteredProjects.forEach(function (p) { showProjectSet.add(p); });

                    const prjMap = new Map();
                    this.projects.forEach(function (p) {
                        p.checked = false;
                        p.hide = !showProjectSet.has(p.id);
                        if (!p.hide) {
                            prjMap.set(p.id, p);
                        }
                    });
                }
            },
            error => {
                this.loading = false;
                if (isDevMode()) { console.log('error=' + JSON.stringify(error)); }

                // clear old state
                if (this.selectedProjects.length > 0) {
                    this.selectedProjects.splice(0, this.selectedProjects.length);
                }
            }
        );
    }

    ngOnChanges(changes: SimpleChanges) {
        if (isDevMode()) { console.log('changes' + changes); }
        if (changes.config
            && this.config.pref
            && this.config.pref.design
            && this.config.pref.design.clazzes) {

            if (this.config.pref.design.clazzes) {
                this.clazzes = this.config.pref.design.clazzes.split(',');
            }
        }
    }

    onChange(form: NgForm) {
        if (isDevMode()) { console.log('form' + form.valid); }
        this.person.valid = form.valid;
    }
}
