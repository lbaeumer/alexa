import { Component, OnInit, isDevMode } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';

import { ToastrService } from 'ngx-toastr';

import { CacheService } from '../cache.service';
import { Config } from '../config';
import { ConfigService } from '../config.service';
import { Selection } from './selection';
import { SelectionService } from './selection.service';
import { Project } from './projects/projectlist';
import { ProjectService } from './projects/project.service';

@Component({
    selector: 'app-election',
    templateUrl: './selection.component.html',
    styleUrls: ['./selection.component.css']
})
export class SelectionComponent implements OnInit {

    type: string;
    basetype: string;
    subtype: string;
    config: Config;
    loading: boolean;
    selection: Selection;
    progress: boolean;
    projects: Project[];

    isDevMode: boolean;

    constructor(
        private router: Router,
        private route: ActivatedRoute,
        private toastr: ToastrService,
        private cacheService: CacheService,
        private configService: ConfigService,
        private projectService: ProjectService,
        private selectionService: SelectionService
    ) {
        this.router.routeReuseStrategy.shouldReuseRoute = () => false;
        this.isDevMode = isDevMode();
    }

    ngOnInit() {
        if (isDevMode()) { console.log('selection ngOnInit' + this.selection); }

        this.config = new Config();
        this.loading = true;

        this.basetype = this.route.snapshot.paramMap.get('type');
        this.subtype = this.route.snapshot.paramMap.get('subtype');
        if (this.subtype) {
            // this.stateService.emitChange(5);
            this.type = this.basetype + '_' + this.subtype;
        } else {
            // this.stateService.emitChange(2);
            this.type = this.basetype;
        }

        const s: Selection = this.cacheService.getSelection(this.type);
        if (s) {
            if (isDevMode()) { console.log('set cached selection'); }
            this.selection = s;
        } else {
            if (isDevMode()) { console.log('create new selection'); }
            this.selection = new Selection;
            this.cacheService.putSelection(this.type, this.selection);
        }

        this.configService.getConfig(this.basetype).subscribe(
            config => {
                this.loading = false;
                if (!this.subtype) {
                    this.config = config;
                } else if (config.subConfig[this.subtype]) {
                    this.config = config.subConfig[this.subtype];
                }

                this.projectService.getProjects(this.type).subscribe(
                    projectlist => {
                        this.loading = false;
                        this.projects = projectlist.projects;
                        const set = new Set();
                        this.selection.selections.forEach(function (se) { set.add(se.id); });

                        this.projects.forEach(function (p) {
                            if (!p.checked && set.has(p.id)) {
                                p.checked = true;
                            }
                        });
                    },
                    error => {
                        this.loading = false;
                        if (isDevMode()) { console.error('An error occurred:' + JSON.stringify(error)); }
                        if (error instanceof HttpErrorResponse) {
                            this.toastr.error(error.statusText + ' (' + error.status + ')', 'Fehler aufgetreten');
                        } else {
                            this.toastr.error(error.error.text, 'Fehler aufgetreten');
                        }
                    }
                );
            },
            error => {
                this.loading = false;
                if (isDevMode()) { console.error('An error occurred:' + JSON.stringify(error)); }
                setTimeout(() => {
                    if (error instanceof HttpErrorResponse) {
                        this.toastr.error(error.statusText + ' (' + error.status + ')', 'Fehler aufgetreten');
                    } else {
                        this.toastr.error(error.error.text, 'Fehler aufgetreten');
                    }
                });
            }
        );
    }

    onSubmit(): void {
        if (isDevMode()) { console.log('submit'); }
        this.progress = true;
        this.selectionService.insert(this.type, this.selection).subscribe(
            result => {
                this.progress = false;
                if (isDevMode()) { console.log('inserted=' + JSON.stringify(result)); }
                this.toastr.success('Du kannst die Wahl später noch ändern.', 'Wahl erfolgreich',
                    {
                        closeButton: true,
                        disableTimeOut: true
                    });
            },
            error => {
                this.progress = false;
                if (isDevMode()) { console.log('error=' + JSON.stringify(error)); }
                this.toastr.error(error.error.text + ' (' + error.error.code + ')', 'Fehler aufgetreten');
            }
        );
    }
}
