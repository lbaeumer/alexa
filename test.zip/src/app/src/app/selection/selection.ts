export class Person {

    code: string;
    name: string;
    surname: string;

    email: string;

    clazz: string;

    valid: boolean;
}

export class Selection {

    constructor() {
        this.person = new Person;
        this.selections = [];
    }
    person: Person;
    selections: SelectionProject[];

}

export class SelectionProject {
    constructor(id: number, title: string) {
        this.id = id;
        this.title = title;
    }
    id: number;
    title: string;
}

export class ValidationResult {
    selection: Selection;
    filteredProjects: number[];
}
