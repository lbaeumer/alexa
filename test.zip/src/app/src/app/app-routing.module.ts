import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

import { FeedbackComponent } from './feedback/feedback.component';
import { InfoComponent } from './info/info.component';
import { NotfoundComponent } from './notfound/notfound.component';
import { ProjectDetailComponent } from './selection/projects/project-detail/project-detail.component';
import { SelectionComponent } from './selection/selection.component';

const routes: Routes = [
    { path: 'notfound', component: NotfoundComponent },
    { path: 'notfound/:type', component: NotfoundComponent },
    { path: ':type/info', component: InfoComponent },
    { path: ':type/selection/:subtype', component: SelectionComponent },
    { path: ':type/selection', component: SelectionComponent },
    { path: ':type/subproject/:subtype/:id', component: ProjectDetailComponent },
    { path: ':type/project/:id', component: ProjectDetailComponent },
    { path: ':type/feedback', component: FeedbackComponent },
    { path: ':type', redirectTo: ':type/info' },
    { path: '**', redirectTo: '/notfound', pathMatch: 'full' }
];

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forRoot(routes, { useHash: false })
    ],
    exports: [
        RouterModule
    ],
    declarations: []
})
export class AppRoutingModule { }
