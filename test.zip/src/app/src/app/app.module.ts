import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ErrorHandler } from '@angular/core';
import { HttpClientModule, HttpClientXsrfModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { RequestCache } from './http-interceptors/request-cache.service';
import { CacheService } from './cache.service';
import { StateService } from './state.service';
import { httpInterceptorProviders } from './http-interceptors/index';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { NgxPaginationModule } from 'ngx-pagination';

import { ClazzFilterPipe } from './selection/projects/pipes';
import { DotsPipe } from './pipes';
import { MyErrorHandler } from './error-handler';

import { AppRoutingModule } from './app-routing.module';
import { ProjectsComponent } from './selection/projects/projects.component';
import { CodeComponent } from './selection/code/code.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { InfoComponent } from './info/info.component';
import { NameComponent } from './selection/name/name.component';
import { NotfoundComponent } from './notfound/notfound.component';
import { PrioritizeComponent } from './selection/prioritize/prioritize.component';
import { ProjectDetailComponent } from './selection/projects/project-detail/project-detail.component';
import { SelectionComponent } from './selection/selection.component';

@NgModule({
    declarations: [
        AppComponent,
        ClazzFilterPipe,
        DotsPipe,
        InfoComponent,
        SelectionComponent,
        FeedbackComponent,
        ProjectDetailComponent,
        ProjectsComponent,
        CodeComponent,
        NameComponent,
        PrioritizeComponent,
        NotfoundComponent
    ],
    imports: [
        BrowserModule,
        FormsModule,
        HttpClientModule,
        AppRoutingModule,
        CommonModule,
        BrowserAnimationsModule,
        ToastrModule.forRoot({ maxOpened: 1, autoDismiss: true, preventDuplicates: true }),
        NgxPaginationModule,
        HttpClientXsrfModule.withOptions({
            cookieName: 'My-Xsrf-Cookie',
            headerName: 'My-Xsrf-Header',
        })
    ],
    providers: [
        { provide: ErrorHandler, useClass: MyErrorHandler },
        CacheService,
        StateService,
        RequestCache,
        httpInterceptorProviders
    ],
    bootstrap: [AppComponent]
})
export class AppModule { }
