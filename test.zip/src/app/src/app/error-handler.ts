import { ErrorHandler, Injectable, isDevMode } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Location } from '@angular/common';

import { Observable } from 'rxjs';

class QError {
    date: string;
    type: string;
    path: string;
    message: string;
    name: string;
    httpCode: number;
    httpError: string;
    httpStatusText: string;
    stack: string;
}

@Injectable()
export class MyErrorHandler extends ErrorHandler {

    constructor(private http: HttpClient,
        private location: Location) {
        super();
    }

    handleError(error) {
        super.handleError(error);
        this.logError(error);
    }

    logError(error: any) {
        const e: QError = new QError;
        e.path = this.location.path(false);
        e.date = new Date().toISOString();
        e.type = error.constructor.name;
        e.message = error.message;

        if (error instanceof HttpErrorResponse) {
            e.httpCode = (<HttpErrorResponse>error).status;
            e.httpError = (<HttpErrorResponse>error).error;
            e.httpStatusText = (<HttpErrorResponse>error).statusText;
        }

        e.stack = error.stack;
        e.name = error.name;

        if (isDevMode()) { console.log('sending ' + JSON.stringify(e)); }
        this.sendIssue(e).subscribe(
            result => {
                if (isDevMode()) { console.log('error send'); }
            }
        );
    }

    sendIssue(error: any): Observable<any> {
        return this.http.post<any>('/ws/error/report', error);
    }
}

