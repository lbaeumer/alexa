import { Injectable } from '@angular/core';
import { Selection } from './selection/selection';

@Injectable()
export class CacheService {

    cache = new Map();

    getSelection(type: string): Selection {
        const cached = this.cache.get(type);

        if (!cached) {
            return undefined;
        }

        return cached;
    }

    putSelection(type: string, value: Selection): void {

        this.cache.set(type, value);
    }
}
