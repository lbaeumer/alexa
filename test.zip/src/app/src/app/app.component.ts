import { Component, OnInit, isDevMode } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';

import { ToastrService } from 'ngx-toastr';

import { Config } from './config';
import { ConfigService } from './config.service';
import { StateService } from './state.service';

import { environment } from '../environments/environment';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

    adminUrl: string;
    basetype: string;
    config: Config;
    loading: boolean;
    tab = 1;

    imageUrl: string;

    constructor(
        private router: Router,
        private location: Location,
        private toastr: ToastrService,
        private configService: ConfigService,
        private stateService: StateService) {
        this.adminUrl = environment.adminUrl;
        this.config = new Config();
        this.stateService.changeEmitted$.subscribe(
            id => {
                this.tab = id;
            });
    }

    ngOnInit() {
        if (isDevMode()) { console.log('app: ' + this.location.path(false)); }

        // type
        let t = this.location.path(false).substring(1);
        let pos = t.indexOf('/');
        if (pos > 1) {
            t = t.substring(0, pos);
        }
        pos = t.indexOf('_');
        if (pos > 1) {
            t = t.substring(0, pos);
        }
        this.basetype = t;
        this.imageUrl = environment.imageUrl + '/' + this.basetype + '/logo.jpg';

        if (isDevMode()) { console.log('type=' + this.basetype); }

        this.configService.getConfig(this.basetype).subscribe(
            config => {
                this.loading = false;
                this.config = config;
            },
            error => {
                this.loading = false;
                if (isDevMode()) { console.error('An error occurred:' + JSON.stringify(error)); }
                if (error instanceof HttpErrorResponse) {
                    // A client-side or network error occurred. Handle it accordingly.
                    if (error.status === 404) {
                        if (isDevMode()) { console.log('not found' + JSON.stringify(error.error)); }
                        this.basetype = 'notfound';
                        this.imageUrl = environment.imageUrl + '/notfound/logo.jpg';
                        if (error.error && error.error.code === 800) {
                            if (isDevMode()) { console.log('code=' + error.error.text[0]); }
                            this.router.navigate(['/notfound/' + error.error.text[0]]);
                        } else {
                            this.router.navigate(['/notfound']);
                        }
                    } else {
                        this.imageUrl = environment.imageUrl + '/notfound/logo.jpg';
                        setTimeout(() => {
                            this.toastr.error(error.statusText + ' (' + error.status + ')', 'Fehler aufgetreten');
                        });
                    }
                } else {
                    this.imageUrl = environment.imageUrl + '/notfound/logo.jpg';
                    setTimeout(() => {
                        this.toastr.error(error.error.text, 'Fehler aufgetreten');
                    });
                }
            }
        );
    }

    onSelect(i: number): void {
        this.tab = i;
    }
}
