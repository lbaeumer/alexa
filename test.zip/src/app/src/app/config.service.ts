import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Config } from './config';

import { environment } from '../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class ConfigService {

    constructor(private http: HttpClient) { }

    getConfig(type: string): Observable<Config> {
        return this.http.get<Config>(environment.serviceUrl + '/ws/config/' + type + '/get');
    }
}
