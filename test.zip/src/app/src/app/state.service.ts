import { Injectable, isDevMode } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable()
export class StateService {
    private emitChangeSource = new Subject<any>();
    changeEmitted$ = this.emitChangeSource.asObservable();

    emitChange(change: any) {
        if (isDevMode()) { console.log('emitchange' + change); }
        this.emitChangeSource.next(change);
    }
}
