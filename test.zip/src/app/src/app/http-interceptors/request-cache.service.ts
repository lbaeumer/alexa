import { Injectable, isDevMode } from '@angular/core';
import { HttpRequest, HttpResponse } from '@angular/common/http';

const maxAge = 600000;

@Injectable()
export class RequestCache {

    cache = new Map();

    get(req: HttpRequest<any>): HttpResponse<any> | undefined {
        const url = req.urlWithParams;
        const cached = this.cache.get(url);

        if (!cached) {
            return undefined;
        }

        const isExpired = cached.lastRead < (Date.now() - maxAge);
        if (isDevMode()) { console.log('expires=' + (cached.lastRead - ((Date.now() - maxAge)))); }
        if (isExpired) {
            this.cache.delete(url);
            return undefined;
        }
        cached.lastRead = Date.now();

        return cached.response;
    }

    put(req: HttpRequest<any>, response: HttpResponse<any>): void {
        const url = req.urlWithParams;
        const entry = { url, response, lastRead: Date.now() };
        this.cache.set(url, entry);
    }
}
