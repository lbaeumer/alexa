import { Injectable, isDevMode } from '@angular/core';
import { HttpEvent, HttpRequest, HttpResponse, HttpInterceptor, HttpHandler } from '@angular/common/http';

import { Observable, of } from 'rxjs';
import { tap } from 'rxjs/operators';
import { RequestCache } from './request-cache.service';

@Injectable()
export class CachingInterceptor implements HttpInterceptor {
    constructor(private cache: RequestCache) { }

    intercept(req: HttpRequest<any>, next: HttpHandler) {
        if (this.isCached(req)) {
            const cachedResponse = this.cache.get(req);
            if (cachedResponse) {
                if (isDevMode()) { console.log('load cached ' + req.url); }
                return of(cachedResponse);
            } else {
                if (isDevMode()) { console.log('load ** ' + req.url); }
                return this.sendRequest(req, next, this.cache);
            }

        } else {
            if (isDevMode()) { console.log('load uncached ' + req.url); }
            return next.handle(req);
        }
    }

    isCached(req: HttpRequest<any>): boolean {
        if (req.method !== 'GET') {
            return false;
        }
        if (req.url.indexOf('config') > 0 || req.url.indexOf('project') > 0) {
            return true;
        }

        return false;
    }

    sendRequest(
        req: HttpRequest<any>,
        next: HttpHandler,
        cache: RequestCache): Observable<HttpEvent<any>> {
        return next.handle(req).pipe(
            tap(event => {
                if (event instanceof HttpResponse) {
                    cache.put(req, event);
                }
            })
        );
    }
}
