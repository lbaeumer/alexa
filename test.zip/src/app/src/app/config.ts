export class ConfigParameter {
}

export class ConfigDesign {
    event: string;
    school: string;
    city: string;
    minSelections: number;
    maxCodeLen: number;
    minCodeLen: number;
    clazzes: string;
    paginateCount: number;

    txtInfoJumbotron: string;
    txtInfoInstructions: string;
    txtInfoFooter: string;

    txtSelectionHeader: string;
    txtSelectionNote: string;

    txtSelectionFormNameHeadline: string;
    txtSelectionFormCodeHeadline: string;
    txtSelectionFormNameText: string;
    txtSelectionFormCodeText: string;

    txtSelectionProjectsHeadline: string;
    txtSelectionProjectsText: string;

    txtSelectionPrioritizeHeadline: string;
    txtSelectionPrioritizeText: string;

    hidePriortize: boolean;
    lblProject: string;
    lblClass: string;
}

export class Preferences {
    constructor() {
        this.design = new ConfigDesign();
        this.parameter = new ConfigParameter();
        this.subSites = [];
    }
    startDate: Date;
    startDate2: Date;
    endDate: Date;
    endDate2: Date;
    eventDate: Date;
    design: ConfigDesign;
    anonymous: boolean;
    parameter: ConfigParameter;

    subSites: string[];
}

export class Config {
    constructor() {
        this.pref = new Preferences();
    }

    state: string;

    pref: Preferences;
    subConfig: Map<string, Config>;
}
