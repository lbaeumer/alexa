package de.quaestio24.entity;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import de.quaestio24.dto.SettingsDTO;
import de.quaestio24.service.SiteService;

import java.io.Serializable;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Site implements Serializable, Comparable<Site>, JsonDeserializer<Site>, JsonSerializer<Site> {

    private static final long serialVersionUID = 1L;

    private String value;

    private static Set<String> getAllProjects() {
        SettingsDTO settings = new SiteService().getSettings();

        // flatten structure
        Set<String> sites = new HashSet<>(settings.sites);
        settings.subSites.forEach((s, ss) -> ss.forEach(sx -> sites.add(s + "_" + sx)));

        return sites;
    }

    public static Site valueOf(String val) {

        if (!getAllProjects().contains(val)) {
            throw new IllegalArgumentException(val + " is not a valid site. These sites are valid " + getAllProjects());
        }

        Site e = new Site();
        e.value = val;
        return e;
    }

    public static Site[] values() {
        List<String> all = new ArrayList<>(getAllProjects());
        Site[] ret = new Site[all.size()];
        int i = 0;
        for (String s : all) {
            ret[i++] = Site.valueOf(s);
        }
        return ret;
    }

    public String name() {
        return value;
    }

    public boolean isBaseSite() {
        return !(value.indexOf("_") > 0);
    }

    public Site getBaseType() {
        if (value.indexOf("_") > 0) {
            return Site.valueOf(value.substring(0, value.indexOf("_")));
        } else {
            return this;
        }
    }

    public boolean isJunitSite() {
        return value.matches("(prjtest|prjtest2|junit|demo|demo2|demo3.*)");
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((value == null) ? 0 : value.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Site other = (Site) obj;
        if (value == null) {
            return other.value == null;
        } else return value.equals(other.value);
    }

    @Override
    public String toString() {
        return value;
    }

    @Override
    public JsonElement serialize(Site arg0, Type arg1, JsonSerializationContext arg2) {
        return new JsonPrimitive(arg0.name());
    }

    @Override
    public Site deserialize(JsonElement arg0, Type arg1, JsonDeserializationContext arg2) throws JsonParseException {
        return Site.valueOf(arg0.getAsString());
    }

    @Override
    public int compareTo(Site o) {
        return value.compareTo(o.value);
    }
}
