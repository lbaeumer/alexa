package de.quaestio24.dao;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.EntityNotFoundException;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.PreparedQuery;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Text;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import de.quaestio24.constant.RoleEnum;
import de.quaestio24.dto.AuthDTO;
import org.apache.log4j.MDC;

import java.io.Serializable;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

public class AuthDAO {
    private static final Logger log = Logger.getLogger(AuthDAO.class.getName());

    private static final String TABLE = "auth";

    public List<AuthDTO> insertAuth(AuthDTO a) {
        log.info("insertAuth " + a);

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Key key = KeyFactory.createKey(TABLE, (a.provider + "/" + a.email).toLowerCase());

        List<AuthDTO> list = getAuths(a.provider, a.email);
        AuthDTO found = null;
        for (AuthDTO auth : list) {
            if (auth.role.ordinal() >= a.role.ordinal()) {
                log.info("user is already higher privileged with " + auth + ". You added " + a);
                found = auth;
            }
        }
        if (found == null) {
            AuthDTO entry = new AuthDTO();
            entry.created = new Date();
            entry.role = a.role;
            entry.provider = a.provider;
            entry.email = a.email;

            list.add(entry);

            Entity e = new Entity(key);
            Gson gson = new Gson();
            e.setProperty("entry", new Text(gson.toJson(list)));
            e.setProperty("user", "" + MDC.get("user"));
            e.setProperty("updated", new Date());

            datastore.put(e);

        } else {
            // adding permissions would mean a downgrade
            log.warning("there is already an auth with " + found);
            // throw new ValidationException(Collections.singletonList("Already
            // have this auth " + found), 450);
        }
        return list;
    }

    public List<AuthDTO> deleteAuth(AuthDTO a) {
        log.info("deleteAuth " + a);

        List<AuthDTO> auths = getAuths(a.provider, a.email);
        auths.removeIf(au -> a.role.equals(au.role));

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Key key = KeyFactory.createKey(TABLE, (a.provider + "/" + a.email).toLowerCase());
        Entity e = new Entity(key);
        Gson gson = new Gson();
        e.setProperty("entry", new Text(gson.toJson(auths)));
        e.setProperty("user", "" + MDC.get("user"));

        datastore.put(e);

        return auths;
    }

    public List<AuthDTO> getAuths(String provider, String email) {

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Key key = KeyFactory.createKey(TABLE, (provider + "/" + email).toLowerCase());

        Entity e;
        try {
            e = datastore.get(key);

            Object t = e.getProperty("entry");
            if (t == null) {
                return new ArrayList<>();
            }
            Gson gson = new Gson();
            Type collectionType = new TypeToken<List<AuthRegExDTO>>() {
            }.getType();

            List<AuthRegExDTO> al = gson.fromJson(t instanceof Text ? ((Text) t).getValue() : t.toString(),
                    collectionType);

            return buildResult(al);
        } catch (EntityNotFoundException e1) {
            log.fine("did not find auth in " + TABLE);
            return new ArrayList<>();
        }
    }

    public List<AuthDTO> getAllAuths() {

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Query q = new Query(TABLE);

        PreparedQuery pq = datastore.prepare(q);

        List<AuthDTO> l = new ArrayList<>();
        Iterable<Entity> it;
        it = pq.asIterable();

        for (Entity e : it) {
            Object t = e.getProperty("entry");
            Gson gson = new Gson();
            Type collectionType = new TypeToken<List<AuthRegExDTO>>() {
            }.getType();

            String a = t instanceof Text ? ((Text) t).getValue() : t.toString();
            try {
                List<AuthRegExDTO> al = gson.fromJson(a, collectionType);

                l.addAll(buildResult(al));
            } catch (Exception ex) {
                log.warning("parsing " + a + " failed " + ex);
            }
        }

        return l;
    }

    List<AuthDTO> buildResult(final List<AuthRegExDTO> al) {
        log.info("al=" + al);
        List<AuthDTO> res = new ArrayList<>();

        for (AuthRegExDTO a : al) {
            AuthDTO auth = new AuthDTO(a.email, a.role);
            auth.provider = a.provider;
            auth.role = a.role;

            res.add(auth);
        }

        log.info("now build final list");
        res.sort((o1, o2) -> {
            int r;
            r = o1.email.compareTo(o2.email);
            if (r != 0) {
                return r;
            }
            r = o1.provider.compareTo(o2.provider);
            if (r != 0) {
                return r;
            }
            r = o2.role.ordinal() - o1.role.ordinal();
            return r;
        });
        return res;
    }

    public static class AuthRegExDTO implements Serializable {

        private static final long serialVersionUID = 1L;

        public String email;
        public RoleEnum role;
        public Date modified, created;
        public String provider;

        @Override
        public String toString() {
            return "AuthRegExDTO [email=" + email + ", role=" + role + ", provider=" + provider + "]";
        }
    }
}
