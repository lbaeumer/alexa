package de.quaestio24.dao;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.PreparedQuery;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Text;
import com.google.gson.Gson;
import de.quaestio24.dto.NotificationDTO;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

public class NotificationDAO {

    private static final Logger log = Logger.getLogger(NotificationDAO.class.getName());

    private static final String TABLE = "notification";

    public void saveNotification(NotificationDTO w) {
        log.info("saveNotification " + w);

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Date now = new Date();
        Key key = KeyFactory.createKey(TABLE, w.site + "/" + now.getTime());

        Entity e = new Entity(key);

        e.setProperty("created", now);
        w.date = now;
        e.setProperty("entry", new Text(new Gson().toJson(w)));

        log.fine("saveEntry emp=" + e);

        datastore.put(e);
    }

    public List<NotificationDTO> getAllNotification() {

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Query q = new Query(TABLE);
        q.addSort("created", Query.SortDirection.DESCENDING);
        PreparedQuery pq = datastore.prepare(q);

        Iterable<Entity> it;
        it = pq.asIterable();

        List<NotificationDTO> l = new ArrayList<>();
        Gson gson = new Gson();
        for (Entity e : it) {
            Text t = (Text) e.getProperty("entry");
            NotificationDTO s = gson.fromJson(t.getValue(), NotificationDTO.class);
            l.add(s);
        }

        return l;
    }
}
