package de.quaestio24.dao;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.EntityNotFoundException;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.Text;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.dto.PreferencesDTO.DesignParameter;
import de.quaestio24.dto.PreferencesDTO.Parameter;
import de.quaestio24.service.AuthService;
import de.quaestio24.service.PreferencesService;
import org.apache.log4j.MDC;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Logger;

import static de.quaestio24.dto.PreferencesDTO.StrategyEnum.best;

public class PreferencesDAO {

    private static final Logger log = Logger.getLogger(PreferencesDAO.class.getName());

    private static final String TABLE = "preference";
    private static volatile Properties defaultProps;

    public static Properties getDefaultProps() {
        if (defaultProps == null) {
            synchronized (PreferencesDAO.class) {
                Properties props = new Properties();
                try {
                    props.load(PreferencesService.class.getResourceAsStream("/pref_defaults.properties"));
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                defaultProps = props;
            }
        }
        return defaultProps;
    }

    public void addPreference(PreferencesDTO w) {
        log.info("addPreference(" + w + ")");

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Key key = KeyFactory.createKey(TABLE, "config");
        Entity e;
        try {
            e = datastore.get(key);

            // backup old entry
            Key bkpKey = KeyFactory.createKey(TABLE + "_h", "config_" + System.currentTimeMillis());

            Entity bkpEntity = new Entity(bkpKey);
            bkpEntity.setPropertiesFrom(e);
            bkpEntity.setProperty("updated", new Date());
            bkpEntity.setProperty("user", "" + MDC.get("user"));
            datastore.put(bkpEntity);

        } catch (EntityNotFoundException enf) {
            log.fine("no prefs found, so I cannot backup anything");
        }
        e = new Entity(key);

        e.setProperty("eventDate", w.eventDate);
        e.setProperty("startDate", w.startDate);
        e.setProperty("endDate", w.endDate);
        e.setProperty("startDate2", w.startDate2);
        e.setProperty("endDate2", w.endDate2);
        e.setProperty("emailcc", w.emailcc);
        e.setProperty("anonymous", w.anonymous);

        Gson gson = new Gson();
        if (w.design == null) {
            w.design = new DesignParameter();
        }
        e.setProperty("design", new Text(gson.toJson(w.design)));

        if (w.parameter == null) {
            w.parameter = new Parameter();
        }
        e.setProperty("parameter", gson.toJson(w.parameter));
        e.setProperty("includeStatus", w.includeStatus);
        e.setProperty("auth", w.auth);

        List<String> subSites = w.subSites;
        if (subSites == null) {
            subSites = new ArrayList<>();
        }
        e.setProperty("subSites", gson.toJson(subSites));

        e.setProperty("user", "" + MDC.get("user"));
        e.setProperty("updated", new Date());

        datastore.put(e);
    }

    public PreferencesDTO getPreference() {

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Key key = KeyFactory.createKey(TABLE, "config");
        PreferencesDTO p = new PreferencesDTO();
        try {
            Entity e = datastore.get(key);

            p.eventDate = (Date) e.getProperty("eventDate");
            p.startDate = (Date) e.getProperty("startDate");
            p.endDate = (Date) e.getProperty("endDate");
            p.startDate2 = (Date) e.getProperty("startDate2");
            p.endDate2 = (Date) e.getProperty("endDate2");
            p.emailcc = (String) e.getProperty("emailcc");
            Boolean b = (Boolean) e.getProperty("includeStatus");
            p.includeStatus = (b != null ? b : false);
            b = (Boolean) e.getProperty("auth");
            p.auth = (b != null ? b : true);
            b = (Boolean) e.getProperty("anonymous");
            p.anonymous = (b != null ? b : true);

            if (b == null) {
                e.setProperty("auth", true);
                datastore.put(e);
            }

            Gson gson = new Gson();
            Object paramsd = e.getProperty("design");
            if (paramsd != null) {
                p.design = gson.fromJson((paramsd instanceof Text ? ((Text) paramsd).getValue() : (String) paramsd),
                        DesignParameter.class);
            }
            if (p.design == null) {
                p.design = new DesignParameter();
            }

            String params;
            params = (String) e.getProperty("subSites");
            if (params != null) {
                Type ab = new TypeToken<List<String>>() {
                }.getType();
                p.subSites = gson.fromJson(params, ab);
            } else {
                params = (String) e.getProperty("subProjects");
                if (params != null) {
                    Type ab = new TypeToken<Map<String, String>>() {
                    }.getType();
                    Map<String, String> m = gson.fromJson(params, ab);
                    p.subSites = new ArrayList<>(m.keySet());
                } else {
                    p.subSites = new ArrayList<>();
                }
            }

            params = (String) e.getProperty("parameter");
            if (params != null) {
                p.parameter = gson.fromJson(params, Parameter.class);
                if (p.parameter.strategy == null) {
                    p.parameter.strategy = best;
                }
            }

        } catch (EntityNotFoundException e1) {
            // TODO: workaround
            String namespace = NamespaceManager.get();
            if (namespace != null
                    && (namespace.startsWith("prjtest") || namespace.equals("junit") || namespace.startsWith("demo"))) {
                p = getDefaultPreference();
                addPreference(p);
                new AuthService().createDefaultAuth();
            } else {
                throw new IllegalStateException("there are no preferences for " + NamespaceManager.get());
            }
        }

        return p;
    }

    public PreferencesDTO getDefaultPreference() {
        PreferencesDTO p = new PreferencesDTO();
        p.eventDate = new Date(0);
        p.startDate = new Date(0);
        GregorianCalendar cal = new GregorianCalendar();
        cal.add(Calendar.YEAR, 20);
        p.endDate = cal.getTime();
        p.emailcc = "";
        p.includeStatus = false;
        p.auth = false;
        p.anonymous = Boolean.parseBoolean(getDefaultProps().getProperty("parameter.anonymous"));

        p.design = new DesignParameter();
        p.design.minSelections = Integer.parseInt(getDefaultProps().getProperty("design.minSelections"));
        p.design.minCodeLen = Integer.parseInt(getDefaultProps().getProperty("design.minCodeLen"));
        p.design.maxCodeLen = Integer.parseInt(getDefaultProps().getProperty("design.maxCodeLen"));
        p.design.paginateCount = Integer.parseInt(getDefaultProps().getProperty("design.paginateCount"));
        p.design.displayCost = Boolean.parseBoolean(getDefaultProps().getProperty("design.displayCost"));
        p.design.displayRoom = Boolean.parseBoolean(getDefaultProps().getProperty("design.displayRoom"));
        p.design.displayShift = Boolean.parseBoolean(getDefaultProps().getProperty("design.displayShift"));
        p.design.displayTeacher = Boolean.parseBoolean(getDefaultProps().getProperty("design.displayTeacher"));

        p.parameter = new Parameter();
        p.parameter.strategy = best;
        p.parameter.randomize = Boolean.parseBoolean(getDefaultProps().getProperty("parameter.randomize"));
        p.parameter.ignoreEmptyProjects = Boolean
                .parseBoolean(getDefaultProps().getProperty("parameter.ignoreEmptyProjects"));
        p.parameter.skipMinimum = Boolean.parseBoolean(getDefaultProps().getProperty("parameter.skipMinimum"));
        p.parameter.addNonVoters = Boolean.parseBoolean(getDefaultProps().getProperty("parameter.addNonVoters"));

        p.subSites = new ArrayList<>();

        return p;
    }
}
