package de.quaestio24.dao;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.PreparedQuery;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Text;
import de.quaestio24.dto.FeedbackDTO;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.logging.Logger;

public class FeedbackDAO {

    private static final Logger log = Logger.getLogger(FeedbackDAO.class.getName());

    private static final String TABLE = "feedback";

    public FeedbackDAO() {
    }

    public Key saveFeedback(FeedbackDTO w) {
        log.info("saveFeedback " + w);

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Key key = KeyFactory.createKey(TABLE, System.currentTimeMillis());

        Entity e = new Entity(key);

        e.setProperty("name", w.name);
        e.setProperty("email", w.email);
        e.setProperty("phone", w.phone);
        if (w.text != null) {
            e.setProperty("text", new Text(w.text));
        }

        e.setProperty("created", new Date());

        log.fine("saveEntry emp=" + e);

        return datastore.put(e);
    }

    public List<FeedbackDTO> getAllFeedback() {

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Query q = new Query(TABLE);
        PreparedQuery pq = datastore.prepare(q);

        Iterable<Entity> it;
        it = pq.asIterable();

        SortedSet<FeedbackDTO> sels = new TreeSet<>((o1, o2) -> {
            long d = o1.created.getTime() - o2.created.getTime();
            if (d > 0) {
                return 1;
            }
            if (d < 0) {
                return -1;
            }
            return (o1.name.compareTo(o2.name));
        });
        for (Entity e : it) {
            FeedbackDTO s = new FeedbackDTO();
            s.created = (Date) e.getProperty("created");
            s.name = (String) e.getProperty("name");
            s.email = (String) e.getProperty("email");
            s.phone = (String) e.getProperty("phone");
            Text t = (Text) e.getProperty("text");
            if (t != null) {
                s.text = t.getValue();
            }
            sels.add(s);
        }

        log.info("found " + sels.size());
        return new ArrayList<>(sels);
    }
}
