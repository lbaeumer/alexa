package de.quaestio24.dao;

import com.google.appengine.api.NamespaceManager;
import com.google.auth.oauth2.ServiceAccountCredentials;
import com.google.cloud.storage.Blob;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.BlobInfo;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.Storage.BlobTargetOption;
import com.google.cloud.storage.Storage.PredefinedAcl;
import com.google.cloud.storage.StorageException;
import com.google.cloud.storage.StorageOptions;
import de.quaestio24.service.SiteService;
import de.quaestio24.util.SystemConfig;
import de.quaestio24.ws.LoginResources.User;
import org.apache.log4j.MDC;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class BlobstoreDAO {

    private static final Logger log = Logger.getLogger(BlobstoreDAO.class.getName());

    public void uploadFile(String file, byte[] in) {

        try {
            String site = NamespaceManager.get();
            if (site == null) {
                log.log(Level.WARNING, "Type must not be null", new RuntimeException());
            }
            Storage storage = StorageOptions.newBuilder()
                    .setCredentials(ServiceAccountCredentials.fromStream(BlobstoreDAO.class
                            .getResourceAsStream("/" + SystemConfig.getProperties().getProperty("credentials"))))
                    .build().getService();

            DateFormat df = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");

            String newFile = null;
            if (file.indexOf(".") > 0) {
                User u = (User) MDC.get("user");
                newFile = file.substring(0, file.indexOf(".")) + "-" + df.format(new Date()) + "-"
                        + ((u != null ? u.email : "") + "   ").substring(0, 3) + file.substring(file.indexOf("."));
            }
            BlobId blobId = BlobId.of(SystemConfig.getProperties().getProperty("bucket.name"), site + "/" + newFile);

            Map<String, String> m = new HashMap<>();
            m.put("user", "" + MDC.get("user"));

            BlobInfo blobInfo = BlobInfo.newBuilder(blobId).setMetadata(m).build();
            Blob blob = storage.create(blobInfo, in);

            String wfile = blob.getMediaLink();
            log.info("uploaded " + wfile);

        } catch (Exception e) {
            log.log(Level.WARNING, "upload failed", e);
        }
    }

    public void uploadImage() {

        try {
            String site = NamespaceManager.get();
            if (site == null) {
                log.log(Level.WARNING, "Type must not be null", new RuntimeException());
            }
            Storage storage = StorageOptions.newBuilder()
                    .setCredentials(ServiceAccountCredentials.fromStream(SiteService.class
                            .getResourceAsStream("/" + SystemConfig.getProperties().getProperty("credentials"))))
                    .build().getService();

            BlobId blobId = BlobId.of(SystemConfig.getProperties().getProperty("bucket.name"), site + "/logo.jpg");

            BlobInfo blobInfo = BlobInfo.newBuilder(blobId).setContentType("image/jpeg").build();

            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try {
                try (InputStream in = SiteService.class.getResourceAsStream("/logo.png")) {
                    byte[] buffer = new byte[1024];
                    int len;
                    while ((len = in.read(buffer)) > 0) {
                        out.write(buffer, 0, len);
                    }
                }
            } finally {
                out.close();
            }

            storage.create(blobInfo, out.toByteArray(), BlobTargetOption.predefinedAcl(PredefinedAcl.PUBLIC_READ));

        } catch (StorageException | IOException e) {
            log.log(Level.WARNING, "uploading image failed", e);
        }
    }
}
