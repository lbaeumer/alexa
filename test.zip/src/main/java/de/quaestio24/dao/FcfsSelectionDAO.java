package de.quaestio24.dao;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.PreparedQuery;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Query.FilterOperator;
import com.google.appengine.api.datastore.Query.FilterPredicate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.logging.Logger;

public class FcfsSelectionDAO {
    private static final Logger log = Logger.getLogger(FcfsSelectionDAO.class.getName());

    private static final String TABLE = "fcfsselection";

    public Map<Integer, List<Integer>> getSelections(Integer projectId) {

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Query q = new Query(TABLE);
        if (projectId != null) {
            q.setFilter(new FilterPredicate("projectId", FilterOperator.EQUAL, projectId));
        }

        PreparedQuery pq = datastore.prepare(q);
        Iterable<Entity> it = pq.asIterable();

        Map<Integer, List<Integer>> countMap = new TreeMap<>();
        for (Entity e : it) {
            Number booked = (Number) e.getProperty("booked");
            Number overbooked = (Number) e.getProperty("overbooked");
            Number pId = (Number) e.getProperty("projectId");

            List<Integer> c = countMap.get(pId.intValue());
            if (c != null) {
                countMap.put(pId.intValue(),
                        Arrays.asList(c.get(0) + booked.intValue(), c.get(1) + overbooked.intValue()));
            } else {
                countMap.put(pId.intValue(),
                        Arrays.asList(booked.intValue(), overbooked.intValue()));
            }
        }

        log.info("countmap=" + countMap);
        return countMap;
    }

    public void saveSelections(int projectId, int cnt1, int cnt2) {
        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Query q = new Query(TABLE);
        q.setFilter(new FilterPredicate("projectId", FilterOperator.EQUAL, projectId));

        PreparedQuery pq = datastore.prepare(q);
        Iterator<Entity> it = pq.asIterator();

        Entity e;
        Number booked = 0;
        Number overbooked = 0;
        if (it.hasNext()) {
            e = it.next();
            booked = (Number) e.getProperty("booked");
            overbooked = (Number) e.getProperty("overbooked");
        } else {
            Key key = KeyFactory.createKey(TABLE, System.currentTimeMillis());
            e = new Entity(key);
            e.setProperty("projectId", projectId);
        }

        e.setProperty("booked", booked.intValue() + cnt1);
        e.setProperty("overbooked", overbooked.intValue() + cnt2);

        datastore.put(e);
    }

    public void deleteAllSelections() {
        log.info("deleteAllSelections()");
        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        List<Key> entities = new ArrayList<>();

        // live entries
        Query q = new Query(TABLE);
        PreparedQuery pq = datastore.prepare(q);
        for (Entity e : pq.asIterable()) {
            entities.add(e.getKey());
        }

        // history
        q = new Query(TABLE + "_h");
        pq = datastore.prepare(q);
        for (Entity e : pq.asIterable()) {
            entities.add(e.getKey());
        }
        datastore.delete(entities);
    }
}
