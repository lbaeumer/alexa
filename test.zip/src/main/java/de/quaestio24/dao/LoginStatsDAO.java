package de.quaestio24.dao;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.EntityNotFoundException;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.PreparedQuery;
import com.google.appengine.api.datastore.Query;
import de.quaestio24.dto.LoginStatDTO;
import de.quaestio24.dto.UserDTO;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class LoginStatsDAO {

    private static final String TABLE = "login_stats";

    public void addLoginStats(UserDTO user, boolean ok) {
        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Key key = KeyFactory.createKey(TABLE, user.email + "/" + user.provider);
        Entity e;
        Date now = new Date();
        try {
            e = datastore.get(key);
            Number count = (Number) e.getProperty("loginCount");
            if (count == null) {
                count = 0;
            }
            e.setProperty("loginCount", count.intValue() + 1);
            if (ok) {
                e.setProperty("lastSuccessLogin", now);
            } else {
                e.setProperty("lastFailedLogin", now);
            }
            datastore.put(e);
        } catch (EntityNotFoundException ex) {
            e = new Entity(key);
            e.setProperty("created", now);
            e.setProperty("loginCount", 1);
            if (ok) {
                e.setProperty("lastSuccessLogin", now);
            } else {
                e.setProperty("lastFailedLogin", now);
            }
            datastore.put(e);
        }
    }

    public List<LoginStatDTO> getLoginStats() {
        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Query q = new Query(TABLE);
        List<LoginStatDTO> list = new ArrayList<>();
        PreparedQuery pq = datastore.prepare(q);
        Entity e;
        Iterator<Entity> it = pq.asIterator();
        while (it.hasNext()) {
            e = it.next();
            LoginStatDTO l = new LoginStatDTO();
            l.lastSuccessLogin = (Date) e.getProperty("lastSuccessLogin");
            l.lastFailedLogin = (Date) e.getProperty("lastFailedLogin");
            Number n = (Number) e.getProperty("loginCount");
            l.loginCount = (n != null ? n.intValue() : 0);
            l.name = e.getKey().getName();
            if (l.lastSuccessLogin != null && l.lastFailedLogin != null) {
                LoginStatDTO l2 = new LoginStatDTO();
                l2.lastFailedLogin = l.lastFailedLogin;
                l2.loginCount = l.loginCount;
                l2.name = l.name;
                l.lastFailedLogin = null;
                list.add(l2);
            }
            list.add(l);
        }

        list.sort((o1, o2) -> {
            Date d1 = (o1.lastFailedLogin == null ? o1.lastSuccessLogin : o1.lastFailedLogin);
            Date d2 = (o2.lastFailedLogin == null ? o2.lastSuccessLogin : o2.lastFailedLogin);
            if (d1 == null && d2 != null) {
                return 1;
            }
            if (d1 != null && d2 == null) {
                return -1;
            }
            if (d1 != null && d1.before(d2)) {
                return 1;
            }
            if (d2 != null && d2.before(d1)) {
                return -1;
            }
            return o1.name.compareTo(o2.name);
        });
        return list;
    }
}
