package de.quaestio24.dao;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.PreparedQuery;
import com.google.appengine.api.datastore.Query;
import com.google.gson.Gson;
import de.quaestio24.dto.SettingsDTO;
import org.apache.log4j.MDC;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.logging.Logger;

public class SiteDAO {

    private static final Logger log = Logger.getLogger(SiteDAO.class.getName());

    public SettingsDTO saveSettings(SettingsDTO settings) {
        log.info("saveSettings " + settings);

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Key key = KeyFactory.createKey("settings", "sites");

        Entity e = new Entity(key);
        Gson gson = new Gson();
        e.setProperty("sites", gson.toJson(settings));
        e.setProperty("user", "" + MDC.get("user"));
        e.setProperty("updated", new Date());
        datastore.put(e);

        return settings;
    }

    public SettingsDTO getSettings() {

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Key key = KeyFactory.createKey("settings", "sites");

        Query q = new Query(key);
        PreparedQuery pq = datastore.prepare(q);
        Gson gson = new Gson();

        Entity e = pq.asSingleEntity();
        if (e == null) {
            log.warning("I don't know any projects");

            SettingsDTO s = new SettingsDTO();
            s.sites = new ArrayList<>();
            s.sites.add("demo");
            s.sites.add("demo2");
            s.sites.add("demo3");
            s.sites.add("prjtest");
            s.sites.add("prjtest2");
            s.sites.add("junit");
            s.subSites = new HashMap<>();

            e = new Entity(key);
            e.setProperty("sites", gson.toJson(s));
            datastore.put(e);

            return s;
        }

        // return sites
        String sites = (String) e.getProperty("sites");
        return gson.fromJson(sites, SettingsDTO.class);
    }
}
