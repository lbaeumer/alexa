package de.quaestio24.dao;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.EntityNotFoundException;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.Text;
import com.google.gson.Gson;
import de.quaestio24.dto.ProjectPackageDTO;
import org.apache.log4j.MDC;

import java.util.Date;
import java.util.logging.Logger;

public class ProjectPackageDAO {

    private static final Logger log = Logger.getLogger(ProjectPackageDAO.class.getName());

    private static final String TABLE = "projectpackage";

    public long saveProjectPackage(ProjectPackageDTO w) {
        log.info("saveProjectPackage " + w);

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        long id = System.currentTimeMillis();
        Key key = KeyFactory.createKey(TABLE, id);

        Entity e = new Entity(key);

        Gson gson = new Gson();
        e.setProperty("pkg", new Text(gson.toJson(w)));
        e.setProperty("created", new Date());
        e.setProperty("user", "" + MDC.get("user"));

        log.fine("saveEntry emp=" + e);
        datastore.put(e);

        return id;
    }

    public ProjectPackageDTO getProjectPackage(long id) {

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Key key = KeyFactory.createKey(TABLE, id);
        Entity e;
        try {
            e = datastore.get(key);
        } catch (EntityNotFoundException e1) {
            log.info("did not find an entity with id " + id);
            return null;
        }

        Text t = (Text) e.getProperty("pkg");
        Gson gson = new Gson();

        return gson.fromJson(t.getValue(), ProjectPackageDTO.class);
    }
}
