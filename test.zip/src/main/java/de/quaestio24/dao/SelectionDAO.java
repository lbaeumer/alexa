package de.quaestio24.dao;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.EntityNotFoundException;
import com.google.appengine.api.datastore.FetchOptions;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.PreparedQuery;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Query.FilterOperator;
import com.google.appengine.api.datastore.Query.FilterPredicate;
import com.google.appengine.api.datastore.Text;
import com.google.gson.Gson;
import de.quaestio24.dto.CodeDTO;
import de.quaestio24.dto.PersonDTO;
import de.quaestio24.dto.SelectionDTO;
import de.quaestio24.util.CryptoUtil;
import de.quaestio24.util.HashUtil;
import org.apache.log4j.MDC;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.logging.Logger;

public class SelectionDAO {
    private static final Logger log = Logger.getLogger(SelectionDAO.class.getName());

    private static final String TABLE = "selection";

    public Object[] save(SelectionDTO selection) {
        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Key key = KeyFactory.createKey(TABLE, getKey(selection));

        // backup old entry
        int lastPrj, lastPrj2;
        boolean equals = false;
        try {
            Entity oldEntity = datastore.get(key);
            SelectionDTO oldRe = toDto(oldEntity);
            if (oldRe.selections.equals(selection.selections)) {
                int age = (int) (System.currentTimeMillis() - oldRe.created.getTime()) / 1000;
                if (age < 10) {
                    log.info("selection is equal " + oldRe + " = " + selection + "; age=" + age);
                    equals = true;
                } else {
                    log.info("selection is too old " + age);
                }
            }

            Key oldKey = KeyFactory.createKey(TABLE + "_h", oldRe.hashCode() + oldRe.created.getTime());

            Entity oldEntity2 = toEntity(oldKey, oldRe.person, oldRe.selections, oldRe.created,
                    oldRe.verified ? Boolean.TRUE : null, oldRe.idHost, oldRe.idUserAgent,
                    oldRe.addAfterAssignment, oldRe.prio);
            log.fine("backup old entity");

            datastore.put(oldEntity2);

            if (oldRe.selections.size() > 0) {
                lastPrj = oldRe.selections.get(0);
            } else {
                log.info("found a selection but without projects. " + key);
                lastPrj = -1;
            }

            if (oldRe.selections.size() > 1) {
                lastPrj2 = oldRe.selections.get(1);
            } else {
                log.info("found a selection but without projects. " + key);
                lastPrj2 = -1;
            }

        } catch (EntityNotFoundException ex) {
            // so what, do nothing but include
            log.fine("entity does not exist, so create it");
            lastPrj = -1;
            lastPrj2 = -1;
        }

        // save new entry
        Date created = (selection.created == null ? new Date() : selection.created);
        Entity e = toEntity(key, selection.person, selection.selections, created, null, selection.idHost,
                selection.idUserAgent, selection.addAfterAssignment, selection.prio);
        log.fine("e " + e);

        Key k = datastore.put(e);

        String o = k.getName();
        log.fine("saved " + o + ";" + k);

        return new Object[]{o, created, lastPrj, lastPrj2, equals};
    }

    private String getKey(SelectionDTO selection) {

        String s;
        if (selection.person != null && selection.person.code != null && selection.person.code.length() > 0) {
            s = selection.person.code.toLowerCase();
        } else if (selection.person != null && selection.person.name != null) {
            s = selection.person.name.toLowerCase();
        } else {
            log.severe("Illegal selection " + selection + "; " + selection.person);
            throw new IllegalStateException("there's an illegal selection " + selection);
        }

        return HashUtil.md5((PersonDTO.normalize(s, true) + selection.hashCode()).getBytes());
    }

    public SelectionDTO verify(String selectionId) {

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Key key = KeyFactory.createKey(TABLE, selectionId);

        Entity e;
        try {
            e = datastore.get(key);
            e.setProperty("verified", true);
            datastore.put(e);
        } catch (EntityNotFoundException e1) {
            log.warning("entity with id " + selectionId + " does not exist.");
            return null;
        }

        return toDto(e);
    }

    // TODO: set verified to true
    public List<SelectionDTO> getAllSelection() {
        return getSelectionByTable(TABLE, false);
    }

    public List<SelectionDTO> getAllHistorySelection() {
        return getSelectionByTable(TABLE + "_h", false);
    }

    private List<SelectionDTO> getSelectionByTable(String table, boolean filterVerified) {

        List<SelectionDTO> selections;
        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Query q = new Query(table);
        if (filterVerified) {
            q.setFilter(new FilterPredicate("verified", FilterOperator.EQUAL, Boolean.TRUE));
        }

        PreparedQuery pq = datastore.prepare(q);

        Iterable<Entity> it;
        it = pq.asIterable();

        SortedSet<SelectionDTO> sels = new TreeSet<>();
        for (Entity e : it) {
            SelectionDTO s = toDto(e);
            sels.add(s);
        }

        log.info("read " + sels.size() + " selections from database");
        selections = new ArrayList<>(sels);

        return selections;
    }

    public SelectionDTO getSelectionByCode(CodeDTO code) {
        SelectionDTO s = new SelectionDTO();
        s.person = new PersonDTO();
        s.person.code = code.code;
        s.person.clazz = code.clazz;
        String selectionId = getKey(s);

        return getSelection(selectionId);
    }

    public SelectionDTO getSelection(String selectionId) {
        log.fine("getSelection(" + selectionId + ")");
        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Key key = KeyFactory.createKey(TABLE, selectionId);

        try {
            Entity oldEntity = datastore.get(key);

            return toDto(oldEntity);
        } catch (EntityNotFoundException e) {
            log.fine("did not find selectionId " + selectionId);
            return null;
        }
    }

    public int getSelectionCount() {

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Query q = new Query(TABLE);

        return datastore.prepare(q).countEntities(FetchOptions.Builder.withDefaults());
    }

    public void deleteAllSelection() {

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        List<Key> keys = new ArrayList<>();

        // live entries
        Query q = new Query(TABLE);
        PreparedQuery pq = datastore.prepare(q);
        for (Entity e : pq.asIterable()) {
            keys.add(e.getKey());
        }

        // history
        q = new Query(TABLE + "_h");
        pq = datastore.prepare(q);
        for (Entity e : pq.asIterable()) {
            keys.add(e.getKey());
        }

        datastore.delete(keys);
    }

    public SelectionDTO deleteSelection(String selectionId) {

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Key key = KeyFactory.createKey(TABLE, selectionId);

        try {
            Entity oldEntity = datastore.get(key);
            SelectionDTO oldRe = toDto(oldEntity);
            log.info("delete and archive " + oldRe);

            Key oldKey = KeyFactory.createKey(TABLE + "_h", oldRe.hashCode() + oldRe.created.getTime());

            Entity oldEntity2 = toEntity(oldKey, oldRe.person, oldRe.selections, oldRe.created,
                    oldRe.verified ? Boolean.TRUE : null, oldRe.idHost, oldRe.idUserAgent,
                    oldRe.addAfterAssignment, oldRe.addAfterAssignment);
            log.info("backup old entity");

            oldEntity2.setProperty("deleted", new Date());
            oldEntity2.setProperty("user", "" + MDC.get("user"));

            datastore.put(oldEntity2);

            datastore.delete(key);

            return oldRe;
        } catch (EntityNotFoundException ex) {
            // so what, do nothing but include
            log.info("entity does not exist, so do nothing");
            return null;
        }
    }

    private Entity toEntity(Key key, PersonDTO person, List<Integer> sl, Date created, Boolean verified, String idHost,
                            String idUserAgent, Boolean addAfterAssignment, Boolean prio) {
        Entity e = new Entity(key);

        Gson gson = new Gson();
        String s = gson.toJson(person, PersonDTO.class);

        if ((person.name != null && person.name.length() > 0)
                || (person.surname != null && person.surname.length() > 0)) {
            s = "{enc}" + CryptoUtil.encrypt(s);
        }

        if (verified != null && verified) {
            e.setProperty("verified", true);
        }

        SelectionEntry entry = new SelectionEntry();
        entry.person = s;
        entry.created = created.getTime();
        entry.selections = sl;
        entry.idHost = idHost;
        entry.idUserAgent = idUserAgent;
        entry.addAfterAssignment = addAfterAssignment;
        entry.prio = prio;

        s = gson.toJson(entry);
        e.setProperty("entry", new Text(s));

        return e;
    }

    private SelectionDTO toDto(Entity e) {
        SelectionDTO selection = new SelectionDTO();
        selection.id = e.getKey().getName();

        Gson gson = new Gson();

        Boolean verified = (Boolean) e.getProperty("verified");
        if (verified != null) {
            selection.verified = verified;
        }

        // entry
        Text t = (Text) e.getProperty("entry");
        String st = t.getValue();
        SelectionEntry entry = gson.fromJson(st, SelectionEntry.class);
        selection.created = new Date(entry.created);
        if (entry.person.startsWith("{enc}")) {
            st = CryptoUtil.decrypt(entry.person.substring(5));
            selection.person = gson.fromJson(st, PersonDTO.class);
        } else {
            selection.person = gson.fromJson(entry.person, PersonDTO.class);
        }
        selection.addAfterAssignment = entry.addAfterAssignment;
        selection.prio = entry.prio;
        selection.selections = entry.selections;
        selection.idHost = entry.idHost;
        selection.idUserAgent = entry.idUserAgent;

        return selection;
    }

    private static class SelectionEntry implements Serializable {
        private static final long serialVersionUID = 1L;

        public String person;
        public List<Integer> selections;
        public Boolean addAfterAssignment, prio;
        public long created;
        public String idHost, idUserAgent;
    }
}
