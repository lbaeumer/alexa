package de.quaestio24.dao;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.PreparedQuery;
import com.google.appengine.api.datastore.Query;
import com.google.gson.Gson;
import de.quaestio24.dto.AuditDTO;
import de.quaestio24.ws.LoginResources;
import org.apache.log4j.MDC;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.logging.Logger;

public class AuditDAO {
    private static final Logger log = Logger.getLogger(AuditDAO.class.getName());

    private static final String TABLE = "audit";

    public void insertAudit(AuditDTO a) {
        log.info("insertAudit " + a);

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        a.date = new Date();
        LoginResources.User user = (LoginResources.User) MDC.get("user");
        a.user = (user != null ? user.email : "?");
        a.role = (user != null ? user.role : "");

        Key key = KeyFactory.createKey(TABLE, a.date.getTime()
                + "/" + a.category);

        Entity e = new Entity(key);
        Gson gson = new Gson();
        e.setProperty("entry", gson.toJson(a));

        datastore.put(e);
    }

    public List<AuditDTO> getAudits() {

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Query q = new Query(TABLE);

        PreparedQuery pq = datastore.prepare(q);

        Set<AuditDTO> l = new TreeSet<>((o1, o2) -> o2.date.compareTo(o1.date));
        Iterable<Entity> it;
        it = pq.asIterable();

        for (Entity e : it) {
            String t = (String) e.getProperty("entry");
            Gson gson = new Gson();
            AuditDTO a = gson.fromJson(t, AuditDTO.class);
            l.add(a);
        }

        return new ArrayList<>(l);
    }
}
