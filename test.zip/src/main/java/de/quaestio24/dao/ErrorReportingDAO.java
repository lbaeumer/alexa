package de.quaestio24.dao;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.FetchOptions;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.PreparedQuery;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Query.SortDirection;
import com.google.appengine.api.datastore.Text;
import de.quaestio24.dto.ErrorDTO;
import org.apache.log4j.MDC;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ErrorReportingDAO {

    public void reportError(String error, String id) {

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Key key = KeyFactory.createKey("error", System.currentTimeMillis());

        Entity e = new Entity(key);
        e.setProperty("error", new Text(error));
        e.setProperty("id", id);
        e.setProperty("created", new Date());
        e.setProperty("user", "" + MDC.get("provider"));

        datastore.put(e);
    }

    public List<ErrorDTO> getLastErrors() {
        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Query q = new Query("error");
        q.addSort("created", SortDirection.DESCENDING);
        PreparedQuery pq = datastore.prepare(q);

        Iterable<Entity> it;
        it = pq.asIterable(FetchOptions.Builder.withLimit(4));

        List<ErrorDTO> l = new ArrayList<>();
        for (Entity e : it) {
            ErrorDTO error = new ErrorDTO();
            error.text = new ArrayList<>();
            error.text.add(e.getProperty("created").toString());
            error.text.add(e.getProperty("user").toString());
            error.text.add(e.getProperty("error").toString());
            l.add(error);
        }

        return l;
    }
}
