package de.quaestio24.dao;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.PreparedQuery;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Query.FilterOperator;
import com.google.appengine.api.datastore.Query.FilterPredicate;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

public class SessionDAO {
    private static final Logger log = Logger.getLogger(SessionDAO.class.getName());

    public void cleanup() {
        log.info("cleanup");

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Query q = new Query("_ah_SESSION");
        q.setFilter(new FilterPredicate("_expires", FilterOperator.LESS_THAN, System.currentTimeMillis()));

        PreparedQuery pq = datastore.prepare(q);

        Iterable<Entity> it;
        it = pq.asIterable();

        List<Key> todelete = new ArrayList<>();
        for (Entity e : it) {
            long expires = ((Number) e.getProperty("_expires")).longValue();
            log.info("expires " + new Date(expires));
            todelete.add(e.getKey());
        }

        datastore.delete(todelete);
    }
}
