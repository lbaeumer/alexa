package de.quaestio24.dao;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.FetchOptions;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.PreparedQuery;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Query.FilterOperator;
import com.google.appengine.api.datastore.Query.FilterPredicate;
import com.google.appengine.api.datastore.Query.SortDirection;
import com.google.appengine.api.datastore.Text;
import com.google.gson.Gson;
import de.quaestio24.dto.ProjectDTO;
import de.quaestio24.dto.ProjectDTO.ProjectAttribute;
import de.quaestio24.dto.ProjectDetailsDTO;
import org.apache.log4j.MDC;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

public class ProjectDAO {

    private static final Logger log = Logger.getLogger(ProjectDAO.class.getName());

    private static final String TABLE = "project";
    private ShardedCounter shard;

    public ProjectDAO() {
        shard = new ShardedCounter(TABLE + "_s", 1000);
    }

    public List<ProjectDTO> addProjects(List<ProjectDTO> projects, boolean addId) {

        log.info("addProjects " + projects.size() + ", " + addId);
        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        // determine unique key
        int kid = shard.getCount();
        shard.increment(projects.size());

        int id = 1;
        if (addId) {
            // determine next id
            Query q = new Query(TABLE);
            q.addSort("id", SortDirection.DESCENDING);
            PreparedQuery pq = datastore.prepare(q);
            Iterator<Entity> it = pq.asIterator();
            if (it.hasNext()) {
                Number n = (Number) it.next().getProperty("id");
                id = n.intValue();
                id++;
            }
        } else if (projects.size() > 0) {
            id = projects.get(0).id;
        }

        log.info("starting with id " + id + "; kid=" + kid);
        List<Entity> entities = new ArrayList<>();
        List<ProjectDTO> res = new ArrayList<>();
        for (ProjectDTO project : projects) {
            Key key = KeyFactory.createKey(TABLE, kid);
            if (addId) {
                project.id = id;
                id++;
            }
            fixClass(project);
            Entity e = toEntity(key, project);
            entities.add(e);

            ProjectDTO p = new ProjectDTO(project.id, project.maxSize, project.minSize, project.title,
                    project.maxGenderRate, project.additional);
            p.details = project.details;
            res.add(p);

            kid++;
        }

        log.info("adding " + entities.size() + " entities");
        datastore.put(entities);

        return res;
    }

    public ProjectDTO updateProject(ProjectDTO w) {
        log.info("updateProject " + w);
        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Query q = new Query(TABLE);
        q.setFilter(new FilterPredicate("id", FilterOperator.EQUAL, w.id));

        PreparedQuery pq = datastore.prepare(q);
        Entity e;
        Iterable<Entity> it = pq.asIterable();
        if (it.iterator().hasNext()) {
            e = it.iterator().next();

            // backup old entry
            Key bkpKey = KeyFactory.createKey(TABLE + "_h", w.id + "_" + System.currentTimeMillis());

            Entity bkpEntity = new Entity(bkpKey);
            bkpEntity.setPropertiesFrom(e);
            bkpEntity.setProperty("updated", new Date());
            bkpEntity.setProperty("user", "" + MDC.get("user"));
            datastore.put(bkpEntity);

            fixClass(w);
            e = toEntity(e.getKey(), w);
            log.fine("saveEntry emp=" + e);
            datastore.put(e);

            return w;
        }

        return null;
    }

    public void deleteProject(int id) {
        log.info("deleteProject " + id);
        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Query q = new Query(TABLE);
        q.setFilter(new FilterPredicate("id", FilterOperator.EQUAL, id));

        PreparedQuery pq = datastore.prepare(q);
        Entity e;
        Iterable<Entity> it = pq.asIterable();
        if (it.iterator().hasNext()) {

            // save old entry
            e = it.iterator().next();

            Key oldKey = KeyFactory.createKey(TABLE + "_h", id + "_" + System.currentTimeMillis());

            Entity oldEntity2 = new Entity(oldKey);
            oldEntity2.setPropertiesFrom(e);
            oldEntity2.setProperty("deleted", new Date());
            oldEntity2.setProperty("user", "" + MDC.get("user"));

            log.info("backup old entity");
            datastore.put(oldEntity2);

            datastore.delete(e.getKey());
        } else {
            log.info("entity cannot be deleted as it does not exist,");
        }
    }

    public void deleteAllProjects() {
        log.info("deleteAllProjects()");
        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        List<Key> entities = new ArrayList<>();

        // live entries
        Query q = new Query(TABLE);
        PreparedQuery pq = datastore.prepare(q);
        for (Entity e : pq.asIterable()) {
            entities.add(e.getKey());
        }

        // history
        q = new Query(TABLE + "_h");
        pq = datastore.prepare(q);
        for (Entity e : pq.asIterable()) {
            entities.add(e.getKey());
        }
        datastore.delete(entities);
    }

    public List<ProjectDTO> getAllProject(boolean detail) {

        log.info("reading all projects from db");
        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Query q = new Query(TABLE);
        q.addSort("id");
        PreparedQuery pq = datastore.prepare(q);
        List<ProjectDTO> ret = new ArrayList<>();
        List<Entity> it = pq.asList(FetchOptions.Builder.withDefaults());
        for (Entity e : it) {
            ProjectDTO s = toDto(e, detail);
            ret.add(s);
        }

        log.info("found " + ret.size());

        return ret;
    }

    public Map<Integer, Integer> fixNumbers() {

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Query q = new Query(TABLE);
        PreparedQuery pq = datastore.prepare(q);

        Map<Integer, Integer> ret = new LinkedHashMap<>();
        List<Entity> it = pq.asList(FetchOptions.Builder.withDefaults());

        it.sort(new Comparator<Entity>() {

            @Override
            public int compare(Entity o1, Entity o2) {
                ProjectDTO p1 = toDto(o1, false);
                ProjectDTO p2 = toDto(o2, false);

                String class1 = p1.additional.get(ProjectAttribute.clazz);
                String class2 = p2.additional.get(ProjectAttribute.clazz);

                String f1 = firstPart(class1);
                String f2 = firstPart(class2);

                int r = f1.compareToIgnoreCase(f2);
                if (r != 0) {
                    return r;
                }

                f1 = secondPart(class1);
                f2 = secondPart(class2);

                r = f1.compareToIgnoreCase(f2);
                if (r != 0) {
                    return r;
                }

                r = p1.title.trim().replace("\"", "").compareToIgnoreCase(p2.title.trim().replace("\"", ""));
                if (r != 0) {
                    return r;
                }

                return p1.id - p2.id;
            }

            private String firstPart(String clazz) {
                if (clazz == null) {
                    return "";
                }

                clazz = clazz.replaceAll(" ", "");
                int pos = clazz.indexOf('-');
                if (pos > 0) {
                    clazz = clazz.substring(0, pos);
                }
                if (clazz.length() == 1) {
                    clazz = "0" + clazz;
                }

                return clazz;
            }

            private String secondPart(String clazz) {
                if (clazz == null) {
                    return "00";
                }

                clazz = clazz.replaceAll(" ", "");
                int pos = clazz.indexOf('-');
                if (pos > 0) {
                    clazz = clazz.substring(pos + 1);
                    if (clazz.length() == 1) {
                        clazz = "0" + clazz;
                    }
                }

                return clazz;
            }
        });

        int idx = 1;
        for (Entity e : it) {
            int id = ((Number) e.getProperty("id")).intValue();
            if (id != idx) {
                log.warning("found number " + id + ". Overwrite with " + idx);
                ret.put(id, idx);

                // create new record
                e.setProperty("id", idx);
                datastore.put(e);
            }
            idx++;
        }

        return ret;
    }

    public ProjectDTO getProject(int id, boolean detail) {

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Query q = new Query(TABLE);
        q.setFilter(new FilterPredicate("id", FilterOperator.EQUAL, id));

        PreparedQuery pq = datastore.prepare(q);
        Entity e = pq.asSingleEntity();
        if (e != null) {
            return toDto(e, detail);
        } else {
            log.info("entity with id " + id + " does not exist,");
        }

        return null;
    }

    void fixClass(ProjectDTO p) {
        if (p == null || p.additional == null) {
            return;
        }
        String clazz = p.additional.get(ProjectAttribute.clazz);
        if (clazz != null) {
            clazz = clazz.replaceAll("[\\s]*,[\\s]*", ", ");
            clazz = clazz.replaceAll("[\\s]*-[\\s]*", " - ");
            p.additional.put(ProjectAttribute.clazz, clazz.trim());
        }
    }

    private ProjectDTO toDto(Entity e, boolean detail) {
        ProjectDTO s = new ProjectDTO();
        s.id = ((Number) e.getProperty("id")).intValue();

        Gson gson = new Gson();

        // handle entry
        Object to = e.getProperty("entry");
        if (to != null) {
            String t = (to instanceof Text ? ((Text) to).getValue() : to.toString());
            ProjectEntry pe = gson.fromJson(t, ProjectEntry.class);
            s.title = pe.title.trim();
            s.minSize = pe.minSize;
            s.maxSize = pe.maxSize;
            s.maxGenderRate = pe.maxGenderRate;
            s.additional = pe.additional;

            if (detail) {
                s.details = pe.details;
            }
        }

        return s;
    }

    private Entity toEntity(Key key, ProjectDTO w) {
        Entity e = new Entity(key);
        e.setProperty("id", w.id);

        // handle entry
        ProjectEntry pe = new ProjectEntry();
        pe.title = w.title;
        pe.minSize = w.minSize;
        pe.maxSize = w.maxSize;
        pe.maxGenderRate = w.maxGenderRate;
        pe.additional = w.additional;

        if (w.details != null && w.details.description != null) {
            pe.details = new ProjectDetailsDTO();
            pe.details.description = w.details.description;
        }

        Gson gson = new Gson();
        e.setProperty("entry", new Text(gson.toJson(pe)));
        e.setProperty("user", "" + MDC.get("user"));
        e.setProperty("updated", new Date());

        return e;
    }

    private static class ProjectEntry implements Serializable {
        private static final long serialVersionUID = 1L;

        public String title;
        public int minSize, maxSize, maxGenderRate;
        public ProjectDetailsDTO details;

        public Map<ProjectAttribute, String> additional = new HashMap<>();
    }
}
