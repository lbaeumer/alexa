package de.quaestio24.dao;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.EntityNotFoundException;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.PreparedQuery;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Query.FilterOperator;
import com.google.appengine.api.datastore.Query.FilterPredicate;
import de.quaestio24.dto.UserDTO;
import de.quaestio24.util.HashUtil;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.logging.Logger;

public class SignupDAO {

    private static final Logger log = Logger.getLogger(SignupDAO.class.getName());

    private static final String TABLE = "signup";

    public UserDTO insert(UserDTO user) {
        log.info("insert " + user);

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        String pw = HashUtil.sha(user.password.trim());
        String mykey = HashUtil.sha(user.name + user.email.trim().toLowerCase());
        Key key = KeyFactory.createKey(TABLE, mykey);

        Entity e = new Entity(key);
        e.setProperty("user", user.name.trim());
        e.setProperty("email", user.email.trim().toLowerCase());
        e.setProperty("site", user.site);
        e.setProperty("password", pw);
        e.setProperty("created", new Date());

        datastore.put(e);

        UserDTO u = new UserDTO();
        u.email = user.email;
        u.name = user.name;
        u.site = user.site;
        u.key = mykey;

        return u;
    }

    public void deleteSignup(String mykey) {
        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Key key = KeyFactory.createKey(TABLE, mykey);
        datastore.delete(key);
    }

    public void cleanup() {
        log.info("cleanup");
        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        GregorianCalendar cal = new GregorianCalendar();
        cal.add(Calendar.HOUR, -24);

        Query q = new Query(TABLE);
        q.setFilter(new FilterPredicate("created", FilterOperator.LESS_THAN, cal.getTime()));

        PreparedQuery pq = datastore.prepare(q);
        pq.asIterable().forEach(e -> datastore.delete(e.getKey()));
    }

    public UserDTO getSignup(String mykey) {
        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Key key = KeyFactory.createKey(TABLE, mykey);
        Entity e;
        try {
            e = datastore.get(key);

            UserDTO user = new UserDTO();
            user.email = (String) e.getProperty("email");
            user.name = (String) e.getProperty("user");
            user.site = (String) e.getProperty("site");
            user.password = (String) e.getProperty("password");

            return user;
        } catch (EntityNotFoundException e1) {
            log.info("entry with " + mykey + " wasn't found");
            return null;
        }
    }
}
