package de.quaestio24.dao;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.EntityNotFoundException;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.PreparedQuery;
import com.google.appengine.api.datastore.Query;
import com.google.gson.Gson;
import de.quaestio24.dto.AuthRequestDTO;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

public class AuthRequestDAO {
    private static final Logger log = Logger.getLogger(AuthRequestDAO.class.getName());

    private static final String TABLE = "authrequest";

    public boolean insertAuthRequest(AuthRequestDTO request) {
        log.info("insertAuthRequest " + request);

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Key key = KeyFactory.createKey(TABLE, (request.provider + "/" + request.email).toLowerCase());

        Entity e;
        try {
            datastore.get(key);
        } catch (EntityNotFoundException e1) {
            e = new Entity(key);
            Gson gson = new Gson();
            e.setProperty("entry", gson.toJson(request));
            e.setProperty("created", new Date());

            datastore.put(e);

            return true;
        }

        return false;
    }

    public List<AuthRequestDTO> deleteAuthRequest(AuthRequestDTO request) {
        log.info("deleteAuthRequest " + request);

        List<AuthRequestDTO> l = getAuthRequests();
        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Key key = KeyFactory.createKey(TABLE, (request.provider + "/" + request.email).toLowerCase());
        datastore.delete(key);

        l.removeIf(a -> a.email.equals(request.email) && a.provider.equals(request.provider));

        return l;
    }

    public List<AuthRequestDTO> getAuthRequests() {

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Query q = new Query(TABLE);

        List<AuthRequestDTO> requests = new ArrayList<>();
        PreparedQuery pq = datastore.prepare(q);

        Iterable<Entity> it;
        it = pq.asIterable();
        Gson gson = new Gson();
        for (Entity e : it) {
            AuthRequestDTO s = gson.fromJson((String) e.getProperty("entry"), AuthRequestDTO.class);
            requests.add(s);
        }

        return requests;
    }
}
