package de.quaestio24.dao;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.PreparedQuery;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Query.FilterOperator;
import com.google.appengine.api.datastore.Query.FilterPredicate;
import de.quaestio24.dto.UserDTO;
import de.quaestio24.exception.NotAuthenticatedException;
import de.quaestio24.util.HashUtil;

import java.util.Date;
import java.util.logging.Logger;

public class UserDAO {

    private static final Logger log = Logger.getLogger(UserDAO.class.getName());

    private static final String TABLE = "user";

    public UserDTO login(UserDTO user) {
        log.fine("login " + user);

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Query q = new Query(TABLE);
        Entity e = null;

        if (user.email != null) {
            q.setFilter(new FilterPredicate("email", FilterOperator.EQUAL, user.email.trim().toLowerCase()));
            PreparedQuery pq = datastore.prepare(q);
            e = pq.asSingleEntity();
        }

        if (e == null) {
            log.info("no email entry found for " + user.email);

            q = new Query(TABLE);
            q.setFilter(new FilterPredicate("user", FilterOperator.EQUAL, user.email.trim()));
            PreparedQuery pq = datastore.prepare(q);
            e = pq.asSingleEntity();
        }

        if (e == null) {
            log.info("no user entry found for " + user.email);
            throw new NotAuthenticatedException("Der User " + user.email + " existiert nicht.",
                    201);
        }

        String pw = HashUtil.sha((user.password != null ? user.password.trim() : null));

        String pw2 = (String) e.getProperty("password");

        if (!pw.equals(pw2)) {
            log.info("password wrong" + pw + "!=" + pw2);

            throw new NotAuthenticatedException("Der User bzw. das Password ist nicht korrekt.",
                    202);
        }

        return toUser(e);
    }

    public UserDTO getUserByName(String user) {
        log.info("getUserByName " + user);

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Query q = new Query(TABLE);
        q.setFilter(new FilterPredicate("user", FilterOperator.EQUAL, user.trim()));
        PreparedQuery pq = datastore.prepare(q);

        Entity e = pq.asSingleEntity();
        if (e == null) {
            log.info("no entry found for " + user);
            return null;
        }

        return toUser(e);
    }

    public UserDTO getUserByEmail(String email) {
        log.info("getUserByEmail " + email);

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Query q = new Query(TABLE);
        q.setFilter(new FilterPredicate("email", FilterOperator.EQUAL, email.trim().toLowerCase()));
        PreparedQuery pq = datastore.prepare(q);

        Entity e = pq.asSingleEntity();
        if (e == null) {
            log.info("no entry found for " + email);
            return null;
        }

        return toUser(e);
    }

    public UserDTO insert(UserDTO user) {
        log.info("insert " + user);

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Key key = KeyFactory.createKey(TABLE, user.email.toLowerCase());

        Entity e = new Entity(key);
        e.setProperty("user", user.name.toLowerCase());
        e.setProperty("email", user.email.toLowerCase());
        e.setProperty("site", user.site);
        e.setProperty("password", user.password);
        e.setProperty("created", new Date());

        datastore.put(e);

        UserDTO u = new UserDTO();
        u.email = user.email;
        u.name = user.name;

        return u;
    }

    private UserDTO toUser(Entity e) {
        UserDTO u = new UserDTO();
        u.name = (String) e.getProperty("user");
        u.email = (String) e.getProperty("email");
        u.site = (String) e.getProperty("site");
        if (u.site == null) {
            u.site = (String) e.getProperty("type");
        }
        return u;
    }
}
