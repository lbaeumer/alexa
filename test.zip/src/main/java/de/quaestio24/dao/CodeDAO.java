package de.quaestio24.dao;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.EntityNotFoundException;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.Text;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import de.quaestio24.dto.CodeDTO;
import de.quaestio24.dto.PersonDTO;
import org.apache.log4j.MDC;

import java.lang.reflect.Type;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

public class CodeDAO {

    private static final Logger log = Logger.getLogger(CodeDAO.class.getName());

    public int insertPersons(List<PersonDTO> persons) {

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Key key = KeyFactory.createKey("selectionpersons", 2);
        Entity e;
        try {
            e = datastore.get(key);

            // backup old entry
            Key bkpKey = KeyFactory.createKey("selectionpersons" + "_h", "persons_" + System.currentTimeMillis());

            Entity bkpEntity = new Entity(bkpKey);
            bkpEntity.setPropertiesFrom(e);
            bkpEntity.setProperty("updated", new Date());
            bkpEntity.setProperty("user", "" + MDC.get("user"));
            datastore.put(bkpEntity);

        } catch (EntityNotFoundException enf) {
            log.fine("no persons found, so I cannot backup anything");
        }

        Type collectionType = new TypeToken<List<PersonDTO>>() {
        }.getType();
        Gson gson = new Gson();
        e = new Entity(key);
        e.setProperty("persons", new Text(gson.toJson(persons, collectionType)));
        e.setProperty("updated", new Date());
        e.setProperty("user", "" + MDC.get("user"));
        datastore.put(e);

        return persons.size();
    }

    public void insertCodes(List<CodeDTO> codes) {

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Key key = KeyFactory.createKey("selectioncodes", 1);
        Entity e;
        try {
            e = datastore.get(key);

            // backup old entry
            Key bkpKey = KeyFactory.createKey("selectioncodes" + "_h", "codes_" + System.currentTimeMillis());

            Entity bkpEntity = new Entity(bkpKey);
            bkpEntity.setPropertiesFrom(e);
            bkpEntity.setProperty("updated", new Date());
            bkpEntity.setProperty("user", "" + MDC.get("user"));
            datastore.put(bkpEntity);

        } catch (EntityNotFoundException enf) {
            log.fine("no prefs found, so I cannot backup anything");
        }

        Type collectionType = new TypeToken<List<CodeDTO>>() {
        }.getType();
        Gson gson = new Gson();
        e = new Entity(key);
        e.setProperty("codes", new Text(gson.toJson(codes, collectionType)));
        e.setProperty("updated", new Date());
        e.setProperty("user", "" + MDC.get("user"));
        datastore.put(e);

    }

    public List<CodeDTO> getCodes() {

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Key key = KeyFactory.createKey("selectioncodes", 1);
        Entity e;
        try {
            e = datastore.get(key);
            Type collectionType = new TypeToken<List<CodeDTO>>() {
            }.getType();
            Gson gson = new Gson();

            Text t = (Text) e.getProperty("codes");
            List<CodeDTO> codes;
            codes = gson.fromJson(t.getValue(), collectionType);

            return codes;

        } catch (EntityNotFoundException e1) {
            return Collections.emptyList();
        }
    }

    public List<PersonDTO> getPersons() {

        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

        Key key = KeyFactory.createKey("selectionpersons", 2);
        Entity e;
        try {
            e = datastore.get(key);
            Type collectionType = new TypeToken<List<PersonDTO>>() {
            }.getType();
            Gson gson = new Gson();

            Text t = (Text) e.getProperty("persons");
            List<PersonDTO> persons;
            persons = gson.fromJson(t.getValue(), collectionType);

            return persons;

        } catch (EntityNotFoundException e1) {
            return Collections.emptyList();
        }
    }
}
