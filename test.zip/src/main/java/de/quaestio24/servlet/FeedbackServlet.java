package de.quaestio24.servlet;

import de.quaestio24.util.SendMail;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Logger;

@WebServlet(urlPatterns = {"/ws/feedback/insert/contact-forms/29/feedback", "/ws/feedback/insertcontact-form-7/v1/contact-forms/29/feedback"})
public class FeedbackServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private static final Logger log = Logger.getLogger(FeedbackServlet.class.getName());

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        BufferedReader r = new BufferedReader(new InputStreamReader(request.getInputStream()));
        StringBuilder strb = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) {
            strb.append(line);
        }
        log.warning(strb.toString());

        new SendMail().send("Quaestio spam servlet", strb.toString(), "lui", "lui.baeumer@gmail.com", null,
                false);
        response.sendError(404);
    }
}
