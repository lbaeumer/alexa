package de.quaestio24.servlet;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.taskqueue.Queue;
import com.google.appengine.api.taskqueue.QueueFactory;
import com.google.appengine.api.taskqueue.TaskOptions;
import de.quaestio24.dao.SessionDAO;
import de.quaestio24.dao.SignupDAO;
import de.quaestio24.dto.CodeDTO;
import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.dto.ProjectDTO;
import de.quaestio24.dto.SelectionDTO;
import de.quaestio24.exception.ValidationException;
import de.quaestio24.service.CodeService;
import de.quaestio24.service.PreferencesService;
import de.quaestio24.service.ProjectImportService;
import de.quaestio24.service.ProjectService;
import de.quaestio24.service.SelectionService;
import de.quaestio24.service.SiteService;
import de.quaestio24.util.CacheUtil;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.logging.Logger;

@WebServlet(urlPatterns = "/ws/cleanup")
public class CleanupServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private static final Logger log = Logger.getLogger(CleanupServlet.class.getName());

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        Queue queue = QueueFactory.getQueue("default");
        queue.add(TaskOptions.Builder.withUrl("/ws/cleanup"));
        response.getWriter().append("kicked off clean job");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        log.info("cleanup");
        new SessionDAO().cleanup();
        new SignupDAO().cleanup();

        NamespaceManager.set("demo");
        ProjectImportService projectImportService = new ProjectImportService();
        ProjectService projectService = new ProjectService();
        SelectionService selectionService = new SelectionService();
        List<ProjectDTO> projects = projectService.getProjects();
        log.info("found #=" + projects.size() + " projects in demo");
        if (projects.isEmpty()) {

            // demo has to be a personalized election
            PreferencesService pref = new PreferencesService();
            PreferencesDTO p = pref.getPreference();
            if (p.anonymous) {
                p.anonymous = false;
                pref.updatePreference(p);
            }

            selectionService.deleteAllSelection();
            try (InputStream in = this.getClass().getResourceAsStream("/data/projects-demo.xls")) {
                CacheUtil.clear();
                projectImportService.importProjectsXLS(in);
            }

            try (InputStream in = this.getClass().getResourceAsStream("/data/selections-demo.csv")) {
                List<SelectionDTO> sels = selectionService.parseSelectionCSV(in);
                selectionService.insertSelections(sels);
            }
        }

        CodeService codeService = new CodeService();

        // demo2
        NamespaceManager.set("demo2");
        projects = projectService.getProjects();
        log.info("found #=" + projects.size() + " projects in demo2");
        if (projects.isEmpty()) {
            selectionService.deleteAllSelection();

            try (InputStream in = this.getClass().getResourceAsStream("/data/codes-demo2.csv")) {
                List<CodeDTO> codes = codeService.parseCodeCSV(in);
                codeService.insertCodes(codes);
            }

            try (InputStream in = this.getClass().getResourceAsStream("/data/projects-demo.xls")) {
                CacheUtil.clear();
                projectImportService.importProjectsXLS(in);
            }

            try (InputStream in = this.getClass().getResourceAsStream("/data/selections-demo2.csv")) {
                List<SelectionDTO> sels = selectionService.parseSelectionCSV(in);
                selectionService.insertSelections(sels);
            }
        }

        // demo3
        NamespaceManager.set("demo3");
        SiteService siteService = new SiteService();
        log.info("found #=" + projects.size() + " projects in demo3");

        for (String subsite : new String[]{"tag1", "tag2"}) {
            try {
                siteService.addSubSite(subsite);
            } catch (ValidationException e) {
                // ignore
            }
        }

        for (String subsite : new String[]{"tag1", "tag2"}) {
            NamespaceManager.set("demo3_" + subsite);

            projects = projectService.getProjects();
            if (projects.isEmpty()) {
                selectionService.deleteAllSelection();

                try (InputStream in = this.getClass().getResourceAsStream("/data/codes-demo2.csv")) {
                    List<CodeDTO> codes = codeService.parseCodeCSV(in);
                    codeService.insertCodes(codes);
                }

                try (InputStream in = this.getClass().getResourceAsStream("/data/projects-demo.xls")) {
                    CacheUtil.clear();
                    projectImportService.importProjectsXLS(in);
                }

                try (InputStream in = this.getClass().getResourceAsStream("/data/selections-demo2.csv")) {
                    List<SelectionDTO> sels = selectionService.parseSelectionCSV(in);
                    selectionService.insertSelections(sels);
                }
            }
        }
    }
}
