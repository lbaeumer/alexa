package de.quaestio24.service;

import com.google.appengine.api.NamespaceManager;
import de.quaestio24.dao.ProjectPackageDAO;
import de.quaestio24.dto.AuditDTO;
import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.dto.ProjectPackageDTO;
import de.quaestio24.util.CacheUtil;

import java.util.HashMap;
import java.util.logging.Logger;

public class ProjectPackageService {
    private static final Logger log = Logger.getLogger(ProjectPackageService.class.getName());

    private PreferencesService preferencesService = new PreferencesService();
    private ProjectService projectService = new ProjectService();
    private ProjectImportService projectImportService = new ProjectImportService();
    private SelectionService selectionService = new SelectionService();
    private SiteService siteService = new SiteService();
    private CodeService codeService = new CodeService();
    private PersonService personService = new PersonService();
    private AuditService auditService = new AuditService();

    private ProjectPackageDAO dao = new ProjectPackageDAO();

    public long saveProjectPackage(ProjectPackageDTO w) {
        return dao.saveProjectPackage(w);
    }

    public ProjectPackageDTO getProjectPackage(long id) {
        return dao.getProjectPackage(id);
    }

    public ProjectPackageDTO exportAll() {
        log.info("exportAll()");
        CacheUtil.clear();

        ProjectPackageDTO p = new ProjectPackageDTO();
        p.projects = projectService.getProjectsDetail();
        p.prefs = preferencesService.getPreference(false);
        p.codes = codeService.getCodes();
        p.persons = personService.getPersons();
        p.selections = selectionService.getAllSelection();

        if (p.prefs.subSites != null && p.prefs.subSites.size() > 0) {
            p.subPackages = new HashMap<>();
            String name = NamespaceManager.get();
            try {
                for (String subPrj : p.prefs.subSites) {
                    NamespaceManager.set(name + "_" + subPrj);
                    ProjectPackageDTO childp = exportAll();
                    p.subPackages.put(subPrj, childp);
                }
            } finally {
                NamespaceManager.set(name);
            }
        }

        return p;
    }

    public void importAll(ProjectPackageDTO projectPackage) {
        log.info("importAll()");
        CacheUtil.clear();

        if (projectPackage.prefs.subSites != null) {
            PreferencesDTO prefs = preferencesService.getPreference();
            for (String subPrj : projectPackage.prefs.subSites) {
                if (!prefs.subSites.contains(subPrj)) {
                    siteService.addSubSite(subPrj);
                }
            }
        }

        try {
            auditService.insertAudit(new AuditDTO(
                    "projectpackage",
                    "imported project package"));

            selectionService.skipValidation(true);

            log.info("going to import " + projectPackage.projects.size() + " projects");
            projectImportService.importProjects(projectPackage.projects);

            log.info("going to update preferences");
            preferencesService.updatePreference(projectPackage.prefs);
            codeService.insertCodes(projectPackage.codes);
            personService.insertPersons(projectPackage.persons);
            selectionService.insertSelections(projectPackage.selections);

            String name = NamespaceManager.get();
            try {
                if (projectPackage.prefs.subSites != null) {
                    for (String subPrj : projectPackage.prefs.subSites) {
                        ProjectPackageDTO childPkg = projectPackage.subPackages.get(subPrj);
                        NamespaceManager.set(name + "_" + subPrj);
                        importAll(childPkg);
                    }
                }
            } finally {
                NamespaceManager.set(name);
            }
        } finally {
            selectionService.skipValidation(false);
        }
        CacheUtil.clear();
    }
}
