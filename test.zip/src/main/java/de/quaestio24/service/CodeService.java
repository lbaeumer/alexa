package de.quaestio24.service;

import de.quaestio24.dao.CodeDAO;
import de.quaestio24.dto.AuditDTO;
import de.quaestio24.dto.CodeDTO;
import de.quaestio24.dto.CodeStatDTO;
import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.exception.ValidationException;
import de.quaestio24.util.CacheUtil;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.poifs.filesystem.OfficeXmlFileException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.logging.Logger;

public class CodeService {
    private static final Logger log = Logger.getLogger(CodeService.class.getName());

    private CodeDAO dao = new CodeDAO();
    private AuditService auditService = new AuditService();
    private PreferencesService prefService = new PreferencesService();

    public CodeDTO validateCode(String code) {
        if (code != null) {
            Map<String, String> codes = getCodesLowerCase();
            String clazz = codes.get(code.toLowerCase());

            if (clazz == null) {
                throw new ValidationException(Collections.singletonList("Der Code " + code + " ist ungültig."), 450);
            }
            CodeDTO c = new CodeDTO();
            c.clazz = clazz;
            c.code = code;
            return c;
        }
        return null;
    }

    public CodeStatDTO insertCodes(List<CodeDTO> codes) {

        log.info("insertCodes(" + codes.size() + ")");

        Set<String> oldCodes = new LinkedHashSet<>();
        Set<String> newCodes = new LinkedHashSet<>();
        List<CodeDTO> cds = getCodes();
        for (CodeDTO c : cds) {
            oldCodes.add(c.code.toLowerCase());
        }
        for (CodeDTO c : codes) {
            newCodes.add(c.code.toLowerCase());
        }

        CodeStatDTO stats = new CodeStatDTO();
        stats.codes = codes;
        for (String c : oldCodes) {
            if (!newCodes.contains(c)) {
                stats.removedCodes++;
            }
        }
        for (String c : newCodes) {
            if (!oldCodes.contains(c)) {
                stats.addedCodes++;
            }
        }

        String key = "codes";

        auditService.insertAudit(new AuditDTO(
                "code",
                "insert " + codes.size() + " codes"));

        dao.insertCodes(codes);

        CacheUtil.remove(key);

        return stats;
    }

    @SuppressWarnings("unchecked")
    public List<CodeDTO> getCodes() {
        List<CodeDTO> l = (List<CodeDTO>) CacheUtil.get("codes");
        if (l == null) {
            l = dao.getCodes();
            CacheUtil.put("codes", l);
        } else {
            log.info("reading from cache #codes()=" + l.size());
        }

        return l;
    }

    public Map<String, String> getCodesLowerCase() {
        List<CodeDTO> l1 = getCodes();
        Map<String, String> l = new TreeMap<>();
        for (CodeDTO c : l1) {
            l.put(c.code.toLowerCase(), c.clazz);
        }

        return l;
    }

    public List<CodeDTO> parseCodeCSV(InputStream imgStream) {

        List<CodeDTO> sel = new ArrayList<>();

        try (CSVParser parser = new CSVParser(new InputStreamReader(imgStream, StandardCharsets.UTF_8), CSVFormat.EXCEL)) {
            List<CSVRecord> selections = parser.getRecords();

            int row = 0;
            for (CSVRecord record : selections) {
                row++;

                int i = 0;

                String code = record.get(i++);
                String clazz = null;
                if (record.size() > 1) {
                    clazz = record.get(i);
                }

                String l = (code + (clazz != null && clazz.length() > 0 ? "," + clazz : "")).replaceAll(";", ",");

                CodeDTO c = getCode(l);

                if (c != null) {
                    sel.add(c);
                }
            }

            log.info("read " + row + " codes");
        } catch (Exception e) {
            e.printStackTrace();
        }

        return sel;
    }

    public List<CodeDTO> parseCodeXLS(byte[] imgStream) throws IOException {

        List<CodeDTO> ret = new ArrayList<>();

        Workbook wb;
        try {
            wb = new HSSFWorkbook(new ByteArrayInputStream(imgStream));
        } catch (OfficeXmlFileException e) {
            OPCPackage pkg;
            try {
                pkg = OPCPackage.open(new ByteArrayInputStream(imgStream));
                wb = new XSSFWorkbook(pkg);
            } catch (InvalidFormatException e1) {
                throw new IOException(e1);
            }
        }

        try {
            Sheet s0 = wb.getSheetAt(0);

            log.info("found rows=" + s0.getLastRowNum());
            for (int ri = 0; ri <= s0.getLastRowNum(); ri++) {
                Row r = s0.getRow(ri);
                log.fine("read row " + ri);

                if (r == null || r.getCell(0) == null) {
                    continue;
                }

                String code = r.getCell(0).getStringCellValue();
                String clazz = null;
                if (r.getCell(1) != null) {
                    clazz = r.getCell(1).getStringCellValue();
                }

                String l = (code + (clazz != null && clazz.length() > 0 ? "," + clazz : "")).replaceAll(";", ",");

                CodeDTO c = getCode(l);

                if (c != null) {
                    ret.add(c);
                }
            }
        } finally {
            wb.close();
        }

        return ret;
    }

    private CodeDTO getCode(String l) {
        CodeDTO c = null;
        if (l.toUpperCase().matches("[A-Z0-9]{4,20},.+")) {
            c = new CodeDTO();
            String[] item = l.split(",");
            c.code = item[0].trim();
            c.clazz = item[1].trim().toLowerCase().replaceAll("\\s+", "");
            while (c.clazz.startsWith("0") && c.clazz.length() > 1) {
                c.clazz = c.clazz.substring(1);
            }
        }
        return c;
    }

    public List<CodeDTO> addCode(CodeDTO code) {
        if (code == null || code.code == null || code.clazz == null) {
            throw new ValidationException(Collections.singletonList("Bitte Code/Klasse eingeben."));
        }
        PreferencesDTO p = prefService.getPreference();
        if (code.code.length() < p.design.minCodeLen) {
            throw new ValidationException(Collections.singletonList("Der Code ist zu kurz."));
        }
        if (code.code.length() > p.design.maxCodeLen) {
            throw new ValidationException(Collections.singletonList("Der Code ist zu lang."));
        }
        if (getCodesLowerCase().containsKey(code.code.toLowerCase())) {
            throw new ValidationException(Collections.singletonList("Der Code existiert schon."));
        }

        List<CodeDTO> codes = getCodes();
        codes.add(code);

        auditService.insertAudit(new AuditDTO(
                "code",
                "insert code " + code.code));

        CodeStatDTO c = insertCodes(codes);
        return c.codes;
    }

    public List<CodeDTO> deleteCode(CodeDTO code) {
        List<CodeDTO> codes = getCodes();
        codes.remove(code);

        auditService.insertAudit(new AuditDTO(
                "code",
                "delete code " + code.code));

        CodeStatDTO c = insertCodes(codes);
        return c.codes;
    }

    public void deleteAllCodes() {
        List<CodeDTO> codes = getCodes();
        dao.insertCodes(codes);

        auditService.insertAudit(new AuditDTO(
                "code",
                "delete all codes"));
    }
}
