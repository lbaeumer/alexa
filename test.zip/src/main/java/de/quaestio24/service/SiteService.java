package de.quaestio24.service;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.repackaged.com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import de.quaestio24.dao.SiteDAO;
import de.quaestio24.dto.AuditDTO;
import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.dto.ProjectPackageDTO;
import de.quaestio24.dto.SettingsDTO;
import de.quaestio24.entity.Site;
import de.quaestio24.exception.NotFoundException;
import de.quaestio24.exception.ValidationException;
import de.quaestio24.util.CacheUtil;

import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Logger;

public class SiteService {
    private static final Logger log = Logger.getLogger(SiteService.class.getName());
    private final String key = "qu3:allprjs";
    private SiteDAO dao = new SiteDAO();
    private PreferencesService prefService = new PreferencesService();
    private AuthService authService = new AuthService();
    private AuditService auditService = new AuditService();
    private BlobstoreService blobstoreService = new BlobstoreService();

    public SettingsDTO addSite(String site) {
        return addSite(site, null);
    }

    public SettingsDTO addSite(String site, PreferencesDTO prefs) {
        site = site.toLowerCase();
        SettingsDTO s = getSettings();
        if (s.sites.contains(site)) {
            log.warning("the site " + site + " already exists.");
            throw new ValidationException(Collections.singletonList("the site " + site + " already exists."));
        }
        if (site.contains("_")) {
            log.warning("the site " + site + " must not contain _ characters.");
            throw new ValidationException(Collections.singletonList("illegal name " + site + " contains _"));
        }
        s.sites.add(site);
        saveSettings(s);

        String namespace = NamespaceManager.get();
        try {
            NamespaceManager.set(site);

            prefService.createDefaultPreference(prefs);
            authService.createDefaultAuth();
            blobstoreService.uploadImage();
            return s;
        } finally {
            NamespaceManager.set(namespace);
        }
    }

    public SettingsDTO deleteSite(String site) {
        SettingsDTO s = getSettings();
        boolean removed = s.sites.remove(site);
        if (!removed) {
            throw new NotFoundException("site " + site + " did not exist.", 404);
        }
        saveSettings(s);
        return s;
    }

    public void resetSite(Site site) {

        ProjectPackageDTO pp = new ProjectPackageService().exportAll();
        GsonBuilder builder = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss.sssZ").setPrettyPrinting();

        byte[] content = builder.create().toJson(pp).getBytes(StandardCharsets.UTF_8);
        new BlobstoreService().uploadFile("backup/" + site + ".qpkg", content);

        ProjectService projectService = new ProjectService();
        projectService.deleteAllProjects();
        SelectionService selectionService = new SelectionService();
        selectionService.deleteAllSelection();
        CodeService codeService = new CodeService();
        codeService.deleteAllCodes();

        if (site.isJunitSite() && site.name().startsWith("demo")) {
            ProjectPackageService pkgService = new ProjectPackageService();
            Gson gson = new Gson();
            ProjectPackageDTO pkg = gson.fromJson(new InputStreamReader(
                            this.getClass().getResourceAsStream("/" + site + ".qpkg"), StandardCharsets.UTF_8),
                    ProjectPackageDTO.class);
            pkgService.importAll(pkg);
        }

        CacheUtil.clear();
    }

    public SettingsDTO addSubSite(String subsite) {
        return addSubSite(subsite, null);
    }

    public SettingsDTO addSubSite(String subsite, PreferencesDTO prefs) {
        subsite = subsite.toLowerCase();

        SettingsDTO s = getSettings();
        String site = NamespaceManager.get();

        List<String> subsites = s.subSites.computeIfAbsent(site, k -> new ArrayList<>());
        if (subsites.contains(subsite)) {
            throw new ValidationException(
                    Collections.singletonList("Your site " + site + " already contains subsite " + subsite));
        }
        subsites.add(subsite);

        auditService.insertAudit(new AuditDTO(
                "site",
                "insert subsite " + subsite));

        saveSettings(s);

        // pref
        PreferencesDTO pref = prefService.getPreference(false);
        pref.subSites.add(subsite);
        prefService.updatePreference(pref);

        NamespaceManager.set(site + "_" + subsite);
        try {
            pref = prefService.createDefaultPreference(prefs);

            // pref
            if (pref.design.event == null) {
                pref.design.event = subsite;
            }
            prefService.updatePreference(pref);
        } finally {
            NamespaceManager.set(site);
        }

        return s;
    }

    private SettingsDTO saveSettings(SettingsDTO settings) {
        String namespace = NamespaceManager.get();
        try {
            NamespaceManager.set(null);

            SettingsDTO s = dao.saveSettings(settings);
            CacheUtil.put(key, s);
            return s;
        } finally {
            NamespaceManager.set(namespace);
        }

    }

    public SettingsDTO getSettings() {

        String namespace = NamespaceManager.get();
        try {
            NamespaceManager.set(null);

            SettingsDTO s = (SettingsDTO) CacheUtil.get(key);
            if (s == null) {
                log.info("reading from database");
                s = dao.getSettings();
                CacheUtil.put(key, s);
            }

            return s;
        } finally {
            NamespaceManager.set(namespace);
        }
    }
}
