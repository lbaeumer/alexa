package de.quaestio24.service;

import com.google.appengine.api.NamespaceManager;
import de.quaestio24.dao.AuditDAO;
import de.quaestio24.dto.AuditDTO;
import de.quaestio24.dto.AuditsDTO;
import de.quaestio24.entity.Site;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.logging.Logger;

public class AuditService {
    private static final Logger log = Logger.getLogger(AuditService.class.getName());

    private final AuditDAO dao = new AuditDAO();

    public void insertAudit(AuditDTO a) {
        log.info("insert audit " + a);
        dao.insertAudit(a);
    }

    public List<AuditDTO> getAudits() {
        return dao.getAudits();
    }

    public AuditsDTO getLatestAudits() {
        AuditsDTO audits = new AuditsDTO();

        // sort audits by date
        Map<Date, Object[]> m = new TreeMap<>(((o1, o2) -> -o1.compareTo(o2)));
        for (Site site : Site.values()) {
            if (site.isBaseSite()) {
                NamespaceManager.set(site.name());
                getAudits().forEach(a ->
                        m.put(a.date, new Object[]{a, site.name(), a.user, a.role}));
            }
        }

        String lastSite = null;

        Calendar c = new GregorianCalendar();
        c.add(Calendar.DAY_OF_YEAR, -30);

        List<AuditDTO> list = null;
        for (Object[] entry : m.values()) {
            String role = (String) entry[3];
            String user = (String) entry[2];
            String site = (String) entry[1];
            AuditDTO a = (AuditDTO) entry[0];

            if (c.getTime().after(a.date)) {
                // audit entry older than 30 days
                break;
            }

            if (!(site + ":" + user + ":" + role).equals(lastSite)) {
                lastSite = (site + ":" + user + ":" + role);

                AuditsDTO.AuditSet set = new AuditsDTO.AuditSet();
                list = new ArrayList<>();
                set.audits = list;
                set.site = site;
                set.user = user;
                set.role = role;
                audits.auditSet.add(set);
            }

            list.add(a);
        }

        return audits;
    }
}
