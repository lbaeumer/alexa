package de.quaestio24.service;

import com.google.appengine.api.NamespaceManager;
import de.quaestio24.constant.SiteStateEnum;
import de.quaestio24.dto.ConfigDTO;
import de.quaestio24.util.CacheUtil;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Objects;
import java.util.logging.Logger;

public class ConfigService {

    public static final String key = "qu:config:";
    private static final Logger log = Logger.getLogger(ConfigService.class.getName());
    private PreferencesService pservice = new PreferencesService();

    public ConfigDTO getConfig(boolean replace) {
        log.info("getConfig(" + replace + ", " + NamespaceManager.get() + ")");

        ConfigDTO c = (ConfigDTO) CacheUtil.get(key + ":" + replace);
        if (c == null) {

            c = new ConfigDTO();
            c.pref = pservice.getPreference(replace);

            String namespace = NamespaceManager.get();
            if (c.pref.subSites != null && !c.pref.subSites.isEmpty()) {
                c.subConfig = new HashMap<>();
                try {
                    for (String sp : c.pref.subSites) {
                        ConfigDTO sc = new ConfigDTO();
                        NamespaceManager.set(namespace + "_" + sp);
                        sc.pref = pservice.getPreference(replace);
                        sc.site = namespace + "_" + sp;
                        c.subConfig.put(sp, sc);
                    }
                } finally {
                    NamespaceManager.set(namespace);
                }
            }
            c.site = namespace;
            CacheUtil.put(key + ":" + replace, c);
        }

        // set date
        if (c.subConfig != null && !c.subConfig.isEmpty()) {

            // now set the date of the base config
            Date start = null;
            Date end = null;
            for (ConfigDTO sc : c.subConfig.values()) {
                if (start == null || start.after(sc.pref.startDate)) {
                    start = sc.pref.startDate;
                }
                if (end == null || end.before(sc.pref.endDate)) {
                    end = sc.pref.endDate;
                }
            }
            c.pref.startDate = start;
            c.pref.endDate = end;
        }

        setState(c);
        if (c.subConfig != null && !c.subConfig.isEmpty()) {
            for (ConfigDTO sc : c.subConfig.values()) {
                setState(sc);
            }
        }

        return c;
    }

    private void setState(ConfigDTO c) {
        Date now = new Date();

        Calendar ago = new GregorianCalendar();
        ago.add(Calendar.YEAR, -2);
        Calendar future = new GregorianCalendar();
        future.add(Calendar.YEAR, 1);

        // start date a year ago
        if (c.pref.startDate != null && c.pref.startDate.after(now)) {
            c.state = SiteStateEnum.preElection;
        } else if (c.pref.startDate != null && c.pref.startDate.before(now) && c.pref.endDate != null
                && c.pref.endDate.after(now)
                && (now.getTime() - c.pref.startDate.getTime()) / 1000 / 60 / 60 / 24 < 30) {
            // no election is running for more than 30 days
            c.state = SiteStateEnum.election;
        } else if (c.pref.startDate2 != null && c.pref.endDate != null && c.pref.endDate.before(now)
                && c.pref.endDate2 != null && c.pref.endDate2.after(now)
                && (now.getTime() - c.pref.startDate2.getTime()) / 1000 / 60 / 60 / 24 < 30) {
            c.state = SiteStateEnum.election2;

        } else if (c.pref.startDate != null && c.pref.startDate.before(now) && c.pref.endDate != null
                && c.pref.startDate2 == null && c.pref.endDate.before(now)) {
            c.state = SiteStateEnum.postElection;
        } else if (c.pref.startDate != null && c.pref.startDate.before(now) && c.pref.startDate2 != null
                && Objects.requireNonNull(c.pref.endDate2).before(now)) {
            c.state = SiteStateEnum.postElection;
        } else {
            c.state = SiteStateEnum.undefined;
            log.info("State is undefined " + c);
        }
    }
}