package de.quaestio24.service;

import com.google.appengine.api.NamespaceManager;
import de.quaestio24.dto.CodeDTO;
import de.quaestio24.dto.ConfigDTO;
import de.quaestio24.dto.IssueDTO;
import de.quaestio24.dto.IssueDTO.Severity;
import de.quaestio24.dto.IssuesDTO;
import de.quaestio24.dto.ProjectDTO;
import de.quaestio24.dto.ValidationDTO;
import de.quaestio24.entity.Site;
import de.quaestio24.util.SystemConfig;
import org.apache.commons.collections4.map.HashedMap;

import javax.annotation.Nullable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import static de.quaestio24.dto.PreferencesDTO.StrategyEnum.fcfs;

public class IssueService {
    private static final Logger log = Logger.getLogger(IssueService.class.getName());
    private static Comparator<IssueDTO> COMPARE = (o1, o2) -> {
        int i = o2.severity.ordinal() - o1.severity.ordinal();
        if (i != 0) {
            return i;
        }

        return o1.message.compareTo(o2.message);
    };
    private ConfigService configService = new ConfigService();
    private ProjectService projectService = new ProjectService();
    private CodeService codeService = new CodeService();
    private SelectionService selectionService = new SelectionService();

    public IssuesDTO getAllIssues() {
        ConfigDTO config = configService.getConfig(true);

        IssuesDTO issues = new IssuesDTO();
        issues.maxSeverity = Severity.info;
        issues.issues = getConfigurationIssues(false, config, null);
        issues.issues.forEach(i -> {
            if (i.severity.ordinal() > issues.maxSeverity.ordinal())
                issues.maxSeverity = i.severity;
        });
        issues.count += issues.issues.size();

        if (Site.valueOf(config.site).isBaseSite()) {
            if (config.subConfig != null && config.subConfig.size() > 0) {
                issues.subIssues = new HashMap<>();
                for (Map.Entry<String, ConfigDTO> entry : config.subConfig.entrySet()) {
                    List<IssueDTO> is = getConfigurationIssues(false, entry.getValue(), config);
                    issues.subIssues.put(entry.getKey(), is);
                    is.forEach(i -> {
                        if (i.severity.ordinal() > issues.maxSeverity.ordinal())
                            issues.maxSeverity = i.severity;
                    });
                    issues.count += is.size();
                }
            }
        }

        return issues;
    }

    public List<IssueDTO> getConfigurationIssues(boolean allIssues) {
        log.info("getConfigurationIssues()");
        ConfigDTO config = configService.getConfig(true);
        return getConfigurationIssues(allIssues, config, null);
    }

    private List<IssueDTO> getConfigurationIssues(boolean allIssues, ConfigDTO config, ConfigDTO baseConfig) {
        log.info("getConfigurationIssues(" + config + ")");
        List<IssueDTO> list = new ArrayList<>();

        checkConfig(list, config, baseConfig);
        if (allIssues) {
            checkAuthentication(list, config);
        }
        String site = NamespaceManager.get();
        try {
            NamespaceManager.set(config.site);
            checkProjects(list, config);
        } finally {
            NamespaceManager.set(site);
        }

        list.sort(COMPARE);

        return list;
    }

    public List<IssueDTO> getAuthenticationIssues() {
        log.info("getAuthenticationIssues()");

        ConfigDTO config = configService.getConfig(true);
        List<IssueDTO> list = new ArrayList<>();
        if (Site.valueOf(config.site).isBaseSite()) {

            checkAuthentication(list, config);
        }

        return list;
    }

    private void checkAuthentication(List<IssueDTO> list, ConfigDTO config) {
        long now = System.currentTimeMillis();
        log.info("checkAuth(" + config.pref.auth + ")");

        // Auth enabled
        if (!config.pref.auth) {
            int days = (int) ((config.pref.startDate.getTime() - now) / (1000 * 60 * 60 * 24));
            if (config.pref.startDate.getTime() > now) {
                if (days < 5) {
                    list.add(new IssueDTO(Severity.error,
                            "Authentication disabled. Election will start in " + days + " days"));
                } else {
                    list.add(new IssueDTO(Severity.warning,
                            "Authentication disabled. Election will start in " + days + " days"));
                }
            }
        }
    }

    private void checkConfig(List<IssueDTO> list, ConfigDTO config, @Nullable ConfigDTO baseConfig) {
        final String adminUrl = SystemConfig.getProperties().getProperty("adminUrl");

        DateFormat df = new SimpleDateFormat("dd.MM.yyyy HH:mm");
        // Date
        Calendar c1 = new GregorianCalendar();
        c1.add(Calendar.MONTH, -4);
        Calendar c2 = new GregorianCalendar();
        c2.add(Calendar.YEAR, 2);

        // check start date defined
        boolean electionDefined = false;
        if (config.subConfig == null || config.subConfig.isEmpty()) {
            // check start date is defined
            if (config.pref.startDate.before(c1.getTime()) || config.pref.startDate.after(c2.getTime())) {
                electionDefined = true;
                IssueDTO issue = new IssueDTO(Severity.error, "Der Beginn der Wahl ist nicht korrekt");
                issue.description = "Der aktuell konfigurierte Wahlbeginn (" + df.format(config.pref.startDate)
                        + ") ist nicht korrekt. Bitte konfigurieren Sie den Start <a href=\"" + adminUrl + "/"
                        + config.site + "/admin#startdate\">hier</a>.";
                list.add(issue);
            }

            // check end date defined
            if (config.pref.endDate.before(c1.getTime()) || config.pref.endDate.after(c2.getTime())) {
                electionDefined = true;
                IssueDTO issue = new IssueDTO(Severity.error, "Das Ende der Wahl ist nicht korrekt");
                issue.description = "Das aktuell konfigurierte Wahlende (" + df.format(config.pref.endDate)
                        + ") ist nicht korrekt. Bitte konfigurieren Sie das Wahlende <a href=\"" + adminUrl + "/"
                        + config.site + "/admin#enddate\">hier</a>.";
                list.add(issue);
            }

            // check end date after start date
            if (config.pref.endDate.before(config.pref.startDate)) {
                IssueDTO issue = new IssueDTO(Severity.error, "Das Ende der Wahl liegt vor dem Start");
                issue.description = "Das aktuell konfigurierte Wahlfenster (" + df.format(config.pref.startDate) + " - "
                        + df.format(config.pref.endDate)
                        + ") ist nicht korrekt. Bitte konfigurieren Sie den Wahlzeitraum <a href=\"" + adminUrl + "/"
                        + config.site + "/admin#startdate\">hier</a>.";
                list.add(issue);
            }

            // check election length, > 14d or < 4d
            int len = (int) ((config.pref.endDate.getTime() - config.pref.startDate.getTime()) / 1000 / 60 / 60 / 24);
            if (config.pref.endDate.after(config.pref.startDate) && len > 14 && !electionDefined) {
                IssueDTO issue = new IssueDTO(Severity.info, "Die Wahl sollte nicht länger als 14 Tage dauern.");
                issue.description = "Das aktuell konfigurierte Wahlfenster (" + df.format(config.pref.startDate) + " - "
                        + df.format(config.pref.endDate) + ") ist " + len
                        + " Tage lang. Empfohlen ist eine maximale Länge von 14 Tagen. Sie können den Wahlzeitraum <a href=\""
                        + adminUrl + "/" + config.site + "/admin#startdate\">hier</a> anpassen.";
                list.add(issue);
            }
            if (config.pref.endDate.after(config.pref.startDate) && len < 4 && !electionDefined) {
                IssueDTO issue = new IssueDTO(Severity.info, "Die Wahl sollte nicht kürzer als 4 Tage sein.");
                issue.description = "Das aktuell konfigurierte Wahlfenster (" + df.format(config.pref.startDate) + " - "
                        + df.format(config.pref.endDate) + ") ist nur " + len
                        + " Tage lang. Empfohlen ist eine minimale Länge von 5 Tagen. Sie können den Wahlzeitraum <a href=\""
                        + adminUrl + "/" + config.site + "/admin#startdate\">hier</a> anpassen.";
                list.add(issue);
            }

            // validate post election

            // only start2 date defined
            if (config.pref.startDate2 != null && config.pref.endDate2 == null) {
                IssueDTO issue = new IssueDTO(Severity.error, "Die Nachwahl hat kein Enddatum.");
                issue.description = "Sie haben eine Nachwahl angelegt. Diese beginnt am (" + df.format(config.pref.startDate2)
                        + ") hat aber kein Ende. Bitte konfigurieren Sie das Ende der Nachwahl <a href=\"" + adminUrl + "/"
                        + config.site + "/admin#enddate2\">hier</a>.";
                list.add(issue);
            }

            // only end2 date defined
            if (config.pref.endDate2 != null && config.pref.startDate2 == null) {
                IssueDTO issue = new IssueDTO(Severity.error, "Die Nachwahl hat kein Startdatum.");
                issue.description = "Sie haben eine Nachwahl angelegt. Diese endet am (" + df.format(config.pref.endDate2)
                        + ") hat aber keinen Beginn. Bitte konfigurieren Sie den Beginn der Nachwahl <a href=\"" + adminUrl + "/"
                        + config.site + "/admin#startdate2\">hier</a>.";
                list.add(issue);
            }

            if (config.pref.startDate2 != null && config.pref.endDate2 != null) {
                // check start date2 is defined
                if (config.pref.startDate2.before(c1.getTime()) || config.pref.startDate2.after(c2.getTime())) {
                    IssueDTO issue = new IssueDTO(Severity.error, "Der Beginn der Nachwahl ist nicht korrekt");
                    issue.description = "Der aktuell konfigurierte Nachwahlbeginn (" + df.format(config.pref.startDate2)
                            + ") ist nicht korrekt. Bitte konfigurieren Sie den Start <a href=\"" + adminUrl + "/"
                            + config.site + "/admin#startdate2\">hier</a>.";
                    list.add(issue);
                }

                // check end date2 defined
                if (config.pref.endDate2.before(c1.getTime()) || config.pref.endDate2.after(c2.getTime())) {
                    IssueDTO issue = new IssueDTO(Severity.error, "Das Ende der Nachwahl ist nicht korrekt");
                    issue.description = "Das aktuell konfigurierte Nachwahlende (" + df.format(config.pref.endDate2)
                            + ") ist nicht korrekt. Bitte konfigurieren Sie das Nachwahlende <a href=\"" + adminUrl + "/"
                            + config.site + "/admin#enddate2\">hier</a>.";
                    list.add(issue);
                }

                // check end date2 after start2 date
                if (config.pref.endDate2.before(config.pref.startDate2)) {
                    IssueDTO issue = new IssueDTO(Severity.error, "Das Ende der Nachwahl liegt vor dem Start");
                    issue.description = "Das aktuell konfigurierte Nachwahlfenster (" + df.format(config.pref.startDate2) + " - "
                            + df.format(config.pref.endDate2)
                            + ") ist nicht korrekt. Bitte konfigurieren Sie den Nachwahlzeitraum <a href=\"" + adminUrl + "/"
                            + config.site + "/admin#startdate2\">hier</a>.";
                    list.add(issue);
                }

                // check end date2 after start2 date
                if (config.pref.startDate2.before(config.pref.endDate)) {
                    IssueDTO issue = new IssueDTO(Severity.error, "Die Nachwahl liegt vor der Hauptwahl");
                    issue.description = "Das aktuell konfigurierte Nachwahlfenster (" + df.format(config.pref.startDate2) + " - "
                            + df.format(config.pref.endDate2)
                            + ") liegt vor der Hauptwahl, die am " + df.format(config.pref.endDate)
                            + " endet. Bitte konfigurieren Sie den Nachwahlzeitraum <a href=\"" + adminUrl + "/"
                            + config.site + "/admin#startdate2\">hier</a>.";
                    list.add(issue);
                }

                // check election length, > 7
                len = (int) ((config.pref.endDate2.getTime() - config.pref.startDate2.getTime()) / 1000 / 60 / 60 / 24);
                if (config.pref.endDate2.after(config.pref.startDate2) && len > 7) {
                    IssueDTO issue = new IssueDTO(Severity.info, "Die Nachwahl sollte nicht länger als 14 Tage dauern.");
                    issue.description = "Das aktuell konfigurierte Nachwahlfenster (" + df.format(config.pref.startDate2) + " - "
                            + df.format(config.pref.endDate2) + ") ist " + len
                            + " Tage lang. Empfohlen ist eine maximale Länge von 7 Tagen. Sie können den Nachwahlzeitraum <a href=\""
                            + adminUrl + "/" + config.site + "/admin#startdate2\">hier</a> anpassen.";
                    list.add(issue);
                }
            }
        }

        // min minSelections
        if (config.pref.parameter.strategy != fcfs
                && config.pref.design.minSelections < 5) {

            IssueDTO issue = new IssueDTO(
                    (config.pref.design.minSelections < 3 ? Severity.error : (
                            config.pref.design.minSelections < 4 ? Severity.warning : Severity.info
                    )), "Es sollten mindestes 3 Projekte gewählt werden. Eine Mindestanzahl von 5 ist noch besser.");
            issue.description = "Aktuell müssen die Schüler nur " + config.pref.design.minSelections
                    + " Projekte wählen. Empfohlen wird eine Anzahl von 5. Sie können die min. Anzahl Wahlen <a href=\""
                    + adminUrl + "/" + config.site + "/admin#minSelections\">hier</a> anpassen.";
            list.add(issue);
        }

        // email
        if (Site.valueOf(config.site).isBaseSite()) {
            if (config.pref.emailcc == null || config.pref.emailcc.length() == 0) {
                IssueDTO issue = new IssueDTO(Severity.info, "Sie haben keine Email angegeben.");
                issue.description = "Sie können Ihre Email eintragen, um automatisierte Info-Mails sowie das Schülerfeedback zu erhalten. Sie können die Email <a href=\""
                        + adminUrl + "/" + config.site
                        + "/admin#email\">hier</a> konfigurieren. Die Angabe ist optional.";
                list.add(issue);
            }
        }

        // check start, end date in sync
        if (baseConfig != null) {
            Date startDate1 = config.pref.startDate;
            Date endDate1 = config.pref.endDate;
            String event1 = config.pref.design.event;

            for (Map.Entry<String, ConfigDTO> subConfigEntry : baseConfig.subConfig.entrySet()) {
                if (subConfigEntry.getKey().equals(config.site)) {
                    continue;
                }
                String event2 = subConfigEntry.getValue().pref.design.event;
                Date startDate2 = subConfigEntry.getValue().pref.startDate;
                Date endDate2 = subConfigEntry.getValue().pref.endDate;

                if ((!startDate1.equals(startDate2) || !endDate1.equals(endDate2))
                        && event1.compareToIgnoreCase(event2) < 0) {
                    IssueDTO issue = new IssueDTO(Severity.info,
                            "Die einzelnen Tage haben unterschiedliche Wahlzeiträume.");
                    issue.description = "Der Wahlzeiträume stimmen nicht überein:" + "<ul>" + "<li>\"" + event1 + "\" ("
                            + df.format(startDate1) + " - " + df.format(endDate1) + ")" + "<li>\"" + event2 + "\" ("
                            + df.format(startDate2) + " - " + df.format(endDate2) + ")" + "</ul>"
                            + "Da das vermutlich nicht beabsichtigt ist, können Sie die Wahlzeiträume für "
                            + "<a href=\"" + adminUrl + "/" + config.site + "/admin#startdate\">\"" + event1
                            + "\"</a> bzw. " + "<a href=\"" + adminUrl + "/" + subConfigEntry.getValue().site
                            + "/admin#startdate\">\"" + event2 + "\"</a> anpassen.";
                    list.add(issue);
                }
            }
        }
    }

    private void checkProjects(List<IssueDTO> list, ConfigDTO config) {

        if (config.pref.subSites != null && config.pref.subSites.size() > 0) {
            // do not check if project has subprojects
            return;
        }

        final String adminUrl = ""; // SystemConfig.getProperties().getProperty("adminUrl");

        List<ProjectDTO> projects = projectService.getProjects();
        int maxCapacity = 0;
        Map<Integer, Integer> capacityByProject = new HashedMap<>();
        for (ProjectDTO p : projects) {
            maxCapacity += p.maxSize;
            capacityByProject.put(p.id, p.maxSize);
        }

        // more than 5 projects have a min capacity
        int minCapacity = 0;
        for (ProjectDTO p : projects) {
            if (p.minSize > 0) {
                minCapacity++;
            }
        }

        if (minCapacity > 5) {
            IssueDTO issue = new IssueDTO(Severity.warning,
                    "Insgesamt " + minCapacity + "/" + projects.size() + " haben eine minimale Projektgröße.");
            issue.description = "Zuviele Projekt mit einer minimalen Projektgröße können sich nachteilig auf den berechneten Plan auswirken. Sie können die Projekte hier <a href=\""
                    + adminUrl + "/" + config.site + "/projects\">konfigurieren</a>.";
            list.add(issue);
        }

        // check projects
        if (projects.isEmpty()) {
            IssueDTO issue = new IssueDTO(Severity.error, "Es wurden noch keine Projekte eingegeben.");
            issue.description = "Bitte legen Sie die Projekte <a href=\"" + adminUrl + "/" + config.site
                    + "/projects\">hier</a> an.";
            list.add(issue);
        } else if (projects.size() < 4) {
            IssueDTO issue = new IssueDTO(Severity.error,
                    "Es wurden erst " + projects.size() + " Projekte eingegeben.");
            issue.description = "Bitte legen Sie die Projekte <a href=\"" + adminUrl + "/" + config.site
                    + "/projects\">hier</a> an.";
            list.add(issue);
        }

        // check codes globally
        boolean anonymous = config.pref.anonymous;
        List<CodeDTO> codes = null;
        if (anonymous) {
            codes = codeService.getCodes();
            if (codes.size() == 0) {
                IssueDTO issue = new IssueDTO(Severity.error, "Es wurden noch keine Codes hochgeladen.");
                issue.description = "Da die Schüler sich anonym anmelden, müssen vor der Wahl Codes erstellt werden und an die Schüler verteilt werden."
                        + " Um Ihnen die Erstellung der Codes zu erleichtern, können Sie sich ein <a href=\"http://quaestio24.de/downloads/code_berechnen.xlsx\">vorbereitetes Excel Sheet</a> herunterladen und die Schüler eintragen."
                        + " Die Codes werden automatisch berechnet und können im Anschluss von mir importiert werden.";
                list.add(issue);
            } else if (codes.size() > maxCapacity) {
                IssueDTO issue = new IssueDTO(Severity.error,
                        "Die gesamte Projektkapazität beträgt nur " + maxCapacity + " Plätze.");
                issue.description = "Es wurden " + codes.size()
                        + " codes importiert. Damit alle Schüler zugeordnet werden können, müssen entweder weitere Projekte eingegeben werden oder die Projektkapazitäten je Projekt erhöht werden. Bitte legen Sie die Projekte <a href=\""
                        + adminUrl + "/" + config.site + "/projects\">hier</a> an.";
                list.add(issue);
            } else if (codes.size() > (int) (maxCapacity * 1.2)) {
                IssueDTO issue = new IssueDTO(Severity.warning,
                        "Die gesamte Projektkapazität beträgt nur " + maxCapacity + " Plätze.");
                issue.description = "Es wurden aber " + codes.size()
                        + " codes importiert. Es wird empfohlen mind. 20% Projektkapazität zu konfigurieren. Sie können noch weitere Projekte einzugeben oder die Projektkapazität zu erhöhen. Andernfalls ist die Wahrscheinlichkeit sehr hoch, dass nicht alle Schüler zugeordnet werden können. Bitte legen Sie die Projekte <a href=\""
                        + adminUrl + "/" + config.site + "/projects\">hier</a> an.";
                list.add(issue);
            }
        }

        // check codes per class
        if (anonymous && false) {
            Map<String, Integer> projectsByClass = new HashedMap<>();
            Map<String, Integer> codesByClass = new HashedMap<>();
            for (CodeDTO code : codes) {
                Integer cnt = codesByClass.get(code.clazz);
                cnt = (cnt == null ? 1 : cnt + 1);
                codesByClass.put(code.clazz, cnt);

                ValidationDTO valid = selectionService.isCodeValid(code.code);
                cnt = projectsByClass.get(code.clazz);
                if (cnt == null) {
                    cnt = 0;
                    for (int i : valid.filteredProjects) {
                        cnt += capacityByProject.get(i);
                    }
                    projectsByClass.put(code.clazz, cnt);
                }
            }
            if (!projectsByClass.keySet().equals(codesByClass.keySet())) {
                IssueDTO issue = new IssueDTO(Severity.error, "Die Klassen sind inkonsistent");
                issue.description = projectsByClass.keySet() + " != " + codesByClass.keySet();
                list.add(issue);
            } else {
                for (String clazz : projectsByClass.keySet()) {
                    if (projectsByClass.get(clazz) * 100 / codesByClass.get(clazz) < 100) {
                        IssueDTO issue = new IssueDTO(Severity.error,
                                "Die Klasse " + clazz + " hat " + codesByClass.get(clazz)
                                        + " Schüler, aber nur eine Kapazität von " + projectsByClass.get(clazz));
                        issue.description = "Bitte passen Sie die Kapazität an!!!";
                        list.add(issue);
                    } else if (projectsByClass.get(clazz) * 100 / codesByClass.get(clazz) < 120) {
                        IssueDTO issue = new IssueDTO(Severity.error,
                                "Die Klasse " + clazz + " hat " + codesByClass.get(clazz)
                                        + " Schüler, aber nur eine Kapazität von " + projectsByClass.get(clazz));
                        issue.description = "Bitte passen Sie die Kapazität an.";
                        list.add(issue);
                    }
                }
            }

        }
    }
}
