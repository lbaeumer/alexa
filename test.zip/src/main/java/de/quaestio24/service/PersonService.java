package de.quaestio24.service;

import de.quaestio24.dao.CodeDAO;
import de.quaestio24.dto.AuditDTO;
import de.quaestio24.dto.PersonDTO;
import de.quaestio24.util.CacheUtil;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.poifs.filesystem.OfficeXmlFileException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class PersonService {
    private static final Logger log = Logger.getLogger(PersonService.class.getName());

    private CodeDAO dao = new CodeDAO();
    private AuditService auditService = new AuditService();

    public int insertPersons(List<PersonDTO> persons) {

        if (persons == null) {
            log.info("insertPersons(null)");
            return 0;
        }
        log.info("insertPersons(" + persons.size() + ")");
        String key = "persons";

        auditService.insertAudit(new AuditDTO(
                "person",
                "insert " + persons.size() + " persons"));

        int nb = dao.insertPersons(persons);

        CacheUtil.remove(key);

        return nb;
    }

    @SuppressWarnings("unchecked")
    public List<PersonDTO> getPersons() {
        List<PersonDTO> l = (List<PersonDTO>) CacheUtil.get("persons");
        if (l == null) {
            l = dao.getPersons();
            CacheUtil.put("persons", l);
        } else {
            log.info("reading from cache #persons()=" + l.size());
        }

        return l;
    }

    public List<PersonDTO> parsePersonCSV(InputStream imgStream) {

        List<PersonDTO> sel = new ArrayList<>();

        try (CSVParser parser = new CSVParser(new InputStreamReader(imgStream, StandardCharsets.UTF_8), CSVFormat.EXCEL)) {
            List<CSVRecord> selections = parser.getRecords();

            int row = 0;
            for (CSVRecord record : selections) {
                row++;

                int i = 0;

                PersonDTO c = new PersonDTO();
                c.name = record.get(i++);
                c.surname = record.get(i++);
                c.clazz = record.get(i);

                sel.add(c);
            }

            log.info("read " + row + " names");
        } catch (Exception e) {
            e.printStackTrace();
        }

        return sel;
    }

    public List<PersonDTO> parsePersonXLS(byte[] imgStream) throws IOException {

        List<PersonDTO> ret = new ArrayList<>();

        Workbook wb;
        try {
            wb = new HSSFWorkbook(new ByteArrayInputStream(imgStream));
        } catch (OfficeXmlFileException e) {
            OPCPackage pkg;
            try {
                pkg = OPCPackage.open(new ByteArrayInputStream(imgStream));
                wb = new XSSFWorkbook(pkg);
            } catch (InvalidFormatException e1) {
                throw new IOException(e1);
            }
        }

        try {
            Sheet s0 = wb.getSheetAt(0);

            log.info("found rows=" + s0.getLastRowNum());
            for (int ri = 0; ri <= s0.getLastRowNum(); ri++) {
                Row r = s0.getRow(ri);
                log.fine("read row " + ri);

                if (r == null || r.getCell(0) == null) {
                    continue;
                }

                PersonDTO c = new PersonDTO();
                c.name = r.getCell(0).getStringCellValue();
                c.surname = r.getCell(1).getStringCellValue();
                c.clazz = r.getCell(2).getStringCellValue();

                ret.add(c);
            }
        } finally {
            wb.close();
        }

        return ret;
    }
}
