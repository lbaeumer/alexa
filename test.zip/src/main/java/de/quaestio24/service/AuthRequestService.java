package de.quaestio24.service;

import com.google.appengine.api.NamespaceManager;
import de.quaestio24.constant.RoleEnum;
import de.quaestio24.dao.AuthRequestDAO;
import de.quaestio24.dto.AuditDTO;
import de.quaestio24.dto.AuthDTO;
import de.quaestio24.dto.AuthRequestDTO;
import de.quaestio24.util.SendMail;
import de.quaestio24.util.SystemConfig;

import java.util.List;
import java.util.logging.Logger;

public class AuthRequestService {
    private static final Logger log = Logger.getLogger(AuthRequestService.class.getName());

    private AuthRequestDAO dao = new AuthRequestDAO();
    private AuditService auditService = new AuditService();
    private AuthService authService = new AuthService();

    public boolean insertAuthRequest(AuthRequestDTO request) {
        log.info("insertAuthRequest(" + request + ")");

        String namespace = NamespaceManager.get();
        String base = null;
        if (namespace != null && namespace.indexOf("_") > 0) {
            base = namespace.substring(0, namespace.indexOf("_"));
            NamespaceManager.set(base);
        }

        try {
            auditService.insertAudit(new AuditDTO(
                    "authrequest",
                    "insert auth " + request.email));

            return dao.insertAuthRequest(request);
        } finally {
            if (base != null) {
                NamespaceManager.set(namespace);
            }
        }
    }

    public List<AuthRequestDTO> deleteAuthRequest(AuthRequestDTO request) {
        log.info("deleteAuthRequest(" + request + ")");
        String namespace = NamespaceManager.get();
        String base = null;
        if (namespace != null && namespace.indexOf("_") > 0) {
            base = namespace.substring(0, namespace.indexOf("_"));
            NamespaceManager.set(base);
        }

        List<AuthRequestDTO> l;
        try {
            l = dao.deleteAuthRequest(request);
        } finally {
            if (base != null) {
                NamespaceManager.set(namespace);
            }
        }

        return l;
    }

    public List<AuthRequestDTO> grantAuthRequest(AuthRequestDTO request, RoleEnum role) {
        log.info("grantAuthRequest(" + request + ", " + role + ")");

        AuthDTO auth = new AuthDTO();
        auth.email = request.email;
        auth.provider = request.provider;
        auth.role = role;
        authService.insertAuth(auth);

        List<AuthRequestDTO> l = deleteAuthRequest(request);
        log.info("l=" + l);

        String adminUrl = SystemConfig.getProperties().getProperty("adminUrl");

        auditService.insertAudit(new AuditDTO(
                "authrequest",
                "grant role " + role.name() + " to " + request.email));

        new SendMail().send("Quaestio Berechtigung",
                "Hallo " + request.email + ",<br/><br/>"
                        + "Sie wurden für den Admin Zugang berechtigt:<br/><br/>"
                        + "<a href=\"" + adminUrl + "/" + NamespaceManager.get() + "\">"
                        + adminUrl + "/" + NamespaceManager.get() + "</a><br/><br/>" +
                        "Viele Grüße,<br/><br/>" +
                        "das Quaestio24 Team.<br/><br/>", null, "lui.baeumer@gmail.com", null, true);

        return l;
    }

    public List<AuthRequestDTO> getAuthRequests() {
        log.info("getAuthRequests()");

        String namespace = NamespaceManager.get();
        String base = null;
        if (namespace != null && namespace.indexOf("_") > 0) {
            base = namespace.substring(0, namespace.indexOf("_"));
            NamespaceManager.set(base);
        }

        List<AuthRequestDTO> l;
        try {
            l = dao.getAuthRequests();
        } finally {
            if (base != null) {
                NamespaceManager.set(namespace);
            }
        }

        return l;
    }
}
