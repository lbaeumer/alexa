package de.quaestio24.service;

import com.google.appengine.api.NamespaceManager;
import de.quaestio24.dto.AuditDTO;
import de.quaestio24.dto.CodeDTO;
import de.quaestio24.dto.PersonDTO;
import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.dto.PreferencesDTO.DependencyDTO;
import de.quaestio24.dto.PreferencesDTO.Parameter;
import de.quaestio24.dto.ProjectDTO;
import de.quaestio24.dto.ReportDTO;
import de.quaestio24.dto.ReportDTO.SubReport;
import de.quaestio24.dto.SelectionDTO;
import de.quaestio24.dto.UnassignedPersonDTO;
import de.quaestio24.service.dto.AssignedProjectListIntDTO;
import de.quaestio24.service.dto.EvaluationResultDTO;
import de.quaestio24.service.strategy.AssignmentStrategy;
import de.quaestio24.service.strategy.BestAssignmentStrategy;
import de.quaestio24.service.strategy.FirstComeFirstServeAssignmentStrategy;
import de.quaestio24.service.strategy.GreedyAssignmentStrategy;
import de.quaestio24.service.strategy.MultipleAssignmentStrategy;
import org.apache.commons.text.similarity.LevenshteinDistance;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Header;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.logging.Logger;

import static de.quaestio24.dto.PreferencesDTO.StrategyEnum.best;
import static de.quaestio24.dto.PreferencesDTO.StrategyEnum.fcfs;

public class ReportingService {
    private static final Logger log = Logger.getLogger(ReportingService.class.getName());

    private ProjectService projectService = new ProjectService();
    private SelectionService selectionService = new SelectionService();
    private PreferencesService preferenceService = new PreferencesService();
    private AuditService auditService = new AuditService();
    private CodeService codeService = new CodeService();
    private PersonService personService = new PersonService();

    public AssignedProjectListIntDTO getAssignedProjects(Parameter parameter) {

        PreferencesDTO preferences = preferenceService.getPreference();

        Set<PersonDTO> personsToBeDeleted = new HashSet<>();
        String prj = NamespaceManager.get();
        log.info("prj=" + prj);

        DependencyDTO dependency = preferences.parameter.dependency;
        if (dependency != null) {
            log.info("switch to predecessor project " + dependency.predecessor + "; projects="
                    + dependency.predecessorProjects);
            if (dependency.predecessor == null || dependency.predecessorProjects == null) {
                throw new IllegalStateException("Detected a configuration problem. Values must be set.");
            }
            NamespaceManager.set(dependency.predecessor);
            AssignedProjectListIntDTO day1 = getAssignedProjects(parameter);

            log.info("switch back " + prj);
            NamespaceManager.set(prj);

            Map<ProjectDTO, List<PersonDTO>> assigned = day1.assignedPersons;

            // remove all persons that are assigned
            for (Map.Entry<ProjectDTO, List<PersonDTO>> entry : assigned.entrySet()) {
                if (dependency.predecessorProjects.contains(entry.getKey().id)) {
                    personsToBeDeleted.addAll(entry.getValue());
                }
            }

            log.info("delete persons=" + personsToBeDeleted);
        }

        log.info("getAssignedProjects(" + parameter + ")");
        if (parameter == null) {
            parameter = preferences.parameter;
            log.info("reading default parameter " + parameter);
        }

        log.info("read from database");
        int maxCapacity = 0;
        List<ProjectDTO> projects = projectService.getProjects();
        Map<Integer, ProjectDTO> projectById = new HashMap<>();
        for (ProjectDTO p : projects) {
            projectById.put(p.id, p);
            maxCapacity += p.maxSize;
        }

        List<SelectionDTO> selections = selectionService.getAllSelection();
        if (!personsToBeDeleted.isEmpty()) {
            List<SelectionDTO> selections2 = new ArrayList<>();
            for (SelectionDTO s : selections) {
                if (!personsToBeDeleted.contains(s.person)) {
                    log.fine("add selection " + s);
                    selections2.add(s);
                } else {
                    log.info("remove selection " + s);
                }
            }
            selections = selections2;
        }
        log.info("found #projects=" + projects.size() + "; #selections=" + selections.size());

        // remove projects
        removeProjectsFromSelections(projectById.keySet(), selections);

        if (maxCapacity > 0) {
            log.info("fillratio=" + (selections.size() * 100 / maxCapacity) + "%" + "; avg. project site="
                    + (maxCapacity / projects.size()));
        }

        List<Date> dates = new ArrayList<>();
        if (preferences.endDate != null) {
            dates.add(preferences.endDate);
        }
        if (preferences.endDate2 != null) {
            dates.add(preferences.endDate2);
        }

        AssignmentStrategy strategy;
        if (preferences.parameter.strategy == null) {
            preferences.parameter.strategy = best;
        }
        switch (preferences.parameter.strategy) {
            case fcfs: {
                strategy = new FirstComeFirstServeAssignmentStrategy(preferences);
                break;
            }
            case greedy: {
                strategy = new GreedyAssignmentStrategy(preferences);
                break;
            }
            case multiple: {
                strategy = new MultipleAssignmentStrategy(preferences);
                break;
            }
            default: {
                strategy = new BestAssignmentStrategy(preferences);
            }
        }

        // calculate assignment
        List<CodeDTO> codes = codeService.getCodes();
        EvaluationResultDTO eval = strategy.calculateAssignment(projectById, selections, codes, dates);

        // sort persons
        if (preferences.parameter.strategy != fcfs) {
            eval.assignedPersons.forEach((p, l) -> Collections.sort(l));
        }

        // delete persons if only 2nd shall be shown
        String only2nd = parameter != null ? "" + parameter.only2nd : "false";
        if (Boolean.parseBoolean(only2nd)) {
            Date end = dates.get(0);
            log.info("remove 1st voters younger than " + end);
            Set<PersonDTO> personsToDelete = new HashSet<>();
            // exclude all persons with created <= end
            for (SelectionDTO s : selections) {
                if (!s.created.after(end)) {
                    log.info("dlete " + s.created);
                    personsToDelete.add(s.person);
                }
            }
            log.info(personsToDelete.size() + " persons to delete younger than " + end);

            int deleted = 0;
            for (ListIterator<PersonDTO> it = eval.unassignedPersons.listIterator(); it.hasNext(); ) {
                PersonDTO p = it.next();
                if (personsToDelete.contains(p)) {
                    it.remove();
                    deleted++;
                }
            }

            for (Map.Entry<ProjectDTO, List<PersonDTO>> entry : eval.assignedPersons.entrySet()) {
                for (ListIterator<PersonDTO> it = entry.getValue().listIterator(); it.hasNext(); ) {
                    PersonDTO p = it.next();
                    if (personsToDelete.contains(p)) {
                        it.remove();
                        deleted++;
                    }
                }
            }

            log.info("deleted " + deleted + " persons");
        }

        // remove empty projects from result
        String ignoreEmptyProjects = parameter != null ? "" + parameter.ignoreEmptyProjects : "false";
        if (Boolean.parseBoolean(ignoreEmptyProjects)) {
            List<ProjectDTO> emptyProjects = new ArrayList<>();
            for (Map.Entry<ProjectDTO, List<PersonDTO>> entry : eval.assignedPersons.entrySet()) {
                if (entry.getValue() == null || entry.getValue().isEmpty()) {
                    emptyProjects.add(entry.getKey());
                }
            }
            for (ProjectDTO p : emptyProjects) {
                eval.assignedPersons.remove(p);
            }
        }

        Map<PersonDTO, List<Integer>> selectionsByPerson = new HashMap<>();
        for (SelectionDTO s : selections) {
            selectionsByPerson.put(s.person, s.selections);
        }

        AssignedProjectListIntDTO ret = new AssignedProjectListIntDTO();
        ret.selections = selections;
        ret.assignedPersons = eval.assignedPersons;
        ret.personsToBeDeleted = personsToBeDeleted;
        ret.unassignedPersons = new ArrayList<>();
        for (PersonDTO p : eval.unassignedPersons) {
            UnassignedPersonDTO unassignedPerson = new UnassignedPersonDTO(p);
            unassignedPerson.selections = selectionsByPerson.get(p);
            ret.unassignedPersons.add(unassignedPerson);
        }

        // fill other fields
        ret.posByPerson = getPosByPerson(ret, selections);

        ret.countByPos = getCountByPos(ret.posByPerson);

        ret.countByProject = getCountByProject(selections, projectById);

        log.info("writing the orig datastructure to cache");

        return ret;
    }

    private void removeProjectsFromSelections(Set<Integer> projectIds, List<SelectionDTO> selections) {
        for (SelectionDTO s : selections) {
            ListIterator<Integer> it = s.selections.listIterator();
            while (it.hasNext()) {
                Integer i = it.next();
                if (!projectIds.contains(i)) {
                    log.info("project " + i + " does not exist any more");
                    it.remove();
                }
            }
        }
    }

    private Map<String, Integer> getCountByProject(List<SelectionDTO> selections,
                                                   Map<Integer, ProjectDTO> projectById) {
        Map<String, Integer> map = new TreeMap<>();
        for (SelectionDTO e : selections) {
            List<Integer> sel = e.selections;
            if (sel.size() > 0) {
                ProjectDTO proj = projectById.get(sel.get(0));
                if (proj != null) {
                    map.merge(proj.title, 1, Integer::sum);
                } else {
                    log.warning("project " + sel.get(0) + " does not exist.");
                }
            } else {
                log.warning("no selections in " + e);
            }
        }

        return sort(map);
    }

    Map<String, Integer> sort(Map<String, Integer> map) {
        DecimalFormat f = new DecimalFormat("000000");

        List<String> l = new ArrayList<>();
        for (Entry<String, Integer> e : map.entrySet()) {
            l.add(f.format(e.getValue()) + "-" + e.getKey());
        }
        Collections.sort(l);
        Collections.reverse(l);

        Map<String, Integer> mp = new LinkedHashMap<>();
        for (String s : l) {
            mp.put(s.substring(7), Integer.parseInt(s.substring(0, 6)));
        }

        return mp;
    }

    private Map<PersonDTO, Integer> getPosByPerson(AssignedProjectListIntDTO dto, List<SelectionDTO> selections) {

        Map<PersonDTO, List<Integer>> map = new HashMap<>();
        for (SelectionDTO s : selections) {
            PersonDTO person = s.person;
            map.put(person, s.selections);
        }

        Map<PersonDTO, Integer> posByPerson = new HashMap<>();

        Map<ProjectDTO, List<PersonDTO>> assigned = dto.assignedPersons;
        for (ProjectDTO p : assigned.keySet()) {
            for (PersonDTO person : assigned.get(p)) {
                List<Integer> sels = map.get(person);
                if (sels == null) {
                    log.warning("did not find selections for " + person);
                    posByPerson.put(person, 0);
                } else {
                    int pos;
                    for (pos = 0; pos < sels.size(); pos++) {
                        // log.info("p " + sels.get(pos).sortid);
                        if (p.id == sels.get(pos)) {
                            break;
                        }
                    }
                    log.fine("Person " + person + " at pos " + pos);
                    posByPerson.put(person, pos + 1);
                }
            }
        }

        return posByPerson;
    }

    private Map<Integer, Integer> getCountByPos(Map<PersonDTO, Integer> posByPerson) {
        Map<Integer, Integer> countByPos = new TreeMap<>();
        for (Map.Entry<PersonDTO, Integer> e : posByPerson.entrySet()) {
            Integer pos = e.getValue();
            countByPos.merge(pos, 1, Integer::sum);
        }
        return countByPos;
    }

    public byte[] getAssignedReportXLS(Parameter parameters) {

        log.info("getAssignedReport()");
        AssignedProjectListIntDTO retdto = getAssignedProjects(parameters);

        PreferencesDTO pref = preferenceService.getPreference();
        boolean anonymous = pref.anonymous;

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (Workbook wb = new HSSFWorkbook(getClass().getResourceAsStream("/assigned-template.xls"))) {
            Sheet sheet1 = wb.getSheetAt(1);
            Sheet sheet2 = wb.getSheetAt(2);
            Sheet sheet3 = wb.getSheetAt(3);
            log.info("sheet1=" + sheet1 + "; " + sheet2 + ";" + sheet3);

            Font titleFont = wb.createFont();
            titleFont.setBold(true);
            titleFont.setFontHeight((short) (titleFont.getFontHeight() * 1.2));

            CellStyle titleStyle = wb.createCellStyle();
            titleStyle.setFont(titleFont);
            titleStyle.setVerticalAlignment(VerticalAlignment.CENTER);
            titleStyle.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
            titleStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            titleStyle.setWrapText(true);
            titleStyle.setBorderBottom(BorderStyle.THIN);
            titleStyle.setBottomBorderColor(IndexedColors.GREY_80_PERCENT.getIndex());

            CellStyle style = wb.createCellStyle();
            style.setBorderBottom(BorderStyle.THIN);

            // sheet 1
            Header header = sheet1.getHeader();
            header.setLeft("Zugeordnete Schüler");
            int width = sheet1.getColumnWidth(0);
            sheet1.setColumnWidth(0, (int) (width * 0.8));
            sheet1.setColumnWidth(1, width * 2);
            sheet1.setColumnWidth(2, width * 2);

            handleSheet1(retdto, sheet1, titleStyle, anonymous);

            // sheet 2
            header = sheet2.getHeader();
            header.setLeft("nicht zugeordnete Schüler");

            handleSheet2(retdto, sheet2, anonymous);

            if (anonymous) {
                // sheet 3
                header = sheet3.getHeader();
                header.setLeft("Schüler ohne Wahl");

                handleSheet3Code(retdto, sheet3);
            } else {
                List<PersonDTO> persons = personService.getPersons();
                if (!persons.isEmpty()) {
                    log.info("found persons, so list up the non-voters");
                    header = sheet3.getHeader();
                    header.setLeft("Schüler ohne Wahl");

                    handleSheet3Name(retdto, sheet3);
                }
            }

            wb.write(out);

        } catch (IOException e) {
            throw new RuntimeException("failed ", e);
        }

        auditService.insertAudit(new AuditDTO(
                "report",
                "download result excel file "));

        new BlobstoreService().uploadFile("result/assigned.xls", out.toByteArray());

        return out.toByteArray();
    }

    boolean isPersonMatch(PersonDTO p1, PersonDTO p2) {

        boolean b = p1.equals(p2);
        if (b) {
            return true;
        }

        if (!p1.clazz.trim().equalsIgnoreCase(p2.clazz.trim())) {
            return false;
        }

        LevenshteinDistance ldist = LevenshteinDistance.getDefaultInstance();

        String n1 = PersonDTO.normalize(p1.name, true);
        String n2 = PersonDTO.normalize(p2.name, true);
        Integer dist1 = ldist.apply(n1, n2);

        if (dist1 > 1) {
            return false;
        }

        n1 = PersonDTO.normalize(p1.surname, false);
        n2 = PersonDTO.normalize(p2.surname, false);
        Integer dist2 = ldist.apply(n1, n2);

        if (dist1 + dist2 <= 1) {
            return true;
        }

        return n1.contains(n2) || n2.contains(n1);
    }

    private void handleSheet1(AssignedProjectListIntDTO retdto, Sheet sheet1, CellStyle titleStyle,
                              boolean anonymous) {

        int rowId = 1;

        for (Map.Entry<ProjectDTO, List<PersonDTO>> entry : retdto.assignedPersons.entrySet()) {
            ProjectDTO p = entry.getKey();

            Row row = sheet1.createRow(rowId);
            row.setRowStyle(titleStyle);
            Cell cell = row.createCell(0);
            cell.setCellValue(p.id + ". " + p.title);
            cell.setCellStyle(titleStyle);

            sheet1.addMergedRegion(new CellRangeAddress(rowId, rowId, 0, 3));
            rowId++;

            int id = 1;
            for (PersonDTO pers : entry.getValue()) {
                Row r = writePerson(pers, id++, sheet1, rowId, anonymous);
                Cell c = r.createCell(5);
                c.setCellValue("" + entry.getKey().title);
                rowId++;
            }
        }
    }

    private void handleSheet2(AssignedProjectListIntDTO retdto, Sheet sheet2,
                              boolean anonymous) {

        int rowId = 1;

        int id = 1;
        for (PersonDTO pers : retdto.unassignedPersons) {
            writePerson(pers, id++, sheet2, rowId++, anonymous);
        }
    }

    private void handleSheet3Name(AssignedProjectListIntDTO retdto, Sheet sheet3) {

        List<PersonDTO> allPersons = personService.getPersons();
        log.info("#persons=" + allPersons.size());

        Map<PersonDTO, Boolean> votedPersons = new HashMap<>();
        for (List<PersonDTO> plist : retdto.assignedPersons.values()) {
            for (PersonDTO p : plist) {
                votedPersons.put(p, false);
            }
        }
        for (PersonDTO p : retdto.unassignedPersons) {
            votedPersons.put(p, false);
        }

        Map<String, Set<PersonDTO>> personsByClass = new TreeMap<>();

        for (PersonDTO person : allPersons) {

            // delete all persons that have already been assigned to the
            // dependent project
            boolean matched = false;
            for (PersonDTO p : retdto.personsToBeDeleted) {
                if (isPersonMatch(p, person)) {
                    log.info("remove person" + p);
                    matched = true;
                    break;
                }
            }
            if (matched) {
                continue;
            }

            for (Map.Entry<PersonDTO, Boolean> entry : votedPersons.entrySet()) {
                if (isPersonMatch(entry.getKey(), person)) {
                    entry.setValue(true);
                    matched = true;
                    break;
                }
                // some students might change name and surname
                PersonDTO p1 = new PersonDTO();
                p1.clazz = person.clazz;
                p1.surname = person.name;
                p1.name = person.surname;

                if (isPersonMatch(entry.getKey(), p1)) {
                    entry.setValue(true);
                    matched = true;
                    break;
                }
            }

            if (!matched) {
                // person has not voted
                Set<PersonDTO> s = personsByClass.computeIfAbsent(person.clazz.toLowerCase(), k -> new TreeSet<>());
                s.add(person);
            }
        }

        // persons voted by not uploaded before
        List<PersonDTO> votedButUnknown = new ArrayList<>();
        for (Map.Entry<PersonDTO, Boolean> entry : votedPersons.entrySet()) {
            if (!entry.getValue()) {
                votedButUnknown.add(entry.getKey());
            }
        }
        if (!votedButUnknown.isEmpty()) {
            log.warning("people voted but unknown " + votedButUnknown);
        }

        int rowId = 1;

        int id = 1;
        for (Map.Entry<String, Set<PersonDTO>> entry : personsByClass.entrySet()) {
            for (PersonDTO pers : entry.getValue()) {

                writePerson(pers, id++, sheet3, rowId++, false);
            }
        }
    }

    private void handleSheet3Code(AssignedProjectListIntDTO retdto, Sheet sheet3) {

        List<CodeDTO> codes = codeService.getCodes();
        log.info("#codes=" + codes);

        Set<String> votedCodes = new HashSet<>();
        for (List<PersonDTO> plist : retdto.assignedPersons.values()) {
            for (PersonDTO p : plist) {
                votedCodes.add(p.code.toLowerCase());
            }
        }
        for (PersonDTO p : retdto.unassignedPersons) {
            votedCodes.add(p.code.toLowerCase());
        }

        Map<String, Set<PersonDTO>> personsByClass = new TreeMap<>();

        Set<String> codesToBeDeleted = new HashSet<>();
        for (PersonDTO p : retdto.personsToBeDeleted) {
            codesToBeDeleted.add(p.code.toUpperCase());
        }

        for (CodeDTO code : codes) {

            // delete all persons that have already been assigned to the
            // dependent project
            if (codesToBeDeleted.contains(code.code)) {
                log.info("remove code" + code);
                continue;
            }

            if (!votedCodes.contains(code.code.toLowerCase())) {
                Set<PersonDTO> s = personsByClass.computeIfAbsent(code.clazz.toLowerCase(), k -> new TreeSet<>());
                PersonDTO p = new PersonDTO();
                p.code = code.code;
                p.clazz = code.clazz;
                s.add(p);
            }
        }

        int rowId = 1;

        int id = 1;
        for (Map.Entry<String, Set<PersonDTO>> entry : personsByClass.entrySet()) {
            for (PersonDTO pers : entry.getValue()) {

                writePerson(pers, id++, sheet3, rowId++, true);
            }
        }
    }

    private Row writePerson(PersonDTO pers, int jd, Sheet sheet, int rowId, boolean anonymous) {

        Row row = sheet.createRow(rowId);
        rowId++;

        int colId = 0;
        Cell cell = row.createCell(colId++);
        cell.setCellValue("" + jd);

        if (!anonymous) {
            cell = row.createCell(colId++);
            cell.setCellValue(pers.name);

            cell = row.createCell(colId++);
            cell.setCellValue(pers.surname);

            cell = row.createCell(colId);
            cell.setCellValue((pers.clazz != null ? pers.clazz : ""));
        } else {
            cell = row.createCell(colId++);
            cell.setCellFormula("INDEX(Codes!A:A,MATCH(E" + rowId + ",Codes!C:C,0))");
            cell = row.createCell(colId++);
            cell.setCellFormula("INDEX(Codes!B:B,MATCH(E" + rowId + ",Codes!C:C,0))");

            cell = row.createCell(colId++);
            cell.setCellValue((pers.clazz != null ? pers.clazz : ""));

            cell = row.createCell(colId);
            cell.setCellValue(pers.code);
        }

        return row;
    }

    public ReportDTO getReport() {

        AssignedProjectListIntDTO retdto = getAssignedProjects(null);
        List<ProjectDTO> projects = projectService.getProjects();

        ReportDTO report = new ReportDTO();
        report.report1 = getReport1(retdto);
        report.report2 = getReport2(retdto, projects);
        report.report3 = getReport3(retdto);

        return report;
    }

    private SubReport getReport1(AssignedProjectListIntDTO retdto) {

        SubReport r = new SubReport();

        // now fill data
        r.data = new ArrayList<>();

        List<Object> l;
        Map<Integer, Integer> countByPos = retdto.countByPos;

        boolean forcedAssignmend = false;
        for (Map.Entry<Integer, Integer> e : countByPos.entrySet()) {
            l = new ArrayList<>();
            if (e.getKey() == 0) {
                forcedAssignmend = true;
                l.add("autom. zugeordnet");
            } else {
                l.add(e.getKey() + ". Wahl");
            }
            l.add(e.getValue());
            r.data.add(l);
        }

        if (retdto.unassignedPersons.size() > 0) {
            l = new ArrayList<>();
            l.add("Nicht zugeordnet");
            l.add(retdto.unassignedPersons.size());
            r.data.add(l);
        }

        // options
        r.options = new HashMap<>();
        if (forcedAssignmend) {
            r.options.put("colors",
                    new String[]{"gray", "green", "fcff00", "#ffd200", "#ffa200", "#ff6f00", "#ff0000", "red"});
        } else {
            r.options.put("colors",
                    new String[]{"green", "fcff00", "#ffd200", "#ffa200", "#ff6f00", "#ff0000", "red"});
        }
        r.options.put("title", "Verteilung der Stimmen");
        r.options.put("is3D", false);
        r.options.put("width", 350);
        r.options.put("height", 350);

        Map<String, Object> m = new HashMap<>();
        m.put("position", "top");
        m.put("maxLines", 3);
        r.options.put("legend", m);

        m = new HashMap<>();
        m.put("left", 0);
        m.put("top", 80);
        m.put("width", "90%");
        m.put("height", "90%");
        r.options.put("chartArea", m);

        if (retdto.unassignedPersons.size() > 0) {
            Map<Integer, Object> slices = new HashMap<>();
            Map<String, Object> m1 = new HashMap<>();
            m1.put("offset", 0.1);
            slices.put(r.data.size() - 1, m1);
            r.options.put("slices", slices);
        }

        return r;
    }

    private SubReport getReport2(AssignedProjectListIntDTO retdto, List<ProjectDTO> projects) {

        SubReport r = new SubReport();

        // columns
        r.columnNames = new ArrayList<>();
        r.columnNames.add("Project");
        r.columnNames.add("belegt");
        r.columnNames.add("min. Belegung");
        r.columnNames.add("freie Kapazität");
        r.columnNames.add("überbucht");

        // now fill data
        r.data = new ArrayList<>();
        Map<ProjectDTO, List<PersonDTO>> countByPos = retdto.assignedPersons;

        List<Object> l;
        for (ProjectDTO p : projects) {
            List<PersonDTO> ps = countByPos.get(p);
            int size = (ps != null ? ps.size() : 0);

            int m2 = (p.minSize > size ? p.minSize - size : 0);
            int m3 = p.maxSize - m2 - size;
            int m4 = 0;
            if (m3 < 0) {
                m4 = -m3;
                m3 = 0;
            }

            l = new ArrayList<>();
            l.add(p.id + ". " + p.title + "(" + p.minSize + "/" + p.maxSize + ")");
            l.add(size);
            l.add(m2);
            l.add(m3);
            l.add(m4);
            r.data.add(l);
        }

        // options
        r.options = new HashMap<>();
        r.options.put("colors", new String[]{"yellow", "orange", "green", "red"});
        r.options.put("title", "Ausbuchung der Projekte");
        r.options.put("isStacked", true);
        r.options.put("width", 400);
        r.options.put("height", r.data.size() * 20 + 100);

        Map<String, Object> m = new HashMap<>();
        m.put("position", "top");
        m.put("maxLines", 3);
        r.options.put("legend", m);

        m = new HashMap<>();
        m.put("left", 100);
        m.put("top", 60);
        m.put("width", "100%");
        m.put("height", "90%");
        r.options.put("chartArea", m);

        return r;
    }

    private SubReport getReport3(AssignedProjectListIntDTO retdto) {
        SubReport r = new SubReport();

        // data
        r.data = new ArrayList<>();

        List<Object> l;
        Map<String, Integer> countByPos = retdto.countByProject;

        for (Map.Entry<String, Integer> e : countByPos.entrySet()) {
            l = new ArrayList<>();
            l.add(e.getKey());
            l.add(e.getValue());
            r.data.add(l);
        }

        // options
        r.options = new HashMap<>();
        // r.options.put("colors", new String[] { "green", "fcff00", "#ffd200",
        // "#ffa200", "#ff6f00", "#ff0000", "red" });
        r.options.put("title", "Beliebte Projekte");
        r.options.put("is3D", false);
        r.options.put("width", 350);
        r.options.put("height", 350);

        Map<String, Object> m = new HashMap<>();
        m.put("position", "top");
        m.put("maxLines", 3);
        r.options.put("legend", m);

        m = new HashMap<>();
        m.put("left", 0);
        m.put("top", 60);
        m.put("width", "90%");
        m.put("height", "90%");
        r.options.put("chartArea", m);

        return r;
    }
}
