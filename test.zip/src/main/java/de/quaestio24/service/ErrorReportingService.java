package de.quaestio24.service;

import de.quaestio24.dao.ErrorReportingDAO;
import de.quaestio24.dto.ErrorDTO;

import java.util.List;
import java.util.logging.Logger;

public class ErrorReportingService {
    private static final Logger log = Logger.getLogger(ErrorReportingService.class.getName());

    private ErrorReportingDAO dao = new ErrorReportingDAO();

    public void reportError(String error, String id) {
        log.info("reportError(" + error + ", " + id + ")");
        dao.reportError(error, id);
    }

    public List<ErrorDTO> getErrors() {
        log.info("reportErrors()");
        return dao.getLastErrors();
    }
}
