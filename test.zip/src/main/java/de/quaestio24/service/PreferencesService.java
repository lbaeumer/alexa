package de.quaestio24.service;

import com.google.appengine.api.NamespaceManager;
import de.quaestio24.dao.PreferencesDAO;
import de.quaestio24.dto.AuditDTO;
import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.dto.PreferencesDTO.DesignParameter;
import de.quaestio24.util.CacheUtil;
import de.quaestio24.util.HashUtil;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Properties;
import java.util.TimeZone;
import java.util.logging.Logger;

public class PreferencesService {

    private static final Logger log = Logger.getLogger(PreferencesService.class.getName());
    private final String key = "qu3:preference:";
    private PreferencesDAO dao = new PreferencesDAO();

    private AuditService auditService = new AuditService();

    public PreferencesDTO getPreference() {
        return getPreference(true);
    }

    public PreferencesDTO getPreference(boolean replace) {
        log.info("getPreference(" + replace + ")");

        PreferencesDTO p = (PreferencesDTO) CacheUtil.get(key + ":" + replace);
        if (p == null) {
            log.info("reading from database");
            p = dao.getPreference();
            String namespace = NamespaceManager.get();
            String baseSite;
            if (namespace != null && namespace.indexOf("_") > 0) {
                baseSite = namespace.substring(0, namespace.indexOf("_"));
            } else {
                baseSite = namespace;
            }
            if (namespace != null && !namespace.equals(baseSite)) {

                PreferencesDTO basePrefs;
                try {
                    NamespaceManager.set(baseSite);
                    basePrefs = getPreference();
                } finally {
                    NamespaceManager.set(namespace);
                }
                // overwrite subsite attribute by base site
                p.auth = basePrefs.auth;
                p.anonymous = basePrefs.anonymous;

                p.parameter.randomize = basePrefs.parameter.randomize;
                p.parameter.strategy = basePrefs.parameter.strategy;
            }
            CacheUtil.put(key + ":" + replace, p);
        }

        setDefaultValues(p);

        if (replace) {
            replace(p);
        }

        return p;
    }

    private void setDefaultValues(PreferencesDTO p) {

        // set default values
        Properties props = PreferencesDAO.getDefaultProps();
        if (p.design.txtInfoJumbotron == null) {
            p.design.txtInfoJumbotron = props.getProperty("design.txtInfoJumbotron");
        }
        if (p.design.txtInfoInstructions == null) {
            p.design.txtInfoInstructions = props.getProperty("design.txtInfoInstructions");
        }
        if (p.design.txtInfoFooter == null) {
            p.design.txtInfoFooter = props.getProperty("design.txtInfoFooter");
        }

        if (p.design.txtSelectionHeader == null) {
            p.design.txtSelectionHeader = props.getProperty("design.txtSelectionHeader");
        }
        if (p.design.txtSelectionFormCodeHeadline == null) {
            p.design.txtSelectionFormCodeHeadline = props.getProperty("design.txtSelectionFormCodeHeadline");
        }
        if (p.design.txtSelectionFormCodeText == null) {
            p.design.txtSelectionFormCodeText = props.getProperty("design.txtSelectionFormCodeText");
        }
        if (p.design.txtSelectionFormNameHeadline == null) {
            p.design.txtSelectionFormNameHeadline = props.getProperty("design.txtSelectionFormNameHeadline");
        }
        if (p.design.txtSelectionFormNameText == null) {
            p.design.txtSelectionFormNameText = props.getProperty("design.txtSelectionFormNameText");
        }

        if (p.design.txtSelectionProjectsHeadline == null) {
            p.design.txtSelectionProjectsHeadline = props.getProperty("design.txtSelectionProjectsHeadline");
        }
        if (p.design.txtSelectionProjectsText == null) {
            p.design.txtSelectionProjectsText = props.getProperty("design.txtSelectionProjectsText");
        }

        if (p.design.txtSelectionPrioritizeHeadline == null) {
            p.design.txtSelectionPrioritizeHeadline = props.getProperty("design.txtSelectionPrioritizeHeadline");
        }
        if (p.design.txtSelectionPrioritizeText == null) {
            p.design.txtSelectionPrioritizeText = props.getProperty("design.txtSelectionPrioritizeText");
        }

        if (p.design.lblClass == null) {
            p.design.lblClass = props.getProperty("design.lblClass");
        }
        if (p.design.lblProject == null) {
            p.design.lblProject = props.getProperty("design.lblProject");
        }

        if (p.design.event == null) {
            p.design.event = props.getProperty("design.event");
        }
        if (p.design.clazzes == null) {
            p.design.clazzes = props.getProperty("design.clazzes");
        }
        if (p.design.paginateCount == 0) {
            p.design.paginateCount = Integer.parseInt(props.getProperty("design.paginateCount"));
        }
    }

    private void replace(PreferencesDTO p) {

        // fill variables
        DateFormat df = new SimpleDateFormat("dd.MM.yyyy");
        df.setTimeZone(TimeZone.getTimeZone("GMT+1"));
        DateFormat dtf = new SimpleDateFormat("dd.MM.yyyy HH:mm");
        dtf.setTimeZone(TimeZone.getTimeZone("GMT+1"));

        if (p.design.txtInfoJumbotron != null) {
            if (p.eventDate != null) {
                p.design.txtInfoJumbotron = p.design.txtInfoJumbotron.replaceAll("\\$\\{eventDate}",
                        df.format(p.eventDate));
            }
            if (p.design.school != null) {
                p.design.txtInfoJumbotron = p.design.txtInfoJumbotron.replaceAll("\\$\\{school}", p.design.school);
            }
        }

        if (p.design.txtInfoInstructions != null) {
            p.design.txtInfoInstructions = p.design.txtInfoInstructions.replaceAll("\\$\\{minCodeLen}",
                    "" + p.design.minCodeLen);
            p.design.txtInfoInstructions = p.design.txtInfoInstructions.replaceAll("\\$\\{minSelections}",
                    "" + p.design.minSelections);
        }

        if (p.design.txtSelectionHeader != null) {
            if (p.startDate != null) {
                p.design.txtSelectionHeader = p.design.txtSelectionHeader.replaceAll("\\$\\{startDate}",
                        df.format(p.startDate));
            }
            if (p.endDate != null) {
                p.design.txtSelectionHeader = p.design.txtSelectionHeader.replaceAll("\\$\\{endDate}",
                        dtf.format(p.endDate));
            }
        }

        if (p.design.txtSelectionFormCodeText != null) {
            p.design.txtSelectionFormCodeText = p.design.txtSelectionFormCodeText.replaceAll("\\$\\{minCodeLen}",
                    "" + p.design.minCodeLen);

            p.design.txtSelectionProjectsText = p.design.txtSelectionProjectsText.replaceAll("\\$\\{minSelections}",
                    "" + p.design.minSelections);
        }
    }

    public PreferencesDTO updatePreference(PreferencesDTO pref) {
        log.info("updatePreference(" + pref + ")");
        CacheUtil.remove(key + ":true");
        CacheUtil.remove(key + ":false");
        CacheUtil.remove(ConfigService.key + ":false");
        CacheUtil.remove(ConfigService.key + ":true");

        String site = NamespaceManager.get();
        if (site != null && site.indexOf("_") > 0) {
            NamespaceManager.set(site.substring(0, site.indexOf("_")));
            try {
                CacheUtil.remove(ConfigService.key + ":false");
                CacheUtil.remove(ConfigService.key + ":true");
            } finally {
                NamespaceManager.set(site);
            }
        }

        // fix data
        if (pref.startDate != null) {
            Calendar cal = new GregorianCalendar();
            cal.setTime(pref.startDate);
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);
            pref.startDate = cal.getTime();
        }
        if (pref.endDate != null) {
            Calendar cal = new GregorianCalendar();
            cal.setTime(pref.endDate);
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);
            pref.endDate = cal.getTime();
        }

        if (pref.endDate2 != null && pref.startDate2 == null) {
            pref.startDate2 = pref.endDate;
        }

        PreferencesDTO p2 = (PreferencesDTO) HashUtil.clone(pref);
        if (p2.design == null) {
            p2.design = new DesignParameter();
        }
        if (p2.design.txtInfoJumbotron != null
                && p2.design.txtInfoJumbotron.equals(PreferencesDAO.getDefaultProps().get("design.txtInfoJumbotron"))) {
            p2.design.txtInfoJumbotron = null;
        }
        if (p2.design.txtInfoInstructions != null && p2.design.txtInfoInstructions
                .equals(PreferencesDAO.getDefaultProps().get("design.txtInfoInstructions"))) {
            p2.design.txtInfoInstructions = null;
        }
        if (p2.design.txtInfoFooter != null
                && p2.design.txtInfoFooter.equals(PreferencesDAO.getDefaultProps().get("design.txtInfoFooter"))) {
            p2.design.txtInfoFooter = null;
        }

        if (p2.design.txtSelectionHeader != null && p2.design.txtSelectionHeader
                .equals(PreferencesDAO.getDefaultProps().get("design.txtSelectionHeader"))) {
            p2.design.txtSelectionHeader = null;
        }
        if (p2.design.txtSelectionFormCodeHeadline != null && p2.design.txtSelectionFormCodeHeadline
                .equals(PreferencesDAO.getDefaultProps().get("design.txtSelectionFormCodeHeadline"))) {
            p2.design.txtSelectionFormCodeHeadline = null;
        }
        if (p2.design.txtSelectionFormCodeText != null && p2.design.txtSelectionFormCodeText
                .equals(PreferencesDAO.getDefaultProps().get("design.txtSelectionFormCodeText"))) {
            p2.design.txtSelectionFormCodeText = null;
        }
        if (p2.design.txtSelectionFormNameHeadline != null && p2.design.txtSelectionFormNameHeadline
                .equals(PreferencesDAO.getDefaultProps().get("design.txtSelectionFormNameHeadline"))) {
            p2.design.txtSelectionFormNameHeadline = null;
        }
        if (p2.design.txtSelectionFormNameText != null && p2.design.txtSelectionFormNameText
                .equals(PreferencesDAO.getDefaultProps().get("design.txtSelectionFormNameText"))) {
            p2.design.txtSelectionFormNameText = null;
        }
        if (p2.design.txtSelectionProjectsHeadline != null && p2.design.txtSelectionProjectsHeadline
                .equals(PreferencesDAO.getDefaultProps().get("design.txtSelectionProjectsHeadline"))) {
            p2.design.txtSelectionProjectsHeadline = null;
        }
        if (p2.design.txtSelectionProjectsText != null && p2.design.txtSelectionProjectsText
                .equals(PreferencesDAO.getDefaultProps().get("design.txtSelectionProjectsText"))) {
            p2.design.txtSelectionProjectsText = null;
        }
        if (p2.design.txtSelectionPrioritizeHeadline != null && p2.design.txtSelectionPrioritizeHeadline
                .equals(PreferencesDAO.getDefaultProps().get("design.txtSelectionPrioritizeHeadline"))) {
            p2.design.txtSelectionPrioritizeHeadline = null;
        }
        if (p2.design.txtSelectionPrioritizeText != null && p2.design.txtSelectionPrioritizeText
                .equals(PreferencesDAO.getDefaultProps().get("design.txtSelectionPrioritizeText"))) {
            p2.design.txtSelectionPrioritizeText = null;
        }

        if (p2.design.lblClass != null
                && p2.design.lblClass.equals(PreferencesDAO.getDefaultProps().get("design.lblClass"))) {
            p2.design.lblClass = null;
        }
        if (p2.design.lblProject != null
                && p2.design.lblProject.equals(PreferencesDAO.getDefaultProps().get("design.lblProject"))) {
            p2.design.lblProject = null;
        }

        if (p2.design.event != null && p2.design.event.equals(PreferencesDAO.getDefaultProps().get("design.event"))) {
            p2.design.event = null;
        }
        if (p2.design.clazzes != null
                && p2.design.clazzes.equals(PreferencesDAO.getDefaultProps().get("design.clazzes"))) {
            p2.design.clazzes = null;
        }

        auditService.insertAudit(new AuditDTO(
                "preference",
                "updated preferences"));

        dao.addPreference(p2);
        return pref;
    }

    public PreferencesDTO createDefaultPreference(PreferencesDTO overwrite) {
        PreferencesDTO p = dao.getDefaultPreference();
        if (overwrite != null && overwrite.design != null) {
            if (overwrite.design.city != null) {
                p.design.city = overwrite.design.city;
            }
            if (overwrite.design.event != null) {
                p.design.event = overwrite.design.event;
            }
            if (overwrite.design.school != null) {
                p.design.school = overwrite.design.school;
            }
        }
        dao.addPreference(p);
        return p;
    }
}
