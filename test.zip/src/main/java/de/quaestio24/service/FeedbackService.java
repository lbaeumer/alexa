package de.quaestio24.service;

import com.google.appengine.api.NamespaceManager;
import de.quaestio24.dao.FeedbackDAO;
import de.quaestio24.dto.AuditDTO;
import de.quaestio24.dto.FeedbackDTO;
import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.exception.ValidationException;
import de.quaestio24.util.SendMail;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;

public class FeedbackService {
    private static final Logger log = Logger.getLogger(FeedbackService.class.getName());

    private FeedbackDAO dao = new FeedbackDAO();
    private AuditService auditService = new AuditService();
    private PreferencesService pref = new PreferencesService();

    public String saveFeedback(FeedbackDTO feedback) {

        log.info("saveFeedback(" + feedback + ")");
        validate(feedback);
        String key = dao.saveFeedback(feedback).getName();

        String site = NamespaceManager.get();

        String email = null;
        if (site != null) {
            PreferencesDTO prefs = pref.getPreference();
            email = prefs.emailcc;
        }

        if (email == null || email.trim().length() == 0) {
            email = "lui.baeumer@gmail.com";
        }

        auditService.insertAudit(new AuditDTO(
                "feedback",
                "insert feedback" + feedback.name));

        new SendMail().send("Anfrage Quaestio24" + (site != null ? " (" + site + ")" : ""),
                "Hallo,<br/><br/>hier ist eine externe Anfrage:<br/><br/>\"" + feedback.text + "\"<br/>" + "<br/>Name: "
                        + feedback.name + "<br/>Email: " + feedback.email + "<br/>URL: " + feedback.phone,
                email, email, feedback.email, false);

        return key;
    }

    public List<FeedbackDTO> getAllFeedback() {
        log.info("getAppFeebdack()");
        return dao.getAllFeedback();
    }

    private void validate(FeedbackDTO reg) {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();

        List<String> validation = new ArrayList<>();

        Set<ConstraintViolation<FeedbackDTO>> v = validator.validate(reg);
        for (ConstraintViolation<FeedbackDTO> ss : v) {
            validation.add(ss.getMessage());
            log.warning("ss=" + ss + ";" + ss.getMessage() + "; path=" + ss.getPropertyPath() + "\ninvalidval="
                    + ss.getInvalidValue() + "\npayload?" + ss.getConstraintDescriptor().getPayload());
        }

        if (validation.size() > 0) {
            throw new ValidationException(validation);
        }
    }
}
