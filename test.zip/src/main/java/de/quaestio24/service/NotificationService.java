package de.quaestio24.service;

import com.google.appengine.api.NamespaceManager;
import de.quaestio24.constant.SiteStateEnum;
import de.quaestio24.dao.NotificationDAO;
import de.quaestio24.dto.IssueDTO;
import de.quaestio24.dto.NotificationDTO;
import de.quaestio24.dto.SiteDTO;
import de.quaestio24.entity.Site;
import de.quaestio24.service.dto.AssignedProjectListIntDTO;
import de.quaestio24.util.SendMail;
import de.quaestio24.util.SystemConfig;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

public class NotificationService {
    private static final Logger log = Logger.getLogger(NotificationService.class.getName());

    private NotificationDAO dao = new NotificationDAO();
    private DashboardService dashboardService = new DashboardService();
    private DateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm");

    public List<NotificationDTO> getAllNotifications() {
        List<NotificationDTO> list = new ArrayList<>();

        for (Site site : Site.values()) {
            if (site.isBaseSite()) {
                NamespaceManager.set(site.name());
                List<NotificationDTO> l = getNotifications();
                list.addAll(l);
            }
        }

        list.sort(Comparator.comparing(o -> o.date));

        return list;
    }

    public List<NotificationDTO> getNotifications() {
        return dao.getAllNotification();
    }

    public List<NotificationDTO> sendNotifications() {

        log.info("sendNotifications() for " + NamespaceManager.get());
        List<NotificationDTO> list = new ArrayList<>();

        SiteDTO site = dashboardService.getSite();
        switch (site.config.state) {
            case undefined: {
                handleUndefined(site, list);
                break;
            }
            case preElection: {
                handlePreElection(site, list);
                handlePreElectionAuth(site, list);
                break;
            }
            case election: {
                handleElection(site, list);
                break;
            }
            case postElection: {
                handlePostElection(site, list);
                handleInvoice(site, list);
                handleCleanup(site, list);
                break;
            }
        }

        return list;
    }

    /**
     * Check if auth is enabled before election starts.
     *
     * @param site the site
     */
    private void handlePreElectionAuth(SiteDTO site, List<NotificationDTO> list) {

        List<IssueDTO> issues = site.authIssues;
        if (!site.authIssues.isEmpty() && site.remainingDays < 5) {

            StringBuilder strb = new StringBuilder();
            strb.append("<p>Hallo Lui,</p><p>in ").append(site.remainingDays).append(" Tagen am ").append(format.format(site.config.pref.startDate)).append(" beginnt die Wahl. Die Authentifizierung muss noch aktiviert werden:</p>");
            strb.append("<ul>");
            for (IssueDTO c : issues) {
                strb.append("<li>").append(c.message);
                if (c.description != null) {
                    strb.append(" ").append(c.description);
                }
                strb.append("</li>");
            }
            strb.append("</ul>");

            final String adminUrl = SystemConfig.getProperties().getProperty("adminUrl")
                    + "/" + site.config.site + "/advanced";

            strb.append("<p><a href=\"").append(adminUrl).append("\">");
            strb.append(adminUrl).append("</a>").append("</p>");

            strb.append("<p>Viele Grüße,</p>").append("<p>Deine Sekretärin.</p>");

            NotificationDTO n = new NotificationDTO();
            n.info = "The election starts in " + site.remainingDays + " days. There are authentication issues. Lui, please fix!";
            n.site = site.config.site;
            n.state = SiteStateEnum.preElection;
            n.recipient = "lui.baeumer@gmail.com";
            list.add(n);

            dao.saveNotification(n);
            new SendMail().send("Quaestio24 Auth " + site.config.site, strb.toString(), "lui",
                    "lui.baeumer@gmail.com", null, true);
        }
    }

    private void handleUndefined(SiteDTO site, List<NotificationDTO> list) {

        List<IssueDTO> issues = site.issues.issues;
        if (!issues.isEmpty()) {

            StringBuilder strb = new StringBuilder();
            strb.append("<p>Hallo Lui,</p>");
            strb.append("<p>Bei der Wahl ").append(site.config.site).append(" gibt es noch einige Konfigurationsprobleme:");
            strb.append("<ul>");
            for (IssueDTO c : issues) {
                strb.append("<li>").append(c.message);
                if (c.description != null) {
                    strb.append(" ").append(c.description);
                }
                strb.append("</li>");
            }
            strb.append("</ul>");
            strb.append("</p><p>Bitte nochmal anschreiben ob die Wahl noch benötigt wird." + "</p>");

            strb.append("<p>Viele Grüße,</p><p>Deine Sekretärin.</p>");

            NotificationDTO n = new NotificationDTO();
            n.info = "There are " + issues.size() + " configuration issues.";
            n.site = site.config.site;
            n.recipient = "lui.baeumer@gmail.com";
            n.state = SiteStateEnum.undefined;
            list.add(n);

            dao.saveNotification(n);
            new SendMail().send("Quaestio24 Undefined " + site.config.site, strb.toString(), "lui",
                    "lui.baeumer@gmail.com", null, true);
        }
    }

    private void handlePreElection(SiteDTO site, List<NotificationDTO> list) {

        log.info("election starts in " + site.remainingDays + " days");

        List<IssueDTO> issues = site.issues.issues;
        if (!issues.isEmpty()
                && (site.remainingDays == 20
                || site.remainingDays == 10
                || site.remainingDays == 5)) {

            // election starts in the next 2-4 weeks
            StringBuilder strb = new StringBuilder();
            strb.append("<p>Hallo ").append(site.config.pref.emailcc).append(",</p>");

            strb.append("<p>in ");
            strb.append(site.remainingDays);
            strb.append(" Tagen am ").append(format.format(site.config.pref.startDate));
            strb.append(" beginnt die Wahl. ");
            strb.append("Bis zum Start sind noch die folgenden Korrekturen nötig:");

            strb.append("<ul>");
            for (IssueDTO c : issues) {
                strb.append("<li>").append(c.message);
                if (c.description != null) {
                    strb.append(" ").append(c.description);
                }
                strb.append("</li>");
            }
            strb.append("</ul>");
            strb.append("</p>");

            strb.append("<p>Bitte prüfen Sie die offenen Punkte und nehmen Sie die Einstellungen im Admin Bereich vor: ");
            final String adminUrl = SystemConfig.getProperties().getProperty("adminUrl")
                    + "/" + site.config.site;
            strb.append("</p>");

            strb.append("<p><a href=\"").append(adminUrl).append("\">");
            strb.append(adminUrl).append("</a>");
            strb.append("</p>");

            strb.append("<p>Bei Fragen stehe ich Ihnen gerne zur Verfügung.</p>");

            strb.append("<p>Viele Grüße,</p><p>Ludger Bäumer</p>");

            NotificationDTO n = new NotificationDTO();
            n.info = "The election starts in " + site.remainingDays + " days. There are " + issues.size() + " configuration issues.";
            n.site = site.config.site;
            n.recipient = site.config.pref.emailcc;
            n.state = SiteStateEnum.preElection;
            list.add(n);

            dao.saveNotification(n);
            new SendMail().send("Quaestio24 Konfiguration " + site.config.site, strb.toString(), "lui",
                    "lui.baeumer@gmail.com", null, true);
        }
    }

    private void handleElection(SiteDTO site, List<NotificationDTO> list) {

        final String adminUrl = SystemConfig.getProperties().getProperty("adminUrl");
        log.info("election " + site + " + starts in " + site.remainingDays + " days");

        Date startDate = site.config.pref.startDate;
        long timeSinceStartInH = (new Date().getTime() - startDate.getTime()) / 1000 / 60 / 60;
        long timeSinceStartInD = Math.round(timeSinceStartInH / 24.0);

        if (timeSinceStartInD == 0
                || timeSinceStartInD == 2
                || timeSinceStartInD == 5) {

            DateFormat df = new SimpleDateFormat("dd.MM.yyyy HH:mm");
            // election started days ago
            SelectionService selectionService = new SelectionService();

            StringBuilder strb = new StringBuilder();
            List<Integer> o = selectionService.getSelectionCount();
            strb.append("<p>Hallo ").append(site.config.pref.emailcc).append(",</p>");

            strb.append("<p>die Wahl läuft nun seit ");
            if (timeSinceStartInD == 1) {
                strb.append(" einem Tag");
            } else if (timeSinceStartInD > 0) {
                strb.append(timeSinceStartInD).append(" Tagen");
            } else {
                strb.append(timeSinceStartInH).append(" Stunden");
            }
            strb.append(" und endet am ");
            strb.append(df.format(site.config.pref.endDate));
            strb.append("Uhr.</p>");

            strb.append("<p>Es wurden bisher ");
            strb.append(o.get(0));
            strb.append(site.config.pref.anonymous && o.get(2) != 0
                    ? " von " + o.get(2) + " ("
                    + Math.round(100.0 * o.get(0) / o.get(2)) + "%)" : "");
            strb.append(" Stimmen abgegeben.</p>");

            if (!site.issues.issues.isEmpty()) {
                strb.append("<p>");
                if (site.issues.maxSeverity == IssueDTO.Severity.info) {
                    strb.append("Es gibt noch einige Hinweise zur Konfiguration, die hilfreich für Sie sein könnten:");
                } else {
                    strb.append("Es gibt noch Probleme bei der Konfiguration, die Sie prüfen sollten:");
                }
                strb.append("<ul>");
                for (IssueDTO c : site.issues.issues) {
                    strb.append("<li>").append(c.message);
                    if (c.description != null) {
                        strb.append(" ").append(c.description);
                    }
                    strb.append("</li>");
                }
                strb.append("</ul>");
                strb.append("</p>");
            }

            strb.append("<p>");
            strb.append("Sie können sich die detaillierten Ergebnisse im Admin Bereich ansehen:<ul>");
            strb.append("<li>Welche Projekte sind besonders beliebt? (<a href=\"").append(adminUrl).append("/").append(NamespaceManager.get()).append("/report\">Report</a>)</li>");
            strb.append("<li>Welche Schüler wurden zu welchen Projekten zugeordnet? (<a href=\"").append(adminUrl).append("/").append(NamespaceManager.get()).append("/assignment\">Zuordnung</a>)</li>");

            if (site.config.pref.anonymous) {
                strb.append("<li>Welche Schüler haben noch nicht gewählt? Laden Sie dazu die Excel Auswertung herunter und kopieren Sie die Schülernamen in das Dokument. Die Nichtwähler erscheinen auf dem Reiter Nichtwähler (<a href=\"").append(adminUrl).append("/").append(NamespaceManager.get()).append("/assignment\">Zuordnung</a>)</li>");
            }

            strb.append("<li>Eine vollständige Auflistung aller Wahlstimmen incl. Excel Download. (<a href=\"").append(adminUrl).append("/").append(NamespaceManager.get()).append("/selection\">Wahl</a>)</li>");
            strb.append("</ul>");
            strb.append("</p>");

            strb.append("<p>Bei Fragen stehe ich Ihnen gerne zur Verfügung.</p>");

            strb.append("<p>Viele Grüße,</p><p>Ludger Bäumer</p>");

            NotificationDTO n = new NotificationDTO();
            n.info = "The election is running for " + timeSinceStartInD + " day.";
            n.site = site.config.site;
            n.recipient = site.config.pref.emailcc;
            n.state = SiteStateEnum.election;
            list.add(n);

            dao.saveNotification(n);
            new SendMail().send("Die Wahl " + NamespaceManager.get() + " ist gestartet.", strb.toString(), "lui",
                    "lui.baeumer@gmail.com", null, true);
        }
    }

    private void handlePostElection(SiteDTO site, List<NotificationDTO> list) {

        final String adminUrl = SystemConfig.getProperties().getProperty("adminUrl");
        log.info("election starts in " + site.remainingDays + " days");

        Date now = new Date();
        // config not complete

        Date endDate = site.config.pref.endDate;
        if (site.config.pref.endDate2 != null) {
            endDate = site.config.pref.endDate2;
        }

        long timeEndedInH = (now.getTime() - endDate.getTime()) / 1000 / 60 / 60;
        long timeEndedInD = Math.round(timeEndedInH / 24.0);
        log.info("election is finished " + timeEndedInH + " days ago");
        if (timeEndedInH > 0 && timeEndedInH < 24) {

            ReportingService reportService = new ReportingService();
            SelectionService selectionService = new SelectionService();

            AssignedProjectListIntDTO assigned = reportService.getAssignedProjects(site.config.pref.parameter);

            List<Integer> o = selectionService.getSelectionCount();

            StringBuilder strb = new StringBuilder();

            strb.append("<p>Hallo ").append(site.config.pref.emailcc).append(",</p>");

            strb.append("<p>die Wahl ist nun beendet. Es wurden insgesamt ");
            strb.append(o.get(0)).append(site.config.pref.anonymous && o.get(2) != 0
                    ? " von " + o.get(2) + " (" + (100 * o.get(0) / o.get(2)) + "%)" : "");
            strb.append(" Stimmen abgegeben.</p>");

            strb.append("<p>");
            if (assigned.unassignedPersons.isEmpty()) {
                strb.append("Es konnten alle Schüler auf die Projekte verteilt werden. ");
            } else {
                strb.append("Insgesamt ").append(assigned.unassignedPersons.size()).append(" Schüler konnten nicht zugeordnet werden. Mit den nachfolgenden aufgelisteten Maßnahmen sollte es aber möglich sein, diese Schüler nachträglich noch zuzuordnen. ");
            }
            strb.append("Bei ");
            strb.append(Math.round(100.0 * assigned.countByPos.get(1) / o.get(0)));
            strb.append("% der Schüler konnte die Erstwahl berücksichtigt werden.");
            strb.append("</p>");

            strb.append("<p>Es gibt nun einige interessante Möglichkeiten, die Wahl noch zu optimieren:");
            strb.append("<ul>");
            strb.append("<li>Bei Bedarf können Sie Schüler fix einem Projekt zuordnen, indem Sie die Wahl der Schüler manuell <a href=\"").append(adminUrl).append("/").append(site.config.site).append("/selection\">überschreiben</a>.");
            strb.append("<li>Verschaffen Sie sich <a href=\"");
            strb.append(adminUrl).append("/").append(site.config.site).append("/report\">hier</a> einen Überblick, welche Projekte beliebt sind. Sie haben die Möglichkeit die Projektapazitäten nachträglich zu ändern. So ist es beispielsweise möglich, die Projektkapazität für beliebte Projekte zu erhöhen, um mehr Schüler ihrem Erstwunsch zuzuordnen. ");
            strb.append("<li>Sie können die finale Zuordnung nun <a href=\"");
            strb.append(adminUrl).append("/").append(site.config.site).append("/assignment\">hier</a> als Excel Sheet herunterladen.");
            strb.append("</ul>");
            strb.append("</p>");

            strb.append("<p><a href=\"");
            strb.append(adminUrl).append("/").append(NamespaceManager.get());
            strb.append("\">");
            strb.append(adminUrl).append("/").append(NamespaceManager.get());
            strb.append("</a>");
            strb.append("</p>");

            strb.append("<p>Bei Fragen stehe ich Ihnen gerne zur Verfügung.</p>");

            strb.append("<p>Viele Grüße,</p><p>Ludger Bäumer</p>");

            NotificationDTO n = new NotificationDTO();
            n.info = "The election is finished.";
            n.site = site.config.site;
            n.recipient = site.config.pref.emailcc;
            n.state = SiteStateEnum.postElection;
            list.add(n);

            dao.saveNotification(n);
            new SendMail().send("Wahl " + NamespaceManager.get() + " beendet.", strb.toString(), "Lui",
                    "lui.baeumer@gmail.com", null, true);
        }

        if (timeEndedInD == 7) {

            NotificationDTO n = new NotificationDTO();
            n.info = "The election is finished " + timeEndedInD + " days ago.";
            n.site = site.config.site;
            n.recipient = site.config.pref.emailcc;
            n.state = SiteStateEnum.postElection;
            list.add(n);

            String strb = "<p>Hallo " + site.config.pref.emailcc + ",</p>" +
                    "<p>nun ist die Wahl seit " + timeEndedInD + " Tagen beendet. " + "Ich hoffe mit der Wahl hat alles wie gewünscht geklappt und dass ich Sie bei der Durchführung und Auswertung der Projektwoche unterstützen konnte.</p>" +
                    "<p>Falls von Ihrer Seite noch Fragen oder Änderungswünsche aufgekommen sind, "
                    + "freue ich mich auf Ihr Feedback." +
                    "</p>" +
                    "<p>Viele Grüße,</p><p>Ludger Bäumer</p>";

            dao.saveNotification(n);
            new SendMail().send("Wahl " + NamespaceManager.get() + " beendet.",
                    strb,
                    "Lui", "lui.baeumer@gmail.com", null, true);
        }
    }

    private void handleInvoice(SiteDTO site, List<NotificationDTO> list) {
        Date now = new Date();
        Date endDate = site.config.pref.endDate;
        if (site.config.pref.endDate2 != null) {
            endDate = site.config.pref.endDate2;
        }

        long timeEndedInD = Math.round(1.0 * (now.getTime() - endDate.getTime()) / 1000 / 60 / 60 / 24);
        log.info("election is finished " + timeEndedInD + " days ago");
        if (timeEndedInD == 14) {

            NotificationDTO n = new NotificationDTO();
            n.info = "The election is finished " + timeEndedInD + " days ago. Please send invoice.";
            n.site = site.config.site;
            n.recipient = "lui.baeumer@gmail.com";
            n.state = SiteStateEnum.postElection;

            list.add(n);

            String strb = "<p>Hallo Lui,</p>" +
                    "<p>nun ist die Wahl seit " + timeEndedInD + " Tagen beendet. Du kannst die Rechnung an " + site.config.pref.emailcc + " versenden." +
                    "</p>" +
                    "<p>Viele Grüße,</p><p>Deine Sekretärin</p>";

            dao.saveNotification(n);
            new SendMail().send("Wahl " + NamespaceManager.get() + " beendet.",
                    strb, "Lui",
                    "lui.baeumer@gmail.com", null, false);
        }
    }

    private void handleCleanup(SiteDTO site, List<NotificationDTO> list) {
        Date now = new Date();
        // config not complete

        Date endDate = site.config.pref.endDate;
        if (site.config.pref.endDate2 != null) {
            endDate = site.config.pref.endDate2;
        }

        long timeEndedInD = Math.round(1.0 * (now.getTime() - endDate.getTime()) / 1000 / 60 / 60 / 24);
        log.info("election is finished " + timeEndedInD + " days ago");
        if (timeEndedInD == 45) {

            NotificationDTO n = new NotificationDTO();
            n.info = "The election is finished " + timeEndedInD + " days ago. Please cleanup.";
            n.site = site.config.site;
            n.recipient = "lui.baeumer@gmail.com";
            n.state = SiteStateEnum.postElection;
            list.add(n);

            String strb = "<p>Hallo Lui,</p>" +
                    "<p>nun ist die Wahl seit " + timeEndedInD + " Tagen beendet. Du kannst die Wahl wieder löschen."
                    + "</p>"
                    + "<p>Viele Grüße,</p><p>Deine Sekretärin</p>";

            dao.saveNotification(n);
            new SendMail().send("Wahl " + NamespaceManager.get() + " beendet.",
                    strb, "Lui",
                    "lui.baeumer@gmail.com", null, false);
        }
    }
}
