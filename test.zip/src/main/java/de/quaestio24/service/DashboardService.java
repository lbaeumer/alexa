package de.quaestio24.service;

import com.google.appengine.api.NamespaceManager;
import de.quaestio24.dto.ConfigDTO;
import de.quaestio24.dto.DashboardDTO;
import de.quaestio24.dto.PreferencesDTO.DesignParameter;
import de.quaestio24.dto.SiteDTO;
import de.quaestio24.entity.Site;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.logging.Logger;

import static de.quaestio24.constant.SiteStateEnum.election;
import static de.quaestio24.constant.SiteStateEnum.election2;
import static de.quaestio24.constant.SiteStateEnum.postElection;
import static de.quaestio24.constant.SiteStateEnum.preElection;
import static de.quaestio24.constant.SiteStateEnum.undefined;
import static de.quaestio24.dto.PreferencesDTO.StrategyEnum.fcfs;

public class DashboardService {
    private static final Logger log = Logger.getLogger(DashboardService.class.getName());

    private ConfigService configService = new ConfigService();
    private IssueService issueService = new IssueService();
    private AuthRequestService authRequestService = new AuthRequestService();
    private SelectionService selectionService = new SelectionService();
    private LoginStatsService loginStatsService = new LoginStatsService();
    private AuditService auditService = new AuditService();
    private FcfsSelectionService fcfsSelectionService = new FcfsSelectionService();

    public DashboardDTO getDashboard() {

        log.info("getDashboard");

        DashboardDTO dashboard = new DashboardDTO();

        Set<ConfigDTO> baseSites = new TreeSet<>((o1, o2) -> {

            long a, b, c;

            // by start date
            a = (o1.pref.startDate == null ? 0 : o1.pref.startDate.getTime());
            b = (o2.pref.startDate == null ? 0 : o2.pref.startDate.getTime());
            c = a - b;
            if (c != 0) {
                return (c < 0 ? -1 : 1);
            }

            // by site
            return o1.site.compareTo(o2.site);
        });

        for (Site site : Site.values()) {
            if (site.isBaseSite()) {
                NamespaceManager.set(site.name());
                ConfigDTO c = configService.getConfig(false);
                baseSites.add(c);
            }
        }

        for (ConfigDTO baseSite : baseSites) {
            NamespaceManager.set(baseSite.site);
            SiteDTO s = handleSite(baseSite);

            if (Site.valueOf(baseSite.site).isJunitSite()) {
                dashboard.junitSites.add(s);
            } else if (baseSite.state == preElection) {
                dashboard.preElectionSites.add(s);
            } else if (baseSite.state == election || baseSite.state == election2) {
                dashboard.electionSites.add(s);
            } else if (baseSite.state == postElection) {
                dashboard.postElectionSites.add(s);
            } else if (baseSite.state == undefined) {
                dashboard.undefinedSites.add(s);
            } else {
                log.warning("illegal state " + baseSite.state);
            }
        }

        Collections.reverse(dashboard.postElectionSites);

        return dashboard;
    }

    public SiteDTO getSite() {

        log.info("getSite");
        ConfigDTO c = configService.getConfig(false);

        SiteDTO site = handleSite(c);
        if (site.issues == null) {
            site.issues = issueService.getAllIssues();
        }
        if (site.authIssues == null) {
            site.authIssues = issueService.getAuthenticationIssues();
        }
        if (site.authRequests == null) {
            site.authRequests = authRequestService.getAuthRequests();
        }
        if (site.loginStats == null) {
            site.loginStats = loginStatsService.getLoginStats();
        }
        if (site.audits == null) {
            site.audits = auditService.getAudits();
        }
        if (site.greedySync == null && c.pref.parameter.strategy == fcfs) {
            site.greedySync = fcfsSelectionService.sync(true);
        }

        if (c.state == election || c.state == election2) {
            int rHours;
            if (c.pref.endDate2 != null) {
                rHours = (int) ((c.pref.endDate2.getTime() - System.currentTimeMillis()) / 1000 / 60 / 60);
            } else {
                rHours = (int) ((c.pref.endDate.getTime() - System.currentTimeMillis()) / 1000 / 60 / 60);
            }

            site.remainingDays = rHours / 24;
            site.remainingHours = (rHours - site.remainingDays * 24);

        } else if (c.state == preElection) {
            int rHours = (int) ((c.pref.startDate.getTime() - System.currentTimeMillis()) / 1000 / 60 / 60);

            site.remainingDays = rHours / 24;
            site.remainingHours = (rHours - site.remainingDays * 24);
        }

        return site;
    }

    private void reduceDesign(ConfigDTO config) {
        DesignParameter design = config.pref.design;
        design.clazzes = null;
        design.txtInfoFooter = null;
        design.txtInfoInstructions = null;
        design.txtInfoJumbotron = null;
        design.txtSelectionFormCodeHeadline = null;
        design.txtSelectionFormCodeText = null;
        design.txtSelectionFormNameHeadline = null;
        design.txtSelectionFormNameText = null;
        design.txtSelectionHeader = null;
        design.txtSelectionNote = null;
        design.txtSelectionPrioritizeHeadline = null;
        design.txtSelectionPrioritizeText = null;
        design.txtSelectionProjectsHeadline = null;
        design.txtSelectionProjectsText = null;
        if (config.subConfig != null) {
            config.subConfig.forEach((k, c) -> reduceDesign(c));
        }
    }

    private SiteDTO handleSite(ConfigDTO c) {

        SiteDTO site = new SiteDTO();
        site.config = c;
        reduceDesign(site.config);

        Date endDate = c.pref.endDate;
        if (c.pref.endDate2 != null && c.pref.endDate2.after(endDate)) {
            endDate = c.pref.endDate2;
        }
        int agoForDays = (int) ((System.currentTimeMillis() - endDate.getTime()) / 1000 / 60 / 60 / 24);

        if ((c.state == preElection
                || c.state == election
                || c.state == election2
                || (c.state == postElection && agoForDays < 10)
        ) && !Site.valueOf(c.site).isJunitSite()) {

            Map<String, List<Integer>> selectionCountMap = getSelectionCountMap(c);

            // selection count
            if (c.subConfig != null && c.subConfig.size() > 0) {
                site.subSelectionCount = new HashMap<>();
                c.subConfig.forEach((k, cx) -> site.subSelectionCount.put(k, selectionCountMap.get(cx.site)));
            } else {
                site.selectionCount = selectionCountMap.get(c.site);
            }

            site.issues = issueService.getAllIssues();
            site.authIssues = issueService.getAuthenticationIssues();
            site.authRequests = authRequestService.getAuthRequests();
        }

        if ((c.state == preElection
                || c.state == election
                || c.state == election2
                || c.state == postElection
                || c.state == undefined)) {

            if (!Site.valueOf(c.site).isJunitSite()) {
                site.loginStats = loginStatsService.getLoginStats();
            }
            site.audits = auditService.getAudits();
        }

        if ((c.state == election || c.state == election2)
                && c.pref.parameter.strategy == fcfs) {
            site.greedySync = fcfsSelectionService.sync(true);
        }

        return site;
    }

    private Map<String, List<Integer>> getSelectionCountMap(ConfigDTO c) {
        String site = NamespaceManager.get();
        try {
            Map<String, List<Integer>> selectionCountMap = new HashMap<>();
            if (c.subConfig != null && c.subConfig.size() > 0) {
                for (ConfigDTO subConfig : c.subConfig.values()) {
                    log.info("select: " + subConfig.site);
                    NamespaceManager.set(subConfig.site);
                    List<Integer> sc = selectionService.getSelectionCount();
                    log.info("sc " + sc);
                    selectionCountMap.put(subConfig.site, sc);
                }
            } else {
                selectionCountMap.put(c.site, selectionService.getSelectionCount());
            }
            return selectionCountMap;
        } finally {
            NamespaceManager.set(site);
        }
    }

}
