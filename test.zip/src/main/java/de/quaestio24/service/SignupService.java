package de.quaestio24.service;

import de.quaestio24.dao.SignupDAO;
import de.quaestio24.dto.AuditDTO;
import de.quaestio24.dto.RegisterUserDTO;
import de.quaestio24.dto.UserDTO;
import de.quaestio24.exception.NotFoundException;
import de.quaestio24.exception.ValidationException;
import de.quaestio24.util.SendMail;
import de.quaestio24.util.SystemConfig;

import java.util.Collections;
import java.util.logging.Logger;

public class SignupService {

    private static final Logger log = Logger.getLogger(SignupService.class.getName());
    private SignupDAO dao = new SignupDAO();
    private AuditService auditService = new AuditService();
    private UserService userService = new UserService();

    public UserDTO register(RegisterUserDTO user) {
        log.info("register " + user);
        user.provider = "login";

        validate(user);
        UserDTO u = dao.insert(user);

        String url = SystemConfig.getProperties().getProperty("adminUrl");
        String projectId = SystemConfig.getProperties().getProperty("projectId");

        auditService.insertAudit(new AuditDTO(
                "signup",
                "register " + u.name + " for " + u.site));

        new SendMail().send("Neuer Account " + projectId,
                "Hallo " + u.name + ",<br/><br/>"
                        + "Sie haben soeben einen neuen Account angelegt. Bitte aktivieren Sie den Account noch<br/><br/>"
                        + url + "/" + u.site + "/signup/" + u.key + "<br/><br/>"
                        + "Der Link bleibt 24 Stunden gültig.<br/><br/>Viele Grüße,<br/><br/>das Quaestio24 Team.",
                u.name, u.email, null, false);

        return u;
    }

    public UserDTO activate(String key) {
        log.info("activate " + key);
        if (key == null || key.length() == 0) {
            throw new ValidationException(Collections.singletonList("please provide a key"), 401);
        }
        UserDTO user = dao.getSignup(key);
        if (user == null) {
            throw new NotFoundException("key was not found", 400);
        }

        auditService.insertAudit(new AuditDTO(
                "signup",
                "activate account"));

        userService.insert(user);
        user.password = null;

        dao.deleteSignup(key);

        return user;
    }

    public UserDTO get(String key) {
        log.info("get " + key);
        if (key == null || key.length() == 0) {
            throw new ValidationException(Collections.singletonList("please provide a key"), 401);
        }
        UserDTO user = dao.getSignup(key);
        if (user == null) {
            throw new NotFoundException("key was not found", 400);
        }
        user.password = null;
        return user;
    }

    private void validate(RegisterUserDTO user) {
        if (user == null || user.name == null || user.name.length() == 0) {
            throw new ValidationException(Collections.singletonList("Bitte einen Usernamen eingeben."));
        }
        if (userService.getUserByName(user.name) != null) {
            throw new ValidationException(
                    Collections.singletonList("Der Username " + user.name + " existiert bereits."));
        }
        if (user.email == null || user.email.length() == 0) {
            throw new ValidationException(Collections.singletonList("Bitte die Email eingeben."));
        }
        if (userService.getUserByEmail(user.email) != null) {
            throw new ValidationException(Collections.singletonList("Die Email " + user.email + " existiert bereits."));
        }
        if (user.password == null || user.password.length() == 0) {
            throw new ValidationException(Collections.singletonList("Bitte ein Password eingeben."));
        }
        if (!user.password.equals(user.password2)) {
            throw new ValidationException(Collections.singletonList("Die Passwörter sind nicht identisch."));
        }
        if (user.password.length() < 6) {
            throw new ValidationException(Collections.singletonList("Das Password muss mindestens 6 stellig sein."));
        }
    }
}
