package de.quaestio24.service;

import com.google.appengine.api.NamespaceManager;
import de.quaestio24.constant.RoleEnum;
import de.quaestio24.dao.AuthDAO;
import de.quaestio24.dto.AuditDTO;
import de.quaestio24.dto.AuthDTO;

import java.util.Collections;
import java.util.List;
import java.util.logging.Logger;

public class AuthService {
    private static final Logger log = Logger.getLogger(AuthService.class.getName());

    private AuthDAO dao = new AuthDAO();
    private AuditService auditService = new AuditService();

    public List<AuthDTO> insertAuth(AuthDTO auth) {
        log.info("insertAuth(" + auth + ")");
        if (auth == null || auth.email == null || auth.provider == null) {
            log.severe("illegal parameter " + auth);
            throw new IllegalArgumentException();
        }

        if (auth.role == null) {
            auth.role = RoleEnum.teacher;
        }

        String namespace = NamespaceManager.get();
        String base = null;
        if (namespace != null && namespace.indexOf("_") > 0) {
            base = namespace.substring(0, namespace.indexOf("_"));
            NamespaceManager.set(base);
        }

        try {
            List<AuthDTO> l = dao.insertAuth(auth);
            Collections.sort(l);
            return l;
        } finally {
            if (base != null) {
                NamespaceManager.set(namespace);
            }
        }
    }

    public List<AuthDTO> getAllAuths() {
        String namespace = NamespaceManager.get();
        String base = null;
        if (namespace != null && namespace.indexOf("_") > 0) {
            base = namespace.substring(0, namespace.indexOf("_"));
            NamespaceManager.set(base);
        }

        try {
            List<AuthDTO> l = dao.getAllAuths();
            Collections.sort(l);
            return l;
        } finally {
            if (base != null) {
                NamespaceManager.set(namespace);
            }
        }
    }

    public List<AuthDTO> deleteAuth(AuthDTO a) {
        String namespace = NamespaceManager.get();
        String base = null;
        if (namespace != null && namespace.indexOf("_") > 0) {
            base = namespace.substring(0, namespace.indexOf("_"));
            NamespaceManager.set(base);
        }

        auditService.insertAudit(new AuditDTO(
                "auth",
                "delete auth " + a.email + " with role " + a.role));

        try {
            List<AuthDTO> l = dao.deleteAuth(a);
            Collections.sort(l);
            return l;

        } finally {
            if (base != null) {
                NamespaceManager.set(namespace);
            }
        }
    }

    public List<RoleEnum> getRoles(String provider, String email) {
        log.info("getRoles(" + provider + ", " + email + ")");
        if (email == null || provider == null) {
            return Collections.emptyList();
        }
        if ("localhost".equals(email) && "noauth".equals(provider)) {
            return Collections.singletonList(RoleEnum.superadmin);
        }

        List<AuthDTO> l;

        String namespace = NamespaceManager.get();
        String base = null;
        if (namespace != null && namespace.indexOf("_") > 0) {
            base = namespace.substring(0, namespace.indexOf("_"));
            NamespaceManager.set(base);
        }

        try {
            l = dao.getAuths(provider, email);
            if (l.isEmpty() && NamespaceManager.get() == null) {
                // if global request it is null, so generate a default auth
                log.info("createDefaultAuth");
                l = createDefaultAuth();
            }
        } finally {
            if (base != null) {
                NamespaceManager.set(namespace);
            }
        }

        log.info("roles=" + l);
        for (AuthDTO a : l) {
            return Collections.singletonList(a.role);
        }
        return Collections.emptyList();
    }

    public List<AuthDTO> createDefaultAuth() {
        AuthDTO auth = new AuthDTO("lui.baeumer@gmail.com", RoleEnum.superadmin);
        auth.provider = "amazon";
        insertAuth(auth);
        return Collections.singletonList(auth);
    }
}
