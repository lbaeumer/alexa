package de.quaestio24.service;

import de.quaestio24.dao.FcfsSelectionDAO;
import de.quaestio24.dto.PersonDTO;
import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.dto.ProjectDTO;
import de.quaestio24.exception.ValidationException;
import de.quaestio24.service.dto.AssignedProjectListIntDTO;
import de.quaestio24.util.CacheUtil;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.logging.Logger;

import static de.quaestio24.dto.PreferencesDTO.StrategyEnum.fcfs;

public class FcfsSelectionService {
    private static final Logger log = Logger.getLogger(FcfsSelectionService.class.getName());
    private final String key = "qu3:greedyselection";
    private FcfsSelectionDAO dao = new FcfsSelectionDAO();
    private PreferencesService preferencesService = new PreferencesService();

    @SuppressWarnings("unchecked")
    public Map<Integer, List<Integer>> getSelections() {

        log.info("getSelections()");
        Map<Integer, List<Integer>> countMap = (Map<Integer, List<Integer>>) CacheUtil.get(key);
        if (countMap == null) {
            countMap = dao.getSelections(null);
            CacheUtil.put(key, countMap);
        } else {
            log.info("reading greedy sels from cache " + countMap);
        }

        return countMap;
    }

    public List<Integer> getSelections(Integer projectId) {

        log.info("getSelections(" + projectId + ")");
        String ckey = key + projectId;
        Map<Integer, List<Integer>> countMap = (Map<Integer, List<Integer>>) CacheUtil.get(ckey);
        if (countMap == null) {
            countMap = dao.getSelections(projectId);
            CacheUtil.put(ckey, countMap);
        } else {
            log.info("reading greedy sels from cache " + countMap);
        }

        return countMap.get(projectId);
    }

    public void saveSelections(Integer projectId, int cnt, int cnt2) {
        log.info("saveSelections(" + projectId + ", " + cnt + ", " + cnt2 + ")");

        dao.saveSelections(projectId, cnt, cnt2);

        CacheUtil.remove(key + projectId);
        CacheUtil.remove(key);
    }

    public void deleteSelections() {
        log.info("deleteSelections()");

        dao.deleteAllSelections();

        CacheUtil.clear();
    }

    public Map<Integer, List<Integer>> sync(boolean dryRun) {

        PreferencesDTO pref = preferencesService.getPreference();
        if (pref.parameter.strategy != fcfs) {
            log.info("you cannot sync a non-fcfs algo site");
            throw new ValidationException(Collections.singletonList("You cannot sync a non-greedy algo site"));
        }

        ReportingService reportingService = new ReportingService();

        log.info("syncing(" + dryRun + ")");

        AssignedProjectListIntDTO result = reportingService.getAssignedProjects(pref.parameter);

        Map<Integer, List<Integer>> realMap = getRealMap(result);

        Map<Integer, List<Integer>> greedyMap = getSelections();

        if (!greedyMap.equals(realMap)) {
            log.info("greedySelection is \n" + greedyMap + ", according to report list is: \n" + realMap);
            Map<Integer, List<Integer>> delta = calculateDelta(realMap, greedyMap);
            if (!delta.isEmpty()) {
                log.warning("delta=" + delta);
            }

            if (!dryRun) {
                delta.forEach((p, v) -> saveSelections(p, v.get(0), v.get(1)));
            }

            return delta;
        }

        return Collections.emptyMap();
    }

    Map<Integer, List<Integer>> getRealMap(AssignedProjectListIntDTO result) {

        Map<Integer, List<Integer>> realMap = new TreeMap<>();

        //
        Map<PersonDTO, ProjectDTO> assignedProjectByPerson = new HashMap<>();
        result.assignedPersons.forEach((prj, pl) -> {
            pl.forEach(person -> assignedProjectByPerson.put(person, prj));
        });

        //
        result.selections.forEach(sel -> {
            ProjectDTO p = assignedProjectByPerson.get(sel.person);
            if (p != null) {

                for (Integer s : sel.selections) {
                    if (s == p.id) {
                        addToMap(realMap, s, 1, 0);
                        break;
                    } else {
                        addToMap(realMap, s, 0, 1);
                    }
                }
            }
        });

        return realMap;
    }

    void addToMap(Map<Integer, List<Integer>> map, int prj, int cnt1, int cnt2) {
        List<Integer> l = map.computeIfAbsent(prj, k -> Arrays.asList(0, 0));
        l.set(0, l.get(0) + cnt1);
        l.set(1, l.get(1) + cnt2);
    }

    Map<Integer, List<Integer>> calculateDelta(Map<Integer, List<Integer>> map1, Map<Integer, List<Integer>> map2) {
        Map<Integer, List<Integer>> delta = new HashMap<>();

        // entries in map1 and not in map2
        map1.forEach((k, v) -> {
            List<Integer> cnt = map2.get(k);
            if (cnt == null) {
                cnt = Arrays.asList(0, 0);
            }
            if (!v.equals(cnt)) {
                if (!v.get(0).equals(cnt.get(0)) || !v.get(1).equals(cnt.get(1))) {
                    delta.put(k, Arrays.asList(v.get(0) - cnt.get(0), v.get(1) - cnt.get(1)));
                }
            }
        });
        map2.forEach((k, v) -> {
            List<Integer> cnt = map1.get(k);
            if ((cnt != null ? cnt.get(0) : 0) != v.get(0)
                    || (cnt != null ? cnt.get(1) : 0) != v.get(1)) {
                delta.put(k, Arrays.asList(
                        (cnt != null ? cnt.get(0) : 0) - v.get(0),
                        (cnt != null ? cnt.get(1) : 0) - v.get(1)
                ));
            }
        });

        return delta;
    }
}
