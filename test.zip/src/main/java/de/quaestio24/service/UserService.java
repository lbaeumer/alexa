package de.quaestio24.service;

import com.google.appengine.api.NamespaceManager;
import de.quaestio24.dao.UserDAO;
import de.quaestio24.dto.UserDTO;

import java.util.logging.Logger;

public class UserService {

    private static final Logger log = Logger.getLogger(UserService.class.getName());
    private UserDAO dao = new UserDAO();
    private LoginStatsService loginStatsService = new LoginStatsService();

    public UserDTO login(UserDTO user) {
        log.info("login " + user);
        if ("googleplus".equals(user.provider) || "facebook".equals(user.provider) || "twitter".equals(user.provider)
                || "amazon".equals(user.provider)) {
            // https://www.googleapis.com/oauth2/v3/tokeninfo?id_token=
            loginStatsService.addLoginStats(user, true);
            return user;
        }

        UserDTO u;
        try {
            String site = NamespaceManager.get();
            try {
                NamespaceManager.set(null);
                u = dao.login(user);
            } finally {
                NamespaceManager.set(site);
            }
            loginStatsService.addLoginStats(user, true);
        } catch (SecurityException e) {
            loginStatsService.addLoginStats(user, false);
            throw e;
        }

        return u;
    }

    public void insert(UserDTO user) {
        dao.insert(user);
    }

    public UserDTO getUserByEmail(String email) {
        return dao.getUserByEmail(email);
    }

    public UserDTO getUserByName(String name) {
        return dao.getUserByName(name);
    }
}
