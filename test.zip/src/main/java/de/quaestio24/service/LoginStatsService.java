package de.quaestio24.service;

import de.quaestio24.dao.LoginStatsDAO;
import de.quaestio24.dto.LoginStatDTO;
import de.quaestio24.dto.LoginStatsDTO;
import de.quaestio24.dto.UserDTO;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Logger;

public class LoginStatsService {

    private static final Logger log = Logger.getLogger(LoginStatsService.class.getName());
    private LoginStatsDAO dao = new LoginStatsDAO();

    public LoginStatsDTO getLoginStats() {
        log.info("getLoginStats");
        LoginStatsDTO stats = new LoginStatsDTO();
        stats.logins = dao.getLoginStats();
        stats.userWithLastLoginFailed = new ArrayList<>();
        stats.userWithLastLoginSucceeded = new ArrayList<>();

        Set<String> map = new HashSet<>();
        for (LoginStatDTO l : stats.logins) {
            if (!map.contains(l.name)) {
                map.add(l.name);
                if (l.lastSuccessLogin != null) {
                    stats.userWithLastLoginSucceeded.add(l);
                } else {
                    stats.userWithLastLoginFailed.add(l);
                }
            }
        }

        return stats;
    }

    public void addLoginStats(UserDTO user, boolean ok) {
        dao.addLoginStats(user, ok);
    }
}
