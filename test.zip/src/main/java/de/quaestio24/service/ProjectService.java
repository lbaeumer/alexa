package de.quaestio24.service;

import com.google.appengine.api.NamespaceManager;
import de.quaestio24.constant.SiteStateEnum;
import de.quaestio24.dao.ProjectDAO;
import de.quaestio24.dto.AuditDTO;
import de.quaestio24.dto.ConfigDTO;
import de.quaestio24.dto.PersonDTO;
import de.quaestio24.dto.ProjectDTO;
import de.quaestio24.dto.ProjectDTO.ProjectAttribute;
import de.quaestio24.dto.ProjectDetailsDTO;
import de.quaestio24.exception.ValidationException;
import de.quaestio24.service.dto.AssignedProjectListIntDTO;
import de.quaestio24.util.CacheUtil;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.text.StringEscapeUtils;
import org.apache.log4j.MDC;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.logging.Logger;

import static de.quaestio24.dto.PreferencesDTO.StrategyEnum.fcfs;

public class ProjectService {
    private static final Logger log = Logger.getLogger(ProjectService.class.getName());
    private static final int PRJ_SIZE = 500;
    private final String key = "qu3:projects:";
    boolean skipValidation;
    private ProjectDAO projectDao = new ProjectDAO();
    private ConfigService configService = new ConfigService();
    private AuditService auditService = new AuditService();
    private FcfsSelectionService fcfsSelectionService = new FcfsSelectionService();

    public void addStatus(List<ProjectDTO> projs) {

        // check if status should be added
        ConfigDTO conf = configService.getConfig(false);
        if (!conf.pref.includeStatus && conf.state != SiteStateEnum.election2) {
            return;
        }

        // if fcfs strategy then shortcut
        if (conf.pref.parameter.strategy != fcfs) {
            AssignedProjectListIntDTO rep = new ReportingService().getAssignedProjects(conf.pref.parameter);

            for (ProjectDTO p : projs) {
                List<PersonDTO> ps = rep.assignedPersons.get(p);
                if (ps != null) {
                    if (ps.size() >= p.maxSize) {
                        p.status = 2;
                    } else if (ps.size() >= 4 * p.maxSize / 5) {
                        p.status = 1;
                    }
                }
            }
        } else {
            Map<Integer, List<Integer>> count = fcfsSelectionService.getSelections();

            for (ProjectDTO p : projs) {
                List<Integer> cnt = count.get(p.id);
                if (cnt != null) {
                    if (cnt.get(0) > p.maxSize) {
                        p.status = 2;
                        log.warning("Project has " + cnt.get(0) + " assignments, which is more than " + p.maxSize);
                    } else if (cnt.get(0) == p.maxSize) {
                        p.status = 2;
                    } else if (cnt.get(0) >= 4 * p.maxSize / 5) {
                        p.status = 1;
                    }
                }
            }
        }
    }

    private void addShortDesc(List<ProjectDTO> projs) {
        for (ProjectDTO p : projs) {
            ProjectDetailsDTO detail = p.details;
            if (detail != null && detail.description != null) {
                String html = detail.description;
                html = html.replaceAll("</?[a-zA-Z0-9]{1,6}[^>]*>", " ");
                html = html.replaceAll("&#34;", "\"");
                html = html.replaceAll("&#10;", " ");
                // html = html.replaceAll("&#[0-9]{1,3};", " ");
                html = html.replaceAll("\\s+", " ");
                detail.longdesc = StringEscapeUtils.unescapeHtml4(html.trim());
                if (html.length() > 140) {
                    html = html.substring(0, 140);
                    if (html.lastIndexOf(" ") > 120) {
                        html = html.substring(0, html.lastIndexOf(" "));
                    }
                    html = html + " ...";
                }
                detail.shortdesc = StringEscapeUtils.unescapeHtml4(html.trim());
            }
        }
    }

    @SuppressWarnings("unchecked")
    public List<ProjectDTO> getProjects() {

        log.info("getProjects()");
        List<ProjectDTO> projs = (List<ProjectDTO>) CacheUtil.get(key);
        if (projs == null) {
            projs = getProjectsInternal(false);
            CacheUtil.put(key, projs);
        }

        return projs;
    }

    @SuppressWarnings("unchecked")
    public List<ProjectDTO> getProjectsDetail() {

        log.info("getProjectsDetail()");
        List<ProjectDTO> projs = (List<ProjectDTO>) CacheUtil.get(key + ":true");
        if (projs == null) {
            projs = getProjectsInternal(true);
            CacheUtil.put(key + ":true", projs);
        }

        return projs;
    }

    private List<ProjectDTO> getProjectsInternal(boolean detail) {

        log.info("getProjectsInternal(" + detail + ")");
        List<ProjectDTO> projs;
        String namespace = NamespaceManager.get();
        if ("prjtest2".equals(namespace)) {
            projs = getProjectsPrjtest();
        } else if ("prjtest".equals(namespace)) {
            try (InputStream in = getClass().getResourceAsStream("/data/prjtest.csv")) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
                String line;
                StringBuilder strb = new StringBuilder();
                while ((line = reader.readLine()) != null) {
                    strb.append(line);
                    strb.append("\n");
                }
                CSVParser parser = CSVParser.parse(strb.toString(), CSVFormat.DEFAULT);
                projs = new ArrayList<>();
                int cnt = 0;
                for (CSVRecord record : parser.getRecords()) {
                    cnt++;
                    if (cnt == 1) {
                        continue;
                    }
                    ProjectDTO p = new ProjectDTO();
                    int idx = 0;
                    p.id = Integer.parseInt(record.get(idx++).trim());
                    p.title = record.get(idx++);
                    p.maxSize = Integer.parseInt(record.get(idx++).trim());
                    p.minSize = Integer.parseInt(record.get(idx++).trim());
                    if (record.size() > 4) {
                        p.maxGenderRate = Integer.parseInt(record.get(idx++));
                    } else {
                        p.maxGenderRate = 100;
                    }
                    p.additional = new TreeMap<>();
                    if (record.size() > 5) {
                        p.additional.put(ProjectAttribute.teacher, record.get(idx++));
                    } else {
                        p.additional.put(ProjectAttribute.teacher, "-");
                    }
                    if (record.size() > 6) {
                        p.additional.put(ProjectAttribute.clazz, record.get(idx));
                    } else {
                        p.additional.put(ProjectAttribute.clazz, "-");
                    }

                    projs.add(p);
                }

            } catch (IOException e) {
                log.warning("Problem with reading csv " + e);
                throw new IllegalStateException("Problem with reading csv ");
            }
        } else {
            projs = projectDao.getAllProject(detail);
        }

        if (detail) {
            addShortDesc(projs);
        }

        return projs;
    }

    private List<ProjectDTO> getProjectsPrjtest() {

        List<ProjectDTO> list = new ArrayList<>();
        for (int i = 0; i < PRJ_SIZE; i++) {
            ProjectDTO p = new ProjectDTO();
            p.id = i + 100;
            p.additional = new TreeMap<>();
            p.additional.put(ProjectAttribute.teacher, "Teacher_" + p.id);
            p.additional.put(ProjectAttribute.clazz, "" + (5 + i % 7));
            p.title = "Titel Project " + p.id;
            p.maxSize = 1 + (i % 10);
            p.maxGenderRate = 30;
            list.add(p);
        }
        return list;
    }

    public ProjectDTO addProject(ProjectDTO project) {
        return addProjects(Collections.singletonList(project), true).get(0);
    }

    public List<ProjectDTO> addProjects(List<ProjectDTO> projects, boolean addIds) {
        log.info("addProjects(" + projects.size() + ", " + MDC.get("user") + ")");

        for (ProjectDTO project : projects) {
            if (project.additional == null) {
                project.additional = new TreeMap<>();
            }
            validate(project);
        }

        auditService.insertAudit(new AuditDTO(
                "project",
                "add " + projects.size() + " projects"));

        List<ProjectDTO> p = projectDao.addProjects(projects, addIds);
        log.info("added projects " + p.size());

        CacheUtil.remove(key);
        CacheUtil.remove(key + ":true");

        return p;
    }

    public ProjectDTO updateProject(ProjectDTO project) {
        log.info("updateProject(" + project + ", " + MDC.get("user") + ")");
        validate(project);

        auditService.insertAudit(new AuditDTO(
                "project",
                "updated project " + project.id));

        ProjectDTO p = projectDao.updateProject(project);

        CacheUtil.remove(key);
        CacheUtil.remove(key + ":true");
        CacheUtil.remove(key + ":" + project.id);

        return p;
    }

    public void deleteProject(int id) {
        log.info("deleteProject(" + id + ")");

        auditService.insertAudit(new AuditDTO(
                "project",
                "delete project " + id));

        projectDao.deleteProject(id);

        CacheUtil.remove(key + ":" + id);
        CacheUtil.remove(key);
        CacheUtil.remove(key + ":true");
    }

    public List<ProjectDTO> deleteAllProjects() {
        log.info("deleteAllProjects()");

        auditService.insertAudit(new AuditDTO(
                "project",
                "deleted all projects"));

        projectDao.deleteAllProjects();

        CacheUtil.clear();
        return Collections.emptyList();
    }

    public ProjectDTO getProject(int id) {
        log.info("getProject(" + id + ")");

        ProjectDTO p = (ProjectDTO) CacheUtil.get(key + ":" + id);
        if (p == null) {
            log.info("reading project from db");
            p = projectDao.getProject(id, true);
            CacheUtil.put(key + ":" + id, p);
        }

        addStatus(Collections.singletonList(p));
        // remove room, teacher is not enabled

        return p;
    }

    void validate(ProjectDTO project) {
        if (skipValidation) {
            return;
        }

        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();

        List<String> validation = new ArrayList<>();

        Set<ConstraintViolation<ProjectDTO>> v = validator.validate(project);
        for (ConstraintViolation<ProjectDTO> ss : v) {
            validation.add(ss.getMessage());
            log.info("ss=" + ss + ";" + ss.getMessage() + ";" + ss.getInvalidValue() + "\n"
                    + ss.getConstraintDescriptor().getPayload());
        }

        if (project.details != null) {
            Set<ConstraintViolation<ProjectDetailsDTO>> v1 = validator.validate(project.details);
            for (ConstraintViolation<ProjectDetailsDTO> ss : v1) {
                validation.add(ss.getMessage());
                log.info("person=" + ss + ";" + ss.getMessage() + ";" + ss.getInvalidValue() + "\n"
                        + ss.getConstraintDescriptor().getPayload());
            }
        }

        if (project.minSize > project.maxSize) {
            validation.add("Die minimale Größe (" + project.minSize + ") muss kleiner als die max. Projektgröße ("
                    + project.maxSize + ") sein.");
        }

        if (validation.size() > 0) {
            log.info("project validation exception " + validation);
            throw new ValidationException(validation);
        }
    }

    public Map<Integer, Integer> fixNumbers() {
        log.info("fixNumbers()");

        Map<Integer, Integer> ret = projectDao.fixNumbers();
        if (!ret.isEmpty()) {
            log.info("fixed: " + ret);
        }

        auditService.insertAudit(new AuditDTO(
                "project",
                "fix numbers " + ret));

        CacheUtil.clear();

        return ret;
    }
}
