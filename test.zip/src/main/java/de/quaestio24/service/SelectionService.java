package de.quaestio24.service;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import de.quaestio24.dao.SelectionDAO;
import de.quaestio24.dto.AuditDTO;
import de.quaestio24.dto.CodeDTO;
import de.quaestio24.dto.PersonDTO;
import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.dto.ProjectDTO;
import de.quaestio24.dto.ProjectDTO.ProjectAttribute;
import de.quaestio24.dto.ProjectListDTO;
import de.quaestio24.dto.SelectionDTO;
import de.quaestio24.dto.SelectionResponseDTO;
import de.quaestio24.dto.ValidationDTO;
import de.quaestio24.exception.ValidationException;
import de.quaestio24.util.CacheUtil;
import de.quaestio24.util.SendMail;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static de.quaestio24.dto.PreferencesDTO.StrategyEnum.fcfs;

public class SelectionService {
    private static final Logger log = Logger.getLogger(SelectionService.class.getName());
    private final String key = "qu3:selection";
    private ProjectService projectService = new ProjectService();
    private SelectionDAO dao = new SelectionDAO();
    private PreferencesService pservice = new PreferencesService();
    private AuditService auditService = new AuditService();
    private FcfsSelectionService fcfsSelectionService = new FcfsSelectionService();
    private CodeService codeService = new CodeService();
    private boolean skipValidation;

    public SelectionResponseDTO insert(SelectionDTO selection, String host) {

        log.info("insert(" + selection + ", " + host + ")");

        // validation
        PreferencesDTO pr = pservice.getPreference();
        validateTime(pr);
        validate(selection, pr);

        // check if code is valid
        if (selection.person.code != null && selection.person.code.length() > 0) {
            selection.person.code = selection.person.code.trim();
            ValidationDTO v = isCodeValid(selection.person.code);
            if (selection.person.clazz == null) {
                log.info("no class in selection. Ignore it.");
            } else if (!v.selection.person.clazz.equalsIgnoreCase(selection.person.clazz)) {
                log.warning("class mismatch in insert " + v.selection.person.clazz + " != " + selection.person.clazz);
            }
            Set<Integer> prjs = new HashSet<>(v.filteredProjects);
            for (Integer pid : selection.selections) {
                if (!prjs.contains(pid)) {
                    log.warning("person " + selection.person.code + " selected project " + pid
                            + " which is not valid for class "
                            + v.selection.person.clazz
                            + ", valid are=" + v.filteredProjects);
                }
            }
            selection.person.clazz = v.selection.person.clazz;
        } else if (selection.person.name != null) {
            try {
                List<Integer> filteredProjects = getValidProjects(selection.person.clazz);
                Set<Integer> prjs = new HashSet<>(filteredProjects);
                for (Integer pid : selection.selections) {
                    if (!prjs.contains(pid)) {
                        log.warning("person " + selection.person.name + " selected project " + pid
                                + " which is not valid for class "
                                + selection.person.clazz
                                + ", valid are=" + filteredProjects);
                    }
                }
            } catch (Exception e) {
                log.log(Level.SEVERE, "failed", e);
            }
        }

        // backup & save
        Object[] id = dao.save(selection);
        final int oldProjectId = (Integer) id[2];
        final int oldProjectId2 = (Integer) id[3];
        final boolean equals = (Boolean) id[4];

        CacheUtil.remove(key);

        // prepare response object
        SelectionResponseDTO response = new SelectionResponseDTO();
        response.id = (String) id[0];
        response.created = (Date) id[1];
        response.projects = new ArrayList<>();
        response.person = selection.person;
        response.selections = selection.selections;

        log.info("saved selection with id " + response.id);

        // add selected projects to response
        List<ProjectDTO> projs = projectService.getProjects();
        Map<Integer, ProjectDTO> projById = new HashMap<>();
        for (ProjectDTO p : projs) {
            projById.put(p.id, p);
        }

        for (int sel : selection.selections) {
            ProjectDTO p = projById.get(sel);
            if (p == null) {
                log.severe("failed, did not find a project for id " + sel + " in " + projById);
            } else {
                response.projects.add(p);
            }
        }

        if (pr.parameter.strategy == fcfs && !equals) {
            updateFcsc(selection.selections, projById, oldProjectId, oldProjectId2);
        }

        if (selection.person.email != null && !host.startsWith("localhost") && !host.startsWith("import")) {
            sendMail(response, selection.person);
        }

        return response;
    }

    public void insertSelections(List<SelectionDTO> selection) {
        if (selection == null) {
            return;
        }

        auditService.insertAudit(new AuditDTO(
                "selections",
                "insert " + selection.size() + " selections"));

        for (SelectionDTO s : selection) {
            insert(s, "import");
        }
    }

    public SelectionResponseDTO update(SelectionDTO selection, String host) {

        log.info("update(" + selection + ", " + host + ")");

        PreferencesDTO pr = pservice.getPreference();

        auditService.insertAudit(new AuditDTO(
                "selections",
                "update selection " + selection));

        // save
        Object[] id = dao.save(selection);
        final int oldProjectId = (Integer) id[2];
        final int oldProjectId2 = (Integer) id[3];
        final boolean equals = (Boolean) id[4];

        SelectionResponseDTO response = new SelectionResponseDTO();
        response.id = (String) id[0];
        response.created = (Date) id[1];
        response.projects = new ArrayList<>();
        response.person = selection.person;
        response.selections = selection.selections;

        if (!selection.id.equals(response.id)) {
            log.info("delete old entry " + selection.id + "!=" + response.id);
            dao.deleteSelection(selection.id);
        }

        if (pr.parameter.strategy == fcfs && !equals) {
            List<ProjectDTO> projs = projectService.getProjects();
            Map<Integer, ProjectDTO> projById = new HashMap<>();
            for (ProjectDTO p : projs) {
                projById.put(p.id, p);
            }

            updateFcsc(selection.selections, projById, oldProjectId, oldProjectId2);
        }

        CacheUtil.remove(key);

        return response;
    }

    void updateFcsc(List<Integer> selections, Map<Integer, ProjectDTO> projectById, Integer oldProjectId,
                    Integer oldProjectId2) {
        log.info("updateFcsc(" + selections + ", " + oldProjectId + ", " + oldProjectId2 + ")");
        int i = 0;
        boolean found = false;
        for (int sel : selections) {
            ProjectDTO p = projectById.get(sel);
            List<Integer> assignmentCount = fcfsSelectionService.getSelections(sel);
            if (assignmentCount == null || assignmentCount.get(0) < p.maxSize) {
                fcfsSelectionService.saveSelections(sel, 1, 0);
                found = true;

                // if sel is not the first choice add 1 to cnt2 for for choice
                for (int j = 0; j < i; j++) {
                    fcfsSelectionService.saveSelections(selections.get(j), 0, 1);
                }

                // update greedy stats
                if (oldProjectId >= 0) {
                    // check if old project is overbooked
                    List<Integer> assignmentCountOldPrj = fcfsSelectionService.getSelections(oldProjectId);

                    if (assignmentCountOldPrj.get(1) > 0) {
                        // the plan has to be synced new
                        log.warning("the plan has to be synced now. Prj " + oldProjectId + " is overbooked, but has free capacity now");
                        //fcfsSelectionService.saveSelections(oldProjectId, 0, -1);
                        fcfsSelectionService.sync(false);
                    } else {
                        fcfsSelectionService.saveSelections(oldProjectId, -1, 0);
                    }
                }

                break;
            }
            i++;
        }
        if (!found) {
            log.warning("couldn't match. So sync");
            fcfsSelectionService.sync(false);
        }
    }

    public ValidationDTO isCodeValid(String code) {
        log.info("isCodeValid(" + code + ")");
        CodeDTO c = codeService.validateCode(code);

        ValidationDTO valid = new ValidationDTO();
        SelectionDTO selection = dao.getSelectionByCode(c);
        valid.selection = new SelectionDTO();
        valid.selection.person = new PersonDTO();
        valid.selection.person.code = c.code;
        valid.selection.person.clazz = c.clazz;

        if (selection != null) {

            PreferencesDTO pr = pservice.getPreference();

            // if greedy strategy then shortcut
            if (pr.parameter.strategy == fcfs
                    && selection.selections != null && selection.selections.size() > 0) {
                try {
                    // remove full projects
                    List<ProjectDTO> projs = projectService.getProjects();
                    Map<Integer, ProjectDTO> m = new HashMap<>();
                    for (ProjectDTO p : projs) {
                        m.put(p.id, p);
                    }

                    Map<Integer, List<Integer>> count = fcfsSelectionService.getSelections();
                    valid.selection.selections = new ArrayList<>();
                    log.info("previous selection " + selection.selections);
                    for (Integer id : selection.selections) {
                        Integer i = (count.get(id) != null ? count.get(id).get(0) : 0);
                        ProjectDTO p = m.get(id);
                        if (p != null && (i == null || i < p.maxSize)) {
                            valid.selection.selections.add(id);
                        } else {
                            log.info("delete project " + id + " from selection");
                        }
                    }
                } catch (Exception e) {
                    log.warning("failed");
                    e.printStackTrace();
                }
            } else {
                valid.selection.selections = selection.selections;
            }
        }

        // return valid projects
        valid.filteredProjects = getValidProjects(c.clazz);

        log.info("return " + valid);
        return valid;
    }

    public ValidationDTO isClassValid(String clazz) {
        log.info("isClassValid(" + clazz + ")");

        ValidationDTO valid = new ValidationDTO();
        valid.selection = new SelectionDTO();
        valid.selection.person = new PersonDTO();
        valid.selection.person.clazz = clazz;

        // return valid projects
        valid.filteredProjects = getValidProjects(clazz);

        log.info("return " + valid);
        return valid;
    }

    List<Integer> getValidProjects(String clazz) {
        List<Integer> filteredProjects = new ArrayList<>();
        try {
            List<ProjectDTO> projects = projectService.getProjects();
            for (ProjectDTO p : projects) {
                if (isClazzMatch(p.additional.get(ProjectAttribute.clazz), clazz)) {
                    filteredProjects.add(p.id);
                }
            }
        } catch (Exception e) {
            log.log(Level.SEVERE, "failed", e);
        }
        return filteredProjects;
    }

    boolean isClazzMatch(String range, String clazz) {
        if (range == null) {
            return true;
        }
        if (clazz == null) {
            return false;
        }

        // normalize clazz, range
        clazz = clazz.toLowerCase();
        clazz = clazz.replace("ef", "10");
        clazz = clazz.replace("eph", "10");
        clazz = clazz.replace("q1", "11");
        clazz = clazz.replace("ks1a", "11");
        clazz = clazz.replace("ks1b", "11");
        clazz = clazz.replace("ks1c", "11");
        clazz = clazz.replace("ks1d", "11");
        clazz = clazz.replace("ks1e", "11");
        clazz = clazz.replace("q2", "12");
        clazz = clazz.replaceAll("[ .]", "");

        range = range.toLowerCase();
        range = range.replace("ef", "10");
        range = range.replace("eph", "10");
        range = range.replace("q1", "11");
        range = range.replace("ks1", "11");
        range = range.replace("q2", "12");
        range = range.replaceAll("[ .]", "");

        // strip trailing non-digits
        int clazzNo;

        Pattern p = Pattern.compile("(\\d+).*");
        Matcher m = p.matcher(clazz);
        if (m.matches()) {
            clazzNo = Integer.parseInt(m.group(1));
        } else {
            log.warning("class does not match number (\\d+).*: " + clazz);
            return true;
        }

        // if range a,b,c
        if (range.contains(",")) {
            String[] parts = range.split(",");
            for (String part : parts) {
                if (part.length() > 0) {
                    boolean match = isClazzMatch(part, clazz);
                    if (match) {
                        return true;
                    }
                }
            }
            return false;
        }

        // if range a-b
        int min = -1;
        int max = -1;
        p = Pattern.compile("(\\d+)[\\-](\\d+)");
        m = p.matcher(range);
        if (m.matches()) {
            min = Integer.parseInt(m.group(1));
            max = Integer.parseInt(m.group(2));
            log.fine("min=" + min + "<" + max);
        } else {
            p = Pattern.compile("(\\d+).*");
            m = p.matcher(range);
            if (m.matches()) {
                min = Integer.parseInt(m.group(1));
                max = min;
                log.fine("min=" + min + "<" + max);
            }
        }
        if (min == -1 || max == -1) {
            log.warning("range does not match number " + range);
            return true;
        }

        return min <= clazzNo && clazzNo <= max;
    }

    private void sendMail(SelectionResponseDTO response, PersonDTO person) {
        SendMail mail = new SendMail();

        StringBuilder strb = new StringBuilder();
        strb.append("<p>Hallo ").append(person.surname).append(" ").append(person.name).append(",</p>");
        strb.append("<p>Sie haben folgende Projekte gewählt:</p>");

        strb.append("<ol>");
        for (ProjectDTO p : response.projects) {
            strb.append("<li>").append(p.title).append("</li>");
        }
        strb.append("</ol>");

        strb.append("<br/><br/>");
        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.GERMANY);
        format.setTimeZone(TimeZone.getTimeZone("Europe/Berlin"));
        strb.append("<p>Die Eingabe erfolgte am ").append(format.format(response.created));
        strb.append(".</p>");
        strb.append("<p>Viele Grüße,</p><p>Das Projektteam.</p>");

        mail.send("Erfolgreich gewählt", strb.toString(), person.name, person.email, null, false);
    }

    @SuppressWarnings("unchecked")
    public List<SelectionDTO> getAllSelection() {
        log.info("getAllSelection()");
        List<SelectionDTO> l = (List<SelectionDTO>) CacheUtil.get(key);
        if (l == null) {
            l = dao.getAllSelection();
            CacheUtil.put(key, l);
        } else {
            log.info("reading from cache");
        }
        log.info("found #selection=" + l.size());
        return l;
    }

    public SelectionDTO getSelection(String selectionId) {
        return dao.getSelection(selectionId);
    }

    public List<Integer> getSelectionCount() {
        List<ProjectDTO> projects = projectService.getProjects();
        int all = 0;
        for (ProjectDTO p : projects) {
            all += p.maxSize;
        }
        int used = dao.getSelectionCount();
        List<Integer> l = new ArrayList<>();
        l.add(used);
        l.add(all);

        List<CodeDTO> codes = codeService.getCodes();
        l.add(codes.size());
        l.add(projects.size());

        return l;
    }

    public List<SelectionDTO> getAllHistorySelection() {
        log.info("getAllHistorySelection()");
        return dao.getAllHistorySelection();
    }

    public void deleteSelection(String selectionid) {
        log.info("deleteSelection(" + selectionid + ")");
        SelectionDTO s = dao.deleteSelection(selectionid);

        auditService.insertAudit(new AuditDTO(
                "selections",
                "delete selection " + s));

        CacheUtil.remove(key);
    }

    public void deleteAllSelection() {
        log.info("deleteAllSelection()");
        dao.deleteAllSelection();
        CacheUtil.remove(key);

        auditService.insertAudit(new AuditDTO(
                "selections",
                "delete all selections"));

        fcfsSelectionService.deleteSelections();
    }

    public ProjectListDTO verifySelection(String selectionId) {

        log.info("verifySelection(" + selectionId + ")");

        ProjectListDTO pl = new ProjectListDTO();
        pl.projects = projectService.getProjects();

        SelectionDTO s;
        s = new SelectionDAO().verify(selectionId);
        if (s == null) {
            log.warning("the id " + selectionId + " is invalid.");
        } else {
            pl.selection = s;
        }

        return pl;
    }

    void validate(SelectionDTO reg, PreferencesDTO pr) {

        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();

        List<String> validation = new ArrayList<>();

        Set<ConstraintViolation<SelectionDTO>> v = validator.validate(reg);
        for (ConstraintViolation<SelectionDTO> ss : v) {
            validation.add(ss.getMessage());
            log.info("ss=" + ss + ";" + ss.getMessage() + ";" + ss.getInvalidValue() + "\n"
                    + ss.getConstraintDescriptor().getPayload());
        }

        PersonDTO person = reg.person;
        if (person == null) {
            validation.add("Bitte das Formular ausfüllen.");
        } else {
            if (!pr.anonymous) {

                if (person.name == null || person.name.length() < 1 || person.name.length() > 80) {
                    validation.add("Bitte den Namen angeben.");
                }
                if (person.surname == null || person.surname.length() < 1 || person.surname.length() > 80) {
                    validation.add("Bitte den Vornamen angeben.");
                }
                if (person.clazz == null || person.clazz.length() < 1 || person.clazz.length() > 80) {
                    validation.add("Bitte die Klasse eingeben.");
                }

                Set<ConstraintViolation<PersonDTO>> v1 = validator.validate(person);
                for (ConstraintViolation<PersonDTO> ss : v1) {
                    validation.add(ss.getMessage());
                    log.info("person=" + ss + ";" + ss.getMessage() + ";" + ss.getInvalidValue() + "\n"
                            + ss.getConstraintDescriptor().getPayload());
                }

                if (person.code != null && person.code.trim().length() > 0) {
                    log.warning("warning: this is a personalized election. selection with a person " + person
                            + " and a code " + person.code);
                    person.code = null;
                }
            } else {
                if (person.code == null || person.code.length() < 2 || person.code.length() > 80) {
                    validation.add("Bitte den Code angeben.");
                }
                if ((person.name != null && person.name.length() > 0)
                        || (person.surname != null && person.surname.length() > 0)
                        || (person.email != null && person.email.length() > 0)) {
                    log.warning("warning: this is an anonymous election. selection with a code " + person.code
                            + " and a person " + person);
                    person.name = null;
                    person.surname = null;
                    person.email = null;
                }
            }

            if (reg.selections != null && reg.selections.size() > 1
                    && reg.selections.size() != new HashSet<>(reg.selections).size()) {
                log.warning("you selected " + reg.selections);
                validation.add("Ein Projekt darf nur einmal gewählt werden: " + reg.selections);
            }
        }

        if (validation.size() > 0) {
            throw new ValidationException(validation);
        }
    }

    public void skipValidation(boolean b) {
        skipValidation = b;
    }

    void validateTime(PreferencesDTO p) {
        if (skipValidation) {
            return;
        }

        GregorianCalendar now = new GregorianCalendar();
        DateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm");
        format.setTimeZone(TimeZone.getTimeZone("Europe/Berlin"));

        if (p.startDate.after(now.getTime())) {
            log.warning("voting not before " + p.startDate + ";" + p + " start in "
                    + diff(now.getTime().getTime(), p.startDate.getTime()) + "; cal.getTime()="
                    + format.format(now.getTime()));
            throw new ValidationException(
                    Collections.singletonList("Die Wahl ist erst ab " + format.format(p.startDate) + " möglich."), 441);
        }
        if (p.endDate.before(now.getTime())) {
            if (p.startDate2 != null && p.startDate2.after(now.getTime())) {
                log.warning("voting not before " + p.startDate2 + ";" + p + " start in "
                        + diff(now.getTime().getTime(), p.startDate2.getTime()) + "; cal.getTime()="
                        + format.format(now.getTime()));
                throw new ValidationException(Collections.singletonList(
                        "Die Nachwahl hat noch nicht begonnen. Beginn ist " + format.format(p.startDate2) + "."), 443);
            }
            if (p.endDate2 != null && p.endDate2.before(now.getTime())) {
                log.warning("voting not after " + p.endDate2 + ";" + p + " ended for "
                        + diff(p.endDate2.getTime(), now.getTime().getTime()) + "; cal.getTime()="
                        + format.format(now.getTime()));
                throw new ValidationException(Collections
                        .singletonList("Die Nachwahl ist seit dem " + format.format(p.endDate2) + " beendet."), 444);
            }
            if (p.startDate2 == null) {
                log.warning("voting not after " + p.endDate + ";" + p + " ended for "
                        + diff(p.endDate.getTime(), now.getTime().getTime()) + "; cal.getTime()="
                        + format.format(now.getTime()));

                throw new ValidationException(Collections
                        .singletonList("Die Wahl ist seit dem " + format.format(p.endDate) + " geschlossen."), 442);
            }
        }

        log.info("open for " + diff(now.getTime().getTime(), p.endDate.getTime()) + "; cal.getTime()="
                + format.format(now.getTime()));
    }

    private String diff(long time1, long time2) {
        long diff = time2 - time1;
        long days = diff / 1000 / 60 / 60 / 24;
        diff = diff - days * 24 * 60 * 60 * 1000;

        long hours = diff / 1000 / 60 / 60;
        diff = diff - hours * 60 * 60 * 1000;

        long minutes = diff / 1000 / 60;
        diff = diff - hours * 60 * 1000;

        long seconds = diff / 1000;

        StringBuilder strb = new StringBuilder();
        if (days > 0)
            strb.append(days).append("d ");
        strb.append(hours).append(":").append(minutes).append(":").append(seconds);

        return strb.toString();
    }

    public String convertToCsv(List<SelectionDTO> selections) {

        log.info("received " + selections.size() + " selections");

        StringBuilder strb = new StringBuilder();
        strb.append(CSVFormat.newFormat(';').format("Datum", "Name", "Vorname", "Code", "Klasse", "Geschlecht",
                "Lehrer", "Email", "Wahl", "Verifiziert"));
        strb.append("\n");

        DateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
        for (SelectionDTO s : selections) {
            strb.append(CSVFormat.newFormat(';').format(format.format(s.created), s.person.name, s.person.surname,
                    s.person.code, s.person.clazz, s.person.gender, s.person.att1, s.person.email,
                    s.selections.toString(), s.idHost, s.idUserAgent, s.verified));

            strb.append("\n");
        }
        strb.append("\n");

        return strb.toString();
    }

    public List<SelectionDTO> parseSelectionCSV(InputStream imgStream) {

        List<SelectionDTO> sel = new ArrayList<>();

        Type collectionType = new TypeToken<List<Integer>>() {
        }.getType();
        Gson gson = new Gson();
        int row = 0;

        DateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

        try (CSVParser parser = new CSVParser(new InputStreamReader(imgStream, StandardCharsets.ISO_8859_1),
                CSVFormat.newFormat(';'))) {
            List<CSVRecord> selections = parser.getRecords();

            for (CSVRecord record : selections) {
                row++;
                if (row == 1 || record.size() < 9 || record.get(8).length() == 0) {
                    log.info("row is empty " + row);
                    continue;
                }

                int i = 0;

                SelectionDTO s = new SelectionDTO();
                s.created = format.parse(record.get(i++));
                s.person = new PersonDTO();
                s.person.name = record.get(i++);
                s.person.surname = record.get(i++);
                s.person.code = record.get(i++);
                s.person.clazz = record.get(i++);
                s.person.gender = record.get(i++);
                s.person.att1 = record.get(i++);
                s.person.email = s.person.surname.toLowerCase();
                i++;//// record.get(i++);
                s.selections = gson.fromJson(record.get(i++), collectionType);
                s.idHost = record.get(i++);
                s.idUserAgent = record.get(i++);
                s.verified = Boolean.parseBoolean(record.get(i));

                sel.add(s);
            }
        } catch (Exception e) {
            log.warning("cannot read dataset " + row + e);
        }

        return sel;
    }
}
