package de.quaestio24.service.dto;

import de.quaestio24.dto.PersonDTO;
import de.quaestio24.dto.ProjectDTO;
import de.quaestio24.dto.SelectionDTO;
import de.quaestio24.dto.UnassignedPersonDTO;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AssignedProjectListIntDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    public Map<ProjectDTO, List<PersonDTO>> assignedPersons;
    public List<UnassignedPersonDTO> unassignedPersons;
    public Map<PersonDTO, Integer> posByPerson;
    public Map<Integer, Integer> countByPos;
    public Map<String, Integer> countByProject;
    public Set<PersonDTO> personsToBeDeleted;
    public List<SelectionDTO> selections;

    @Override
    public String toString() {
        StringBuilder strb = new StringBuilder("assigned: ");
        for (Map.Entry<ProjectDTO, List<PersonDTO>> e : assignedPersons.entrySet()) {
            strb.append(e.getKey()).append(" -> ").append(e.getValue() != null ? e.getValue().size() : null).append(", ");
        }
        strb.append("unassigned: ").append(unassignedPersons != null ? unassignedPersons.size() : null).append(", ");

        return strb.toString();
    }
}
