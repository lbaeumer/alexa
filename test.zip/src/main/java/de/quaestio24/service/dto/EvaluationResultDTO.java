package de.quaestio24.service.dto;

import de.quaestio24.dto.PersonDTO;
import de.quaestio24.dto.ProjectDTO;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class EvaluationResultDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    public Map<ProjectDTO, List<PersonDTO>> assignedPersons;
    public List<PersonDTO> unassignedPersons;
    public List<PersonDTO> nonVoters;

    @Override
    public String toString() {
        return "EvaluationResultDTO [assignedPersons=" + assignedPersons + ", unassignedPersons=" + unassignedPersons
                + "]";
    }
}
