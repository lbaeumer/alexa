package de.quaestio24.service;

import de.quaestio24.dto.IpfilterDTO;
import de.quaestio24.exception.ValidationException;
import de.quaestio24.util.CacheUtil;
import de.quaestio24.util.SendMail;

import java.util.Collections;
import java.util.logging.Logger;

public class IpfilterService {

    public final static String USER_AGENT = "Lynx/2.8.4rel.1 libwww-FM/2.14 SSL-MM/1.4.1 OpenSSL/0.9.6c/lui";
    // 50 failed attempts in the last 8h or
    // 40 failed attempts in the last 3s or
    // ...
    // 15 failed attempts in the last 18 seconds
    // 10 failed attempts in the last 3 seconds
    public static final int[] THRESHOLD = {10, 3, 15, 18, 20, 180, 30, 1200, 40, 3 * 3600, 50, 8 * 3600};
    public static final String[] TEXT = {"Nicht so ungeduldig... ;-)", "Bitte einen Augenblick warten... ;-)",
            "Bitte einen Augenblick warten... ;-)", "Bitte versuchen Sie es später nochmal... ;-)", null, null};
    private static final Logger log = Logger.getLogger(IpfilterService.class.getName());
    private static final String key = "qu3:ipfilter";

    public void clearCache(String function, String ip) {
        CacheUtil.remove(key + ":" + function + ip);
    }

    public IpfilterDTO checkAndIncreaseLastAccess(String function, String ip, String userAgent) {
        IpfilterDTO f = (IpfilterDTO) CacheUtil.get(key + ":" + function + ip);
        if (f == null) {
            f = new IpfilterDTO();
            f.created = System.currentTimeMillis();
            f.lastAccess = f.created;
            f.cnt = 1;
        } else {
            f.lastAccess = System.currentTimeMillis();
            f.cnt++;
        }

        log.info("checkLastAccess(" + function + ", " + ip + ", " + userAgent + ") -> " + f);

        CacheUtil.put(key + ":" + function + ip, f);
        check(f);

        return f;
    }

    private void check(IpfilterDTO f) {
        if (f == null) {
            return;
        }

        // Handling
        for (int idx = 10; idx >= 0; idx = idx - 2) {
            if (f.cnt > THRESHOLD[idx] && f.lastAccess - f.created < THRESHOLD[idx + 1] * 1000) {
                // more that 3 calls in the last 3 seconds seconds
                log.warning("there might be a hacking attack " + f + ". Please wait for "
                        + (THRESHOLD[idx + 1] * 1000 - (f.lastAccess - f.created)) / 1000 + "s");
                if (f.cnt == THRESHOLD[2]) {
                    new SendMail().send("quaestio ", "there might be a hacking attack " + f, "lui",
                            "lui.baeumer@gmail.com", null, true);
                }
                throw new ValidationException(Collections.singletonList(TEXT[idx / 2]), 460 + idx / 2);
            }
        }
    }
}
