package de.quaestio24.service;

import de.quaestio24.dao.BlobstoreDAO;

import java.util.logging.Logger;

public class BlobstoreService {

    private static final Logger log = Logger.getLogger(BlobstoreService.class.getName());

    private BlobstoreDAO dao = new BlobstoreDAO();

    public void uploadFile(String file, byte[] in) {
        log.info("uploading file " + file);
        dao.uploadFile(file, in);
    }

    public void uploadImage() {
        dao.uploadImage();
    }
}
