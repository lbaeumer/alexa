package de.quaestio24.service;

import de.quaestio24.dto.AuditDTO;
import de.quaestio24.dto.ProjectDTO;
import de.quaestio24.dto.ProjectDTO.ProjectAttribute;
import de.quaestio24.dto.ProjectDetailsDTO;
import de.quaestio24.util.CacheUtil;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.poifs.filesystem.OfficeXmlFileException;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Header;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ProjectImportService {
    private static final Logger log = Logger.getLogger(ProjectImportService.class.getName());

    private ProjectService projectService = new ProjectService();
    private AuditService auditService = new AuditService();

    public byte[] getAllProjectsXls() {

        log.info("getAllProjectsXls");

        List<ProjectDTO> projects = projectService.getProjectsDetail();
        log.info("received #=" + projects.size());

        // check which titles to export
        Set<String> titles = new LinkedHashSet<>();
        titles.add("id");
        titles.add("Title");
        for (ProjectDTO p : projects) {
            if (p.additional.get(ProjectAttribute.teacher) != null) {
                titles.add("Lehrer");
                break;
            }
        }
        for (ProjectDTO p : projects) {
            if (p.additional.get(ProjectAttribute.clazz) != null) {
                titles.add("Klasse");
            }
            if (p.additional.get(ProjectAttribute.room) != null) {
                titles.add("Raum");
            }
            if (p.additional.get(ProjectAttribute.costs) != null) {
                titles.add("Kosten");
            }
            if (p.additional.get(ProjectAttribute.shift) != null) {
                titles.add("Zeit");
            }
        }
        for (ProjectDTO p : projects) {
            if (p.maxSize > 0) {
                titles.add("max. Anzahl");
                break;
            }
        }
        for (ProjectDTO p : projects) {
            if (p.minSize > 0) {
                titles.add("min. Anzahl");
            }
            if (p.maxGenderRate != 100) {
                titles.add("Max.Geschlecht");
            }
        }
        for (ProjectDTO p : projects) {
            if (p.details != null && p.details.description != null) {
                titles.add("Beschreibung");
                break;
            }
        }

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (Workbook wb = new HSSFWorkbook()) {
            Sheet sheet1 = wb.createSheet("Projekte");

            Header header = sheet1.getHeader();
            header.setLeft("Projekte");

            CellStyle style = wb.createCellStyle();
            style.setBorderBottom(BorderStyle.THIN);

            // write header line
            int i = 0;
            Cell cell;
            Row row;
            int rowId = 0;

            row = sheet1.createRow(rowId++);
            for (String s : titles) {
                cell = row.createCell(i++);
                cell.setCellStyle(style);
                cell.setCellValue(s);
            }

            // write content lines
            for (ProjectDTO p : projects) {
                i = 0;
                row = sheet1.createRow(rowId++);
                for (String s : titles) {
                    if ("id".equals(s)) {
                        cell = row.createCell(i++);
                        cell.setCellValue(p.id);
                    } else if ("Title".equals(s)) {
                        cell = row.createCell(i++);
                        cell.setCellValue(p.title);
                    } else if ("Lehrer".equals(s)) {
                        cell = row.createCell(i++);
                        cell.setCellValue(p.additional.get(ProjectAttribute.teacher));
                    } else if ("Klasse".equals(s)) {
                        cell = row.createCell(i++);
                        cell.setCellValue(p.additional.get(ProjectAttribute.clazz));
                    } else if ("Raum".equals(s)) {
                        cell = row.createCell(i++);
                        cell.setCellValue(p.additional.get(ProjectAttribute.room));
                    } else if ("Kosten".equals(s)) {
                        cell = row.createCell(i++);
                        cell.setCellValue(p.additional.get(ProjectAttribute.costs));
                    } else if ("Zeit".equals(s)) {
                        cell = row.createCell(i++);
                        cell.setCellValue(p.additional.get(ProjectAttribute.shift));
                    } else if ("max. Anzahl".equals(s)) {
                        cell = row.createCell(i++);
                        cell.setCellValue(p.maxSize);
                    } else if ("min. Anzahl".equals(s)) {
                        cell = row.createCell(i++);
                        cell.setCellValue(p.minSize);
                    } else if ("Max.Geschlecht".equals(s)) {
                        cell = row.createCell(i++);
                        cell.setCellValue(p.maxGenderRate);
                    } else if ("Beschreibung".equals(s)) {
                        cell = row.createCell(i++);
                        String desc = (p.details != null ? p.details.description : null);
                        if (desc != null) {

                            int ix = 0;
                            while (desc.length() > 32000 && ix < 20) {
                                ix++;
                                log.info("too long desc=" + desc.length());
                                desc = desc.replaceFirst("<img\\s+src=['\"]?data:image/(gif|png|jpg)[^>]+>", "");
                            }

                            if (desc.length() > 32000) {
                                log.info("still too long=" + desc.length());
                                desc = desc.substring(0, 32000);
                            }
                        }
                        cell.setCellValue(desc);
                    } else {
                        throw new RuntimeException("header " + s + " is unknown.");
                    }
                }
            }

            wb.write(out);
        } catch (IOException e) {
            throw new RuntimeException("failed ", e);
        }

        return out.toByteArray();
    }

    public List<ProjectDTO> parseXLS(InputStream imgStream) throws IOException {

        List<ProjectDTO> ret = new ArrayList<>();

        byte[] array;
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int i;
        byte[] buffer = new byte[1024];
        while ((i = imgStream.read(buffer)) > 0) {
            out.write(buffer, 0, i);
        }

        out.flush();
        array = out.toByteArray();

        Workbook wb;
        try {
            wb = new HSSFWorkbook(new ByteArrayInputStream(array));
        } catch (OfficeXmlFileException e) {
            OPCPackage pkg;
            try {
                pkg = OPCPackage.open(new ByteArrayInputStream(array));
                wb = new XSSFWorkbook(pkg);
            } catch (InvalidFormatException e1) {
                throw new IOException(e1);
            }
        }

        try {
            Sheet s0 = wb.getSheetAt(0);

            // read header
            List<String> titles = new ArrayList<>();
            Row r = s0.getRow(0);
            for (i = 0; i < 20; i++) {
                Cell s = r.getCell(i);
                if (s != null && s.getStringCellValue() != null) {
                    titles.add(s.getStringCellValue());
                } else {
                    break;
                }
            }
            log.info("titles=" + titles);

            log.info("found rows=" + s0.getLastRowNum());
            for (int ri = 1; ri <= s0.getLastRowNum(); ri++) {
                r = s0.getRow(ri);
                log.fine("read row " + ri);

                try {
                    ProjectDTO p = new ProjectDTO();
                    p.additional = new TreeMap<>();

                    for (i = 0; i < titles.size(); i++) {
                        String s = titles.get(i);
                        if ("id".equalsIgnoreCase(s)) {
                            try {
                                p.id = (int) r.getCell(i).getNumericCellValue();
                            } catch (Exception e) {
                                log.warning("id not numeric");
                            }
                        } else if ("Title".equalsIgnoreCase(s) || "Titel".equalsIgnoreCase(s)) {
                            p.title = r.getCell(i).getStringCellValue();
                        } else if ("Lehrer".equalsIgnoreCase(s)) {
                            p.additional.put(ProjectAttribute.teacher, r.getCell(i).getStringCellValue());
                        } else if ("Klasse".equalsIgnoreCase(s) || "Klassen".equalsIgnoreCase(s)) {
                            p.additional.put(ProjectAttribute.clazz, r.getCell(i).getStringCellValue());
                        } else if ("Raum".equalsIgnoreCase(s)) {
                            p.additional.put(ProjectAttribute.room, r.getCell(i).getStringCellValue());
                        } else if ("Kosten".equalsIgnoreCase(s)) {
                            p.additional.put(ProjectAttribute.costs, r.getCell(i).getStringCellValue());
                        } else if ("Zeit".equalsIgnoreCase(s)) {
                            p.additional.put(ProjectAttribute.shift, r.getCell(i).getStringCellValue());
                        } else if ("max. Anzahl".equalsIgnoreCase(s) || "Max Anzahl".equalsIgnoreCase(s)) {
                            p.maxSize = (int) r.getCell(i).getNumericCellValue();
                        } else if ("min. Anzahl".equalsIgnoreCase(s)) {
                            p.minSize = (int) r.getCell(i).getNumericCellValue();
                        } else if ("Max.Geschlecht".equalsIgnoreCase(s)) {
                            p.maxGenderRate = (int) r.getCell(i).getNumericCellValue();
                        } else if ("Beschreibung".equalsIgnoreCase(s)) {
                            p.details = new ProjectDetailsDTO();
                            p.details.description = r.getCell(i).getStringCellValue();
                        } else {
                            throw new RuntimeException("header " + s + " is unknown.");
                        }
                    }

                    log.fine("p=" + p);
                    ret.add(p);
                } catch (Exception e) {
                    log.log(Level.WARNING, "failed reading row " + ri, e);
                }
            }
        } finally {
            wb.close();
        }

        return ret;
    }

    public List<ProjectDTO> importProjectsXLS(InputStream imgStream) throws IOException {

        List<ProjectDTO> parsed = parseXLS(imgStream);
        importProjects(parsed);
        return parsed;
    }

    public void importProjects(List<ProjectDTO> projects) {
        List<ProjectDTO> allProjects = projectService.getProjects();
        Set<Integer> existingIds = new HashSet<>();
        for (ProjectDTO p : allProjects) {
            existingIds.add(p.id);
        }

        log.info("the following ids exist: " + existingIds);
        List<ProjectDTO> projectsToAdd = new ArrayList<>();
        List<ProjectDTO> projectsToUpdate = new ArrayList<>();
        List<ProjectDTO> projectsToDelete = new ArrayList<>();

        Set<Integer> importIds = new HashSet<>();
        for (ProjectDTO p : projects) {
            importIds.add(p.id);
            if (existingIds.contains(p.id)) {
                projectsToUpdate.add(p);
            } else {
                projectsToAdd.add(p);
            }
        }
        for (ProjectDTO p : allProjects) {
            if (!importIds.contains(p.id)) {
                projectsToDelete.add(p);
            }
        }

        log.info("now adding " + projectsToAdd.size() + " projects");
        try {
            auditService.insertAudit(new AuditDTO(
                    "project",
                    "imported projects"));

            projectService.skipValidation = true;
            projectService.addProjects(projectsToAdd, false);

            log.info("now updating " + projectsToUpdate.size() + " projects");
            for (ProjectDTO p : projectsToUpdate) {
                projectService.updateProject(p);
            }

            log.info("now delete " + projectsToDelete.size() + " projects");
            for (ProjectDTO p : projectsToDelete) {
                projectService.deleteProject(p.id);
            }
        } finally {
            projectService.skipValidation = false;
        }
        CacheUtil.clear();
    }
}
