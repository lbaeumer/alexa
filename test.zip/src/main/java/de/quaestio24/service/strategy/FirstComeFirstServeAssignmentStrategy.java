package de.quaestio24.service.strategy;

import de.quaestio24.dto.PersonDTO;
import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.dto.ProjectDTO;
import de.quaestio24.dto.SelectionDTO;
import de.quaestio24.service.dto.EvaluationResultDTO;
import de.quaestio24.util.ProjectComparator;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.logging.Logger;

public class FirstComeFirstServeAssignmentStrategy extends AssignmentStrategy {

    private static final Logger log = Logger.getLogger(FirstComeFirstServeAssignmentStrategy.class.getName());

    public FirstComeFirstServeAssignmentStrategy(PreferencesDTO preferences) {
        super(preferences);
    }

    @Override
    protected EvaluationResultDTO calculateAssignment(Map<Integer, ProjectDTO> projectById,
                                                      List<SelectionDTO> selections) {

        log.info("calculate Assignemnt");
        selections = new ArrayList<>(selections);
        EvaluationResultDTO ret = new EvaluationResultDTO();

        Map<ProjectDTO, List<PersonDTO>> assigned = new TreeMap<>(new ProjectComparator());

        List<PersonDTO> unassigned = new ArrayList<>();

        ret.assignedPersons = assigned;
        ret.unassignedPersons = unassigned;

        for (SelectionDTO s : selections) {
            PersonDTO person = s.person;
            for (int pos = 0; pos < s.selections.size(); pos++) {

                ProjectDTO p = projectById.get(s.selections.get(pos));
                if (p != null) {
                    // check current Size
                    List<PersonDTO> assignedPersons = assigned.computeIfAbsent(p, k -> new ArrayList<>());
                    // log.info("the first person in " + p + " is " +
                    // person);

                    if (p.maxSize > 0 && p.maxSize > assignedPersons.size()) {
                        assignedPersons.add(person);
                        break;
                    }
                }
            }
            unassigned.add(person);
        }

        return ret;
    }
}
