package de.quaestio24.service.strategy;

import de.quaestio24.dto.PersonDTO;
import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.dto.ProjectDTO;
import de.quaestio24.dto.SelectionDTO;
import de.quaestio24.service.dto.EvaluationResultDTO;
import de.quaestio24.util.ProjectComparator;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.logging.Logger;

public class GreedyAssignmentStrategy extends AssignmentStrategy {

    private static final Logger log = Logger.getLogger(GreedyAssignmentStrategy.class.getName());

    public GreedyAssignmentStrategy(PreferencesDTO preferences) {
        super(preferences);
    }

    @Override
    protected EvaluationResultDTO calculateAssignment(Map<Integer, ProjectDTO> projectById,
                                                      List<SelectionDTO> selections) {

        selections = new ArrayList<>(selections);
        EvaluationResultDTO ret = new EvaluationResultDTO();

        Map<ProjectDTO, List<PersonDTO>> assigned = new TreeMap<>(new ProjectComparator());

        List<PersonDTO> unassigned = new ArrayList<>();

        ret.assignedPersons = assigned;
        ret.unassignedPersons = unassigned;

        int pos = 0;
        while (!selections.isEmpty()) {
            List<Integer> toDelete = new ArrayList<>();
            for (int i = 0; i < selections.size(); i++) {

                SelectionDTO s = selections.get(i);
                PersonDTO person = s.person;

                if (pos >= s.selections.size()) {
                    // no more selections with rank pos
                    unassigned.add(person);
                    toDelete.add(0, i);
                } else {
                    int item = s.selections.get(pos);
                    ProjectDTO p = projectById.get(item);
                    if (p == null) {
                        log.warning("did not find a project with id " + item + " in " + projectById);
                        continue;
                    }
                    // check current Size
                    List<PersonDTO> assignedPersons = assigned.get(p);
                    if (assignedPersons == null) {
                        // log.info("the first person in " + p + " is " +
                        // person);
                        assignedPersons = new ArrayList<>();
                        assigned.put(p, assignedPersons);
                        if (p.maxSize > 0) {
                            assignedPersons.add(person);
                            toDelete.add(0, i);
                        }
                    } else if (assignedPersons.size() < p.maxSize) {
                        log.fine("handle project " + p + " with person " + person);

                        if (p.maxGenderRate > 0) {
                            int maxcount = p.maxSize;
                            int sameGenderCount = 1;
                            int otherGenderCount = 0;
                            for (PersonDTO per : assignedPersons) {
                                if (per.gender != null && per.gender.equals(person.gender)) {
                                    sameGenderCount++;
                                } else {
                                    otherGenderCount++;
                                }
                            }
                            log.fine("current gender ratio=" + (100 * sameGenderCount + "/" + maxcount) + "="
                                    + (100 * sameGenderCount / maxcount) + ">" + p.maxGenderRate);
                            log.fine("other gender ratio=" + (100 * otherGenderCount + "/" + maxcount) + "="
                                    + (100 * otherGenderCount / maxcount) + ">" + p.maxGenderRate);
                            if (100 * sameGenderCount / maxcount > p.maxGenderRate) {
                                log.info(p.title + ": sorry, exceeded maxGenderRate " + p.maxGenderRate
                                        + ", there are already enough " + person.gender + " persons");
                            } else {
                                assignedPersons.add(person);
                                toDelete.add(0, i);
                            }
                        } else {
                            assignedPersons.add(person);
                            toDelete.add(0, i);
                        }
                    }
                }
            }
            for (int i : toDelete) {
                selections.remove(i);
            }
            pos++;
        }

        return ret;
    }
}
