package de.quaestio24.service.strategy;

import de.quaestio24.dto.PersonDTO;
import de.quaestio24.dto.ProjectDTO;
import de.quaestio24.dto.SelectionDTO;
import de.quaestio24.service.dto.EvaluationResultDTO;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.logging.Logger;

public class SelectionValidation {
    private static final Logger log = Logger.getLogger(SelectionValidation.class.getName());
    private static final int POS_NOT_ASSIGNED = 10000;

    static Map<PersonDTO, ProjectDTO> getAssignedProjectByUser(EvaluationResultDTO result) {
        Map<PersonDTO, ProjectDTO> map = new HashMap<>();
        for (Map.Entry<ProjectDTO, List<PersonDTO>> entry : result.assignedPersons.entrySet()) {
            for (PersonDTO p : entry.getValue()) {
                ProjectDTO ptmp = map.put(p, entry.getKey());
                if (ptmp != null) {
                    throw new IllegalStateException("User " + entry.getKey() + " was assigned twice");
                }
            }
        }
        return map;
    }

    static Map<PersonDTO, Integer> getAssignedPositionByUser(EvaluationResultDTO result,
                                                             List<SelectionDTO> selections) {

        Map<PersonDTO, List<Integer>> selectionsByUser = new HashMap<>();
        for (SelectionDTO s : selections) {
            selectionsByUser.put(s.person, s.selections);
        }

        Map<PersonDTO, Integer> positionByUser = new HashMap<>();
        for (PersonDTO p : result.unassignedPersons) {
            positionByUser.put(p, POS_NOT_ASSIGNED);
        }

        for (Map.Entry<ProjectDTO, List<PersonDTO>> entry : result.assignedPersons.entrySet()) {
            for (PersonDTO person : entry.getValue()) {
                for (int i = 0; i < selectionsByUser.get(person).size(); i++) {
                    if ((selectionsByUser.get(person)).get(i) == entry.getKey().id) {
                        positionByUser.put(person, i + 1);
                        break;
                    }
                }
            }
        }

        return positionByUser;
    }

    static void validateAssignment1(EvaluationResultDTO result, Map<Integer, ProjectDTO> projectById,
                                    List<SelectionDTO> selections) {

        Map<PersonDTO, ProjectDTO> assignedProjectByUser = getAssignedProjectByUser(result);
        Map<PersonDTO, Integer> positionByUser = getAssignedPositionByUser(result, selections);

        // check if there are any projects with free capacity for which users
        // exist
        // who voted for this project as 1st choice.
        Set<Integer> projectsWithFreeCapacity = new HashSet<>();
        Set<Integer> projectsWithMinCapacity = new HashSet<>();
        for (ProjectDTO project : projectById.values()) {
            List<PersonDTO> persons = result.assignedPersons.get(project);
            if (persons != null) {
                if (project.maxSize > persons.size()) {
                    // there is free capacity in project
                    projectsWithFreeCapacity.add(project.id);
                }
                if (project.minSize > persons.size() && persons.size() > 0) {
                    // there is free capacity in project
                    projectsWithMinCapacity.add(project.id);
                }
            }
        }

        for (SelectionDTO sel : selections) {
            int pos = positionByUser.get(sel.person);
            if (pos == POS_NOT_ASSIGNED) {
                continue;
            }
            int i = 1;
            ProjectDTO p = assignedProjectByUser.get(sel.person);
            while (i < pos) {
                int prjId = sel.selections.get(i - 1);
                if (projectsWithFreeCapacity.contains(prjId)) {
                    if (projectsWithMinCapacity.contains(prjId)) {
                        log.info("Cannot move User " + sel.person + " was assigned to " + p + "(pos " + pos
                                + "), but project " + sel.selections.get(i - 1) + " has free capacity ");
                    } else if (p.minSize < result.assignedPersons.get(p).size()) {
                        log.warning("User " + sel.person + " with selection " + sel.selections + " was assigned to "
                                + p.id + "(min=" + p.minSize + "<" + result.assignedPersons.get(p).size()
                                + "), but project " + sel.selections.get(i - 1) + " has free capacity ");

                        throw new IllegalStateException(
                                "User " + sel.person + " was assigned to " + p + "(pos " + pos + "), but project "
                                        + sel.selections.get(i - 1) + " has free capacity; selection=" + sel);
                    }
                }
                i++;
            }
        }
    }

    public static void validateAssignment(EvaluationResultDTO result, Map<Integer, ProjectDTO> projectById,
                                          List<SelectionDTO> selections) {

        Map<PersonDTO, Set<Integer>> selectionsByPerson = new HashMap<>();

        // everbody votes only once
        Map<PersonDTO, PersonDTO> ptmp = new HashMap<>();
        for (SelectionDTO s : selections) {
            if (ptmp.get(s.person) != null) {
                log.warning("person " + ptmp.get(s.person) + " does already exist; new person " + s.person);
                throw new IllegalStateException(
                        "person " + ptmp.get(s.person) + " does already exist; new person " + s.person);
            }
            selectionsByPerson.put(s.person, new HashSet<>(s.selections));
            ptmp.put(s.person, s.person);
        }

        // all assigned projects exist
        Set<ProjectDTO> p1 = new HashSet<>(projectById.values());

        if (!p1.containsAll(result.assignedPersons.keySet())) {
            log.warning("the plan is not valid. projects unequal: " + p1 + "\n!=\n" + result.assignedPersons.keySet());
            throw new IllegalStateException();
        }

        // all project have maximal assignments
        Set<PersonDTO> uniquePersons = new HashSet<>();
        Set<Integer> projectsOfUnasignedPeople = new TreeSet<>();
        Set<Integer> fullProjects = new TreeSet<>();
        for (PersonDTO ps : result.unassignedPersons) {
            projectsOfUnasignedPeople.addAll(selectionsByPerson.get(ps));
        }

        for (Map.Entry<ProjectDTO, List<PersonDTO>> p : result.assignedPersons.entrySet()) {
            if (projectById.get(p.getKey().id).maxSize < p.getValue().size()) {
                log.warning("Project " + p.getKey() + " has too many" + p.getValue().size() + " assignments");
                throw new IllegalStateException();
            }
            if (projectById.get(p.getKey().id).maxSize == p.getValue().size()) {
                fullProjects.add(p.getKey().id);
            }

            if (projectById.get(p.getKey().id).minSize > p.getValue().size()) {
                log.info("Project " + p.getKey() + " has only " + p.getValue().size() + " assignments. min "
                        + projectById.get(p.getKey().id).minSize + " required");
            }

            // assignments are conform to selections
            for (PersonDTO per : p.getValue()) {
                if (!selectionsByPerson.get(per).contains(p.getKey().id)) {
                    log.warning("User " + per + " wasn't assigned conform to his selections ");
                    throw new IllegalStateException();
                }
            }

            uniquePersons.addAll(p.getValue());
        }
        if (!fullProjects.containsAll(projectsOfUnasignedPeople)) {
            projectsOfUnasignedPeople.removeAll(fullProjects);
            log.warning("there are people who could be assigned; full projects=" + fullProjects
                    + "; the projects are not full: " + projectsOfUnasignedPeople);
            throw new IllegalStateException("there are people who could be assigned; full projects=" + fullProjects
                    + "; the projects are not full: " + projectsOfUnasignedPeople);
        }

        if (selections.size() != uniquePersons.size() + result.unassignedPersons.size()) {
            log.warning("selec " + selections.size() + "!=" + uniquePersons.size() + " + "
                    + result.unassignedPersons.size());
            throw new IllegalStateException("selec " + selections.size() + "!=" + uniquePersons.size() + " + "
                    + result.unassignedPersons.size());
        }

        validateAssignment1(result, projectById, selections);
    }
}
