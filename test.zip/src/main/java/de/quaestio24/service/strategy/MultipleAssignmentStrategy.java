package de.quaestio24.service.strategy;

import de.quaestio24.dto.PersonDTO;
import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.dto.ProjectDTO;
import de.quaestio24.dto.SelectionDTO;
import de.quaestio24.service.dto.EvaluationResultDTO;
import de.quaestio24.util.ProjectComparator;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.logging.Logger;

public class MultipleAssignmentStrategy extends AssignmentStrategy {

    private static final Logger log = Logger.getLogger(MultipleAssignmentStrategy.class.getName());

    public MultipleAssignmentStrategy(PreferencesDTO preferences) {
        super(preferences);
    }

    @Override
    protected EvaluationResultDTO calculateAssignment(Map<Integer, ProjectDTO> projectById,
                                                      List<SelectionDTO> selections) {

        log.info("calculate multiple assignment");
        selections = new ArrayList<>(selections);
        EvaluationResultDTO ret = new EvaluationResultDTO();

        Map<ProjectDTO, List<PersonDTO>> assigned = new TreeMap<>(new ProjectComparator());

        ret.assignedPersons = assigned;
        ret.unassignedPersons = new ArrayList<>();

        for (SelectionDTO s : selections) {

            for (Integer projId : s.selections) {
                ProjectDTO project = projectById.get(projId);
                List<PersonDTO> persons = assigned.computeIfAbsent(project, k -> new ArrayList<>());
                persons.add(s.person);
            }
        }

        return ret;
    }
}
