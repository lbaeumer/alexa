package de.quaestio24.service.strategy;

import de.quaestio24.dto.CodeDTO;
import de.quaestio24.dto.PersonDTO;
import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.dto.ProjectDTO;
import de.quaestio24.dto.SelectionDTO;
import de.quaestio24.service.dto.EvaluationResultDTO;
import de.quaestio24.util.ProjectComparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;

public abstract class AssignmentStrategy {

    private static final Logger log = Logger.getLogger(AssignmentStrategy.class.getName());

    protected PreferencesDTO prefs;

    public AssignmentStrategy(PreferencesDTO preferences) {
        this.prefs = preferences;
    }

    public final EvaluationResultDTO calculateAssignment(Map<Integer, ProjectDTO> projectById,
                                                         List<SelectionDTO> selections, List<CodeDTO> codes, List<Date> untilArray) {

        log.fine("calculateAssignment(" + untilArray + ")");

        List<List<SelectionDTO>> partitions;

        // handle prio
        for (SelectionDTO s : selections) {
            if (s.prio != null && s.prio) {
                List<Integer> o = new ArrayList<>();
                o.add(s.selections.get(0));
                s.selections = o;
            }
        }

        partitions = partitionSelections(untilArray, selections);

        EvaluationResultDTO retStep1 = calculateAssignment(projectById, partitions.get(0));

        log.info("1st loop: found #projects=" + retStep1.assignedPersons.size());
        for (ProjectDTO p : retStep1.assignedPersons.keySet()) {
            log.fine(p.title + ": #=" + retStep1.assignedPersons.get(p).size());
        }
        log.info("unassigned=" + retStep1.unassignedPersons.size());

        EvaluationResultDTO merged = retStep1;

        for (int i = 1; i < partitions.size(); i++) {

            // calculate remaining projects
            Map<Integer, ProjectDTO> projectsByIdRun2 = getRemainingProjectsByIdRun(projectById, merged);

            // calculate run2
            EvaluationResultDTO retStep2 = calculateAssignment(projectsByIdRun2, partitions.get(i));

            log.info("2nd loop: found #projects=" + retStep2.assignedPersons.size());
            for (ProjectDTO p : retStep2.assignedPersons.keySet()) {
                if (log.isLoggable(Level.FINE)) {
                    log.fine(p.title + ": #=" + retStep2.assignedPersons.get(p).size());
                }
            }
            log.info("unassigned=" + retStep2.unassignedPersons.size());

            merged = merge(merged, retStep2);
        }

        // assign all unassigned persons if the addAfterAssignment flag is set
        if (!merged.unassignedPersons.isEmpty()) {
            log.info("adding unassigned persons " + merged.unassignedPersons);
            Map<PersonDTO, List<Integer>> selectionsByPerson = new HashMap<>();
            for (SelectionDTO s : selections) {
                if (s.addAfterAssignment != null && s.addAfterAssignment) {
                    selectionsByPerson.put(s.person, s.selections);
                }
            }
            log.info("selectionsByPerson=" + selectionsByPerson);

            List<PersonDTO> c = new ArrayList<>();
            for (PersonDTO person : merged.unassignedPersons) {
                List<Integer> sels = selectionsByPerson.get(person);
                if (sels != null) {
                    ProjectDTO p = projectById.get(sels.get(0));
                    log.info("assign " + person + " to " + p);

                    List<PersonDTO> l = merged.assignedPersons.get(p);
                    l.add(person);
                    c.add(person);
                }
            }
            merged.unassignedPersons.removeAll(c);
        }

        // show empty projects in report
        for (ProjectDTO p : projectById.values()) {
            merged.assignedPersons.computeIfAbsent(p, k -> new ArrayList<>());
        }

        // assign non voters to projects with free capacity randomly
        merged = addNonVotingStudents(prefs, codes, selections, merged, projectById);

        return merged;
    }

    private EvaluationResultDTO addNonVotingStudents(PreferencesDTO preferences,
                                                     List<CodeDTO> codes, List<SelectionDTO> selections,
                                                     EvaluationResultDTO merged, Map<Integer, ProjectDTO> projectById) {
        Date now = new Date();
        boolean electionFinished =
                (preferences.endDate2 == null && now.after(preferences.endDate)
                        || preferences.endDate2 != null && now.after(preferences.endDate2));

        if (!electionFinished) {
            merged.nonVoters = Collections.emptyList();
        } else if (preferences.anonymous && preferences.parameter.addNonVoters) {
            log.info("adding no voters");
            log.info("total voters=" + codes.size());
            log.info("selections=" + selections.size());

            // calculate remaining projects
            Map<Integer, ProjectDTO> projectsByIdRun2 = getRemainingProjectsByIdRun(projectById, merged);
            log.info("projectById" + projectsByIdRun2);

            // determine non voters;
            Set<String> codeByCode = new HashSet<>();
            for (SelectionDTO s : selections) {
                codeByCode.add(s.person.code.toUpperCase());
            }
            Map<String, CodeDTO> nonVoters = new HashMap<>();
            for (CodeDTO c : codes) {
                if (!codeByCode.contains(c.code.toUpperCase())) {
                    nonVoters.put(c.code.toUpperCase(), c);
                }
            }
            log.info("I found " + nonVoters.size() + " non voters: " + nonVoters.keySet());

            // determine free capacity
            Map<Integer, Integer> freeProjectCapacityByProjectId = new TreeMap<>();
            for (ProjectDTO p : projectById.values()) {
                List<PersonDTO> ps = merged.assignedPersons.get(p);
                if (ps == null) {
                    log.warning("no persons assigned to project " + p);
                }
                int s = (ps == null ? 0 : ps.size());
                if (p.maxSize > s) {
                    freeProjectCapacityByProjectId.put(p.id, p.maxSize - s);
                }
            }
            log.info("free project capacity=" + freeProjectCapacityByProjectId);
            if (!freeProjectCapacityByProjectId.isEmpty()) {

                // create selections
                List<SelectionDTO> forcedSelections = new ArrayList<>();
                List<Integer> prjIds = new ArrayList<>(freeProjectCapacityByProjectId.keySet());
                int pos = 0;
                for (Map.Entry<String, CodeDTO> nonVotingEntry : nonVoters.entrySet()) {
                    SelectionDTO s = new SelectionDTO();
                    s.person = new PersonDTO();
                    s.person.code = nonVotingEntry.getKey();
                    s.person.clazz = nonVotingEntry.getValue().clazz;
                    s.selections = new ArrayList<>();
                    int prjId = prjIds.get(pos);
                    s.selections.add(prjId);
                    forcedSelections.add(s);

                    freeProjectCapacityByProjectId.put(prjId, freeProjectCapacityByProjectId.get(prjId) - 1);
                    if (freeProjectCapacityByProjectId.get(prjId) <= 0) {
                        prjIds.remove(pos);
                    }

                    log.fine("free project capacity=" + freeProjectCapacityByProjectId + ":" + prjIds);
                    if (prjIds.isEmpty()) {
                        // all projects are full
                        break;
                    }

                    pos = (pos + 1) % prjIds.size();
                }

                log.info("adding selections=" + forcedSelections);

                // calculate run2
                GreedyAssignmentStrategy greedy = new GreedyAssignmentStrategy(preferences);
                EvaluationResultDTO retStep2 = greedy.calculateAssignment(projectsByIdRun2, forcedSelections);

                merged = merge(merged, retStep2);
            }

            merged.nonVoters = Collections.emptyList();
        } else if (preferences.anonymous) {
            Set<String> codeByCode = new HashSet<>();
            for (SelectionDTO s : selections) {
                String code = s.person.code;
                codeByCode.add(code.toUpperCase());
            }
            Set<String> nonVoters = new HashSet<>();
            for (CodeDTO c : codes) {
                if (!codeByCode.contains(c.code.toUpperCase())) {
                    nonVoters.add(c.code.toUpperCase());
                }
            }
            log.info("I found " + nonVoters.size() + " non voters: " + nonVoters);

            merged.nonVoters = new ArrayList<>();
            for (String c : nonVoters) {
                PersonDTO p = new PersonDTO();
                p.code = c;
                merged.nonVoters.add(p);
            }
        }
        return merged;
    }

    private List<List<SelectionDTO>> partitionSelections(List<Date> dates, List<SelectionDTO> selections) {

        // check randomize
        String handle = prefs.parameter != null ? "" + prefs.parameter.randomize : "false";
        Random random = new Random(1);

        List<List<SelectionDTO>> list = new ArrayList<>();
        for (int i = 0; i < dates.size() + 1; i++) {
            list.add(new ArrayList<>());
        }

        for (SelectionDTO s : selections) {
            boolean found = false;
            for (int i = 0; i < dates.size(); i++) {
                if (s.created.before(dates.get(i))) {
                    list.get(i).add(s);
                    found = true;
                    break;
                }
            }
            if (!found) {
                list.get(list.size() - 1).add(s);
            }
        }

        for (List<SelectionDTO> s : list) {
            log.info("split; #s=" + s.size());

            if (Boolean.parseBoolean(handle)) {
                log.info("randomize");
                selections = new ArrayList<>(selections);
                Collections.shuffle(s, random);
            }
        }

        return list;
    }

    private Map<Integer, ProjectDTO> getRemainingProjectsByIdRun(Map<Integer, ProjectDTO> projectById,
                                                                 EvaluationResultDTO retStep1) {

        // there is an issue
        Map<Integer, ProjectDTO> projectsByIdRun2 = new HashMap<>();
        for (Map.Entry<Integer, ProjectDTO> entry : projectById.entrySet()) {
            ProjectDTO oldP = entry.getValue();
            int oldSize = retStep1.assignedPersons.get(oldP) != null ? retStep1.assignedPersons.get(oldP).size() : 0;
            ProjectDTO newP = new ProjectDTO(oldP.id, oldP.maxSize - oldSize, oldP.minSize, oldP.title,
                    oldP.maxGenderRate, oldP.additional);
            projectsByIdRun2.put(entry.getKey(), newP);
        }

        return projectsByIdRun2;
    }

    private EvaluationResultDTO merge(EvaluationResultDTO retStep1, EvaluationResultDTO retStep2) {
        // merge results
        EvaluationResultDTO merged = new EvaluationResultDTO();
        merged.assignedPersons = new TreeMap<>(new ProjectComparator());
        merged.assignedPersons.putAll(retStep1.assignedPersons);

        merged.unassignedPersons = new ArrayList<>(retStep1.unassignedPersons);

        merged.unassignedPersons.addAll(retStep2.unassignedPersons);
        for (Map.Entry<ProjectDTO, List<PersonDTO>> entry : retStep2.assignedPersons.entrySet()) {
            List<PersonDTO> l = merged.assignedPersons.get(entry.getKey());
            if (l == null) {
                merged.assignedPersons.put(entry.getKey(), retStep2.assignedPersons.get(entry.getKey()));
            } else {
                l.addAll(retStep2.assignedPersons.get(entry.getKey()));
            }
        }

        return merged;
    }

    protected abstract EvaluationResultDTO calculateAssignment(Map<Integer, ProjectDTO> projectById,
                                                               List<SelectionDTO> selec);
}
