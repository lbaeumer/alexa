package de.quaestio24.service.strategy;

import de.quaestio24.dto.PersonDTO;
import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.dto.ProjectDTO;
import de.quaestio24.dto.SelectionDTO;
import de.quaestio24.service.dto.EvaluationResultDTO;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.logging.Logger;

public class BestAssignmentStrategy extends AssignmentStrategy {

    private static final Logger log = Logger.getLogger(BestAssignmentStrategy.class.getName());
    private static final int POS_NOT_ASSIGNED = 10000;

    public BestAssignmentStrategy(PreferencesDTO preferences) {
        super(preferences);
    }

    @Override
    protected EvaluationResultDTO calculateAssignment(Map<Integer, ProjectDTO> projectById,
                                                      List<SelectionDTO> selections) {

        log.fine("calculate best assignment");
        EvaluationResultDTO ret = new GreedyAssignmentStrategy(prefs).calculateAssignment(projectById, selections);

        log.info("handleUnassigned1");
        handleUnassigned(ret, projectById, selections);

        // SelectionValidation.validateAssignment(ret, projectById, selections);

        String handle = prefs.parameter != null ? "" + prefs.parameter.skipMinimum : "false";
        if (!Boolean.parseBoolean(handle)) {
            log.info("handleMinimum");
            handleMinimum(ret, projectById, selections);

            log.info("handleMoveToBetterProjects");
            handleMoveToBetterProjects(ret, projectById, selections);
        }

        handleUnassigned(ret, projectById, selections);
        log.info("handleMoveToBetterProjects");
        handleMoveToBetterProjects(ret, projectById, selections);
        // handleUnassigned(ret, projectById, selections);
        SelectionValidation.validateAssignment(ret, projectById, selections);

        // log.info("handleUnassigned2");
        // boolean b = handleUnassigned(ret, projectById, selections);
        // if (b)
        // throw new IllegalStateException("should already be done");
        // SelectionValidation.validateAssignment(ret, projectById, selections);

        return ret;
    }

    private void handleUnassigned(EvaluationResultDTO ret, Map<Integer, ProjectDTO> projectById,
                                  List<SelectionDTO> selections) {

        boolean r = false;
        int unassignedCount = ret.unassignedPersons.size();
        if (unassignedCount == 0) {
            return;
        }

        // prepare datastructures
        final Map<PersonDTO, SelectionDTO> selectionsByPerson = new HashMap<>();
        final Map<ProjectDTO, Set<PersonDTO>> personsByProject = new HashMap<>();
        for (SelectionDTO s : selections) {
            selectionsByPerson.put(s.person, s);

            for (Integer i : s.selections) {
                ProjectDTO p = projectById.get(i);
                Set<PersonDTO> ss = personsByProject.computeIfAbsent(p, k -> new HashSet<>());
                ss.add(s.person);
            }
        }

        int cnt = 0;
        int pos = 0;
        while (!ret.unassignedPersons.isEmpty()) {

            if (pos >= ret.unassignedPersons.size()) {
                cnt++;
                pos = 0;
            }
            if (cnt > 2) {
                break;
            }

            PersonDTO unassignedPerson = ret.unassignedPersons.get(pos);

            // these are the overbooked projects
            Set<Integer> attractiveProjects = new TreeSet<>();
            Map<ProjectDTO, List<PersonDTO>> pm = ret.assignedPersons;
            for (Entry<ProjectDTO, List<PersonDTO>> entry : pm.entrySet()) {
                if (entry.getKey().maxSize <= entry.getValue().size()) {
                    attractiveProjects.add(entry.getKey().id);
                }
            }
            for (ProjectDTO p : projectById.values()) {
                if (p.maxSize == 0) {
                    attractiveProjects.add(p.id);
                }
            }

            log.fine("the overbooked projects: " + attractiveProjects);

            // scan assigned persons until a person is found
            SelectionDTO selectionOfUnassignedPerson = selectionsByPerson.get(unassignedPerson);

            log.fine("remaining #=" + ret.unassignedPersons.size() + ": unassigned person " + unassignedPerson
                    + " selected " + selectionOfUnassignedPerson.selections);

            boolean found = false;
            for (Integer projectToRelease : selectionOfUnassignedPerson.selections) {

                // check if project i can be released
                Object[] o = findPersonToReassign(projectToRelease, attractiveProjects, pm, selectionsByPerson);

                if (o != null) {
                    PersonDTO personToReassign = (PersonDTO) o[0];
                    int newProject = (int) o[1];
                    log.fine("assign user " + personToReassign + " ("
                            + selectionsByPerson.get(personToReassign).selections + ") from project " + projectToRelease
                            + " to " + newProject);

                    ProjectDTO from = projectById.get(projectToRelease);
                    ProjectDTO to = projectById.get(newProject);

                    ret.unassignedPersons.remove(unassignedPerson);
                    ret.assignedPersons.get(from).add(unassignedPerson);
                    ret.assignedPersons.get(from).remove(personToReassign);
                    List<PersonDTO> l = ret.assignedPersons.computeIfAbsent(to, k -> new ArrayList<>());
                    l.add(personToReassign);

                    found = true;
                    r = true;
                    break;
                }
            }

            if (!found) {
                pos++;
            }
        }

        if (r) {
            log.info("reduced unassiged set " + unassignedCount + " -> " + ret.unassignedPersons.size());
        }

    }

    private void handleMinimum(EvaluationResultDTO ret, Map<Integer, ProjectDTO> projectById,
                               List<SelectionDTO> selections) {

        // prepare datastructures
        final Map<ProjectDTO, Set<PersonDTO>> personsByProject = new HashMap<>();
        for (SelectionDTO s : selections) {

            for (Integer i : s.selections) {
                ProjectDTO p = projectById.get(i);
                Set<PersonDTO> ss = personsByProject.computeIfAbsent(p, k -> new HashSet<>());
                ss.add(s.person);
            }
        }

        Map<PersonDTO, ProjectDTO> assignedProjectByPerson = new HashMap<>();
        for (Map.Entry<ProjectDTO, List<PersonDTO>> p : ret.assignedPersons.entrySet()) {
            for (PersonDTO pe : p.getValue()) {
                assignedProjectByPerson.put(pe, p.getKey());
            }
        }

        // Now check if minimum is not reached
        Set<ProjectDTO> projectSizeTooSmall = new LinkedHashSet<>();
        for (ProjectDTO p : projectById.values()) {
            if (p.maxSize > 0
                    && (ret.assignedPersons.get(p) == null || p.minSize > ret.assignedPersons.get(p).size())) {
                projectSizeTooSmall.add(p);
            }
        }

        int projectsTooSmallBefore = projectSizeTooSmall.size();

        for (ProjectDTO tooSmallProject : projectSizeTooSmall) {
            log.fine("check project " + tooSmallProject + " with " + (ret.assignedPersons.get(tooSmallProject) != null
                    ? ret.assignedPersons.get(tooSmallProject).size() : 0) + " persons");
            Set<PersonDTO> personsVotedForProject = personsByProject.get(tooSmallProject);
            if (personsVotedForProject == null) {
                // nobody voted for this project
                continue;
            }

            log.fine(tooSmallProject + ": #persons=" + personsVotedForProject.size() + " voted the project. So go on");

            // loop over all persons who voted a too-small-project
            for (PersonDTO person : personsVotedForProject) {
                log.fine("check if " + person + " can be reassigned");
                ProjectDTO assignedProj = assignedProjectByPerson.get(person);

                // can person be reassigned to a tooSmallProject?
                boolean b = reassign(ret, person, assignedProj, tooSmallProject);
                if (b) {
                    assignedProjectByPerson.put(person, tooSmallProject);
                }

                if (ret.assignedPersons.get(tooSmallProject) != null
                        && ret.assignedPersons.get(tooSmallProject).size() >= tooSmallProject.minSize) {
                    log.fine("now it's enough");
                    break;
                }
            }
        }

        int projectsTooSmallAfter = 0;
        for (ProjectDTO p : projectById.values()) {
            if (p.maxSize > 0
                    && (ret.assignedPersons.get(p) == null || p.minSize > ret.assignedPersons.get(p).size())) {
                projectsTooSmallAfter++;
            }
        }

        log.info("reduced projects too small " + projectsTooSmallBefore + " -> " + projectsTooSmallAfter);
    }

    private boolean reassign(EvaluationResultDTO ret, PersonDTO person, ProjectDTO assignedProj, ProjectDTO p) {

        if (assignedProj != null && assignedProj.equals(p)) {
            return false;
        }

        int countOld = assignedProj != null ? ret.assignedPersons.get(assignedProj).size() : 0;
        int countNew = (ret.assignedPersons.get(p) != null ? ret.assignedPersons.get(p).size() : 0);
        if ((assignedProj == null || countOld > assignedProj.minSize) && countNew < p.maxSize) {
            log.fine("reassign " + person + ": " + assignedProj + " -> " + p + "(" + countOld + ")");
            boolean b = assignedProj == null || ret.assignedPersons.get(assignedProj).remove(person);
            if (!b && !ret.unassignedPersons.contains(person)) {
                log.warning("not assigned" + assignedProj + ";" + person);
                throw new IllegalStateException("not assigned" + assignedProj + ";" + person);
            }
            List<PersonDTO> persns = ret.assignedPersons.computeIfAbsent(p, k -> new ArrayList<>());
            persns.add(person);

            return true;
        } else {
            log.fine("do not reassign, because project " + assignedProj + " will be too small or too big");
        }
        return false;
    }

    private Object[] findPersonToReassign(int projectToRelease, Set<Integer> attractiveProjects,
                                          Map<ProjectDTO, List<PersonDTO>> pm, Map<PersonDTO, SelectionDTO> selectionsByPerson) {

        log.fine("check if prj " + projectToRelease + " can be released");

        ProjectDTO ptmp = new ProjectDTO();
        ptmp.id = projectToRelease;
        List<PersonDTO> pdl = pm.get(ptmp);
        if (pdl == null) {
            pdl = Collections.emptyList();
        }
        List<PersonDTO> personsWhoSelectedProject = new ArrayList<>(pdl);
        Collections.reverse(personsWhoSelectedProject);
        for (PersonDTO p : personsWhoSelectedProject) {
            SelectionDTO selection = selectionsByPerson.get(p);
            log.fine("check person " + p + " with selections " + selection);
            for (int c = 0; c < selection.selections.size(); c++) {
                log.fine(selection.selections.get(c) + " matches " + projectToRelease + "?");
                if (selection.selections.get(c) == projectToRelease) {
                    log.fine("hit position " + c);
                    c++;
                    while (c < selection.selections.size()) {
                        if (!attractiveProjects.contains(selection.selections.get(c))) {
                            log.fine("reassign " + p + " from " + projectToRelease + " to project "
                                    + selection.selections.get(c));
                            // ret.assignedPersons.get(key)
                            return new Object[]{p, selection.selections.get(c)};
                        }
                        c++;
                    }
                }
            }
        }
        return null;
    }

    private void handleMoveToBetterProjects(EvaluationResultDTO result, Map<Integer, ProjectDTO> projectById,
                                            List<SelectionDTO> selections) {
        Map<Integer, List<PersonDTO>> userByPos;

        // prepare datastructures
        Map<PersonDTO, List<Integer>> selectionByUser = new HashMap<>();
        for (SelectionDTO s : selections) {
            selectionByUser.put(s.person, s.selections);
        }

        boolean found;
        do {

            log.info("reading userByPos");
            userByPos = getAssignedUsersByPosition(result, selections);

            found = handleMoveToBetterProjects(result, projectById, userByPos, selectionByUser);
        } while (found);
    }

    private boolean handleMoveToBetterProjects(EvaluationResultDTO result, Map<Integer, ProjectDTO> projectById,
                                               Map<Integer, List<PersonDTO>> userByPos, Map<PersonDTO, List<Integer>> selectionByUser) {

        boolean found = false;
        for (Map.Entry<Integer, List<PersonDTO>> entry : userByPos.entrySet()) {
            int currentPos = entry.getKey();
            if (currentPos == 1) {
                return false;
            }

            log.fine("currentPos=" + currentPos);

            for (PersonDTO p : entry.getValue()) {

                ProjectDTO oldPrj = null;
                if (currentPos != POS_NOT_ASSIGNED) {
                    int oldPrjId = selectionByUser.get(p).get(currentPos - 1);
                    oldPrj = projectById.get(oldPrjId);
                }

                // check if there is a better pos for user p
                for (int i = 0; i < selectionByUser.get(p).size() - 1 && i < currentPos - 1; i++) {

                    int prjId = selectionByUser.get(p).get(i);
                    ProjectDTO prj = projectById.get(prjId);
                    result.assignedPersons.computeIfAbsent(prj, k -> new ArrayList<>());
                    if ((oldPrj == null || (result.assignedPersons.get(oldPrj).size() > oldPrj.minSize)
                            && result.assignedPersons.get(prj).size() < prj.maxSize)) {
                        log.fine("shift " + p + " from pos " + currentPos + " to " + (i + 1) + " (" + prj + ")");
                        boolean b = reassign(result, p, oldPrj, prj);
                        if (b) {
                            found = true;
                            break;
                        }
                    }

                }
            }

            if (found) {
                break;
            }
        }

        return found;
    }

    private Map<Integer, List<PersonDTO>> getAssignedUsersByPosition(EvaluationResultDTO result,
                                                                     List<SelectionDTO> selections) {

        Map<PersonDTO, List<Integer>> selectionsByUser = new HashMap<>();
        for (SelectionDTO s : selections) {
            selectionsByUser.put(s.person, s.selections);
        }

        Map<Integer, List<PersonDTO>> positionByUser = new TreeMap<>((o1, o2) -> o2 - o1);

        for (PersonDTO p : result.unassignedPersons) {
            List<PersonDTO> l = positionByUser.computeIfAbsent(POS_NOT_ASSIGNED, k -> new ArrayList<>());
            l.add(p);
        }

        for (Map.Entry<ProjectDTO, List<PersonDTO>> entry : result.assignedPersons.entrySet()) {
            for (PersonDTO person : entry.getValue()) {
                for (int i = 0; i < selectionsByUser.get(person).size(); i++) {
                    if ((selectionsByUser.get(person)).get(i) == entry.getKey().id) {
                        List<PersonDTO> l = positionByUser.computeIfAbsent(i + 1, k -> new ArrayList<>());
                        l.add(person);
                        break;
                    }
                }
            }
        }

        return positionByUser;
    }

}
