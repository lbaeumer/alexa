package de.quaestio24.exception;

import java.io.IOException;

public class HttpIoException extends IOException {

    private static final long serialVersionUID = -3161071310735465712L;

    private int rc;

    public HttpIoException() {
        super();
    }

    public HttpIoException(String message, Throwable cause) {
        super(message, cause);
    }

    public HttpIoException(String message) {
        super(message);
    }

    public HttpIoException(String message, int rc) {
        super(message);
        this.rc = rc;
    }

    public HttpIoException(int rc) {
        this.rc = rc;
    }

    public HttpIoException(Throwable cause) {
        super(cause);
    }

    public int getResponseCode() {
        return rc;
    }

    @Override
    public String getMessage() {
        return super.getMessage() + " with rc " + rc;
    }
}
