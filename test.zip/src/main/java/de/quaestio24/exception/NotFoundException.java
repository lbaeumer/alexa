package de.quaestio24.exception;

public class NotFoundException extends java.lang.SecurityException {

    private static final long serialVersionUID = -3161071310735465712L;

    public String message;
    public int errorCode;

    public NotFoundException(String s, int errorCode) {
        super(s);
        message = s;
        this.errorCode = errorCode;
    }
}
