package de.quaestio24.exception;

import java.util.List;

public class ValidationException extends RuntimeException {

    private static final long serialVersionUID = -3161071310735465712L;
    public List<String> messages;
    public int errorCode = 400;

    public ValidationException() {
    }

    public ValidationException(List<String> messages) {
        this.messages = messages;
    }

    public ValidationException(List<String> messages, int errorCode) {
        this(messages);
        this.errorCode = errorCode;
    }

    @Override
    public String toString() {
        return "ValidationException [messages=" + messages + ", errorCode=" + errorCode + "]";
    }
}
