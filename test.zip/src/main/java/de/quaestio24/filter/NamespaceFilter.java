package de.quaestio24.filter;

import com.google.appengine.api.NamespaceManager;
import de.quaestio24.entity.Site;
import de.quaestio24.util.SystemConfig;
import de.quaestio24.util.UrlUtil;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.logging.Logger;

public class NamespaceFilter implements Filter {

    private static final Logger log = Logger.getLogger(NamespaceFilter.class.getName());
    private final String URIS_WITHOUT_SITE_REGEXP;

    public NamespaceFilter() {
        URIS_WITHOUT_SITE_REGEXP = SystemConfig.getProperties().getProperty("urisWithoutSiteRegExp");
    }

    @Override
    public void doFilter(ServletRequest req2, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest request = (HttpServletRequest) req2;

        log.fine("namespace filter " + request.getRequestURI());
        final Site site = UrlUtil.getSite(request);
        if (site == null) {
            if (!request.getRequestURI().matches(URIS_WITHOUT_SITE_REGEXP)) {
                log.warning("the site is null, so set the default namespace");
            } else {
                log.info("set namespace default, no site found");
            }
            NamespaceManager.set(null);
        } else {
            log.info("set namespace " + site + "; uri=" + request.getRequestURI());
            NamespaceManager.set(site.name());
        }

        chain.doFilter(request, response);
    }

    @Override
    public void destroy() {
    }

    @Override
    public void init(FilterConfig filterConfig) {
    }
}
