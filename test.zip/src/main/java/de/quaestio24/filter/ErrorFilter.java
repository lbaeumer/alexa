package de.quaestio24.filter;

import de.quaestio24.exception.NotAuthenticatedException;
import de.quaestio24.exception.NotAuthorizedException;
import de.quaestio24.exception.NotFoundException;
import de.quaestio24.util.SendMail;
import de.quaestio24.ws.NotAuthenticatedExceptionMapper;
import de.quaestio24.ws.NotAuthorizedExceptionMapper;
import de.quaestio24.ws.NotFoundExceptionMapper;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Date;
import java.util.Enumeration;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ErrorFilter implements Filter {

    private static final Logger log = Logger.getLogger(ErrorFilter.class.getName());

    @Override
    public void destroy() {
    }

    @Override
    public void doFilter(ServletRequest arg0, ServletResponse arg1, FilterChain arg2)
            throws IOException, ServletException {

        long s = System.currentTimeMillis();
        HttpServletRequest req = (HttpServletRequest) arg0;
        HttpServletResponse res = (HttpServletResponse) arg1;
        log.fine("before request " + req.getRequestURI());
        try {
            try {
                String delay = req.getParameter("delay");
                if (delay != null) {
                    try {
                        Thread.sleep(Integer.parseInt(delay));
                    } catch (Exception e) {
                        throw new IllegalStateException("Illegal parameter");
                    }
                }
            } catch (Exception e) {
                log.warning("exception while parsing " + e);
            }
            arg2.doFilter(req, res);
            int t = (int) (System.currentTimeMillis() - s);
            if (t < 2000) {
                log.fine("successfully finished request in " + t + "ms");
            } else if (t < 5000
                    || req.getRequestURI().startsWith("/ws/report/")
                    || req.getRequestURI().startsWith("/ws/cleanup")
                    || req.getRequestURI().startsWith("/ws/dashboard")
                    || req.getRequestURI().startsWith("/ws/notification")
                    || req.getRequestURI().endsWith("/resetasync")) {
                log.info("successfully finished request in " + t + "ms");
            } else {
                log.warning("successfully finished request in " + t + "ms");
            }
        } catch (NotAuthenticatedException e) {
            log.log(Level.INFO, "sending 401", e);
            Response r = new NotAuthenticatedExceptionMapper().toResponse(e);
            res.sendError(401, r.getEntity().toString());
        } catch (NotAuthorizedException e) {
            log.log(Level.INFO, "sending 403", e);
            Response r = new NotAuthorizedExceptionMapper().toResponse(e);
            res.sendError(403, r.getEntity().toString());
        } catch (NotFoundException e) {
            log.log(Level.INFO, "sending 404", e);
            Response r = new NotFoundExceptionMapper().toResponse(e);
            res.sendError(404, r.getEntity().toString());
        } catch (IOException e) {
            log.log(Level.SEVERE, "after request", e);
            new SendMail().send("Error on " + req.getServerName(), "<p>failed</p> <pre>" + txt(req, e) + "</pre>",
                    "Lui", "lui.baeumer@gmail.com", null, false);
            throw e; // res.sendRedirect("/500.jsp");
        } catch (ServletException e) {
            log.log(Level.SEVERE, "ServletException after request", e);
            new SendMail().send("Error on " + req.getServerName(), "<p>failed</p> <pre>" + txt(req, e) + "</pre>",
                    "Lui", "lui.baeumer@gmail.com", null, false);
            throw e; // res.sendRedirect("/500.jsp");
        } catch (RuntimeException e) {
            log.log(Level.SEVERE, "RuntimeException after request", e);
            new SendMail().send("Error on " + req.getServerName(), "<p>failed</p> <pre>" + txt(req, e) + "</pre>",
                    "Lui", "lui.baeumer@gmail.com", null, false);
            throw e; // res.sendRedirect("/500.jsp");
        } catch (Error e) {
            log.log(Level.SEVERE, "after request", e);
            if (e.getCause() != null) {
                log.log(Level.SEVERE, "caused by ", e.getCause());
            }
            new SendMail().send("Error on " + req.getServerName(), "<p>failed</p> <pre>" + txt(req, e) + "</pre>",
                    "Lui", "lui.baeumer@gmail.com", null, false);
            throw e; // res.sendRedirect("/500.jsp");
        }
    }

    @Override
    public void init(FilterConfig arg0) {
    }

    private String txt(ServletRequest req, Throwable t) {
        StringWriter s = new StringWriter();
        PrintWriter p = new PrintWriter(s, true);
        t.printStackTrace(p);
        p.close();

        StringBuilder data = new StringBuilder("date=" + new Date() + "\n");
        if (req instanceof HttpServletRequest) {
            HttpServletRequest r = (HttpServletRequest) req;
            data.append("contextPath=").append(r.getContextPath()).append("\n\n");
            data.append("reqestUrl=").append(r.getRequestURL()).append("\n\n");
            data.append("reqestUri=").append(r.getRequestURI()).append("\n\n");
            data.append("queryString=").append(r.getQueryString()).append("\n\n");
            data.append("uri=").append(r.getRequestURI()).append("\n\n");
            @SuppressWarnings("rawtypes")
            Enumeration e = r.getHeaderNames();
            while (e.hasMoreElements()) {
                String h = e.nextElement().toString();
                String v = r.getHeader(h);
                data.append(h).append("=").append(v).append("\n");
            }
        }
        data.append("remote=").append(req.getRemoteAddr()).append("/").append(req.getRemoteHost()).append(":").append(req.getRemotePort()).append("\n");

        return data + s.getBuffer().toString();
    }
}
