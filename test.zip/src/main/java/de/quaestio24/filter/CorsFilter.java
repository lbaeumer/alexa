package de.quaestio24.filter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Enumeration;
import java.util.logging.Logger;

public class CorsFilter implements Filter {

    private static final Logger log = Logger.getLogger(CorsFilter.class.getName());

    @Override
    public void destroy() {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;

        Enumeration<String> headers = req.getHeaderNames();
        while (headers.hasMoreElements()) {
            String h = headers.nextElement();
            log.fine(h + "->" + req.getHeader(h));

        }

        resp.setCharacterEncoding("UTF-8");
        log.fine(request.getServerName() + "/" + request.getRemoteHost() + ":" + request.getRemotePort() + ";"
                + request.getLocalAddr() + "/" + request.getLocalName() + "/" + request.getLocalPort());

        final String origin = req.getHeader("origin");
        if (origin == null || !origin.matches(".*(androidsolutions|quaestio24|localhost).*")) {
            // normal website
            resp.addHeader("Access-Control-Allow-Origin", "*");
        } else {
            // admin
            resp.addHeader("Access-Control-Allow-Origin", origin);
            resp.addHeader("Access-Control-Allow-Credentials", "true");
        }

        resp.addHeader("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS");
        resp.addHeader("Access-Control-Allow-Headers", "Content-Type, Access-Control-Allow-Headers, Authorization");

        if (req.getMethod().equalsIgnoreCase("GET")) {
            resp.addHeader("Cache-Control", "no-cache, no-store, must-revalidate");
            resp.addHeader("Pragma", "no-cache");
            resp.addHeader("Expires", "0");
        }

        chain.doFilter(request, response);
    }

    @Override
    public void init(FilterConfig arg0) {
    }
}
