package de.quaestio24.ws;

import de.quaestio24.annotation.EnforceXsrf;
import de.quaestio24.dto.ProjectDTO;
import de.quaestio24.dto.ProjectListDTO;
import de.quaestio24.entity.Site;
import de.quaestio24.service.ProjectImportService;
import de.quaestio24.service.ProjectService;
import io.swagger.v3.oas.annotations.Operation;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

@Path("/project")
public class ProjectResources {
    private static final Logger log = Logger.getLogger(ProjectResources.class.getName());

    @Context
    UriInfo uriInfo;

    private ProjectService projectService = new ProjectService();

    @GET
    @Path("/{site}/nocache/list")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"project"})
    @PermitAll
    public Response getProjectsNoCache(@PathParam("site") Site site) {

        log.info("getProjectsNoCache(" + site + ")");

        ProjectListDTO pl = new ProjectListDTO();
        pl.projects = projectService.getProjectsDetail();

        log.info("found " + pl.projects.size() + " projects");
        projectService.addStatus(pl.projects);

        return Response.ok(pl).build();
    }

    @GET
    @EnforceXsrf(onlyReport = true)
    @Path("/{site}/list")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"project"})
    @PermitAll
    public Response getProjects(@PathParam("site") Site site) {

        log.info("getProjects(" + site + ")");

        ProjectListDTO pl = new ProjectListDTO();
        pl.projects = projectService.getProjects();

        log.info("found " + pl.projects.size() + " projects");
        projectService.addStatus(pl.projects);

        return Response.ok(pl).build();
    }

    @GET
    @EnforceXsrf(onlyReport = true)
    @Path("/{site}/{id}")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"project"})
    @PermitAll
    public Response getProjectDetails(@PathParam("site") Site site, @PathParam("id") int id) {

        log.info("getProject(" + site + "," + id + ")");

        ProjectDTO p = projectService.getProject(id);

        log.info("found " + p);

        return Response.ok(p).build();
    }

    @POST
    @EnforceXsrf
    @Path("/{site}/update")
    @Produces("application/json; charset=UTF-8")
    @Consumes("application/json")
    @Operation(tags = {"project"})
    @RolesAllowed("teacher")
    public Response updateProject(@PathParam("site") Site site, ProjectDTO regr) {

        log.info("updateProject(" + site + ", " + regr + ")");

        ProjectDTO p = projectService.updateProject(regr);
        return Response.ok(p).build();
    }

    @POST
    @EnforceXsrf
    @Path("/{site}/insert")
    @Produces("application/json; charset=UTF-8")
    @Consumes("application/json")
    @Operation(tags = {"project"})
    @RolesAllowed("teacher")
    public Response addProject(@PathParam("site") Site site, ProjectDTO regr) {

        log.info("addProject(" + site + ", " + regr + ")");

        ProjectDTO p = projectService.addProject(regr);
        return Response.ok(p).build();
    }

    @POST
    @EnforceXsrf
    @Path("/{site}/insertall")
    @Produces("application/json; charset=UTF-8")
    @Consumes("application/json")
    @Operation(tags = {"project"})
    @RolesAllowed("teacher")
    public Response addProjects(@PathParam("site") Site site, List<ProjectDTO> regr) {

        log.info("addProjects(" + site + ")");

        List<ProjectDTO> p = projectService.addProjects(regr, true);
        return Response.ok(p).build();
    }

    @POST
    @EnforceXsrf
    @Path("/{site}/delete")
    @Produces("application/json; charset=UTF-8")
    @Consumes("application/json")
    @Operation(tags = {"project"})
    @RolesAllowed("teacher")
    public Response deleteProject(@PathParam("site") Site site, String id) {

        log.info("deleteProject(" + site + ", " + id + ")");
        projectService.deleteProject(Integer.parseInt(id));
        return Response.ok().build();
    }

    @POST
    @EnforceXsrf
    @Path("/{site}/deleteall")
    @Produces("application/json; charset=UTF-8")
    @Consumes("application/json")
    @Operation(tags = {"project"})
    @RolesAllowed("superadmin")
    public Response deleteProject(@PathParam("site") Site site) {

        log.info("deleteAllProjects(" + site + ")");

        ProjectListDTO pl = new ProjectListDTO();
        pl.projects = projectService.deleteAllProjects();

        return Response.ok(pl).build();
    }

    @GET
    @Path("/{site}/projects-{site1}.xls")
    @Produces("text/csv; charset=UTF-8")
    @Operation(tags = {"project"})
    @RolesAllowed("teacher")
    public Response getAllProjectsXls(@PathParam("site") Site site, @PathParam("site1") String site1) {

        log.info("getAllProjects " + site);
        ProjectImportService projService = new ProjectImportService();
        return Response.ok(projService.getAllProjectsXls()).build();
    }

    @POST
    @EnforceXsrf
    @Path("/{site}/fixnumbers")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"project"})
    @RolesAllowed("superadmin")
    public Response fixNumbers(@PathParam("site") Site site) {
        Map<Integer, Integer> ret = projectService.fixNumbers();

        return Response.ok(ret).build();
    }
}
