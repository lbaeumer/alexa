package de.quaestio24.ws;

import com.google.gson.Gson;
import de.quaestio24.annotation.EnforceXsrf;
import de.quaestio24.dto.AuthDTO;
import de.quaestio24.entity.Site;
import de.quaestio24.service.AuthService;
import io.swagger.v3.oas.annotations.Operation;

import javax.annotation.security.RolesAllowed;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.logging.Logger;

@Path("/auth")
public class AuthResources {
    private static final Logger log = Logger.getLogger(AuthResources.class.getName());

    private AuthService authService = new AuthService();

    @GET
    @EnforceXsrf
    @Path("/{site}/list")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"auth"})
    @RolesAllowed("superadmin")
    public Response getAuths(@PathParam("site") Site site) {

        log.info("getAuths(" + site + ")");
        List<AuthDTO> list = authService.getAllAuths();
        return Response.ok(list).build();
    }

    @POST
    @EnforceXsrf
    @Path("/{site}/delete")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"auth"})
    @RolesAllowed("superadmin")
    public Response deleteAuth(@PathParam("site") Site site, String right) {

        log.info("deleteAuth(" + site + ", " + right + ")");
        AuthDTO a = new Gson().fromJson(right, AuthDTO.class);
        List<AuthDTO> l = authService.deleteAuth(a);
        return Response.ok(l).build();
    }
}
