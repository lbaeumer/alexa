package de.quaestio24.ws;

import de.quaestio24.dto.AssignedProjectListDTO;
import de.quaestio24.dto.PreferencesDTO.Parameter;
import de.quaestio24.dto.ReportDTO;
import de.quaestio24.entity.Site;
import de.quaestio24.service.PreferencesService;
import de.quaestio24.service.ReportingService;
import de.quaestio24.service.dto.AssignedProjectListIntDTO;
import io.swagger.v3.oas.annotations.Operation;

import javax.annotation.security.RolesAllowed;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import java.util.logging.Logger;

@Path("/report")
public class ReportResources {
    private static final Logger log = Logger.getLogger(ReportResources.class.getName());

    private ReportingService reportingService = new ReportingService();
    private PreferencesService preferences = new PreferencesService();

    @GET
    @Path("/{site}/assigned-{site1}.xls")
    @Produces("application/vnd.ms-excel")
    @Operation(tags = {"report"})
    @RolesAllowed("teacher")
    public Response getAssignedReportXLS(@PathParam("site") Site site, @PathParam("site1") String site1,
                                         @Context UriInfo uriInfo) {

        log.info("getAssignedReport(" + site + ")");
        // Parameter parameters = preferences.getPreference().parameter;
        // overwriteParameter(parameters, uriInfo.getQueryParameters());
        // log.info("parameters=" + parameters);
        return Response.ok(reportingService.getAssignedReportXLS(null)).build();
    }

    @GET
    @Path("/{site}/stats.json")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"report"})
    @RolesAllowed("teacher")
    public Response getStats(@PathParam("site") Site site) {

        log.info("getStats2(" + site + ")");
        ReportDTO map = reportingService.getReport();
        return Response.ok(map).build();
    }

    @GET
    @Path("/{site}/assigned.json")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"report"})
    @RolesAllowed("teacher")
    public Response getAssigned(@PathParam("site") Site site, @Context UriInfo uriInfo) {

        log.info("getAssigned(" + site + ")");
        Parameter parameters = preferences.getPreference().parameter;

        overwriteParameter(parameters, uriInfo.getQueryParameters());
        log.info("parameters=" + parameters);

        AssignedProjectListIntDTO retdto = reportingService.getAssignedProjects(parameters);

        return Response.ok(new AssignedProjectListDTO(retdto)).build();
    }

    private void overwriteParameter(Parameter parameters, MultivaluedMap<String, String> queryParams) {

        for (String s : queryParams.keySet()) {
            if ("randomize".equals(s)) {
                parameters.randomize = Boolean.parseBoolean(queryParams.getFirst(s));
            }
            if ("skipMinimum".equals(s)) {
                parameters.skipMinimum = Boolean.parseBoolean(queryParams.getFirst(s));
            }
            if ("only2nd".equals(s)) {
                parameters.only2nd = Boolean.parseBoolean(queryParams.getFirst(s));
            }
            if ("ignoreEmptyProjects".equals(s)) {
                parameters.ignoreEmptyProjects = Boolean.parseBoolean(queryParams.getFirst(s));
            }
        }
    }
}
