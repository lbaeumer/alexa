package de.quaestio24.ws;

import de.quaestio24.annotation.EnforceXsrf;
import de.quaestio24.dto.SelectionDTO;
import de.quaestio24.service.SelectionService;
import de.quaestio24.util.CacheUtil;
import io.swagger.v3.oas.annotations.Operation;

import javax.annotation.security.RolesAllowed;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.util.List;
import java.util.logging.Logger;

@Path("/upload-selection")
public class UploadSelectionResources {

    private static final Logger log = Logger.getLogger(UploadSelectionResources.class.getName());

    @Context
    private HttpServletRequest request;

    @POST
    @EnforceXsrf
    @Path("/{site}")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"upload"})
    @RolesAllowed("admin")
    public Response upload(@PathParam("site") String site) throws IOException {

        log.info("upload new data");

        SelectionService sservice = new SelectionService();
        sservice.skipValidation(true);
        List<SelectionDTO> sel = sservice.parseSelectionCSV(request.getInputStream());
        sservice.insertSelections(sel);
        CacheUtil.clear();

        return Response.ok(sel).build();
    }
}
