package de.quaestio24.ws;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import de.quaestio24.annotation.BulkProtection;
import de.quaestio24.annotation.EnforceXsrf;
import de.quaestio24.dto.PersonDTO;
import de.quaestio24.dto.ProjectListDTO;
import de.quaestio24.dto.SelectionDTO;
import de.quaestio24.dto.SelectionResponseDTO;
import de.quaestio24.dto.ValidationDTO;
import de.quaestio24.entity.Site;
import de.quaestio24.exception.ValidationException;
import de.quaestio24.service.IpfilterService;
import de.quaestio24.service.SelectionService;
import io.swagger.v3.oas.annotations.Operation;
import org.apache.log4j.MDC;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import java.io.Serializable;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

@Path("/selection")
public class SelectionResources {
    private static final Logger log = Logger.getLogger(SelectionResources.class.getName());

    @Context
    UriInfo uriInfo;

    @Context
    HttpServletRequest request;

    private SelectionService selectionService = new SelectionService();
    private IpfilterService ipfilterService = new IpfilterService();

    private Gson gson = new Gson();

    @POST
    @EnforceXsrf(onlyReport = true)
    @Path("/{site}/insert/force")
    @Produces("application/json; charset=UTF-8")
    @Consumes("application/json")
    @Operation(tags = {"selection"})
    @RolesAllowed("admin")
    public Response insertSelectionForce(@PathParam("site") Site site, String json) {
        return insertSelection2(true, json);
    }

    @POST
    @EnforceXsrf(onlyReport = true)
    @BulkProtection(onlyReport = true)
    @Path("/{site}/insert")
    @Produces("application/json; charset=UTF-8")
    @Consumes("application/json")
    @Operation(tags = {"selection"})
    @PermitAll
    public Response insertSelection(@PathParam("site") Site site, String json) {
        return insertSelection2(false, json);
    }

    private Response insertSelection2(boolean force, String json) {

        log.info("insertSelection(" + json + "; userAgent=" + request.getHeader("User-Agent") + "/"
                + request.getRemoteHost());
        if (json == null || json.length() == 0) {
            log.warning("illegal request, payload is null");
            throw new ValidationException();
        }
        SelectionDTO regr;
        try {
            regr = gson.fromJson(json, SelectionDTO.class);
        } catch (JsonSyntaxException ex) {
            SelectionDTO2 regr2 = gson.fromJson(json, SelectionDTO2.class);
            regr = new SelectionDTO();
            regr.created = regr2.created;
            regr.id = regr2.id;
            regr.idHost = regr2.idHost;
            regr.idUserAgent = regr2.idUserAgent;
            regr.person = regr2.person;
            regr.selections = new ArrayList<>();
            for (SelectionProject p : regr2.selections) {
                regr.selections.add(p.id);
            }
        }

        regr.idHost = request.getRemoteAddr();
        regr.idUserAgent = request.getHeader("User-Agent");
        regr.created = new Date();

        String host = uriInfo.getRequestUri().getHost()
                + (uriInfo.getRequestUri().getPort() > 80 ? ":" + uriInfo.getRequestUri().getPort() : "");

        selectionService.skipValidation(force);
        try {
            SelectionResponseDTO response = selectionService.insert(regr, host);
            String ret = gson.toJson(response, SelectionResponseDTO.class);
            log.info("return " + ret);

            return Response.ok(ret).build();
        } finally {
            selectionService.skipValidation(false);
        }
    }

    @POST
    @EnforceXsrf
    @Path("/{site}/insertall")
    @Produces("application/json; charset=UTF-8")
    @Consumes("application/json")
    @Operation(tags = {"selection"})
    @RolesAllowed("admin")
    public Response insertSelections(@PathParam("site") Site site, String json) {

        log.info("insertSelections(" + json + "; userAgent=" + request.getHeader("User-Agent") + "/"
                + request.getRemoteHost());
        if (json == null || json.length() == 0) {
            log.warning("illegal request, payload is null");
            throw new ValidationException();
        }

        Type collectionType = new TypeToken<List<SelectionDTO>>() {
        }.getType();

        List<SelectionDTO> regr = gson.fromJson(json, collectionType);

        SelectionService selService = new SelectionService();
        selService.skipValidation(true);
        selService.insertSelections(regr);
        return Response.ok().build();
    }

    @POST
    @EnforceXsrf
    @Path("/{site}/update")
    @Produces("application/json; charset=UTF-8")
    @Consumes("application/json")
    @Operation(tags = {"selection"})
    @RolesAllowed("admin")
    public Response updateSelection(@PathParam("site") Site site, String json) {

        log.info("updateSelection(" + json + ")");
        SelectionDTO regr = gson.fromJson(json, SelectionDTO.class);

        String host = uriInfo.getRequestUri().getHost()
                + (uriInfo.getRequestUri().getPort() > 80 ? ":" + uriInfo.getRequestUri().getPort() : "");
        regr.created = new Date();

        SelectionResponseDTO response = selectionService.update(regr, host);
        String ret = gson.toJson(response, SelectionResponseDTO.class);
        log.info("return " + ret);

        return Response.ok(ret).build();
    }

    @POST
    @EnforceXsrf
    @Path("/{site}/delete")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"selection"})
    @RolesAllowed("admin")
    public void deleteSelection(@PathParam("site") Site site, String selectionid) {

        log.info("deleteSelection(" + selectionid + ")");
        selectionService.deleteSelection(selectionid);
    }

    @POST
    @EnforceXsrf
    @Path("/{site}/deleteall")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"selection"})
    @RolesAllowed("admin")
    public void deleteSelection(@PathParam("site") Site site) {

        log.info("deleteAllSelection(" + site + ")");
        selectionService.deleteAllSelection();
    }

    @GET
    @EnforceXsrf
    @Path("/{site}/list")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"selection"})
    @RolesAllowed("teacher")
    public Response getAllSelections(@PathParam("site") Site site) {

        log.info("getAllSelections(" + site + ")");
        List<SelectionDTO> selections = selectionService.getAllSelection();

        return Response.ok(selections).build();
    }

    @GET
    @EnforceXsrf
    @BulkProtection(onlyReport = true)
    @Path("/{site}/validate")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"selection"})
    @PermitAll
    public Response isCodeValid(@PathParam("site") Site site, @QueryParam("code") String code,
                                @QueryParam("clazz") String clazz) {

        log.info("isCodeValid(" + site + ", " + code + ", " + clazz + ")");

        ValidationDTO v;
        if (code != null) {
            v = selectionService.isCodeValid(code);
            ipfilterService.clearCache("isCodeValid", (String) MDC.get("token"));
        } else {
            v = selectionService.isClassValid(clazz);
        }

        return Response.ok(v).build();
    }

    @GET
    @Path("/{site}/verify/{id}")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"selection"})
    @PermitAll
    public Response getProjectsAndVerify(@PathParam("site") Site site, @PathParam("id") String selectionId) {

        log.info("getProjectsAndVerify(" + site + ", " + selectionId + ")");

        ProjectListDTO pl = selectionService.verifySelection(selectionId);
        return Response.ok(pl).build();
    }

    @GET
    @Path("/{site}/count")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"selection"})
    @PermitAll
    public Response getSelectionCount(@PathParam("site") Site site) {

        log.info("selectionEndpoint count(" + site + ")");

        List<Integer> cnt = selectionService.getSelectionCount();
        return Response.ok(cnt).build();
    }

    @GET
    @EnforceXsrf
    @Path("/{site}/{selectionId}")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"selection"})
    @RolesAllowed("teacher")
    public Response getSelection(@PathParam("site") Site site, @PathParam("selectionId") String selectionId) {

        log.info("selectionEndpoint doGet(" + site + ")");
        SelectionDTO selection = selectionService.getSelection(selectionId);

        return Response.ok(selection).build();
    }

    @GET
    @EnforceXsrf
    @Path("/{site}/selection-{site1}.csv")
    @Produces("text/csv; charset=ISO-8859-1")
    @Operation(tags = {"selection"})
    @RolesAllowed("teacher")
    public Response getAllSelectionsCsv(@PathParam("site") Site site, @PathParam("site1") String site1) {

        log.info("selectionEndpoint doGet");
        List<SelectionDTO> selections = selectionService.getAllSelection();
        String s = selectionService.convertToCsv(selections);
        return Response.ok(s).build();
    }

    @GET
    @EnforceXsrf
    @Path("/{site}/history-{site1}.csv")
    @Produces("text/csv; charset=ISO-8859-1")
    @Operation(tags = {"selection"})
    @RolesAllowed("teacher")
    public Response getAllHistorySelectionsCsv(@PathParam("site") Site site, @PathParam("site1") String site1) {

        log.info("selectionEndpoint doGet");
        List<SelectionDTO> selections = selectionService.getAllHistorySelection();
        return Response.ok(selectionService.convertToCsv(selections)).build();
    }

    private static class SelectionDTO2 implements Serializable {
        private static final long serialVersionUID = 1L;

        public String id;

        public PersonDTO person;

        @NotNull(message = "Bitte mindestens 1 Projekt auswählen.")
        @Size(min = 1, max = 256, message = "Bitte mindestens 1 Projekt auswählen.", payload = SelectionValidationPayload.Error440.class)
        public List<SelectionProject> selections;

        public Date created;

        public String idHost, idUserAgent;
    }

    private static class SelectionProject implements Serializable {
        private static final long serialVersionUID = 1L;

        public int id;
    }
}
