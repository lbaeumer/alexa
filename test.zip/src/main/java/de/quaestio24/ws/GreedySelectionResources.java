package de.quaestio24.ws;

import de.quaestio24.entity.Site;
import de.quaestio24.service.FcfsSelectionService;
import io.swagger.v3.oas.annotations.Operation;

import javax.annotation.security.PermitAll;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

@Path("/greedy")
public class GreedySelectionResources {
    private static final Logger log = Logger.getLogger(GreedySelectionResources.class.getName());

    private FcfsSelectionService greedyService = new FcfsSelectionService();

    @POST
    @Path("/{site}/sync")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"person"})
    @PermitAll
    public Response sync(@PathParam("site") Site site, @QueryParam("dryRun") Boolean dryRun) {

        log.info("sync(" + site + ")");
        Map<Integer, List<Integer>> sel = greedyService.sync(dryRun != null ? dryRun : false);

        return Response.ok(sel).build();
    }
}
