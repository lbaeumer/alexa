package de.quaestio24.ws;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import de.quaestio24.dto.DashboardDTO;
import de.quaestio24.dto.SiteDTO;
import de.quaestio24.entity.Site;
import de.quaestio24.service.DashboardService;
import io.swagger.v3.oas.annotations.Operation;

import javax.annotation.security.RolesAllowed;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import java.util.logging.Logger;

@Path("/dashboard")
public class DashboardResources {

    private static final Logger log = Logger.getLogger(DashboardResources.class.getName());
    private DashboardService dashboardService = new DashboardService();

    @GET
    @Path("/get")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"dashboard"})
    @RolesAllowed("superadmin")
    public Response getDashboard() {

        log.info("getDashboard");

        DashboardDTO dashboard = dashboardService.getDashboard();

        Gson gson1 = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss.sssZ").setPrettyPrinting().create();
        ResponseBuilder builder = Response.ok(gson1.toJson(dashboard));

        return builder.build();
    }

    @GET
    @Path("/{site}/get")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"dashboard"})
    @RolesAllowed("superadmin")
    public Response getSite(@PathParam("site") Site tmpSite) {

        log.info("getSite" + tmpSite);
        SiteDTO site = dashboardService.getSite();

        Gson gson1 = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss.sssZ").setPrettyPrinting().create();
        ResponseBuilder builder = Response.ok(gson1.toJson(site));

        return builder.build();
    }
}
