package de.quaestio24.ws;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import de.quaestio24.annotation.EnforceXsrf;
import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.entity.Site;
import de.quaestio24.service.PreferencesService;
import io.swagger.v3.oas.annotations.Operation;

import javax.annotation.security.RolesAllowed;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import java.util.logging.Logger;

@Path("/preference")
public class PreferenceResources {
    private static final Logger log = Logger.getLogger(PreferenceResources.class.getName());

    @Context
    UriInfo uriInfo;

    private Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss.sssZ").create();
    private PreferencesService preferenceService = new PreferencesService();

    @GET
    @Path("/{site}/get")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"preference"})
    @RolesAllowed("teacher")
    public Response getPreferences(@PathParam("site") Site site) {

        log.info("getPreferences(" + site + ")");
        PreferencesDTO pref = preferenceService.getPreference(false);

        return Response.ok(pref).build();
    }

    @POST
    @EnforceXsrf
    @Path("/{site}/update")
    @Produces("application/json; charset=UTF-8")
    @Consumes("application/json")
    @Operation(tags = {"preference"})
    @RolesAllowed("teacher")
    public Response updatePreference(@PathParam("site") Site site, String json) {

        log.info("updatePreference(" + site + ", " + json + ")");
        PreferencesDTO pref = gson.fromJson(json, PreferencesDTO.class);

        PreferencesDTO p = preferenceService.updatePreference(pref);
        return Response.ok(p).build();
    }

    @POST
    @EnforceXsrf
    @Path("/{site}/update/advanced")
    @Produces("application/json; charset=UTF-8")
    @Consumes("application/json")
    @Operation(tags = {"preference"})
    @RolesAllowed("admin")
    public Response updatePreferenceAdvanced(@PathParam("site") Site site, String json) {

        log.info("updatePreferenceAdvanced(" + site + ", " + json + ")");
        PreferencesDTO pref = gson.fromJson(json, PreferencesDTO.class);

        PreferencesDTO p = preferenceService.updatePreference(pref);
        return Response.ok(p).build();
    }
}
