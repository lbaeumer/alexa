package de.quaestio24.ws;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import de.quaestio24.dto.ConfigDTO;
import de.quaestio24.dto.ErrorDTO;
import de.quaestio24.entity.Site;
import de.quaestio24.service.ConfigService;
import de.quaestio24.util.UrlUtil;
import de.quaestio24.util.XsrfUtil;
import io.swagger.v3.oas.annotations.Operation;
import org.apache.log4j.MDC;

import javax.annotation.security.PermitAll;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.UriInfo;
import java.util.Collections;
import java.util.logging.Logger;

@Path("/config")
public class ConfigResources {
    private static final Logger log = Logger.getLogger(ConfigResources.class.getName());

    @Context
    UriInfo uriInfo;

    private Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss.sssZ").create();
    private ConfigService configService = new ConfigService();

    @GET
    @Path("/{site}/get")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"config"})
    @PermitAll
    public Response getConfig(@Context HttpServletRequest httpRequest, @PathParam("site") String site,
                              @QueryParam("pretty") Boolean pretty) {

        log.info("getConfig(" + site + ")");
        try {
            Site.valueOf(site);
            ConfigDTO pref = configService.getConfig(true);

            ResponseBuilder builder;
            if (pretty != null && pretty) {
                Gson gson1 = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss.sssZ").setPrettyPrinting().create();
                builder = Response.ok(gson1.toJson(pref));
            } else {
                builder = Response.ok(pref);
            }
            String token = (String) MDC.get("token");
            if (token == null || XsrfUtil.isExpired(token)) {
                String userAgent = (httpRequest != null ? httpRequest.getHeader("User-Agent") : null);
                token = XsrfUtil.encode(userAgent);
                log.info("set new token " + token);
                builder.header("set-cookie", "XSRF-TOKEN=" + token + ";Path=/;Secure;HttpOnly;SameSite=Strict");
            } else {
                log.info("reuse token=" + token);
            }

            return builder.build();

        } catch (IllegalArgumentException ex) {
            log.info("site does not exist " + site + ". " + ex);
            Site guessedSite = UrlUtil.guessSite(site);
            ErrorDTO error;
            Response.ResponseBuilder response = Response.status(404);
            if (guessedSite != null) {
                log.warning("guess site" + guessedSite);
                error = new ErrorDTO();
                error.code = 800;
                error.text = Collections.singletonList(guessedSite.name());
                response.entity(gson.toJson(error));
            }
            return response.build();
        }
    }

    @GET
    @Path("/{site}/get/nocache")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"config"})
    @PermitAll
    public Response getConfigNoCache(@PathParam("site") Site site) {

        log.info("getConfig(" + site + ")");
        ConfigDTO pref = configService.getConfig(true);

        return Response.ok(pref).build();
    }

    @GET
    @Path("/{site}/get/raw")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"config"})
    public Response getConfigRaw(@PathParam("site") Site site) {

        log.info("getConfigRaw(" + site + ")");
        ConfigDTO pref = configService.getConfig(false);

        return Response.ok(pref).build();
    }
}
