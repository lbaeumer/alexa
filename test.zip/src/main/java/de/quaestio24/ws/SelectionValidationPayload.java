package de.quaestio24.ws;

import javax.validation.Payload;

public class SelectionValidationPayload {
    public static class Error440 implements Payload {
    }

    public static class Error441 implements Payload {
    }

    public static class Error442 implements Payload {
    }
}
