package de.quaestio24.ws;

import de.quaestio24.dto.ErrorDTO;
import de.quaestio24.exception.NotAuthenticatedException;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;
import java.util.Collections;
import java.util.logging.Logger;

@Provider
public class NotAuthenticatedExceptionMapper implements ExceptionMapper<NotAuthenticatedException> {

    private static final Logger log = Logger.getLogger(NotAuthenticatedExceptionMapper.class.getName());

    @Override
    public Response toResponse(NotAuthenticatedException e) {
        ErrorDTO ed = new ErrorDTO();
        ed.code = e.errorCode;
        ed.text = Collections.singletonList(e.message);
        log.info("sending error " + ed);
        return Response.status(401).entity(ed).type(MediaType.APPLICATION_JSON_TYPE).build();
    }
}
