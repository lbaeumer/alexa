package de.quaestio24.ws;

import de.quaestio24.annotation.BulkProtection;
import de.quaestio24.annotation.EnforceXsrf;
import de.quaestio24.constant.RoleEnum;
import de.quaestio24.dto.AuthRequestDTO;
import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.entity.Site;
import de.quaestio24.exception.NotAuthenticatedException;
import de.quaestio24.exception.NotAuthorizedException;
import de.quaestio24.exception.ValidationException;
import de.quaestio24.service.AuthRequestService;
import de.quaestio24.service.AuthService;
import de.quaestio24.service.IpfilterService;
import de.quaestio24.service.PreferencesService;
import de.quaestio24.util.SendMail;
import de.quaestio24.util.SystemConfig;
import de.quaestio24.util.UrlUtil;
import de.quaestio24.util.XsrfUtil;
import de.quaestio24.ws.LoginResources.User;
import org.apache.log4j.MDC;

import javax.annotation.security.DenyAll;
import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.container.ResourceInfo;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.Provider;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

@Provider
public class AuthenticationFilter implements ContainerRequestFilter {

    private static final Logger log = Logger.getLogger(AuthenticationFilter.class.getName());
    private final String URIS_WITHOUT_SITE_REGEXP;
    private AuthService authService = new AuthService();
    private AuthRequestService authRequestService = new AuthRequestService();
    private IpfilterService ipFilterService = new IpfilterService();
    private PreferencesService prefService = new PreferencesService();

    @Context
    private ResourceInfo resourceInfo;
    @Context
    private HttpServletRequest request;

    public AuthenticationFilter() {
        URIS_WITHOUT_SITE_REGEXP = SystemConfig.getProperties().getProperty("urisWithoutSiteRegExp");
    }

    @Override
    public void filter(ContainerRequestContext requestContext) {

        Method method = resourceInfo.getResourceMethod();
        MDC.remove("token");
        MDC.remove("user");
        MDC.put("server", request.getServerName());
        readXsrfTokenFromCookie();

        if (method.isAnnotationPresent(PermitAll.class)) {
            log.info(request.getRequestURI() + ", permitAll");

        } else if (method.isAnnotationPresent(DenyAll.class)) {
            log.info(request.getRequestURI() + ", denyAll");
            requestContext.abortWith(Response.status(Response.Status.FORBIDDEN).entity("Access denied").build());
            return;

        } else if (method.isAnnotationPresent(RolesAllowed.class)) {
            RolesAllowed rolesAnnotation = method.getAnnotation(RolesAllowed.class);
            Set<String> rolesSet = new HashSet<>(Arrays.asList(rolesAnnotation.value()));
            RoleEnum requiredRole = RoleEnum.valueOf(rolesSet.iterator().next());

            log.info(request.getRequestURI() + ", required Role " + requiredRole);

            // determine site by reading from uri
            final Site site = UrlUtil.getSite(request);

            // the requests either are site related or the site is a global one
            if (site == null && !request.getRequestURI().matches(URIS_WITHOUT_SITE_REGEXP)) {
                log.warning("site is not defined, so send 404. uri=" + request.getRequestURI());
                requestContext.abortWith(Response.status(404).build());
                return;
            }

            // get authenticated user from session
            User user = getAuthenticatedUser(request);

            // user has been successfully authenticated, now check authorization
            log.info("site=" + site + "; user " + user + " authenticated. Now check if authorized for " + site + " and role "
                    + requiredRole);

            try {
                final RoleEnum currentRole = RoleEnum.valueOf(user.role);

                RoleEnum role = checkAuthorized(user, currentRole, requiredRole);
                log.info("go on authorized " + user + "/" + role);
                user.role = role.toString();
                MDC.put("user", user);

            } catch (NotAuthorizedException secEx) {

                // send email reminder
                AuthRequestDTO req = new AuthRequestDTO();
                req.email = user.email;
                req.provider = user.provider;

                boolean inserted = authRequestService.insertAuthRequest(req);
                if (inserted) {
                    String adminUrl = SystemConfig.getProperties().getProperty("adminUrl") + "/"
                            + (site != null ? site.getBaseType() : "") + "/login?action=privileges";

                    new SendMail().send("Quaestio IAM: " + site + ": " + user.email + " not authorized.",
                            "Hi Lui,<br/><br/>the user " + user.email + " (" + site + ") has the role "
                                    + secEx.currentRole + ", but requires the role " + secEx.requiredRole
                                    + ". You can grant the role here:<br/><br/><a href=\"" + adminUrl + "\">" + adminUrl
                                    + "</a><br/><br/>Regards,<br/><br/>the Quaestio IAM team.",
                            "Lui", "lui.baeumer@gmail.com", null, true);
                }

                throw secEx;
            }

        } else {
            log.info(request.getRequestURI() + ", allowAll, no constraint defined");
        }

        // for junit tests skip all further checks
        String userAgent = request.getHeader("User-Agent");
        if (IpfilterService.USER_AGENT.equals(userAgent)) {
            return;
        }

        boolean onlyReport = Boolean.parseBoolean(SystemConfig.getProperties().getProperty("onlyReport"));
        if (method.isAnnotationPresent(EnforceXsrf.class)) {
            EnforceXsrf enforceAnnotation = method.getAnnotation(EnforceXsrf.class);
            log.info(request.getRequestURI() + ", enforceXsrf; onlyReport=" + onlyReport);
            xsrfCheck(onlyReport || enforceAnnotation.onlyReport());
        }

        if (method.isAnnotationPresent(BulkProtection.class)) {
            BulkProtection bulkProtection = method.getAnnotation(BulkProtection.class);
            log.info(request.getRequestURI() + ", bulkProtection");
            bulkProtection(method.getName(), onlyReport || bulkProtection.onlyReport());
        }
    }

    User getAuthenticatedUser(HttpServletRequest request) {

        Site site = UrlUtil.getSite(request);
        if (site != null) {
            site = site.getBaseType();
        }
        log.fine("site=" + site + " in " + request.getRequestURI());

        User user;

        // get user from session
        user = getUserFromSession(request, site);

        // try to read it from basic auth
        if (user == null) {
            log.info("try to read from basic auth " + site);
            user = getUserFromBasicAuth(request, site);
        }

        // try to read from direct url, angular dies not send basic auth for demo
        if (user == null) {
            log.info("try to read from direct url " + site);
            user = getUserFromDirectUrl(request, site);
        }

        // if not authenticated, send 401
        if (user == null || user.email == null || user.provider == null || user.role == null) {
            log.info("not authenticated, send 401, user=" + user);

            throw new NotAuthenticatedException("user not logged in", 200);
        }

        // if the user is the none user, you must not access only demo sites
        if (user.email.equals("none") && user.provider.equals("noauth") && (site == null || !site.isJunitSite())) {
            log.warning("user none not authenticated for site " + site + ". send 401");

            throw new NotAuthenticatedException("you must not access " + site, 201);
        }

        return user;
    }

    private User getUserFromSession(HttpServletRequest request, Site site) {
        User user = null;

        HttpSession session = request.getSession(false);
        if (session != null) {
            user = (User) session.getAttribute("user");
            if (user == null || user.email == null || user.provider == null || user.role == null
                    || user.site == null) {
                log.info("session exists, but invalid with " + user + ". Delete access");
                user = null;
                session.invalidate();
            } else {
                log.info(user + " from session auth");
                if (site != null && !site.toString().equals(user.site)) {
                    if (site.isJunitSite()) {
                        log.info("I logged in with " + user + "/" + user.site + "; now I'm in junit site " + site);
                    } else {
                        log.warning("I logged in with " + user + "/" + user.site + "; now I'm in site " + site + ". Send error");
                        session.invalidate();
                        throw new NotAuthenticatedException("user not logged in", 201);
                    }
                }

                if (user.role.equals(RoleEnum.none.toString())
                        && site != null && site.isJunitSite()) {
                    log.info("authenticated, but without teacher permissions to " + site + " So set to teacher");
                    user.role = RoleEnum.teacher.toString();
                }
            }
        }

        return user;
    }

    private User getUserFromBasicAuth(HttpServletRequest request, Site site) {
        User user = null;
        if (request.getRequestURI().contains("/ws/site")
                || site != null && site.isJunitSite()) {

            // used for integration tests and demo site
            String basicAuth = request.getHeader("Authorization");
            log.info("check basic auth " + basicAuth);
            if (basicAuth != null && basicAuth.startsWith("Basic ") && basicAuth.length() > 10) {
                // get user from basic auth header
                try {
                    basicAuth = basicAuth.substring(6);
                    byte[] credentials = Base64.getDecoder().decode(basicAuth);
                    String cred = new String(credentials);
                    String u = cred.substring(0, cred.indexOf(":"));
                    user = new User();
                    user.provider = u.substring(0, u.indexOf("/"));
                    user.email = u.substring(u.indexOf("/") + 1);
                    log.info(request.getRequestURI() + ": " + user + " from basic auth");

                    // set role
                    List<RoleEnum> roles = authService.getRoles(user.provider, user.email);
                    RoleEnum currentRole = roles.isEmpty() ? null : roles.get(0);

                    if (currentRole == null) {
                        // user is not authorized for site
                        PreferencesDTO pref = prefService.getPreference();
                        if (!pref.auth) {
                            log.info("no auth required. Provide teacher role.");
                            currentRole = RoleEnum.teacher;
                        } else {
                            currentRole = RoleEnum.none;
                        }
                    }
                    user.role = currentRole.toString();
                    user.site = (site != null ? site.toString() : null);
                } catch (Exception e) {
                    log.log(Level.WARNING, "exception in decoding the basic auth request" + basicAuth, e);
                    user = null;
                }
            }
        }
        return user;
    }

    private User getUserFromDirectUrl(HttpServletRequest request, Site site) {
        User user = null;
        // direct url does not pass basic auth
        if (request.getRequestURI().matches(".*(assigned|selection|history)-demo.*\\.(xls|csv)")
                && site != null && site.isJunitSite()) {
            log.info("direct url, so simulate role teacher");
            user = new User();
            user.role = RoleEnum.teacher.toString();
            user.email = "demo";
            user.name = "demo";
            user.provider = "noauth";
            user.site = site.toString();
        }
        return user;
    }

    private void readXsrfTokenFromCookie() {
        // csrf check
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie c : cookies) {
                log.info("c=" + c.getName() + "=" + c.getValue());
                if ("XSRF-TOKEN".equals(c.getName())) {
                    String token = c.getValue();
                    MDC.put("token", token);
                }
            }
        }
    }

    private void xsrfCheck(boolean onlyReport) {
        // csrf check
        String token = (String) MDC.get("token");
        String userAgent = request.getHeader("User-Agent");

        boolean verifyOk = XsrfUtil.verify(userAgent, token);
        if (!verifyOk) {
            if (!onlyReport) {
                log.warning("xsrf: did not find XSRF-TOKEN cookie in " + request.getRequestURI());
                throw new NotAuthorizedException("xsrf issue, relogin", 300);
            } else {
                log.warning("xsrf: check failed, but ignore and go on");
            }
        }
    }

    private void bulkProtection(String method, boolean onlyReport) {
        String token = (String) MDC.get("token");
        if (token == null) {
            log.warning("token must not be null for bulkProtection check");
            if (!onlyReport) {
                throw new NotAuthorizedException("xsrf token is null", 200);
            }
            return;
        }

        try {
            ipFilterService.checkAndIncreaseLastAccess(method, token, request.getHeader("User-Agent"));
        } catch (ValidationException e) {
            log.log(Level.WARNING, "bulk protection issue detected", e);
            if (!onlyReport) {
                throw e;
            }
        }
    }

    RoleEnum checkAuthorized(User user, final RoleEnum currentRole, final RoleEnum requiredRole) {

        // if /admin/school invoked, then check if school is authorized
        log.info("currentRole=" + currentRole + "; required=" + requiredRole);
        if (requiredRole.ordinal() > currentRole.ordinal()) {
            log.info("You do not have sufficient privileges. You need " + requiredRole + ", but you are only in role "
                    + currentRole);
            NotAuthorizedException s = new NotAuthorizedException(user + " hat keine Berechtigung.", 300);
            s.currentRole = currentRole;
            s.requiredRole = requiredRole;
            throw s;
        }

        return currentRole;
    }
}
