package de.quaestio24.ws;

import com.google.gson.Gson;
import de.quaestio24.annotation.EnforceXsrf;
import de.quaestio24.dto.AuthDTO;
import de.quaestio24.dto.AuthRequestDTO;
import de.quaestio24.entity.Site;
import de.quaestio24.service.AuthRequestService;
import de.quaestio24.service.AuthService;
import io.swagger.v3.oas.annotations.Operation;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import java.util.List;
import java.util.logging.Logger;

@Path("/authrequest")
public class AuthRequestResources {
    private static final Logger log = Logger.getLogger(AuthRequestResources.class.getName());

    @Context
    UriInfo uriInfo;

    @POST
    @EnforceXsrf
    @Path("/{site}/insert")
    @Produces("text/plain; charset=UTF-8")
    @Operation(tags = {"authrequest"})
    @RolesAllowed("superadmin")
    public Response insertAuthRequest(@PathParam("site") Site site, String req) {

        log.info("insertAuthRequest(" + site + ", " + req + ")");
        AuthRequestService authService = new AuthRequestService();
        AuthRequestDTO a = new Gson().fromJson(req, AuthRequestDTO.class);
        authService.insertAuthRequest(a);
        return Response.ok("ok").build();
    }

    @POST
    @EnforceXsrf
    @Path("/{site}/request/delete")
    @Produces("text/plain; charset=UTF-8")
    @Operation(tags = {"authrequest"})
    @RolesAllowed("superadmin")
    public Response deleteAuthRequest(@PathParam("site") Site site, String req) {

        log.info("deleteAuthRequest(" + site + ", " + req + ")");
        AuthRequestService authService = new AuthRequestService();
        AuthRequestDTO a = new Gson().fromJson(req, AuthRequestDTO.class);
        authService.deleteAuthRequest(a);
        return Response.ok("ok").build();
    }

    @POST
    @EnforceXsrf
    @Path("/{site}/grant")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"authrequest"})
    @RolesAllowed("superadmin")
    public Response grantAuthRequest(@PathParam("site") Site site, AuthDTO a) {

        log.info("deleteAuthRequest(" + site + ", " + a + ")");
        AuthRequestService authService = new AuthRequestService();
        List<AuthRequestDTO> l = authService.grantAuthRequest(a, a.role);

        return Response.ok(l).build();
    }

    @POST
    @EnforceXsrf
    @Path("/{site}/defaultauth")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"authrequest"})
    @PermitAll
    public Response grantLui(@PathParam("site") Site site) {

        log.info("grantlui(" + site + ")");
        AuthService authService = new AuthService();
        authService.createDefaultAuth();
        return Response.ok("").build();
    }

    @GET
    @EnforceXsrf
    @Path("/{site}/list")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"authrequest"})
    @RolesAllowed("superadmin")
    public Response getAuthRequests(@PathParam("site") Site site) {

        log.info("getAuthRequests(" + site + ")");
        AuthRequestService authService = new AuthRequestService();
        List<AuthRequestDTO> list = authService.getAuthRequests();
        return Response.ok(list).build();
    }
}
