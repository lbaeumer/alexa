package de.quaestio24.ws;

import de.quaestio24.dto.RegisterUserDTO;
import de.quaestio24.dto.UserDTO;
import de.quaestio24.service.SignupService;
import io.swagger.v3.oas.annotations.Operation;

import javax.annotation.security.PermitAll;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import java.util.logging.Logger;

@Path("/signup")
public class SignupResources {
    private static final Logger log = Logger.getLogger(SignupResources.class.getName());

    @Context
    UriInfo uriInfo;

    private SignupService signupService = new SignupService();

    @POST
    @Path("/register")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"signup"})
    @PermitAll
    public Response register(RegisterUserDTO user) {

        log.info("register(" + user + ")");
        UserDTO u = signupService.register(user);
        log.info("user=" + u);
        return Response.ok(u).build();
    }

    @POST
    @Path("/activate/{key}")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"signup"})
    @PermitAll
    public Response activate(@PathParam("key") String key) {

        log.info("activate(" + key + ")");
        UserDTO user = signupService.activate(key);
        return Response.ok(user).build();
    }

    @GET
    @Path("/get/{key}")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"signup"})
    @PermitAll
    public Response get(@PathParam("key") String key) {

        log.info("get(" + key + ")");
        UserDTO user = signupService.get(key);
        return Response.ok(user).build();
    }
}
