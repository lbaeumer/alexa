package de.quaestio24.ws;

import com.google.gson.Gson;
import de.quaestio24.constant.RoleEnum;
import de.quaestio24.dto.AuthDTO;
import de.quaestio24.dto.AuthRequestDTO;
import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.dto.UserDTO;
import de.quaestio24.entity.Site;
import de.quaestio24.service.AuthRequestService;
import de.quaestio24.service.AuthService;
import de.quaestio24.service.PreferencesService;
import de.quaestio24.service.UserService;
import de.quaestio24.util.SendMail;
import de.quaestio24.util.SystemConfig;
import de.quaestio24.util.XsrfUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

import javax.annotation.security.PermitAll;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import java.io.Serializable;
import java.util.Base64;
import java.util.List;
import java.util.logging.Logger;

@Path("/login")
public class LoginResources {
    private static final Logger log = Logger.getLogger(LoginResources.class.getName());

    @Context
    UriInfo uriInfo;

    private UserService userService = new UserService();
    private PreferencesService prefService = new PreferencesService();
    private AuthService authService = new AuthService();
    private AuthRequestService authRequestService = new AuthRequestService();

    @POST
    @Path("/{site}/login")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"auth"})
    @PermitAll
    public Response login(@Context HttpServletRequest httpRequest, @PathParam("site") String site, UserDTO user) {
        log.info("login(" + user + ", " + site + ")");

        String provider = "login";
        if ("external".equals(user.provider)) {
            String id = user.name;
            String id2 = new String(Base64.getDecoder().decode(id));
            log.info("id2=" + id2);
            Gson g = new Gson();
            User ux = g.fromJson(id2, User.class);
            user.email = ux.email;
            user.name = ux.name;
            user.provider = ux.provider;
            user.site = ux.site;
            provider = ux.provider;
        } else {
            user.provider = provider;
        }

        user = userService.login(user);
        if (!site.equals(user.site)) {
            log.warning(
                    "site mismatch: you request " + site + ", but the account was originally registered with " + user);
        } else {
            log.info("user=" + user);
        }

        String name = (user.email != null ? user.email : user.name);
        if (name == null) {
            // TODO
            // User u = invitationService.
            return Response.status(401).build();
        }
        HttpSession session = httpRequest.getSession(true);
        User u = new User();
        u.name = user.name;
        u.email = name;
        u.provider = provider;
        u.site = site;

        RoleEnum role = getCurrentRole(u);
        u.role = role.toString();

        session.setAttribute("user", u);

        String userAgent = httpRequest.getHeader("User-Agent");
        return Response.ok(u).header("set-cookie", "JSESSIONID=" + session.getId() + ";Path=/;Secure;HttpOnly;SameSite=Strict")
                .header("set-cookie", "XSRF-TOKEN=" + XsrfUtil.encode(userAgent) + ";Path=/;Secure;HttpOnly;SameSite=Strict")
                .build();
    }

    @GET
    @Path("/{site}/info")
    @Produces("application/json; charset=UTF-8")
    @Operation(summary = "Providing info about the logged in user.", tags = {"login"}, responses = {
            @ApiResponse(responseCode = "200", content = @Content(schema = @Schema(implementation = User.class))),
            @ApiResponse(responseCode = "401", content = @Content(schema = @Schema(implementation = Error.class)))})
    @PermitAll
    public Response getLoginInfo(@Context HttpServletRequest httpRequest, @PathParam("site") Site site) {
        return getLoginInfoInternal(httpRequest);
    }

    @GET
    @Path("/info")
    @Produces("application/json; charset=UTF-8")
    @Operation(summary = "Providing info about the logged in user.", tags = {"login"}, responses = {
            @ApiResponse(responseCode = "200", content = @Content(schema = @Schema(implementation = User.class))),
            @ApiResponse(responseCode = "401", content = @Content(schema = @Schema(implementation = Error.class)))})
    @PermitAll
    public Response getLoginInfo(@Context HttpServletRequest httpRequest) {
        return getLoginInfoInternal(httpRequest);
    }

    private Response getLoginInfoInternal(@Context HttpServletRequest httpRequest) {
        log.info("getLoginInfoInternal()");
        User u = new AuthenticationFilter().getAuthenticatedUser(httpRequest);
        return Response.ok(u).build();
    }

    @POST
    @Path("/logout")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"auth"})
    @PermitAll
    public Response logout(@Context HttpServletRequest httpRequest, String u) {

        log.info("logout()");

        HttpSession session = httpRequest.getSession(false);
        if (session != null) {
            session.removeAttribute("user");
            session.invalidate();
        }

        return Response.ok().build();
    }

    RoleEnum getCurrentRole(User user) {
        List<RoleEnum> roles = authService.getRoles(user.provider, user.email);
        RoleEnum currentRole = roles.isEmpty() ? null : roles.get(0);

        if (currentRole == null) {
            // user is not authorized for site
            PreferencesDTO pref = prefService.getPreference();
            if (!pref.auth) {
                log.info("no auth required. Provide min. teacher role.");
                currentRole = RoleEnum.teacher;

                AuthRequestDTO request = new AuthRequestDTO();
                request.email = user.email;
                request.provider = user.provider;
                boolean inserted = authRequestService.insertAuthRequest(request);
                String site = user.site;

                if (inserted) {
                    List<AuthDTO> auths = authService.getAllAuths();
                    boolean anyNonSuperAdminRole = false;
                    for (AuthDTO a : auths) {
                        if (a.role != RoleEnum.superadmin) {
                            anyNonSuperAdminRole = true;
                            break;
                        }
                    }
                    if (!anyNonSuperAdminRole) {
                        log.info("you are the first, so request is granted automatically");
                        currentRole = RoleEnum.admin;
                        authRequestService.grantAuthRequest(request, currentRole);
                    } else {
                        final String adminUrl = SystemConfig.getProperties().getProperty("adminUrl");

                        new SendMail().send(site + ": " + user.email + " not authorized.",
                                user.email + " is not authorized.<br/>Type=" + site + "<br/><br/>grant access:<br/>"
                                        + adminUrl + "/" + site + "/privileges" + "<br/>",
                                "Lui", "lui.baeumer@gmail.com", null,
                                true);
                    }
                }
            } else {
                currentRole = RoleEnum.none;
            }
        }
        return currentRole;
    }

    public static class User implements Serializable {
        private static final long serialVersionUID = 1L;

        public String name, email, provider, site, role;

        @Override
        public String toString() {
            return email + "@" + provider;
        }
    }

}
