package de.quaestio24.ws;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.servers.Server;

import javax.ws.rs.core.Application;
import java.util.HashSet;
import java.util.Set;

@SuppressWarnings("unused")
@OpenAPIDefinition(servers = @Server(url = "https://api.quaestio24.de/ws/"))
public class MyJaxRsApplication extends Application {

    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> rrcs = new HashSet<>();
        rrcs.add(DashboardResources.class);
        rrcs.add(ProjectResources.class);
        rrcs.add(SiteResources.class);
        rrcs.add(ReportResources.class);
        rrcs.add(FeedbackResources.class);
        rrcs.add(SelectionResources.class);
        rrcs.add(AuthRequestResources.class);
        rrcs.add(AuditResources.class);
        rrcs.add(AuthResources.class);
        rrcs.add(PreferenceResources.class);
        rrcs.add(ConfigResources.class);
        rrcs.add(CodeResources.class);
        rrcs.add(NotificationResources.class);
        rrcs.add(PersonResources.class);
        rrcs.add(IssueResources.class);
        rrcs.add(ErrorReportResources.class);
        rrcs.add(LoginResources.class);
        rrcs.add(SignupResources.class);

        rrcs.add(UploadCodeResources.class);
        rrcs.add(UploadPersonsResources.class);
        rrcs.add(UploadProjectPackageResources.class);
        rrcs.add(UploadProjectResources.class);
        rrcs.add(UploadSelectionResources.class);

        rrcs.add(NotAuthenticatedExceptionMapper.class);
        rrcs.add(NotAuthorizedExceptionMapper.class);
        rrcs.add(JsonExceptionMapper.class);
        rrcs.add(ValidationExceptionMapper.class);

        rrcs.add(AuthenticationFilter.class);
        return rrcs;
    }
}
