package de.quaestio24.ws;

import com.google.appengine.api.taskqueue.Queue;
import com.google.appengine.api.taskqueue.QueueFactory;
import com.google.appengine.api.taskqueue.TaskOptions;
import com.google.gson.GsonBuilder;
import de.quaestio24.annotation.EnforceXsrf;
import de.quaestio24.dto.ProjectPackageDTO;
import de.quaestio24.entity.Site;
import de.quaestio24.service.BlobstoreService;
import de.quaestio24.service.ProjectPackageService;
import io.swagger.v3.oas.annotations.Operation;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.logging.Logger;

@Path("/upload-projectpackage")
public class UploadProjectPackageResources {

    private static final Logger log = Logger.getLogger(UploadProjectPackageResources.class.getName());

    @Context
    private HttpServletRequest request;

    @GET
    @EnforceXsrf
    @Path("/{site}/{name}.qpkg")
    @Produces("application/octet-stream; charset=UTF-8")
    @Operation(tags = {"upload"})
    @RolesAllowed("admin")
    public Response exportPackage(@PathParam("site") String site, @PathParam("name") String name) {

        log.info("exportPackage(" + name + ")");

        ProjectPackageDTO pp = new ProjectPackageService().exportAll();
        GsonBuilder builder = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss.sssZ").setPrettyPrinting();

        byte[] content = builder.create().toJson(pp).getBytes(StandardCharsets.UTF_8);
        new BlobstoreService().uploadFile("result/" + name + ".qpkg", content);

        return Response.ok(content).build();
    }

    @POST
    @EnforceXsrf
    @Path("/{site}")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"upload"})
    @RolesAllowed("superadmin")
    public Response uploadPackageTrigger(@PathParam("site") Site site) throws IOException {

        log.info("upload new data " + site);
        GsonBuilder builder = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss.sssZ");

        long id;
        ProjectPackageService uservice = new ProjectPackageService();
        ProjectPackageDTO pkg;
        try (Reader reader = new InputStreamReader(request.getInputStream())) {
            pkg = builder.create().fromJson(reader, ProjectPackageDTO.class);
            id = uservice.saveProjectPackage(pkg);
        }

        log.info("trigger queue with id " + id);
        Queue queue = QueueFactory.getQueue("default");
        TaskOptions bb = TaskOptions.Builder.withUrl("/ws/upload-projectpackage/" + site + "/" + id);
        queue.add(bb);

        Stats stats = new Stats();
        stats.numberCodes = (pkg.codes != null ? pkg.codes.size() : 0);
        stats.numberNames = (pkg.persons != null ? pkg.persons.size() : 0);
        stats.numberProjects = (pkg.projects != null ? pkg.projects.size() : 0);
        stats.numberSelections = (pkg.selections != null ? pkg.selections.size() : 0);
        stats.numberSubPackages = (pkg.subPackages != null ? pkg.subPackages.size() : 0);

        return Response.ok(stats).build();
    }

    @POST
    @Path("/{site}/{id}")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"upload"})
    @PermitAll
    public Response uploadPackageAsync(@PathParam("site") Site site, @PathParam("id") long id) {

        String userAgent = request.getHeader("User-Agent");
        log.info("now import package " + id + "; site=" + site + "; from " + userAgent);
        if (!userAgent.contains("AppEngine")) {
            return Response.status(401).build();
        }

        ProjectPackageService uservice = new ProjectPackageService();
        ProjectPackageDTO projectPackage = uservice.getProjectPackage(id);

        uservice.importAll(projectPackage);
        return Response.ok(id).build();
    }

    private static class Stats {
        @SuppressWarnings("unused")
        public int numberProjects, numberCodes, numberNames, numberSelections, numberSubPackages;
    }
}
