package de.quaestio24.ws;

import de.quaestio24.dto.FeedbackDTO;
import de.quaestio24.entity.Site;
import de.quaestio24.service.FeedbackService;
import io.swagger.v3.oas.annotations.Operation;
import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.text.StringEscapeUtils;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

@Path("/feedback")
public class FeedbackResources {
    private static final Logger log = Logger.getLogger(FeedbackResources.class.getName());

    @Context
    UriInfo uriInfo;

    private FeedbackService feedbackService = new FeedbackService();

    @GET
    @Path("/{site}/list")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"feedback"})
    @RolesAllowed("teacher")
    public Response getFeedbacks(@PathParam("site") Site site) {

        log.info("getFeedback(" + site + ")");

        List<FeedbackDTO> feedbacks = feedbackService.getAllFeedback();

        return Response.ok(feedbacks).build();
    }

    @POST
    @Path("/insert")
    @Produces("plain/text")
    @Consumes("application/x-www-form-urlencoded; charset=UTF-8")
    @Operation(tags = {"feedback"})
    @PermitAll
    public String saveFeedback(@FormParam("name") String name, @FormParam("email") String email,
                               @FormParam("phone") String phone, @FormParam("text") String text) {

        FeedbackDTO regr = new FeedbackDTO();
        regr.name = name;
        regr.email = email;
        regr.phone = phone;
        regr.text = text;
        log.info("saveFeedback(" + regr + ")");
        try {
            feedbackService.saveFeedback(regr);

            return "MF000";
        } catch (Exception e) {
            return "MF255";
        }
        // {"into":"#wpcf7-f29-p361-o1","status":"validation_failed","message":"Bitte
        // die Pflichtfelder
        // ausf\u00fcllen.","invalidFields":[{"into":"span.wpcf7-form-control-wrap.your-name","message":"Dieses
        // Feld ist ein
        // Pflichtfeld.","idref":null},{"into":"span.wpcf7-form-control-wrap.your-email","message":"Dieses
        // Feld ist ein Pflichtfeld.","idref":null}]}
        // {"into":"#wpcf7-f29-p361-o1","status":"validation_failed","message":"Bitte
        // die Pflichtfelder
        // ausf\u00fcllen.","invalidFields":[{"into":"span.wpcf7-form-control-wrap.your-url","message":"The
        // URL is invalid.","idref":null}]}
        // ok
        // {"into":"#wpcf7-f29-p361-o1","status":"mail_sent","message":"Vielen
        // Dank f\u00fcr die Nachricht. Wir melden uns in K\u00fcrze bei
        // Ihnen."}
    }

    @POST
    @Path("/insert")
    @Produces("application/json; charset=UTF-8")
    @Consumes("multipart/form-data")
    @Operation(tags = {"feedback"})
    @PermitAll
    public String saveFeedback2(String text) {

        FeedbackDTO regr = extractFeedback(text);
        log.info("saveFeedback(" + regr + ")");
        try {
            StringBuilder strb = new StringBuilder(
                    "{\"into\":\"#wpcf7-f29-p361-o1\"," + "\"status\":\"validation_failed\","
                            + "\"message\":\"Bitte die Pflichtfelder ausf\u00fcllen.\"," + "\"invalidFields\":[");
            boolean error = false;
            if (regr.name == null || regr.name.trim().length() == 0) {
                error = true;
                strb.append("{" + "\"into\":\"span.wpcf7-form-control-wrap.your-name\","
                        + "\"message\":\"Bitte einen Namen eingeben.\"," + "\"idref\":null" + "}");
            }
            if (regr.email == null || regr.email.trim().length() == 0
                    || !regr.email.matches("([A-Za-z0-9._%+-]+@[A-Za-z0-9.-_]+\\.[A-Za-z]{2,4})?")) {
                if (error) {
                    strb.append(",");
                }
                error = true;
                strb.append("{" + "\"into\":\"span.wpcf7-form-control-wrap.your-email\","
                        + "\"message\":\"Bitte eine gültige Email eingeben.\"," + "\"idref\":null" + "}");
            }
            if (regr.text == null || regr.text.trim().length() == 0) {
                if (error) {
                    strb.append(",");
                }
                error = true;
                strb.append("{" + "\"into\":\"span.wpcf7-form-control-wrap.your-message\","
                        + "\"message\":\"Bitte eine Nachricht eingeben.\"," + "\"idref\":\"xxxnull\"" + "}");
            }
            strb.append("]}");

            if (error) {
                return strb.toString();
            }

            feedbackService.saveFeedback(regr);

            return "{\"into\":\"#wpcf7-f29-p361-o1\",\"status\":\"mail_sent\",\"message\":\"Vielen Dank f\u00fcr die Nachricht. Wir melden uns in K\u00fcrze bei Ihnen.\"}";
        } catch (Exception e) {
            log.warning("failed " + regr);
            return "{\"into\":\"#wpcf7-f29-p361-o1\"," + "\"status\":\"validation_failed\","
                    + "\"message\":\"Bitte die Pflichtfelder ausf\u00fcllen.\"" + "}";
        }
    }

    private FeedbackDTO extractFeedback(String text) {
        log.info("text=" + text);
        FeedbackDTO f = new FeedbackDTO();
        BufferedReader reader = new BufferedReader(new StringReader(text));
        Map<String, String> m = new HashedMap<>();
        String line;
        try {
            StringBuffer strb = new StringBuffer();
            String currentName = null;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Content-Disposition") && line.contains("name=\"")) {
                    if (currentName != null) {
                        m.put(currentName, strb.toString());
                    }
                    int pos = line.indexOf("name=\"");
                    currentName = line.substring(pos + 6);
                    currentName = currentName.substring(0, currentName.indexOf("\""));
                    strb = new StringBuffer();
                    continue;
                }
                if (line.startsWith("------WebKitFormBoundary")) {
                    continue;
                }
                if (!line.trim().isEmpty()) {
                    if (strb.length() > 0) {
                        strb.append("<br/>");
                    }
                    strb.append(StringEscapeUtils.escapeHtml4(line));
                }
            }
            if (currentName != null) {
                m.put(currentName, strb.toString());
            }
        } catch (IOException e) {
            log.warning("failed");
        }

        log.info("m=" + m);
        f.email = m.get("your-email");
        f.name = m.get("your-name");
        f.phone = m.get("your-url");
        f.text = m.get("your-message");
        return f;
    }

    @POST
    @Path("/{site}/insert")
    @Produces("application/json; charset=UTF-8")
    @Consumes("application/json")
    @Operation(tags = {"feedback"})
    @PermitAll
    public Response saveFeedback2(@PathParam("site") Site site, FeedbackDTO regr) {

        log.info("saveFeedback(" + regr + ")");
        return Response.ok(feedbackService.saveFeedback(regr)).build();
    }
}
