package de.quaestio24.ws;

import de.quaestio24.annotation.EnforceXsrf;
import de.quaestio24.dto.AuditDTO;
import de.quaestio24.dto.AuditsDTO;
import de.quaestio24.entity.Site;
import de.quaestio24.service.AuditService;
import io.swagger.v3.oas.annotations.Operation;

import javax.annotation.security.RolesAllowed;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.logging.Logger;

@Path("/audit")
public class AuditResources {
    private static final Logger log = Logger.getLogger(AuditResources.class.getName());

    private AuditService auditService = new AuditService();

    @GET
    @EnforceXsrf
    @Path("/{site}/list")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"auth"})
    @RolesAllowed("superadmin")
    public Response getAudits(@PathParam("site") Site site) {

        log.info("getAudits(" + site + ")");
        List<AuditDTO> list = auditService.getAudits();
        return Response.ok(list).build();
    }

    @GET
    @EnforceXsrf
    @Path("/latest")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"auth"})
    @RolesAllowed("superadmin")
    public Response getLatestAudits() {

        log.info("getLatestAudits()");
        AuditsDTO list = auditService.getLatestAudits();
        return Response.ok(list).build();
    }
}
