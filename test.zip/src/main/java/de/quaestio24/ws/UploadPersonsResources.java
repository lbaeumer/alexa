package de.quaestio24.ws;

import de.quaestio24.annotation.EnforceXsrf;
import de.quaestio24.dto.PersonDTO;
import de.quaestio24.service.BlobstoreService;
import de.quaestio24.service.PersonService;
import de.quaestio24.service.SelectionService;
import de.quaestio24.util.CacheUtil;
import io.swagger.v3.oas.annotations.Operation;

import javax.annotation.security.RolesAllowed;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

@Path("/upload-persons")
public class UploadPersonsResources {

    private static final Logger log = Logger.getLogger(UploadPersonsResources.class.getName());
    private PersonService personService = new PersonService();

    @Context
    private HttpServletRequest request;

    @POST
    @EnforceXsrf
    @Path("/{site}")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"upload"})
    @RolesAllowed("admin")
    public Response upload(@PathParam("site") String site) {

        log.info("upload new data " + request.getContentType());

        SelectionService sservice = new SelectionService();
        sservice.skipValidation(true);
        List<PersonDTO> persons = Collections.emptyList();

        try {
            if (request.getContentType() != null
                    && (request.getContentType().contains("/csv") || request.getContentType().contains("text"))) {
                persons = personService.parsePersonCSV(request.getInputStream());
            } else {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                int i;
                byte[] buffer = new byte[1024];
                try (InputStream in = request.getInputStream()) {
                    while ((i = in.read(buffer)) > 0) {
                        out.write(buffer, 0, i);
                    }
                }
                out.flush();

                new BlobstoreService().uploadFile("uploads/names.xls", out.toByteArray());

                persons = personService.parsePersonXLS(out.toByteArray());
            }
        } catch (Exception e) {
            log.log(Level.SEVERE, "Import failed with exception", e);
        }

        if (!persons.isEmpty()) {
            personService.insertPersons(persons);

            CacheUtil.clear();
        }

        List<PersonDTO> l = new ArrayList<>(persons);

        return Response.ok(l).build();
    }
}
