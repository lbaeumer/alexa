package de.quaestio24.ws;

import com.google.appengine.api.taskqueue.Queue;
import com.google.appengine.api.taskqueue.QueueFactory;
import com.google.appengine.api.taskqueue.TaskOptions;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import de.quaestio24.dto.NotificationDTO;
import de.quaestio24.entity.Site;
import de.quaestio24.service.NotificationService;
import io.swagger.v3.oas.annotations.Operation;

import javax.annotation.security.RolesAllowed;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

@Path("/notification")
public class NotificationResources {
    private static final Logger log = Logger.getLogger(NotificationResources.class.getName());

    private NotificationService notificationService = new NotificationService();

    @GET
    @Path("/")
    @Operation(tags = {"notification"})
    public Response triggerNotification() {

        log.info("triggerNotification()");

        Queue queue = QueueFactory.getQueue("default");

        for (Site site : Site.values()) {
            if (site.isBaseSite() && !site.isJunitSite()) {
                queue.add(TaskOptions.Builder.withUrl("/ws/notification/" + site.name()));
            }
        }

        return Response.ok().build();
    }

    @POST
    @Path("/{site}")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"notification"})
    public Response sendNotification(@PathParam("site") Site site) {

        log.info("send notification");
        try {
            List<NotificationDTO> sn = notificationService.sendNotifications();
            log.info("send notifications " + sn);
        } catch (Exception e) {
            log.log(Level.WARNING, "failed", e);
        }

        return Response.ok().build();
    }

    @GET
    @Path("/list")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"dashboard"})
    @RolesAllowed("superadmin")
    public Response getAllNotifications() {

        log.info("getNotifications");

        List<NotificationDTO> notifications = notificationService.getAllNotifications();

        Gson gson1 = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss.sssZ").setPrettyPrinting().create();
        Response.ResponseBuilder builder = Response.ok(gson1.toJson(notifications));

        return builder.build();
    }
}
