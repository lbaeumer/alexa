package de.quaestio24.ws;

import com.google.gson.JsonParseException;
import de.quaestio24.dto.ErrorDTO;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;
import java.util.Collections;

@Provider
public class JsonExceptionMapper implements ExceptionMapper<JsonParseException> {

    @Override
    public Response toResponse(JsonParseException e) {

        ErrorDTO ed = new ErrorDTO();
        ed.code = 400;
        ed.text = Collections.singletonList("Illegal request");
        return Response.status(400).entity(ed).type(MediaType.APPLICATION_JSON_TYPE).build();
    }
}
