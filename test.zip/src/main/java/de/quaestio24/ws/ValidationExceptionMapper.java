package de.quaestio24.ws;

import de.quaestio24.dto.ErrorDTO;
import de.quaestio24.exception.ValidationException;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

@Provider
public class ValidationExceptionMapper implements ExceptionMapper<ValidationException> {

    @Override
    public Response toResponse(ValidationException e) {
        ErrorDTO ed = new ErrorDTO();
        ed.code = e.errorCode;
        ed.text = e.messages;
        return Response.status(400).entity(ed).type(MediaType.APPLICATION_JSON_TYPE).build();
    }
}
