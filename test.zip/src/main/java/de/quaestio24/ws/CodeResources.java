package de.quaestio24.ws;

import de.quaestio24.annotation.EnforceXsrf;
import de.quaestio24.dto.CodeDTO;
import de.quaestio24.entity.Site;
import de.quaestio24.service.CodeService;
import io.swagger.v3.oas.annotations.Operation;

import javax.annotation.security.RolesAllowed;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.logging.Logger;

@Path("/code")
public class CodeResources {

    private static final Logger log = Logger.getLogger(CodeResources.class.getName());

    private CodeService codeService = new CodeService();

    @GET
    @EnforceXsrf
    @Path("/{site}/list")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"code"})
    @RolesAllowed("teacher")
    public Response getAllCodes(@PathParam("site") Site site) {

        log.info("getAllCodes(" + site + ")");
        List<CodeDTO> selections = codeService.getCodes();

        return Response.ok(selections).build();
    }

    @POST
    @EnforceXsrf
    @Path("/{site}/add")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"code"})
    @RolesAllowed("teacher")
    public Response addCode(@PathParam("site") Site site, CodeDTO code) {

        log.info("addCode(" + site + ", " + code + ")");
        List<CodeDTO> codes = codeService.addCode(code);

        return Response.ok(codes).build();
    }

    @POST
    @EnforceXsrf
    @Path("/{site}/delete")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"code"})
    @RolesAllowed("teacher")
    public Response deleteCode(@PathParam("site") Site site, CodeDTO code) {

        log.info("deleteCode(" + site + ", " + code + ")");
        List<CodeDTO> codes = codeService.deleteCode(code);

        return Response.ok(codes).build();
    }
}
