package de.quaestio24.ws;

import com.google.appengine.api.taskqueue.Queue;
import com.google.appengine.api.taskqueue.QueueFactory;
import com.google.appengine.api.taskqueue.TaskOptions;
import de.quaestio24.annotation.EnforceXsrf;
import de.quaestio24.dto.PreferencesDTO;
import de.quaestio24.dto.SettingsDTO;
import de.quaestio24.entity.Site;
import de.quaestio24.service.SiteService;
import de.quaestio24.util.CacheUtil;
import io.swagger.v3.oas.annotations.Operation;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.cache.CacheStatistics;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import java.util.logging.Level;
import java.util.logging.Logger;

@Path("/site")
public class SiteResources {
    private static final Logger log = Logger.getLogger(SiteResources.class.getName());

    @Context
    UriInfo uriInfo;

    private SiteService siteService = new SiteService();

    @GET
    @Path("/list")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"site"})
    @PermitAll
    public Response getSettings() {

        log.info("getSettings()");

        SettingsDTO settings = siteService.getSettings();
        return Response.ok(settings).build();
    }

    @POST
    @EnforceXsrf
    @Path("/add/{site}")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"site"})
    @RolesAllowed("superadmin")
    public Response addSite(@PathParam("site") String site, PreferencesDTO prefs) {

        log.info("addSite(" + site + ", " + prefs + ")");

        SettingsDTO settings = siteService.addSite(site, prefs);
        return Response.ok(settings).build();
    }

    @POST
    @EnforceXsrf
    @Path("/delete/{site}")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"site"})
    @RolesAllowed("superadmin")
    public Response deleteSite(@PathParam("site") String site) {

        log.info("deleteSite(" + site + ")");

        SettingsDTO settings = siteService.deleteSite(site);
        return Response.ok(settings).build();
    }

    @POST
    @EnforceXsrf
    @Path("/{site}/add/{subsite}")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"site"})
    @RolesAllowed("superadmin")
    public Response addSubSite(@PathParam("subsite") String subsite, PreferencesDTO prefs) {

        log.info("addSubSite(" + subsite + ", " + prefs + ")");

        SettingsDTO settings = siteService.addSubSite(subsite, prefs);
        return Response.ok(settings).build();
    }

    @POST
    @Path("/{site}/clearcache")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"site"})
    @RolesAllowed("teacher")
    public Response clearCache(@PathParam("site") String site) {

        log.info("clearCache(" + site + ")");
        CacheStatistics stats = CacheUtil.getCacheStatistics();
        CacheUtil.clear();
        int[] x = {stats.getObjectCount(), stats.getCacheHits(), stats.getCacheMisses()};

        return Response.ok(x).build();
    }

    @POST
    @EnforceXsrf
    @Path("/{site}/reset")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"site"})
    @RolesAllowed("superadmin")
    public Response resetSite(@PathParam("site") Site site) {

        log.info("resetSite(" + site + ")");
        Queue queue = QueueFactory.getQueue("default");
        queue.add(TaskOptions.Builder.withUrl("/ws/site/" + site + "/resetasync"));
        return Response.ok().build();
    }

    @POST
    @Path("/{site}/resetasync")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"site"})
    @PermitAll
    public Response resetSiteSync(@PathParam("site") Site site) {

        // only called by GAE
        log.info("resetSiteSync(" + site + ")");
        try {
            siteService.resetSite(site);
        } catch (Exception e) {
            log.log(Level.WARNING, "restting failed", e);
        }
        return Response.ok().build();
    }
}
