package de.quaestio24.ws;

import de.quaestio24.annotation.EnforceXsrf;
import de.quaestio24.service.ErrorReportingService;
import io.swagger.v3.oas.annotations.Operation;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

@Path("/error")
public class ErrorReportResources {

    @Context
    HttpServletRequest request;
    private ErrorReportingService service = new ErrorReportingService();

    @POST
    @EnforceXsrf
    @Path("/report")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"error"})
    @PermitAll
    public Response reportError(String json) {

        service.reportError(json, request.getHeader("User-Agent") + "/" + request.getRemoteHost());
        return Response.ok().build();
    }

    @GET
    @Path("/report/list")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"error"})
    @RolesAllowed("superadmin")
    public Response reports() {

        return Response.ok(service.getErrors()).build();
    }
}
