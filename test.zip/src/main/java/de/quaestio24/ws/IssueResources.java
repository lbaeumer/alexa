package de.quaestio24.ws;

import de.quaestio24.dto.IssuesDTO;
import de.quaestio24.entity.Site;
import de.quaestio24.service.IssueService;
import io.swagger.v3.oas.annotations.Operation;

import javax.annotation.security.RolesAllowed;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import java.util.logging.Logger;

@Path("/issue")
public class IssueResources {
    private static final Logger log = Logger.getLogger(IssueResources.class.getName());

    @Context
    UriInfo uriInfo;

    private IssueService issueService = new IssueService();

    @GET
    @Path("/{site}/list")
    @Produces("application/json; charset=UTF-8")
    @Operation(tags = {"issue"})
    @RolesAllowed("teacher")
    public Response getAllIssues(@PathParam("site") Site site) {

        log.info("getAllIssues(" + site + ")");

        IssuesDTO issues = issueService.getAllIssues();
        return Response.ok(issues).build();
    }
}
