package de.quaestio24.util;

import com.google.appengine.api.NamespaceManager;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SendMail {

    private static final Logger log = Logger.getLogger(SendMail.class.getName());

    public void send(String subject, String text, String name, String recipient, String replyTo,
                     boolean auto) {
        try {
            log.info("send mail to " + recipient + " <" + name + ">" + "replyTo: " + replyTo);
            send(subject, text, new InternetAddress(recipient), replyTo, auto);
        } catch (Exception e) {
            log.warning("couldn't send email. Ignoring. " + e);
        }
    }

    private void send(String subject, String text, InternetAddress recipient, String replyTo,
                      boolean auto) {
        if (recipient.getAddress().endsWith("@localhost")) {
            return;
        }
        Properties props = new Properties();
        Session session = Session.getDefaultInstance(props, null);

        try {
            MimeMessage msg = new MimeMessage(session);
            if (replyTo != null && replyTo.length() > 0) {
                msg.setFrom(new InternetAddress("lui.baeumer@gmail.com", "quaestio24"));
                msg.setReplyTo(new Address[]{new InternetAddress(replyTo, replyTo)});
            } else {
                msg.setFrom(new InternetAddress("lui.baeumer@gmail.com", "<noreply>"));
            }

            // InternetAddress("lui.baeumer@googlemail.com", "Lui")});
            // msg.addRecipient(Message.RecipientType.TO,
            // new InternetAddress("lui.baeumer@googlemail.com", "LuiXu"));
            msg.addRecipient(Message.RecipientType.TO, recipient);

            if (!recipient.toString().contains("lui.baeumer") && !subject.startsWith("Erfolgreich")) {
                msg.addRecipient(Message.RecipientType.BCC, new InternetAddress("lui.baeumer@gmail.com", "quaestio24"));
            }
            msg.setSubject(subject, "UTF-8");

            if (auto) {
                String adminUrl = SystemConfig.getProperties().getProperty("adminUrl");
                text += "<br/><br/><small>Diese Mail wurde automatisch versendet. Wenn Sie zukünftig keine Emails dieser Art mehr erhalten möchten, "
                        + "können Sie die Emails hier <a href=\""
                        + adminUrl + "/" + NamespaceManager.get() + "/login?action=admin"
                        + "\">abbestellen</a>.</small><br/>";
            }

            String content = getContent(text);
            msg.setContent(content, "text/html");
            Transport.send(msg);

            log.info("Send mail:" + content);
        } catch (AddressException e) {
            log.log(Level.WARNING, "send mail fail", e);
            throw new IllegalStateException(e);
        } catch (Exception e) {
            log.log(Level.WARNING, "send mail fail", e);
            // throw new IllegalStateException(e);
        }
    }

    String getContent(String text) throws IOException {
        StringBuilder strb = new StringBuilder();
        InputStream in = getClass().getResourceAsStream("/email.html");

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                strb.append(line.replace("<!--TEXT-->", text));
            }
        }

        return strb.toString();
    }
}
