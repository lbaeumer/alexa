package de.quaestio24.util;

import org.apache.log4j.Logger;

import javax.cache.Cache;
import javax.cache.CacheException;
import javax.cache.CacheFactory;
import javax.cache.CacheManager;
import javax.cache.CacheStatistics;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

public class CacheUtil {
    private static final Logger log = Logger.getLogger(CacheUtil.class.getName());

    private static final java.lang.String EXPIRATION_DELTA = "com.google.appengine.api.memcache.jsr107cache.EXPIRATION_DELTA";

    public static void clear() {
        Objects.requireNonNull(getCache()).clear();
    }

    @SuppressWarnings("unchecked")
    public static void put(String key, Object object) {
        Objects.requireNonNull(getCache()).put(key, object);
    }

    public static Object get(String key) {
        return Objects.requireNonNull(getCache()).get(key);
    }

    public static void remove(String key) {
        Objects.requireNonNull(getCache()).remove(key);
    }

    public static CacheStatistics getCacheStatistics() {
        return Objects.requireNonNull(getCache()).getCacheStatistics();
    }

    private static Cache getCache() {
        Cache cache;
        try {
            CacheFactory cacheFactory = CacheManager.getInstance().getCacheFactory();
            Map<Object, Object> properties = new HashMap<>();
            properties.put(EXPIRATION_DELTA, TimeUnit.HOURS.toSeconds(4));
            cache = cacheFactory.createCache(properties);
            return cache;
        } catch (CacheException e) {
            log.warn("failed", e);
            return null;
        }
    }
}
