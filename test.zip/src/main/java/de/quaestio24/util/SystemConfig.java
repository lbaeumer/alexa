package de.quaestio24.util;

import java.io.IOException;
import java.util.Properties;
import java.util.logging.Logger;

public class SystemConfig {
    private static final Logger log = Logger.getLogger(SystemConfig.class.getName());
    private static Properties props;

    public static Properties getProperties() {
        if (props == null) {
            try {
                Properties props2 = new Properties();
                props2.load(SystemConfig.class.getResourceAsStream("/config.properties"));
                props = props2;
            } catch (IOException e) {
                log.info("huups, config issue");
                throw new RuntimeException(e);
            }
        }
        return props;
    }

}
