package de.quaestio24.util;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;

public class CryptoUtil {

    public static final String AES = "AES";

    /**
     * encrypt a value and generate a keyfile if the keyfile is not found then a
     * new one is created
     */
    public static String encrypt(String value) {
        try {
            SecretKeySpec sks = getSecretKeySpec();
            Cipher cipher = Cipher.getInstance(CryptoUtil.AES);
            cipher.init(Cipher.ENCRYPT_MODE, sks, cipher.getParameters());
            byte[] encrypted = cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));

            return byteArrayToHexString(encrypted);
        } catch (Exception e) {
            throw new IllegalStateException("failed", e);
        }
    }

    /**
     * decrypt a value
     */
    public static String decrypt(String message) {
        try {
            SecretKeySpec sks = getSecretKeySpec();
            Cipher cipher = Cipher.getInstance(CryptoUtil.AES);
            cipher.init(Cipher.DECRYPT_MODE, sks);

            byte[] decrypted = cipher.doFinal(hexStringToByteArray(message));

            return new String(decrypted, StandardCharsets.UTF_8);
        } catch (Exception e) {
            throw new IllegalStateException("failed", e);
        }
    }

    private static SecretKeySpec getSecretKeySpec() {
        byte[] key = "djai38dka/8HtgQ662123AioU4952sdf".getBytes();
        return new SecretKeySpec(key, CryptoUtil.AES);
    }

    static String byteArrayToHexString(byte[] b) {
        StringBuilder sb = new StringBuilder(b.length * 2);
        for (byte value : b) {
            int v = value & 0xff;
            if (v < 16) {
                sb.append('0');
            }
            sb.append(Integer.toHexString(v));
        }
        return sb.toString().toUpperCase();
    }

    static byte[] hexStringToByteArray(String s) {
        byte[] b = new byte[s.length() / 2];
        for (int i = 0; i < b.length; i++) {
            int index = i * 2;
            int v = Integer.parseInt(s.substring(index, index + 2), 16);
            b[i] = (byte) v;
        }
        return b;
    }
}
