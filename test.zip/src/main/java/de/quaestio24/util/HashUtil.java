package de.quaestio24.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.logging.Level;
import java.util.logging.Logger;

public class HashUtil {

    private static final Logger log = Logger.getLogger(HashUtil.class.getName());

    public static Object decode(byte[] b) throws IOException, ClassNotFoundException {
        ByteArrayInputStream i = new ByteArrayInputStream(b);
        Object o;
        try (ObjectInputStream in = new ObjectInputStream(i)) {
            o = in.readObject();
        }
        return o;
    }

    public static byte[] encode(Object object) throws IOException {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        try (ObjectOutputStream out = new ObjectOutputStream(o)) {
            out.writeObject(object);
        }
        return o.toByteArray();
    }

    public static String sha(String password) {
        byte[] b;
        b = ("8fg47sj:" + password).getBytes(StandardCharsets.UTF_8);

        MessageDigest md;
        try {
            md = MessageDigest.getInstance("SHA-256");

            InputStream in = new ByteArrayInputStream(b);
            byte[] buffer = new byte[4096];
            int nread;
            while ((nread = in.read(buffer)) >= 0) {
                md.update(buffer, 0, nread);
            }
            byte[] mdbytes = md.digest();

            // convert the byte to hex format method 1
            StringBuilder sb = new StringBuilder();
            for (byte mdbyte : mdbytes) {
                sb.append(Integer.toString((mdbyte & 0xff) + 0x100, 16).substring(1));
            }

            return sb.toString();
        } catch (Exception e) {
            log.log(Level.WARNING, "failed ", e);
            throw new RuntimeException(e);
        }
    }

    public static String md5(byte[] b) {
        MessageDigest md;
        try {
            md = MessageDigest.getInstance("MD5");

            InputStream in = new ByteArrayInputStream(b);
            byte[] buffer = new byte[4096];
            int nread;
            while ((nread = in.read(buffer)) >= 0) {
                md.update(buffer, 0, nread);
            }
            byte[] mdbytes = md.digest();

            // convert the byte to hex format method 1
            StringBuilder sb = new StringBuilder();
            for (byte mdbyte : mdbytes) {
                sb.append(Integer.toString((mdbyte & 0xff) + 0x100, 16).substring(1));
            }

            return sb.toString();
        } catch (Exception e) {
            log.log(Level.WARNING, "failed ", e);
            throw new RuntimeException(e);
        }
    }

    public static Object clone(Serializable object) {
        byte[] b;
        try {
            b = encode(object);
            return decode(b);
        } catch (Exception e) {
            log.log(Level.WARNING, "failed", e);
            throw new RuntimeException(e);
        }
    }
}
