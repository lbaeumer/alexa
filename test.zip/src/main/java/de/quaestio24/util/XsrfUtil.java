package de.quaestio24.util;

import java.util.Objects;
import java.util.Random;
import java.util.logging.Logger;

public class XsrfUtil {

    private static final Logger log = Logger.getLogger(XsrfUtil.class.getName());
    private static Random r = new Random(System.currentTimeMillis());

    public static String encode(String userAgent) {
        log.info("xsrf: encoding user " + userAgent + " to " + (userAgent != null ? userAgent.hashCode() : 0));
        String token = CryptoUtil.encrypt(System.currentTimeMillis() / 1000 / 60 + ":" + (17 * r.nextInt(588) + 3) + ":"
                + (userAgent != null ? userAgent.hashCode() : 0));
        log.info("xsrf: created token=" + token);
        return token;
    }

    public static boolean isExpired(String token) {
        if (token == null) {
            log.severe("xsrf: does not match, token empty");
            return true;
        }
        String plainToken = CryptoUtil.decrypt(token);
        if (!plainToken.matches("[0-9]+[:][0-9]{1,4}[:].+")) {
            log.severe("xsrf: does not match " + plainToken);
            return true;
        }
        int pos1 = plainToken.indexOf(":");

        // 1st check age
        long timeInMin = System.currentTimeMillis() / 1000 / 60 - Long.parseLong(plainToken.substring(0, pos1));

        if (timeInMin < 0 || timeInMin > 60 * 24) {
            log.warning("xsrf: token too old " + (timeInMin) + "min.");
            return true;
        }

        return false;
    }

    public static boolean verify(String userAgent, String token) {
        if (token == null) {
            log.warning("xsrf: does not match, token empty");
            return false;
        }
        String plainToken = CryptoUtil.decrypt(token);
        if (!plainToken.matches("[0-9]+[:][0-9]{1,4}[:].+")) {
            log.info("xsrf: user=" + userAgent + ", token=" + token + "; decoded=" + plainToken);
            log.severe("xsrf: does not match " + plainToken);
            return false;
        }
        int pos1 = plainToken.indexOf(":");

        // 1st check age
        long timeInMin = System.currentTimeMillis() / 1000 / 60 - Long.parseLong(plainToken.substring(0, pos1));

        if (timeInMin < 0 || timeInMin > 60 * 24) {
            log.info("xsrf: user=" + userAgent + ", token=" + token + "; decoded=" + plainToken);
            log.warning("xsrf: token too old " + (timeInMin) + "min.");
            // return false;
        }
        log.info("xsrf: since " + (timeInMin / 1000 / 60) + "min.");

        // 2nd check name
        int pos2 = plainToken.indexOf(":", pos1 + 1);
        String randomNr = plainToken.substring(pos1 + 1, pos2);
        int rn = Integer.parseInt(randomNr);
        if (rn % 17 != 3) {
            log.info("xsrf: user=" + userAgent + ", token=" + token + "; decoded=" + plainToken);
            log.severe("xsrf: the random number is invalid: " + rn);
            return false;
        }

        // 3rd check
        String u = plainToken.substring(pos2 + 1);
        if (!u.equals(userAgent != null ? String.valueOf(userAgent.hashCode()) : "0")) {
            log.info("xsrf: user=" + userAgent + ", token=" + token + "; decoded=" + plainToken);
            log.severe("xsrf: does not match user " + userAgent + " (" + Objects.requireNonNull(userAgent).hashCode() + ") != " + u);
            return false;
        }

        return true;
    }
}
