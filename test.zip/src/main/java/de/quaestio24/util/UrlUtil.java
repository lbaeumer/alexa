package de.quaestio24.util;

import de.quaestio24.entity.Site;
import org.apache.commons.text.similarity.LevenshteinDistance;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.logging.Logger;

public class UrlUtil {

    private static final Logger log = Logger.getLogger(UrlUtil.class.getName());

    public static Site getSite(HttpServletRequest request) {

        String uri = null;
        try {
            uri = request.getRequestURI();
            return getSite(uri);
        } catch (IllegalArgumentException ex) {

            log.info("illegal site detected. Could not derive site from site " + uri + "; valid sites are "
                    + Arrays.asList(Site.values()));
            return null;
        }
    }

    static Site getSite(String uri) {
        if (uri.matches("/ws/[a-zA-Z0-9_\\-]+/[a-zA-Z0-9_]+.*")) {
            uri = uri.substring(4);
            uri = uri.substring(uri.indexOf("/") + 1);
            if (uri.indexOf("/") > 0) {
                uri = uri.substring(0, uri.indexOf("/"));
            }
            return Site.valueOf(uri);
        } else {
            return null;
        }
    }

    public static Site guessSite(String site) {
        Site result;
        try {
            result = Site.valueOf(site);
            return result;
        } catch (IllegalArgumentException ex) {
            class Elem {
                int dist;
                Site tp;

                @Override
                public String toString() {
                    return "[dist=" + dist + ", tp=" + tp + "]";
                }
            }

            List<Elem> l = new ArrayList<>();
            for (Site t : Site.values()) {
                log.info("check site " + t);
                int distance = LevenshteinDistance.getDefaultInstance().apply(t.name().toLowerCase(),
                        site.toLowerCase());
                Elem e = new Elem();
                e.dist = 100 * distance / t.name().length();
                e.tp = t;
                l.add(e);
            }
            l.sort(Comparator.comparingInt((Elem o) -> o.dist).thenComparing(o -> o.tp));
            log.info(site + "; l=" + l);

            if (l.get(0).dist <= 25) {
                return l.get(0).tp;
            }
            return null;
        }
    }

}
