package de.quaestio24.util;

import de.quaestio24.dto.ProjectDTO;

import java.io.Serializable;
import java.util.Comparator;

public class ProjectComparator implements Serializable, Comparator<ProjectDTO> {

    private static final long serialVersionUID = 1L;

    @Override
    public int compare(ProjectDTO o1, ProjectDTO o2) {
        return o1.id - o2.id;
    }

}
