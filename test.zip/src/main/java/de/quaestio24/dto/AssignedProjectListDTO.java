package de.quaestio24.dto;

import de.quaestio24.service.dto.AssignedProjectListIntDTO;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class AssignedProjectListDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    public List<Project2> assignedPersons;
    public List<UnassignedPersonDTO> unassignedPersons;

    public AssignedProjectListDTO() {
    }

    public AssignedProjectListDTO(AssignedProjectListIntDTO dto) {

        unassignedPersons = dto.unassignedPersons;

        assignedPersons = new ArrayList<>();
        for (Map.Entry<ProjectDTO, List<PersonDTO>> m : dto.assignedPersons.entrySet()) {
            assignedPersons.add(new Project2(m.getKey(), m.getValue()));
        }
    }

    public static class Project2 extends ProjectDTO {
        private static final long serialVersionUID = 1L;
        public List<PersonDTO> persons;

        public Project2(ProjectDTO p, List<PersonDTO> persons) {
            super.id = p.id;
            super.maxSize = p.maxSize;
            super.minSize = p.minSize;
            super.title = p.title;
            super.maxGenderRate = p.maxGenderRate;
            super.additional = p.additional;

            this.persons = persons;
        }
    }
}
