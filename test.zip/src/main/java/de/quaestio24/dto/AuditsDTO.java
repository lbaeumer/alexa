package de.quaestio24.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class AuditsDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    public List<AuditSet> auditSet = new ArrayList<>();

    public static class AuditSet {
        public String site, user, role;
        public Integer totalCount;
        public List<AuditDTO> audits = new ArrayList<>();
    }
}
