package de.quaestio24.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class SiteDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    public ConfigDTO config;
    public List<SiteDTO> subSites;

    public List<Integer> selectionCount;
    public Map<String, List<Integer>> subSelectionCount;

    public IssuesDTO issues;
    public List<IssueDTO> authIssues;

    public List<AuthRequestDTO> authRequests;
    public List<AuditDTO> audits;
    public LoginStatsDTO loginStats;
    public Integer remainingDays, remainingHours;
    public Map<Integer, List<Integer>> greedySync;

    @Override
    public String toString() {
        return config.site + "; remaining" + remainingDays;
    }
}
