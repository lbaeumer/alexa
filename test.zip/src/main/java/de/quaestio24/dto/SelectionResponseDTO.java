package de.quaestio24.dto;

import java.util.List;

public class SelectionResponseDTO extends SelectionDTO {

    private static final long serialVersionUID = 1L;

    public List<ProjectDTO> projects;
}
