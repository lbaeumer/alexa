package de.quaestio24.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import de.quaestio24.ws.SelectionValidationPayload;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class SelectionDTO implements Serializable, Comparable<SelectionDTO> {

    private static final long serialVersionUID = 1L;

    public String id;
    public boolean verified;

    public Boolean addAfterAssignment;
    public Boolean prio;

    public PersonDTO person;

    @NotNull(message = "Bitte mindestens 1 Projekt auswählen.")
    @Size(min = 1, max = 256, message = "Bitte mindestens 1 Projekt auswählen.", payload = SelectionValidationPayload.Error440.class)
    public List<Integer> selections;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.sss'Z'", timezone = "UTC")
    public Date created;

    public String idHost, idUserAgent;

    @Override
    public String toString() {
        return "SelectionDTO [person=" + person + ", selections=" + selections + "]";
    }

    @Override
    public int hashCode() {
        if (person == null) {
            return 0;
        }
        return person.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        SelectionDTO other = (SelectionDTO) obj;
        if (person == null) {
            return other.person == null;
        } else return person.equals(other.person);
    }

    @Override
    public int compareTo(SelectionDTO o) {
        long d = created.getTime() - o.created.getTime();
        if (d > 0) {
            return 1;
        }
        if (d < 0) {
            return -1;
        }

        return person.compareTo(o.person);
    }

}
