package de.quaestio24.dto;

public class RegisterUserDTO extends UserDTO {

    private static final long serialVersionUID = 1L;

    public String password2;
}
