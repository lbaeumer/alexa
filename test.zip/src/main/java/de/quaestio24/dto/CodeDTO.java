package de.quaestio24.dto;

import java.io.Serializable;

public class CodeDTO implements Serializable, Comparable<CodeDTO> {

    private static final long serialVersionUID = 1L;

    public String code, clazz;

    @Override
    public int compareTo(CodeDTO o) {
        return code.compareTo(o.code);
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((code == null) ? 0 : code.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        CodeDTO other = (CodeDTO) obj;
        if (code == null) {
            return other.code == null;
        } else return code.equals(other.code);
    }

    @Override
    public String toString() {
        return "CodeDTO [code=" + code + ", clazz=" + clazz + "]";
    }
}
