package de.quaestio24.dto;

import java.io.Serializable;

public class ProjectDetailsDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    public String description;
    public String longdesc;
    public String shortdesc;

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((description == null) ? 0 : description.hashCode());
        result = prime * result + ((shortdesc == null) ? 0 : shortdesc.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        ProjectDetailsDTO other = (ProjectDetailsDTO) obj;
        if (description == null) {
            if (other.description != null)
                return false;
        } else if (!description.equals(other.description))
            return false;
        if (shortdesc == null) {
            return other.shortdesc == null;
        } else return shortdesc.equals(other.shortdesc);
    }
}
