package de.quaestio24.dto;

import java.io.Serializable;

public class UserDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    public String name, password, provider;

    public String email, key;
    public String site;

    @Override
    public String toString() {
        return "UserDTO [name=" + name + ", site=" + site + ", email=" + email + ", provider=" + provider + "]";
    }
}
