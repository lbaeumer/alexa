package de.quaestio24.dto;

import java.io.Serializable;
import java.util.Date;

public class LoginStatDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    public Date lastSuccessLogin;
    public Date lastFailedLogin;

    public String name;
    public int loginCount;

    @Override
    public String toString() {
        return "LoginStatDTO [lastSuccessLogin=" + lastSuccessLogin + ", lastFailedLogin=" + lastFailedLogin + ", name="
                + name + ", loginCount=" + loginCount + "]";
    }
}
