package de.quaestio24.dto;

import java.io.Serializable;
import java.util.List;

public class ValidationDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    public SelectionDTO selection;
    public List<Integer> filteredProjects;

    @Override
    public String toString() {
        return "ValidationDTO [selection=" + selection + ", filteredProjects=" + filteredProjects + "]";
    }
}
