package de.quaestio24.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class DashboardDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    public List<SiteDTO> preElectionSites = new ArrayList<>();
    public List<SiteDTO> electionSites = new ArrayList<>();
    public List<SiteDTO> postElectionSites = new ArrayList<>();
    public List<SiteDTO> undefinedSites = new ArrayList<>();
    public List<SiteDTO> junitSites = new ArrayList<>();
}
