package de.quaestio24.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class ProjectPackageDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    public List<ProjectDTO> projects;
    public PreferencesDTO prefs;
    public List<CodeDTO> codes;
    public List<PersonDTO> persons;
    public List<SelectionDTO> selections;
    public Map<String, ProjectPackageDTO> subPackages;
}