package de.quaestio24.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class SettingsDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    public List<String> sites;
    public Map<String, List<String>> subSites;
}
