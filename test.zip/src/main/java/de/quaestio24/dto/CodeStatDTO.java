package de.quaestio24.dto;

import java.io.Serializable;
import java.util.List;

public class CodeStatDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    public int addedCodes, removedCodes;
    public List<CodeDTO> codes;
}
