package de.quaestio24.dto;

import de.quaestio24.constant.SiteStateEnum;

import java.io.Serializable;
import java.util.Date;

public class NotificationDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    public Date date;

    public String info;
    public String site;
    public String recipient;
    public SiteStateEnum state;

    @Override
    public String toString() {
        return "NotificationDTO{" + date +
                "; info='" + info + '\'' +
                ", site='" + site + '\'' +
                '}';
    }
}
