package de.quaestio24.dto;

import com.fasterxml.jackson.annotation.JsonFormat;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Date;

public class FeedbackDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    @NotNull(message = "Bitte den Namen angeben.")
    @Size(min = 1, message = "Bitte den Namen angeben.")
    public String name;

    @Pattern(regexp = "([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4})?", message = "Die Email Adresse ist ungültig.")
    public String email;

    public String phone;

    @NotNull(message = "Bitte einen Text eingeben.")
    @Size(min = 1, message = "Bitte einen Text eingeben.")
    public String text;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.sss'Z'", timezone = "UTC")
    public Date created;

    @Override
    public String toString() {
        return "FeedbackDTO [name=" + name + ", text=" + text + ", email=" + email + ", phone=" + phone + "]";
    }
}
