package de.quaestio24.dto;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class PreferencesDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.sss'Z'", timezone = "UTC")
    public Date eventDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.sss'Z'", timezone = "UTC")
    public Date startDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.sss'Z'", timezone = "UTC")
    public Date endDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.sss'Z'", timezone = "UTC")
    public Date startDate2;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.sss'Z'", timezone = "UTC")
    public Date endDate2;

    public String emailcc;
    public boolean auth, includeStatus;
    public boolean anonymous;
    public DesignParameter design;
    public Parameter parameter;
    public List<String> subSites;

    @Override
    public String toString() {
        return "[" + startDate + ", " + endDate + (startDate2 != null ? ", " + startDate2 + ";" + endDate2 : "")
                + (auth ? ", auth" : "") + (includeStatus ? ", includeStatus" : "")
                + ", parameter=" + parameter + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (auth ? 1231 : 1237);
        result = prime * result + ((design == null) ? 0 : design.hashCode());
        result = prime * result + ((emailcc == null) ? 0 : emailcc.hashCode());
        result = prime * result + ((endDate == null) ? 0 : endDate.hashCode());
        result = prime * result + ((endDate2 == null) ? 0 : endDate2.hashCode());
        result = prime * result + ((eventDate == null) ? 0 : eventDate.hashCode());
        result = prime * result + (includeStatus ? 1231 : 1237);
        result = prime * result + ((parameter == null) ? 0 : parameter.hashCode());
        result = prime * result + ((startDate == null) ? 0 : startDate.hashCode());
        result = prime * result + ((startDate2 == null) ? 0 : startDate2.hashCode());
        result = prime * result + ((subSites == null) ? 0 : subSites.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        PreferencesDTO other = (PreferencesDTO) obj;
        if (auth != other.auth)
            return false;
        if (design == null) {
            if (other.design != null)
                return false;
        } else if (!design.equals(other.design))
            return false;
        if (emailcc == null) {
            if (other.emailcc != null)
                return false;
        } else if (!emailcc.equals(other.emailcc))
            return false;
        if (endDate == null) {
            if (other.endDate != null)
                return false;
        } else if (!endDate.equals(other.endDate))
            return false;
        if (endDate2 == null) {
            if (other.endDate2 != null)
                return false;
        } else if (!endDate2.equals(other.endDate2))
            return false;
        if (eventDate == null) {
            if (other.eventDate != null)
                return false;
        } else if (!eventDate.equals(other.eventDate))
            return false;
        if (includeStatus != other.includeStatus)
            return false;
        if (parameter == null) {
            if (other.parameter != null)
                return false;
        } else if (!parameter.equals(other.parameter))
            return false;
        if (startDate == null) {
            if (other.startDate != null)
                return false;
        } else if (!startDate.equals(other.startDate))
            return false;
        if (startDate2 == null) {
            if (other.startDate2 != null)
                return false;
        } else if (!startDate2.equals(other.startDate2))
            return false;
        if (subSites == null) {
            return other.subSites == null;
        } else return subSites.equals(other.subSites);
    }

    public enum StrategyEnum {
        greedy, fcfs, multiple, best
    }

    public static class Parameter implements Serializable {
        private static final long serialVersionUID = 1L;
        public boolean skipMinimum;

        public StrategyEnum strategy;

        public boolean randomize;
        public boolean only2nd;
        public boolean ignoreEmptyProjects;

        public boolean addNonVoters;

        public DependencyDTO dependency;

        @Override
        public String toString() {
            return "Parameter [skipMinimum=" + skipMinimum + ", strategy=" + strategy + ", randomize=" + randomize
                    + ", only2nd=" + only2nd + ", ignoreEmptyProjects=" + ignoreEmptyProjects + ", dependency="
                    + dependency + "]";
        }

        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + (addNonVoters ? 1231 : 1237);
            result = prime * result + ((dependency == null) ? 0 : dependency.hashCode());
            result = prime * result + (ignoreEmptyProjects ? 1231 : 1237);
            result = prime * result + (only2nd ? 1231 : 1237);
            result = prime * result + (randomize ? 1231 : 1237);
            result = prime * result + (skipMinimum ? 1231 : 1237);
            return result;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj)
                return true;
            if (obj == null)
                return false;
            if (getClass() != obj.getClass())
                return false;
            Parameter other = (Parameter) obj;
            if (addNonVoters != other.addNonVoters)
                return false;
            if (dependency == null) {
                if (other.dependency != null)
                    return false;
            } else if (!dependency.equals(other.dependency))
                return false;
            if (strategy != other.strategy)
                return false;
            if (ignoreEmptyProjects != other.ignoreEmptyProjects)
                return false;
            if (only2nd != other.only2nd)
                return false;
            if (randomize != other.randomize)
                return false;
            return skipMinimum == other.skipMinimum;
        }
    }

    public static class DependencyDTO implements Serializable {
        private static final long serialVersionUID = 1L;

        public String predecessor;
        public List<Integer> predecessorProjects;

        @Override
        public String toString() {
            return "DependencyDTO [predecessor=" + predecessor + ", predecessorProjects=" + predecessorProjects + "]";
        }

        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((predecessor == null) ? 0 : predecessor.hashCode());
            result = prime * result + ((predecessorProjects == null) ? 0 : predecessorProjects.hashCode());
            return result;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj)
                return true;
            if (obj == null)
                return false;
            if (getClass() != obj.getClass())
                return false;
            DependencyDTO other = (DependencyDTO) obj;
            if (predecessor == null) {
                if (other.predecessor != null)
                    return false;
            } else if (!predecessor.equals(other.predecessor))
                return false;
            if (predecessorProjects == null) {
                return other.predecessorProjects == null;
            } else return predecessorProjects.equals(other.predecessorProjects);
        }
    }

    public static class DesignParameter implements Serializable {
        private static final long serialVersionUID = 1L;

        public int minSelections, minCodeLen, maxCodeLen;
        public String school, event, city, clazzes;
        public boolean displayTeacher, displayCost, displayRoom, displayShift;
        public int paginateCount;

        // info page
        public String txtInfoJumbotron, txtInfoInstructions, txtInfoFooter;

        // selection page
        public String txtSelectionHeader, txtSelectionNote;

        public String txtSelectionFormNameHeadline, txtSelectionFormNameText, txtSelectionFormCodeHeadline,
                txtSelectionFormCodeText;

        public String txtSelectionProjectsHeadline, txtSelectionProjectsText;

        public String txtSelectionPrioritizeHeadline, txtSelectionPrioritizeText;

        public boolean hidePriortize;
        public String lblClass, lblProject;

        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((city == null) ? 0 : city.hashCode());
            result = prime * result + ((clazzes == null) ? 0 : clazzes.hashCode());
            result = prime * result + (displayCost ? 1231 : 1237);
            result = prime * result + (displayRoom ? 1231 : 1237);
            result = prime * result + (displayShift ? 1231 : 1237);
            result = prime * result + (displayTeacher ? 1231 : 1237);
            result = prime * result + ((event == null) ? 0 : event.hashCode());
            result = prime * result + (hidePriortize ? 1231 : 1237);
            result = prime * result + ((lblClass == null) ? 0 : lblClass.hashCode());
            result = prime * result + ((lblProject == null) ? 0 : lblProject.hashCode());
            result = prime * result + maxCodeLen;
            result = prime * result + minCodeLen;
            result = prime * result + minSelections;
            result = prime * result + paginateCount;
            result = prime * result + ((school == null) ? 0 : school.hashCode());
            result = prime * result + ((txtInfoFooter == null) ? 0 : txtInfoFooter.hashCode());
            result = prime * result + ((txtInfoInstructions == null) ? 0 : txtInfoInstructions.hashCode());
            result = prime * result + ((txtInfoJumbotron == null) ? 0 : txtInfoJumbotron.hashCode());
            result = prime * result
                    + ((txtSelectionFormCodeHeadline == null) ? 0 : txtSelectionFormCodeHeadline.hashCode());
            result = prime * result + ((txtSelectionFormCodeText == null) ? 0 : txtSelectionFormCodeText.hashCode());
            result = prime * result
                    + ((txtSelectionFormNameHeadline == null) ? 0 : txtSelectionFormNameHeadline.hashCode());
            result = prime * result + ((txtSelectionFormNameText == null) ? 0 : txtSelectionFormNameText.hashCode());
            result = prime * result + ((txtSelectionHeader == null) ? 0 : txtSelectionHeader.hashCode());
            result = prime * result + ((txtSelectionNote == null) ? 0 : txtSelectionNote.hashCode());
            result = prime * result
                    + ((txtSelectionPrioritizeHeadline == null) ? 0 : txtSelectionPrioritizeHeadline.hashCode());
            result = prime * result
                    + ((txtSelectionPrioritizeText == null) ? 0 : txtSelectionPrioritizeText.hashCode());
            result = prime * result
                    + ((txtSelectionProjectsHeadline == null) ? 0 : txtSelectionProjectsHeadline.hashCode());
            result = prime * result + ((txtSelectionProjectsText == null) ? 0 : txtSelectionProjectsText.hashCode());
            return result;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj)
                return true;
            if (obj == null)
                return false;
            if (getClass() != obj.getClass())
                return false;
            DesignParameter other = (DesignParameter) obj;
            if (city == null) {
                if (other.city != null)
                    return false;
            } else if (!city.equals(other.city))
                return false;
            if (clazzes == null) {
                if (other.clazzes != null)
                    return false;
            } else if (!clazzes.equals(other.clazzes))
                return false;
            if (displayCost != other.displayCost)
                return false;
            if (displayRoom != other.displayRoom)
                return false;
            if (displayShift != other.displayShift)
                return false;
            if (displayTeacher != other.displayTeacher)
                return false;
            if (event == null) {
                if (other.event != null)
                    return false;
            } else if (!event.equals(other.event))
                return false;
            if (hidePriortize != other.hidePriortize)
                return false;
            if (lblClass == null) {
                if (other.lblClass != null)
                    return false;
            } else if (!lblClass.equals(other.lblClass))
                return false;
            if (lblProject == null) {
                if (other.lblProject != null)
                    return false;
            } else if (!lblProject.equals(other.lblProject))
                return false;
            if (maxCodeLen != other.maxCodeLen)
                return false;
            if (minCodeLen != other.minCodeLen)
                return false;
            if (minSelections != other.minSelections)
                return false;
            if (paginateCount != other.paginateCount)
                return false;
            if (school == null) {
                if (other.school != null)
                    return false;
            } else if (!school.equals(other.school))
                return false;
            if (txtInfoFooter == null) {
                if (other.txtInfoFooter != null)
                    return false;
            } else if (!txtInfoFooter.equals(other.txtInfoFooter))
                return false;
            if (txtInfoInstructions == null) {
                if (other.txtInfoInstructions != null)
                    return false;
            } else if (!txtInfoInstructions.equals(other.txtInfoInstructions))
                return false;
            if (txtInfoJumbotron == null) {
                if (other.txtInfoJumbotron != null)
                    return false;
            } else if (!txtInfoJumbotron.equals(other.txtInfoJumbotron))
                return false;
            if (txtSelectionFormCodeHeadline == null) {
                if (other.txtSelectionFormCodeHeadline != null)
                    return false;
            } else if (!txtSelectionFormCodeHeadline.equals(other.txtSelectionFormCodeHeadline))
                return false;
            if (txtSelectionFormCodeText == null) {
                if (other.txtSelectionFormCodeText != null)
                    return false;
            } else if (!txtSelectionFormCodeText.equals(other.txtSelectionFormCodeText))
                return false;
            if (txtSelectionFormNameHeadline == null) {
                if (other.txtSelectionFormNameHeadline != null)
                    return false;
            } else if (!txtSelectionFormNameHeadline.equals(other.txtSelectionFormNameHeadline))
                return false;
            if (txtSelectionFormNameText == null) {
                if (other.txtSelectionFormNameText != null)
                    return false;
            } else if (!txtSelectionFormNameText.equals(other.txtSelectionFormNameText))
                return false;
            if (txtSelectionHeader == null) {
                if (other.txtSelectionHeader != null)
                    return false;
            } else if (!txtSelectionHeader.equals(other.txtSelectionHeader))
                return false;
            if (txtSelectionNote == null) {
                if (other.txtSelectionNote != null)
                    return false;
            } else if (!txtSelectionNote.equals(other.txtSelectionNote))
                return false;
            if (txtSelectionPrioritizeHeadline == null) {
                if (other.txtSelectionPrioritizeHeadline != null)
                    return false;
            } else if (!txtSelectionPrioritizeHeadline.equals(other.txtSelectionPrioritizeHeadline))
                return false;
            if (txtSelectionPrioritizeText == null) {
                if (other.txtSelectionPrioritizeText != null)
                    return false;
            } else if (!txtSelectionPrioritizeText.equals(other.txtSelectionPrioritizeText))
                return false;
            if (txtSelectionProjectsHeadline == null) {
                if (other.txtSelectionProjectsHeadline != null)
                    return false;
            } else if (!txtSelectionProjectsHeadline.equals(other.txtSelectionProjectsHeadline))
                return false;
            if (txtSelectionProjectsText == null) {
                return other.txtSelectionProjectsText == null;
            } else return txtSelectionProjectsText.equals(other.txtSelectionProjectsText);
        }
    }
}
