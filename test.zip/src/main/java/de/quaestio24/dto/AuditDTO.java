package de.quaestio24.dto;

import java.io.Serializable;
import java.util.Date;

public class AuditDTO implements Serializable, Comparable<AuditDTO> {

    private static final long serialVersionUID = 1L;

    public Date date;
    public String category, action;
    public String user, role;

    public AuditDTO() {
    }

    public AuditDTO(String category, String action) {
        this.category = category;
        this.action = action;
    }

    @Override
    public int compareTo(AuditDTO o) {
        int res = (int) (date.getTime() - o.date.getTime());
        if (res != 0) {
            return res;
        }
        res = category.compareTo(o.category);
        if (res != 0) {
            return res;
        }
        return action.compareTo(o.action);
    }
}
