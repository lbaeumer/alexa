package de.quaestio24.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class ReportDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    public SubReport report1, report2, report3;

    public static class SubReport implements Serializable {

        private static final long serialVersionUID = 1L;

        public List<List<Object>> data;
        public Map<String, Object> options;
        public List<String> columnNames;
    }
}
