package de.quaestio24.dto;

import java.io.Serializable;
import java.text.Normalizer;

public class PersonDTO implements Serializable, Comparable<PersonDTO> {

    private static final long serialVersionUID = 1L;

    public String code;

    public String name;

    public String surname;

    public String email;

    public String clazz;

    public String gender;

    public String att1;

    public static String normalize(String in, boolean deleteSpaces) {
        if (in == null) {
            return null;
        }
        String ret = in.toLowerCase().trim();
        ret = ret.replaceAll("ä", "ae");
        ret = ret.replaceAll("ö", "oe");
        ret = ret.replaceAll("ü", "ue");
        ret = ret.replaceAll("ß", "ss");
        ret = ret.replaceAll("-", " ");
        ret = ret.replaceAll("ž", "z");
        ret = ret.replaceAll("[ćč]", "c");
        ret = ret.replaceAll("[áàâ]", "a");
        ret = ret.replaceAll("[éèê]", "e");
        ret = ret.replaceAll("[íìî]", "i");
        ret = ret.replaceAll("[óòô]", "o");
        ret = ret.replaceAll("[úùû]", "u");

        if (deleteSpaces) {
            ret = ret.replaceAll("\\s+", "");
        }
        ret = Normalizer.normalize(ret, Normalizer.Form.NFD);

        return ret;
    }

    public int getId() {
        return hashCode();
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        String c = normalize(clazz, true);
        result = prime * result + ((c == null) ? 0 : c.hashCode());

        if (code == null || code.length() == 0) {
            String n = normalize(name, true);
            String s = normalize(surname, true);
            result = prime * result + ((s == null) ? 0 : s.hashCode());
            result = prime * result + ((n == null) ? 0 : n.hashCode());
        } else {
            String cd = normalize(code, true);
            result = prime * result + cd.hashCode();
            return result;
        }
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof PersonDTO))
            return false;
        PersonDTO other = (PersonDTO) obj;
        String c1 = normalize(clazz, true);
        String c2 = normalize(other.clazz, true);

        if (c1 == null) {
            if (c2 != null)
                return false;
        } else if (!c1.equals(c2))
            return false;

        if (code == null || code.length() == 0 || other.code == null || other.code.length() == 0) {

            String n1 = normalize(name, true);
            String s1 = normalize(surname, true);
            String n2 = normalize(other.name, true);
            String s2 = normalize(other.surname, true);

            if (n1 == null) {
                if (n2 != null)
                    return false;
            } else if (!n1.equals(n2))
                return false;
            if (s1 == null) {
                if (s2 != null)
                    return false;
            } else if (!s1.equals(s2))
                return false;
            if (gender == null) {
                return other.gender == null;
            } else return gender.equals(other.gender);
        } else {
            return code.equals(other.code);
        }
    }

    @Override
    public String toString() {
        return "PersonDTO [" + (name != null ? "name=" + name + ", surname=" + surname : "")
                + (email != null ? ", email=" + email : "") + ", clazz=" + clazz
                + (code != null ? ", code=" + code : "") + "]";
    }

    @Override
    public int compareTo(PersonDTO o) {
        if (clazz != null && o.clazz == null) {
            return -1;
        }
        if (clazz == null && o.clazz != null) {
            return 1;
        }

        int i;
        if (name != null && o.name != null) {
            i = name.compareToIgnoreCase(o.name);
            if (i != 0) {
                return i;
            }
        }
        if (surname != null && o.surname != null) {
            i = surname.compareToIgnoreCase(o.surname);
            if (i != 0) {
                return i;
            }
        }
        if (clazz != null) {
            i = clazz.compareToIgnoreCase(o.clazz);
            if (i != 0) {
                return i;
            }
        }
        if (code != null && o.code != null) {
            i = code.compareToIgnoreCase(o.code);
            return i;
        }

        return 0;

    }
}
