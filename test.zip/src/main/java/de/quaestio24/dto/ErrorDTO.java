package de.quaestio24.dto;

import java.io.Serializable;
import java.util.List;

public class ErrorDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    public int code;
    public List<String> text;

    @Override
    public String toString() {
        return "ErrorDTO [code=" + code + ", text=" + text + "]";
    }
}
