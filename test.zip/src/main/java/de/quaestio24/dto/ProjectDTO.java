package de.quaestio24.dto;

import de.quaestio24.ws.SelectionValidationPayload;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Map;
import java.util.TreeMap;

public class ProjectDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    public int id;

    @Min(value = 0, message = "Bitte die max. Anzahl an Projektteilnehmern eingeben. Der Wert muss >= 0 sein.", payload = SelectionValidationPayload.Error440.class)
    @Max(value = 100, message = "Bitte die max. Anzahl an Projektteilnehmern eingeben. Der Wert muss <= 100 sein.", payload = SelectionValidationPayload.Error440.class)
    public int maxSize;

    public int minSize;

    @Max(value = 100, message = "Es können nicht mehr als 100% eingetragen werden.", payload = SelectionValidationPayload.Error440.class)
    public int maxGenderRate;

    @NotNull(message = "Bitte den Titel eingeben.", payload = SelectionValidationPayload.Error440.class)
    @Size(min = 1, max = 256, message = "Bitte den Titel eingeben.", payload = SelectionValidationPayload.Error440.class)
    public String title;

    public ProjectDetailsDTO details;
    public Integer status;

    public Map<ProjectAttribute, String> additional;

    public ProjectDTO() {
    }

    public ProjectDTO(int id) {
        this.id = id;
    }

    public ProjectDTO(int id, int maxSize, int minSize, String title, int maxGenderRate,
                      Map<ProjectAttribute, String> additional) {
        super();
        this.id = id;
        this.maxSize = maxSize;
        this.minSize = minSize;
        this.title = title;
        this.maxGenderRate = maxGenderRate;
        if (additional != null) {
            this.additional = new TreeMap<>(additional);
        }
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + id;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        ProjectDTO other = (ProjectDTO) obj;
        return id == other.id;
    }

    @Override
    public String toString() {
        return "ProjectDTO [id=" + id + ", maxSize=" + maxSize + ", title=" + title + "]";
    }

    public enum ProjectAttribute {
        clazz, costs, room, shift, teacher
    }
}
