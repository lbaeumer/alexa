package de.quaestio24.dto;

import java.util.List;

public class UnassignedPersonDTO extends PersonDTO {

    private static final long serialVersionUID = 1L;
    public List<Integer> selections;

    public UnassignedPersonDTO() {
    }

    public UnassignedPersonDTO(PersonDTO p) {
        super.att1 = p.att1;
        super.clazz = p.clazz;
        super.email = p.email;
        super.gender = p.gender;
        super.name = p.name;
        super.surname = p.surname;
        super.code = p.code;
    }

    @Override
    public String toString() {
        return "UnassignedPersonDTO [name=" + name + ", surname=" + surname + ", email=" + email + ", clazz=" + clazz
                + "]";
    }
}
