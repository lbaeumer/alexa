package de.quaestio24.dto;

import java.io.Serializable;
import java.util.List;

public class LoginStatsDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    public List<LoginStatDTO> userWithLastLoginFailed;
    public List<LoginStatDTO> userWithLastLoginSucceeded;

    public List<LoginStatDTO> logins;

}
