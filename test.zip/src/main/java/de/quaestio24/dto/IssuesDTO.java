package de.quaestio24.dto;

import de.quaestio24.dto.IssueDTO.Severity;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class IssuesDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    public Severity maxSeverity;
    public int count;

    public List<IssueDTO> issues;
    public Map<String, List<IssueDTO>> subIssues;
}
