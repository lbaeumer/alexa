package de.quaestio24.dto;

import java.io.Serializable;

public class IssueDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    public Severity severity;
    public String message;
    public String description;

    public IssueDTO() {
    }

    public IssueDTO(Severity severity, String message) {
        super();
        this.severity = severity;
        this.message = message;
    }

    @Override
    public String toString() {
        return "Issue [severity=" + severity + ", message=" + message + "]";
    }

    public enum Severity {
        info(1), warning(2), error(3);

        Severity(int severity) {
        }
    }
}
