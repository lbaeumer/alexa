package de.quaestio24.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import de.quaestio24.constant.RoleEnum;

import java.io.Serializable;
import java.util.Date;

public class AuthDTO extends AuthRequestDTO implements Serializable, Comparable<AuthDTO> {

    private static final long serialVersionUID = 1L;

    public RoleEnum role;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.sss'Z'", timezone = "UTC")
    public Date modified, created;

    public AuthDTO() {
    }

    public AuthDTO(String email, RoleEnum role) {
        this.email = email;
        this.role = role;
    }

    @Override
    public String toString() {
        return "AuthDTO [email=" + provider + "/" + email + ", role=" + role + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((email == null) ? 0 : email.hashCode());
        result = prime * result + ((provider == null) ? 0 : provider.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        AuthDTO other = (AuthDTO) obj;
        if (email == null) {
            if (other.email != null)
                return false;
        } else if (!email.equals(other.email))
            return false;
        if (provider == null) {
            return other.provider == null;
        } else return provider.equals(other.provider);
    }

    @Override
    public int compareTo(AuthDTO o) {
        int i = email.compareTo(o.email);
        if (i != 0) {
            return i;
        }
        i = provider.compareTo(o.provider);
        if (i != 0) {
            return i;
        }
        return o.role.ordinal() - role.ordinal();
    }
}
