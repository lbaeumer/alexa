package de.quaestio24.dto;

import java.io.Serializable;

public class AuthRequestDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    public String email;
    public String provider;

    @Override
    public String toString() {
        return "AuthRequestDTO [email=" + email + ", provider=" + provider + "]";
    }
}
