package de.quaestio24.dto;

import java.io.Serializable;
import java.util.List;

public class ProjectListDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    public List<ProjectDTO> projects;

    public SelectionDTO selection;

    @Override
    public String toString() {
        return "ProjectListDTO [projects=" + projects + (selection != null ? ", selection=" + selection : "") + "]";
    }
}
