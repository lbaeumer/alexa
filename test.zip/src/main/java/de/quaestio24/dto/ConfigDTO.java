package de.quaestio24.dto;

import de.quaestio24.constant.SiteStateEnum;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class ConfigDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    public SiteStateEnum state;

    public String site;

    public PreferencesDTO pref;
    public Map<String, ConfigDTO> subConfig = new HashMap<>();

    @Override
    public String toString() {
        return "ConfigDTO [pref=" + pref + ", state=" + state + "]";
    }
}
