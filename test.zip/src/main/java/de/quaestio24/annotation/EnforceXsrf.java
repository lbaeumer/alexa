package de.quaestio24.annotation;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface EnforceXsrf {
    boolean onlyReport() default false;
}
