package de.quaestio24.constant;

public enum RoleEnum {
    none, teacher, admin, superadmin
}
