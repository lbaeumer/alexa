package de.quaestio24.constant;

public enum SiteStateEnum {
    undefined, preElection, election, election2, postElection
}
